# BRR-OS for the M-Vave SMK-37 Pro

BRR-OS is a minimal firmware for the M-Vave SMK-37 Pro (Elite and MKE-P37 through `MODEL`). It has four
tracks, and each one runs a machine: TAPE, MULTI, GRAN or WAVE. All four play from a sample library compiled into
the firmware, and all four are driven by a tracker-style sequencer on the codec's own 0.125 ms sample clock. It
has no Bluetooth, USB audio or serial console. The space goes to the sound, the sequencer and the samples; presets
live in the 120 KiB data area, and the user sample area stays free. The ideas and decisions are in [docs/DESIGN.md](docs/DESIGN.md).

**One clock.** Since v0.3 everything runs on the codec's own 8 kHz sample (0.125 ms): every note, lock, retrig,
table row and LFO step lands on any sample, and every other unit is a power of two of it (2 ms block, 16 ms side
frame, 64 ms keyframe). At that resolution the grid becomes a timbre tool: audio-rate retrig, tables and LFOs, and
sub-millisecond offsets that comb-filter. The second core is supported as an accelerator; one core does everything.

**The air (v0.4).** Every track rebuilds its own 4-16 kHz from its own sound, with its own stereo width, and is a
stereo submix: voice spread, compressor, low cut. A master bus with glue, air and a look-ahead limiter sits at the
end. Against the original audio, the four-loop mix's high-band error went from 5.1 dB (v0.3) to 2.3 dB, level with
the offline recipe. Closed hi-hats went from 29 dB to 2.6 dB.

**Each track's effects (v0.5).** Every track has its own multi-effect and its own reverb. The multi-effect is one
structure whose settings decide what it is: phaser, flanger, chorus or a delay of up to 2 s, stereo or ping-pong.
Turning TIM morphs one into the next. Synced times and LFOs are whole clock samples, locked to the song position, so
nothing inside needs MIDI clock. The reverb freezes and gates on the clock. Both run at 8 kHz before the track's
rebuilt highs, so echoes and tails get their highs back; chorus and flanger measure within 0.4 dB of the same
effect run at 48 kHz on the original audio.

**One filter in two halves (v0.6).** Each track's filter is one analog prototype (LP / BP / HP, 20 Hz-20 kHz, Q to
17) realised twice. On the 8 kHz core it is a state-variable filter whose response is magnitude-matched to the
prototype all the way to 4 kHz; the plain bilinear map it replaces could not place a cutoff above 4 kHz (a resonant
LP at 6 kHz used to whistle at 3.4). On the rebuilt highs, the same filter runs at 32 kHz after they are
un-filtered, so above 4 kHz the slope and the resonance are the filter's own. Against the prototype applied to
the original audio, the high band's error across 14 filter settings went from 13.9 dB to 2.65 (2.35 with no filter
at all). The drive is anti-aliased; the delay's colour and the phaser now tell the rebuilt highs what they did.

**The modulators (v0.7).** One envelope and one LFO, written once and used five times: the AMP envelope and ENV1 in
every voice, ENV2 per track (also on the filter), LFO1 in every voice, LFO2 per track. Envelopes have a LONG range
(pads, ~12 s) and a SHORT one (hits, under 1 s). LFOs run from a 10-minute cycle to 2.56 kHz through a rate knob and
a multiplier, or sync to note values exact to the clock sample; eight shapes, five modes (free, retrigger, hold,
one-shot, half). Each has one target, any register, and a depth: no matrix. Which register a knob shows is one
table, so pages, and later your own mappings, never touch the engine.

**Kits as bits (v0.8).** A kit is four sounds, 8 patterns of up to 8 bars, 8 tables, 8 scenes and a song. Eight
voices are shared by the four tracks, with a voice limit per track. Each pattern keeps its own lengths, and the
song chains patterns to the clock sample. The eight scenes stack, each at its own amount: tap a pad to latch one at
the tap's velocity, hold it for momentary with pressure, or ride the mod wheel. A sound is stored as the registers
that differ from its machine's frozen template (a fresh one is 1 byte, a designed one 14-33). Patterns are stored
like tracker columns, each field predicted from the last. A typical kit is 1.4 KB, so the data area holds about 88.
Saves go to a power-cut-safe log in that area, and SHIFT + PLAY saves the kit.

**A shaper on every track (v0.9).** Nine models on their own page (L SHAP): tape, an asymmetric tube with sag, a
hard clip with a knee, a West Coast folder, Chebyshev harmonics, crossover distortion, a rectifier, a bit crusher
and a polynomial. Each has two parameters of its own, plus drive, bias, a tone before it and a wet mix. It sits
before the filter or after it, and in POST the rebuilt highs leave its new harmonics unfiltered. At 8 kHz a shaper
aliases badly, so it runs 2× oversampled with anti-derivative anti-aliasing and a decimator that keeps the
2-4 kHz band flat. Against an alias-free reference, aliases on high notes drop by 20-40 dB, and the output is
level-matched, so drive changes the character, not the loudness.

> **Status: v0.9, not yet run on a unit.** The firmware type-checks cleanly (with `-Wall`) against
> the real SMK-37 board layer for all three models, with and without the second core. The machines, sequencer, UI, high-band rebuild, master bus, effects and
> decoder run in a host simulation (`tests/`), with unit tests for the filter design (`flt_unit.c`), the
> effects (`fx_unit.c`), the modulators (`mod_unit.c`), the voices (`voice_unit.c`), patterns, the song and scenes
> (`seq_unit.c`, `scene_ui_unit.c`), the preset codec (`store_unit.c`), the flash store on a simulated NOR with
> power cuts (`vault_unit.c`) and the shaper (`shp_unit.c`). It has **not** been built with the JieLi toolchain or started on hardware. The first
> save on a unit writes the data area (0x9D000-0xBAFFF): if it holds another firmware's store, BRR-OS leaves it
> alone until you erase it. Read [docs/INSTALL.md](docs/INSTALL.md) before installing. The flash backup comes first.

## What's inside

| Part | What | Where |
|---|---|---|
| Sample format | **SVBRR v4**: 8 kHz predictive core with 0-4 bits per 2 ms block, static rANS (32-bit integer only), 64 ms seeded keyframes for random access, 16 ms side frames that rebuild 4-16 kHz (each sample places its 45 dB code window), onset maps | `firmware/src/svbrr_dec.c`, `tools/encoder/`, `tools/analyse_library.py` |
| Register file | 4 tracks x 88 bytes. Knobs, locks, tables, the modulators and scenes all write bytes, and one resolver runs per block; the knob pages are a table of register numbers (11 pages of 8) | `os_regs.c`, `os_ui.c` |
| Voices | 8 shared by the four tracks (a sounding mono track is one), a VOI limit per track; steals fade in 1 ms | `os_mach.c` |
| Modulators | one envelope (LONG / SHORT range) and one LFO (rate x multiplier or sync; 8 shapes, 5 modes) as AMP, ENV1, LFO1 per voice and ENV2, LFO2 per track; one target and depth each, per sample on pitch, cutoff, level, pan and frame | `os_mod.c` |
| Machines | TAPE (synced: an exact integer read of the clock; gate, onset slices), MULTI (6 voices by default, chromatic or kit, anti-aliased when pitched up), GRAN (8 grains tapping one decoded ring), WAVE (4 voices by default; a keyframe is a wavetable frame). Per-voice ADSR | `os_mach.c` |
| Filter | per track: one analog prototype in two halves. A magnitude-matched SVF on the core (designed every 0.5 ms, gliding; bilinear for audio-rate FM), the same filter at 32 kHz on the rebuilt highs after an un-filter; anti-aliased drive. The response contract every stage before the air follows | `os_flt.c`, `os_mach.c` |
| Sequencer | 8-byte events in one heap of 10,240 for the kit, 8 patterns x 4 tracks of 1-8 bars (each with its own lengths and speeds), a song of 64 rows, parameter locks, trigless locks, conditions, commands, tables, 8 stacking scenes | `os_seq.c` |
| Presets | SOUND = the registers that differ from the machine's frozen template; KIT = sounds, patterns as predicted columns, scenes, song; lossless, checked before written | `os_store.c` |
| Vault | the 120 KiB data area as a ring of CRC'd chunks: power-cut safe, wear spread, no erase while playing, streamed through 1 KB | `os_vault.c` |
| Feel | live notes stored as grid step + human residual; FEEL / WIN / VFL / GRV at playback; learned and audio-derived grooves; retro capture | `os_seq.c` |
| Render | one clock: every track renders at 8 kHz (WAVE at 32 kHz), event-driven to the sample, as a stereo submix (M/S voice spread, strip, low cut, compressor); the core bus up by Hermite at the exact DAC ratio (375 frames = 68 samples), the 32 kHz buses by a 375-phase resampler; tracks split across two cores when the second one answers | `os_engine.c` |
| The air | per track, on the clock: the 2-4 kHz band at complex baseband, copied up to six slots by one 32-entry carrier table (Schroeder-phased), noise that tiles flat, free stereo from the 90-degree twin; per-voice side info at each voice's rate. Then the master bus: M/S air and width, glue, 1 ms look-ahead limiter | `os_hf.c` |
| Shaper | per track, PRE or POST filter: 9 models (tape, tube, clip, fold, Chebyshev, crossover, rectifier, bits, polynomial), 2x oversampled with ADAA at 16 kHz, level-matched, the air told what is unfiltered | `os_shp.c` |
| Effects | per track, on the clock, before the air: a multi-effect (6-stage allpass chain into a modulated, synced delay line: phaser / flanger / chorus / delay, ST or PING, two 2 s lines in 8-bit block float with a 16-bit 64 ms head) and a 4-line FDN reverb (freeze, clock gate). No libm | `os_tfx.c`, `os_fx.c` |
| UI | STEP, ROLL, LANE, LIST, PERF and MACH views from two renderers; pads mirror the screen | `os_ui.c`, `os_font.c` |
| Platform | Felucca's SMK-37 hardware layer, update loader, USB MIDI device and update entry | `firmware/hal/`, `firmware/loader/`, `usb.c`, `ota*.c` |

**Sizes.** Our code is about 80 KB, measured cross-compiled; the sound engine with the preset store and the
shaper is about 64 KB of it. The default library is 345,498 B: 2 minutes of material in 17 samples, including a 32-frame
wavetable, plus 4.6 KB of onset maps. The SMK app slot is 619,520 B. RAM use is about 382 KB of the 392 KiB pool
(v0.5 moves the RAM / pool boundary to 40 / 392 KiB for the effect lines) and about 27 KB of plain RAM. On the host the full session renders
in about 30 µs per 2.9 ms half; every effect on in all four tracks costs about 1.3 times the rest of the engine,
the filter on in all four about 0.4 times.

## Controls

See [docs/CONTROLS.md](docs/CONTROLS.md). In short:

- **Views:** SEQ is STEP, CHORD is ROLL, PARA is LANE, FADER BANK is LIST, GLOBE is PERF, PATCH is MACH.
- **Knob pages:** KNOB BANK flips pages A-L: MACH, FILT, AMP, ENV1, ENV2, LFO1, LFO2, FX, VERB, AIR, FEEL, SHAP; BT is SHIFT. FX jumps to FX, then VERB, then the MASTER page, then back.
- **Hold + turn:** hold steps and turn a knob to make parameter locks.
- **Chords:** hold keys and tap a step to stamp the chord.
- **Recording:** REC records your timing as played. FEEL (page K) runs from inverted through the grid and as played to exaggerated. SHIFT+REC captures what you just played.
- **Scenes (PERF):** the top pads are 8 scenes: tap to latch at your velocity, hold for momentary (press harder for more), hold + turn to write; GLOBE again for mutes. The mod wheel sets the last scene's amount; the pitch wheel is WARP.
- **Saving:** SHIFT+PLAY saves the kit; it comes back at power-on.

## Build

```sh
tools/get_toolchain.sh                       # JieLi Linux toolchain -> ~/.jieli (Linux x86-64; Docker on a Mac)
git clone --depth 1 --branch AC79NN_SDK_V1.2.1_2023-12-13 https://gitee.com/Jieli-Tech/fw-AC79_AIoT_SDK.git ~/fw-AC79_AIoT_SDK
export JIELI_TOOLCHAIN=~/.jieli/toolchain AC79_SDK=~/fw-AC79_AIoT_SDK
python3 tools/build.py                       # SMK-37 Pro (and Starrykey 37 Play): build/brros-smk37.fwsc
python3 tools/build.py --model elite         # build/brros-smk37-elite.fwsc
python3 tools/build.py --model mke           # build/brros-smk37-mke.fwsc
python3 tools/build.py --cpu2                # with the second core (beta): build/brros-smk37-cpu2.fwsc
```

The build checks five things:

- the entry stub is in place;
- code that runs from RAM makes no calls;
- the second core's waiting loop calls only its job (a `--cpu2` build), or nothing of it is built (the default);
- the image fits the app slot and RAM headroom is kept;
- all register access stays inside `firmware/hal/`.

## Your own samples

```sh
pip install numpy scipy numba
python3 tools/encode_library.py library/spec.example.json     # or: --wav a.wav b.wav --bpm 120
python3 tools/build.py
```

See [docs/LIBRARY.md](docs/LIBRARY.md). At q 18 it averages about 160 KB per minute, so the 350 KB budget
holds about 2 minutes in as many samples as you like. Each sample costs about 30 bytes of bookkeeping, plus
5 bytes per onset.

## Host simulation

```sh
python3 tools/make_library_h.py
cd tests && gcc -O2 -std=gnu11 -DBOARD_SMK37=1 -I. -I../firmware/src -I../firmware/hal -I../build/gen -o host_sim host_sim.c -lm && ./host_sim
gcc -O2 -std=gnu11 -I. -I../firmware/src -I../build/gen -o host_demos host_demos.c -lm && ./host_demos
```

`host_demos.c` renders the audio-rate demos (retrig, table, FM, AM, comb) and the shaper (every model on a kit
loop, then a fold before and after a low-pass). Add `-DOS_HOST_DUAL` to run the
two-core split on the host: the output must match up to the order of float sums (1 LSB).

`tests/run_tests.sh` builds and runs every unit test and the session (with AddressSanitizer), and checks the two-core
split.

`host_sim.c` plays a scripted 34-second session through the real code, using the real gestures (pads, hold + turn,
held keys, views). It programs a kit, chords and a cloud, live-records a melody with human timing, then plays
it at FEEL 100, 0, 150 and -100 %, with your groove, with the loop's groove, and through two scenes on the wheel.
At the end it saves the kit with SHIFT + PLAY into a simulated flash and loads it back as a boot would. It writes
`sim.wav`, the screens (`screen_*.rgb565`) and `timing.txt` (every note's offset from the grid in each section).

## Licence

GPL-3.0-only (`LICENSE`), because BRR-OS is built on Felucca's GPL-3.0 SMK-37 layer. See
[LICENSING.md](LICENSING.md) for every part and its authors. Unofficial: not affiliated with or endorsed by
M-Vave, JieLi, Felucca or the SMK-37 port kit.
