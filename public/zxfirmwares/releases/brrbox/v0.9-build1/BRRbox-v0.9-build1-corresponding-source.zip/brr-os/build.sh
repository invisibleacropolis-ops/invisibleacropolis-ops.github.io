#!/bin/sh
# BRR-OS build: see README.md (MODEL=pro|elite|mke)
exec python3 "$(dirname "$0")/tools/build.py" ${MODEL:+--model "$MODEL"} "$@"
