/* SPDX-License-Identifier: GPL-3.0-only */
/* The filter maths (v0.6), in one place: the strip's filter, the air's copy of it, and the response contract.
 *
 * ONE FILTER, TWO HALVES. A track's filter is one analog prototype (LP, BP or HP, cutoff 20 Hz - 20 kHz, Q 0.5 -
 * 17). It is realised twice:
 *   - on the core (8 kHz; WAVE at 32 kHz), by the strip (os_mach.c): a TPT state-variable filter whose poles and
 *     output mix are MAGNITUDE-MATCHED to the prototype all the way to the core's Nyquist, cutoffs above it
 *     included (the plain bilinear map squeezes every response to zero at 4 kHz and cannot place a cutoff above
 *     it: a resonant LP at 6 kHz used to whistle at 3.4 kHz);
 *   - on the air (32 kHz), by os_hf.c: the rebuilt highs are first un-filtered (divided by what the core filter
 *     did to the 2-4 kHz band they are copied from), then run through the same prototype at 32 kHz. So above
 *     4 kHz the filter's own slope, resonance and self-oscillation are real, not a generic lift.
 *
 * THE MATCHED DESIGN (after M. Vicanek, "Matched Second Order Digital Filters", 2016): poles by impulse
 * invariance at fp = min(fc, 0.42 fs); above that the Q eases as Q / r^2 (r = fc / fp, not below 0.5), so a
 * cutoff above Nyquist shows its skirt, not a false peak. The numerator is matched to the prototype's magnitude
 * in-band (LP: at DC, the pole frequency and Nyquist; BP keeps its zero at DC and matches at half the pole
 * frequency and Nyquist; HP keeps its double zero at DC and matches its gain at the pole frequency, easing to 0.6
 * of it above the split), so the design is continuous as a cutoff sweeps through. Measured against the analog
 * prototype over 50 Hz - 3.9 kHz: LP within 1.4 dB (amplitude-weighted mean) everywhere except a resonant LP right
 * at 4 kHz (Q 16: 6 dB); BP and HP within ~2 dB in third octaves, their skirts above 4 kHz within ~4. The bilinear
 * map it replaces was off by tens of dB near 4 kHz and could not place a cutoff above it.
 *
 * THE SVF FORM. Any biquad b / a is a TPT SVF (g, k) plus a mix of its LP, BP and HP outputs:
 *   c = 4 / (1 - a1 + a2), g = sqrt(c (1 + a1 + a2) / 4), k = 2 (1 - a2) / ((1 - a1 + a2) g), s = c b,
 *   mL = (s0 + s1 + s2) / 4g^2, mB = (s0 - s2) / 2g, mH = (s0 + s2 - s1) / 4,  y = mL lp + mB bp + mH hp.
 * The SVF keeps what makes it the right filter to modulate: coefficients can move every sample, smoothly.
 * The design runs every FLT_CR clock samples (0.5 ms) and the seven coefficients glide linearly between; an
 * LFO on CUT at audio rate (the "fast" path) uses the plain bilinear map every sample instead.
 *
 * THE RESPONSE CONTRACT (for anything added later). The air is rebuilt from the end of the chain. Every linear
 * stage between a voice and the air's tap must tell the air what it did, or the highs will not follow it:
 *   - a stage with resonance or a sharp shape is realised on the air too (as this filter is);
 *   - a smooth stage only declares its magnitude: per slot, the air's targets are scaled by
 *     |H(slot)|^2 / |H(2-4 kHz)|^2 (flt_slot_gain). The low cut, the effects' COL, phaser and reverb damping
 *     do this (os_hf.c, os_tfx.c). */

/* ------------------------------------------------------------------ small maths (no libm) -- */
static float hf_sin(float x)                       /* any x; |error| < 2e-7 */
{
    float k = x * 0.15915494f, y, y2;
    int32_t n = (int32_t)(k + (k < 0.0f ? -0.5f : 0.5f));
    x -= (float)n * 6.28318531f;                    /* -pi .. pi */
    if (x > 1.57079633f) x = 3.14159265f - x;
    else if (x < -1.57079633f) x = -3.14159265f - x;
    y = x; y2 = x * x;
    return y * (1.0f + y2 * (-1.6666667e-1f + y2 * (8.3333331e-3f + y2 * (-1.9841270e-4f + y2 * 2.7557319e-6f))));
}
static inline float hf_cos(float x) { return hf_sin(x + 1.57079633f); }

static float hf_log2(float x)                      /* x > 0; |error| < 1e-4 */
{
    union { float f; uint32_t i; } u;
    float m, e;
    u.f = x;
    e = (float)((int32_t)((u.i >> 23) & 255u) - 127);
    u.i = (u.i & 0x007FFFFFu) | 0x3F800000u;
    m = u.f;                                        /* 1 .. 2 */
    return e + (m - 1.0f) * (1.4426950f + (m - 1.0f) * (-0.7213475f + (m - 1.0f) * (0.4808983f + (m - 1.0f) * (-0.3606738f + (m - 1.0f) * 0.1082022f))));
}
static inline float hf_exp2(float x) { return fx_fexp(x * 0.69314718f); }
static inline float hf_db(float db) { return fx_fexp(db * 0.11512925f); }      /* amplitude */

#define FLT_SPLIT 0.42f                      /* the poles stay below 0.42 fs */
#ifndef FLT_CR
#define FLT_CR 4u                            /* the design's period, clock samples (0.5 ms) */
#endif

/* (flt_c, flt_s and FLT_LP / BP / HP: os_core.h) */

/* |H(f)|^2 of the analog prototype */
static float flt_ana(uint32_t typ, float fc, float q, float f)
{
    float x = f / fc, u = 1.0f - x * x, v = x / q, d = u * u + v * v;
    switch (typ) {
    case FLT_LP: return 1.0f / d;
    case FLT_BP: return v * v / d;
    case FLT_HP: return x * x * x * x / d;
    default: return 1.0f;
    }
}

/* the band the air copies from, measured before and after the filter (os_mach.c) to correct the un-filter. It has
 * the copy band's own shape: the air's 6th-order Butterworth high-pass at 2 kHz (HF_HP6), then its baseband
 * low-pass mirrored about 3 kHz, a 4th-order elliptic high-pass at 2 kHz (0.3 dB / 50 dB): -3 dB at 2 kHz, -14 at
 * 1.8, -41 at 1.5. (Measured through a gentler band, a resonance just under 2 kHz leaks in; through a sharper or
 * higher one, a steep low-pass's slope is under-read: either way the highs come out off by 2-3 dB) */
static const float FLT_MHP[5][5] = {
    {0.0295882236f, -0.0591764473f, 0.0295882236f, 0.0f, 0.0173323801f},
    {1.0f, -2.0f, 1.0f, 0.0f, 0.1715728753f},
    {1.0f, -2.0f, 1.0f, 0.0f, 0.5887907065f},
    {0.103113450f, -0.192851023f, 0.103113450f, 0.415608099f, 0.186575712f},
    {1.000000000f, -1.389430479f, 1.000000000f, -0.102104939f, 0.714030780f},
};
#define FLT_NMHP 5u

/* the 2-4 kHz band the air copies from, as four points (its mean |H|^2 is what the core filter did to it) */
static const float FLT_REF[4] = {2250.0f, 2750.0f, 3250.0f, 3750.0f};
static float flt_ref_gain(uint32_t typ, float fc, float q)
{
    return 0.25f * (flt_ana(typ, fc, q, FLT_REF[0]) + flt_ana(typ, fc, q, FLT_REF[1]) +
                    flt_ana(typ, fc, q, FLT_REF[2]) + flt_ana(typ, fc, q, FLT_REF[3]));
}

/* a smooth stage's share of an air slot (centre fs_hz, 2 kHz wide): its mean |H|^2 over the slot (three points)
 * over its mean over the reference band */
static float flt_slot_gain(uint32_t typ, float fc, float q, float slot_hz)
{
    float s = (flt_ana(typ, fc, q, slot_hz - 667.0f) + flt_ana(typ, fc, q, slot_hz) + flt_ana(typ, fc, q, slot_hz + 667.0f)) * (1.0f / 3.0f);
    return s / (flt_ref_gain(typ, fc, q) + 1e-12f);
}

static void flt_from_biquad(float b0, float b1, float b2, float a1, float a2, flt_c *o)
{
    float dn = 1.0f - a1 + a2, c = 4.0f / dn, g = os_sqrt(c * (1.0f + a1 + a2) * 0.25f), s0, s1, s2, aa;
    if (g < 1e-6f) g = 1e-6f;
    o->k = 2.0f * (1.0f - a2) / (dn * g);
    s0 = c * b0; s1 = c * b1; s2 = c * b2;
    o->ml = (s0 + s1 + s2) / (4.0f * g * g);
    o->mb = (s0 - s2) / (2.0f * g);
    o->mh = (s0 + s2 - s1) * 0.25f;
    aa = 1.0f / (1.0f + g * (g + o->k));
    o->a1 = aa; o->a2 = g * aa; o->a3 = g * g * aa;
}

/* sin^2(w / 2) and the three basis terms of |polynomial|^2 at w */
static inline void flt_phi(float w, float *p0, float *p1, float *p2)
{
    float s = hf_sin(0.5f * w);
    *p1 = s * s; *p0 = 1.0f - *p1; *p2 = 4.0f * *p0 * *p1;
}

/* the magnitude-matched design of the prototype at sample rate fs */
static void flt_design(uint32_t typ, float fc, float q, float fs, flt_c *o)
{
    float fp = fc < FLT_SPLIT * fs ? fc : FLT_SPLIT * fs, r = fc / fp, w0 = 6.2831853f * fp / fs;
    float qp = r <= 1.0f ? q : q / (r * r), z, e, a1, a2, A0, A1, A2, b0, b1, b2, p0, p1, p2, hz = fs * (1.0f / 6.2831853f);
    if (qp < 0.5f) qp = 0.5f;
    z = 0.5f / qp;
    e = fx_fexp(-z * w0);
    a1 = -2.0f * e * hf_cos(os_sqrt(1.0f - z * z > 0.0f ? 1.0f - z * z : 0.0f) * w0);
    a2 = e * e;
    A0 = (1.0f + a1 + a2) * (1.0f + a1 + a2); A1 = (1.0f - a1 + a2) * (1.0f - a1 + a2); A2 = -4.0f * a2;
    if (typ == FLT_HP) {
        /* (1 - z^-1)^2 kept, its gain matched at wm: the pole frequency, easing to 0.6 of it once the cutoff is
         * an octave above the split (the in-band skirt is then what matters) */
        float wm = w0 * (1.0f - 0.4f * os_clampf(r - 1.0f, 0.0f, 1.0f));
        flt_phi(wm, &p0, &p1, &p2);
        b0 = os_sqrt(flt_ana(FLT_HP, fc, q, wm * hz) * (A0 * p0 + A1 * p1 + A2 * p2) / (16.0f * p1 * p1));
        b1 = -2.0f * b0; b2 = b0;
    } else if (typ == FLT_BP) {
        /* its zero at DC kept: N = (1 - z^-1)(c0 + c1 z^-1); |N|^2 = 4 p1 (C0 p0 + C1 p1), matched at Nyquist
         * and at half the pole frequency */
        float C0, C1, wm = 0.5f * w0, c0, c1;
        C1 = flt_ana(FLT_BP, fc, q, 0.5f * fs) * A1 * 0.25f;
        flt_phi(wm, &p0, &p1, &p2);
        C0 = (flt_ana(FLT_BP, fc, q, wm * hz) * (A0 * p0 + A1 * p1 + A2 * p2) / (4.0f * p1) - C1 * p1) / p0;
        C0 = os_sqrt(C0 > 0.0f ? C0 : 0.0f);
        C1 = os_sqrt(C1 > 0.0f ? C1 : 0.0f);
        c0 = 0.5f * (C0 + C1); c1 = 0.5f * (C0 - C1);
        b0 = c0; b1 = c1 - c0; b2 = -c1;
    } else {
        /* LP: |N|^2 = B0 p0 + B1 p1 + B2 p2, matched at DC (B0 = A0), Nyquist (B1) and the pole frequency */
        float B0 = A0, B1, B2, W;
        B1 = flt_ana(FLT_LP, fc, q, 0.5f * fs) * A1;
        flt_phi(w0, &p0, &p1, &p2);
        B2 = (flt_ana(FLT_LP, fc, q, w0 * hz) * (A0 * p0 + A1 * p1 + A2 * p2) - B0 * p0 - B1 * p1) / p2;
        B0 = os_sqrt(B0); B1 = os_sqrt(B1 > 0.0f ? B1 : 0.0f);
        W = 0.5f * (B0 + B1);
        b0 = 0.5f * (W + os_sqrt(W * W + B2 > 0.0f ? W * W + B2 : 0.0f));
        b1 = 0.5f * (B0 - B1);
        b2 = b0 > 1e-12f ? -B2 / (4.0f * b0) : 0.0f;
    }
    flt_from_biquad(b0, b1, b2, a1, a2, o);
}

/* the plain bilinear map, every sample (an LFO on CUT at audio rate) */
static void flt_bilinear(uint32_t typ, float fc, float q, float fs, flt_c *o)
{
    float w = 3.14159265f * fc / fs, g, aa;
    if (w > 1.35f) w = 1.35f;
    g = w * (15.0f - w * w) / (15.0f - 6.0f * w * w);             /* tan, Pade */
    o->k = 1.0f / q;
    aa = 1.0f / (1.0f + g * (g + o->k));
    o->a1 = aa; o->a2 = g * aa; o->a3 = g * g * aa;
    o->ml = typ == FLT_LP ? 1.0f : 0.0f;
    o->mb = typ == FLT_BP ? o->k : 0.0f;
    o->mh = typ == FLT_HP ? 1.0f : 0.0f;
}

static inline float flt_tick(flt_s *s, const flt_c *c, float x)
{
    float v3 = x - s->s2, v1 = c->a1 * s->s1 + c->a2 * v3, v2 = s->s2 + c->a2 * s->s1 + c->a3 * v3;
    s->s1 = 2.0f * v1 - s->s1;
    s->s2 = 2.0f * v2 - s->s2;
    return c->ml * v2 + c->mb * v1 + c->mh * (x - c->k * v1 - v2);
}

static inline void flt_step(flt_c *c, const flt_c *d)            /* the glide toward the next design */
{
    c->a1 += d->a1; c->a2 += d->a2; c->a3 += d->a3; c->k += d->k; c->ml += d->ml; c->mb += d->mb; c->mh += d->mh;
}

static inline void flt_delta(const flt_c *from, const flt_c *to, float inv, flt_c *d)
{
    d->a1 = (to->a1 - from->a1) * inv; d->a2 = (to->a2 - from->a2) * inv; d->a3 = (to->a3 - from->a3) * inv;
    d->k = (to->k - from->k) * inv; d->ml = (to->ml - from->ml) * inv; d->mb = (to->mb - from->mb) * inv;
    d->mh = (to->mh - from->mh) * inv;
}
