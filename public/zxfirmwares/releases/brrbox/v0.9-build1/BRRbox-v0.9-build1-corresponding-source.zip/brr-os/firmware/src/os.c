/* SPDX-License-Identifier: GPL-3.0-only */
/* BRR-OS for the M-Vave SMK-37 Pro (Elite, MKE-P37 by MODEL): one translation unit.
 *
 * Built on the SMK-37 hardware layer from Felucca's smk37 branch (hal/, loader/, crt0.S, app.ld;
 * GPL-3.0, Leo Kuroshita / Hügelton Instruments, SMK-37 layer by genkigenki) and these Felucca
 * files, used unchanged except where marked: libc.c, lcd.c, usb.c (app USB strings overridable),
 * storage_hw.c, ota.c, ota_hw.c. Everything else (os_*.c, svbrr_dec.c) is BRR-OS.
 *
 * No Bluetooth, no USB audio, no serial console, no settings store: a minimal OS around the
 * SVBRR sample engine. Register access stays in hal/ (tools/build.py checks it). */
#ifndef BOARD_SMK37
#error "BRR-OS targets the SMK-37 family: build with tools/build.py (BOARD_SMK37=1)"
#endif
#define FELUCCA_FLASH 1          /* flash driver: needed by the update entry */
#define FELUCCA_OTA 1            /* M-UPGRADE update entry (the usual installers work) */
#define FELUCCA_OTA_DRYRUN 0
#define FELUCCA_CDC 0            /* no serial console */
#define FELUCCA_UAC 0            /* no USB audio */
#define FELUCCA_UART 0           /* SMK: PH8 is a key-matrix row; no TRS MIDI IN */
#ifndef OS_CPU2
#define OS_CPU2 0                /* the second core: tools/build.py --cpu2 (beta). 0: nothing of it is built */
#endif
#define FELUCCA_CPU2 OS_CPU2
#define FM1_CPU1_USED OS_CPU2    /* hal/fm1_sys.h: every reset holds core 1 first; its faults handled (fm1_irq.h) */
#ifndef FELUCCA_ID
#define FELUCCA_ID "SMK-37 Pro_900"   /* package identity (build.py passes the real one) */
#endif

/* ------------------------------------------------------------- HAL --- */
#include <stdint.h>
#include "fm1_time.h"
#include "fm1_sys.h"
#include "fm1_irq.h"
#include "fm1_guard.h"
#include "smk_input.h"           /* SMK-37: keys, buttons, encoders, LEDs, pads, faders, wheels */
#include "smk_compat.h"
#include "fm1_timer.h"
#include "fm1_audio.h"
#include "fm1_lcd_hw.h"
#if OS_CPU2
#include "fm1_cpu1.h"            /* the worker: one job at a time for core 0, inside the audio interrupt */
#endif
#include "os_core.h"

/* ---------------------------------------------------- base, display --- */
#include "libc.c"
#include "lcd.c"
#include "os_font.c"

/* ----------------------------------------------------------- sound --- */
#define SV_API static
#include "svbrr_dec.c"
#include "os_fx.c"
#include "os_regs.c"            /* the register file, machine definitions, resolver */
#include "os_flt.c"             /* the filter maths: matched SVF design, the air's copy, the response contract */
#include "os_hf.c"              /* each track's rebuilt highs, the 32 kHz resampler, the master bus */
#include "os_tfx.c"             /* each track's multi-effect and reverb */
#include "os_mod.c"             /* the modulators: one envelope, one LFO, the routes */
#include "os_mach.c"            /* voices, the four machines, the strip */
#include "os_shp.c"             /* each track's waveshaper / wavefolder */
#include "os_seq.c"             /* events, clock, scheduler, feel, recording */
#include "os_store.c"           /* presets as bits: SOUND, KIT */
#include "os_engine.c"          /* the render loop and the mix */
#include "os_audio.c"          /* (before storage_hw.c: its audio_silence clears abuf) */

/* -------------------------------------------------- USB and update --- */
#define OS_USB_STRINGS
static const uint8_t STR1[] = {14, 3, 'B', 0, 'R', 0, 'R', 0, '-', 0, 'O', 0, 'S', 0};
static const uint8_t STR2[] = {26, 3, 'B', 0, 'R', 0, 'R', 0, '-', 0, 'O', 0, 'S', 0, ' ', 0,
                               'S', 0, 'M', 0, 'K', 0, '3', 0, '7', 0};
#include "usb.c"
#include "fm1_flash.h"
#include "storage_hw.c"
#include "os_vault.c"            /* presets in the data area: the ring of chunks */
#include "ota.c"
#include "ota_hw.c"

/* ------------------------------------------------------- UI, main --- */
#include "os_ui.c"
#include "os_main.c"
