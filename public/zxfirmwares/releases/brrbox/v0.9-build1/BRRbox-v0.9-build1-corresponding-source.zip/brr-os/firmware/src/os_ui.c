/* SPDX-License-Identifier: GPL-3.0-only */
/* The GUI: two renderers and one gesture.
 *   cell grid  STEP (XOX), ROLL (piano roll), LANE (one register over the steps), PERF, MACH; the pad LEDs
 *              are the same cell functions at 2 x 8, so the pads are always a low-resolution copy of the screen
 *   row list   LIST: the event list itself (tracker rows), tables too
 *   strip      the 8 knobs of the current page, always on screen
 * Whatever you hold is what the knobs edit: nothing -> the base registers; step pads -> locks on those steps;
 * a scene pad -> the scene (PERF); SHIFT -> picks the lane register. Keys held, then a pad tapped: that chord is
 * stamped on the step. Everything is drawn only when its signature changes. */
#define ENGINE_LOCKED(stmt) do { uint32_t _k = fm1__lock(); stmt; fm1__unlock(_k); } while (0)

enum { V_STEP, V_ROLL, V_LANE, V_LIST, V_PERF, V_MACH, V_N };
enum { B_KBANK = 0, B_FBANK = 1, B_LEFT = 2, B_RIGHT = 3, B_OCTD = 4, B_OCTU = 5, B_ARP = 6, B_NREP = 7,
       B_SCALE = 8, B_CHORD = 9, B_GLOBE = 10, B_BT = 11, B_PATCH = 12, B_PARA = 13, B_FX = 14, B_SEQ = 15,
       B_PLAY = 16, B_REC = 17 };
static const uint8_t VIEW_BTN[V_N] = {B_SEQ, B_CHORD, B_PARA, B_FBANK, B_GLOBE, B_PATCH};
static const char VIEW_NAME[V_N][5] = {"STEP", "ROLL", "LANE", "LIST", "PERF", "MACH"};
/* THE KNOB PAGES: which register each of the 8 knobs edits, page by page (0xFF: none). The engine never sees
 * this table; rearranging the pages, or a user's own mapping later, is editing it. The scripted session and
 * anything else that drives the UI find a register's page and knob here (ui_find) */
#define P_NONE 0xFFu
#define NPAGE 12u
enum { P_MACH, P_FILT, P_AMP, P_ENV1, P_ENV2, P_LFO1, P_LFO2, P_FX, P_VERB, P_AIR, P_FEEL, P_SHAP };
static const uint8_t PAGES[NPAGE][8] = {
    {0, 1, 2, 3, 4, 5, 6, 7},                                                     /* the machine's own */
    {R_CUT, R_RES, R_TYP, R_FEN, R_DRV, R_LOC, R_CMP, P_NONE},
    {R_ATK, R_DEC, R_SUS, R_REL, R_ARN, R_VOI, R_LEV, R_PAN},
    {R_AT1, R_DE1, R_SU1, R_RE1, R_RG1, R_ET1, R_ED1, P_NONE},
    {R_AT2, R_DE2, R_SU2, R_RE2, R_RG2, R_ET2, R_ED2, R_FLT},
    {R_RT1, R_MU1, R_SH1, R_MD1, R_PH1, R_LT1, R_LD1, P_NONE},
    {R_RT2, R_MU2, R_SH2, R_MD2, R_PH2, R_LT2, R_LD2, P_NONE},
    {R_TIM, R_FBK, R_DEP, R_RAT, R_DIS, R_COL, R_PNG, R_MIX},
    {R_SIZ, R_DCY, R_DMP, R_PRE, R_RMD, R_DIF, R_GAT, R_REV},
    {R_WID, R_AIR, R_TLT, R_TON, R_SPR, P_NONE, P_NONE, P_NONE},
    {R_FEL, R_WIN, R_VFL, R_GRV, R_TBL, R_TSP, R_STP, R_SPD},
    {R_SMD, R_SIN, R_SA, R_SB, R_SBI, R_STN, R_SPS, R_SMX},
};
static const char PAGE_NAME[NPAGE][6] = {"MACH", "FILT", "AMP", "ENV1", "ENV2", "LFO1", "LFO2", "FX", "VERB", "AIR", "FEEL", "SHAP"};

/* where register r sits: page * 8 + knob, or -1 */
static int32_t ui_find(uint32_t r)
{
    uint32_t pg, i;
    for (pg = 0; pg < NPAGE; pg++)
        for (i = 0; i < 8u; i++)
            if (PAGES[pg][i] == r) return (int32_t)(pg * 8u + i);
    return -1;
}
static const uint32_t TRK_RGB[NTRACK] = {0xFF5A3Cu, 0xF2A93Bu, 0x3CD2E6u, 0xA47CFFu};

#define BODY_Y 26u
#define STRIP_Y 190u

/* key edges with the transport position you heard: TIMER5 pushes them (os_main.c), the host script too */
static struct { uint8_t key, vel, on; uint32_t core; } kq[32];
static volatile uint32_t kq_w, kq_r;

static struct {
    uint8_t view, page, fx_page, spage, oct_shift, fx_ret;
    int8_t oct;
    uint8_t lane_reg, roll_pitch;          /* ROLL: lowest row's note */
    uint8_t list_src;                      /* 0 = the pattern, 1..8 = table */
    int16_t list_cur, list_top;
    uint8_t mach_bank;
    /* pads */
    uint8_t pad_was[SMK_NPAD], pad_used[SMK_NPAD], held_n, scene_held;
    /* PERF: page 0 scenes + patterns, page 1 mutes, FILL, CAP + patterns. A scene pad: in while held (its
     * hit's velocity, pressed harder toward 127), a tap latches it in (at the hit's velocity) or out; the
     * wheel sets the amount of the last scene touched */
    uint8_t perf_pg, scn_last, scn_latch, scn_was, scn_lat_amt[NSCN], wheel_last;
    /* the vault: the kit's slot; a format waiting for its second press (fm1_ms of the first) */
    uint8_t kit_slot;
    uint32_t fmt_t;
    uint32_t pad_t[SMK_NPAD];
    uint64_t keys_down;                    /* bit k: key k is down (for chord stamping): 37 keys */
    uint8_t key_vel[FM1_NKEY];
    uint8_t keyset_step[SMK_NPAD];         /* a held step already took keys: further keys add */
    /* faders, wheels */
    uint8_t fad_last[4];
    int32_t pc, plo, phi, mlo, mhi, rest;
    /* draw caches */
    uint32_t sig[512];                     /* 0..399 cells, 400..463 text slots, 464.. the strip's bars */
    uint8_t force;
    uint8_t last_view, last_sel;
    char msg[41];
    uint32_t msg_until;
} ui;

/* ------------------------------------------------------------- helpers -- */
static uint16_t c565(uint32_t rgb) { return os_rgb(rgb >> 16 & 255u, rgb >> 8 & 255u, rgb & 255u); }

static uint32_t rgb_pct(uint32_t rgb, uint32_t pct)
{
    uint32_t r = (rgb >> 16 & 255u) * pct / 100u, g = (rgb >> 8 & 255u) * pct / 100u, b = (rgb & 255u) * pct / 100u;
    return (r > 255u ? 255u : r) << 16 | (g > 255u ? 255u : g) << 8 | (b > 255u ? 255u : b);
}

static uint32_t rgb_mix(uint32_t a, uint32_t b, uint32_t pct)
{
    uint32_t r = ((a >> 16 & 255u) * (100u - pct) + (b >> 16 & 255u) * pct) / 100u;
    uint32_t g = ((a >> 8 & 255u) * (100u - pct) + (b >> 8 & 255u) * pct) / 100u;
    uint32_t c = ((a & 255u) * (100u - pct) + (b & 255u) * pct) / 100u;
    return r << 16 | g << 8 | c;
}

static char *note_name(char *p, uint32_t n)
{
    static const char N[] = "C-C#D-D#E-F-F#G-G#A-A#B-";
    p[0] = N[(n % 12u) * 2u];
    p[1] = N[(n % 12u) * 2u + 1u];
    p[2] = (char)('0' + (n / 12u) - 1u);
    p[3] = 0;
    return p + 3;
}

/* a residual (Q12 of a step) in QX units: 1/384 of a beat, i.e. 96 to a 16th, rounded */
static int32_t off_ppq(int32_t off) { return (off * 96 + (off < 0 ? -2048 : 2048)) / 4096; }

static void ui_say(const char *s)
{
    os_fmt_str(ui.msg, s);
    ui.msg_until = fm1_ms + 1500u;
}

/* a text slot: drawn only when its string or colours change */
static void ui_text(uint32_t slot, uint32_t x, uint32_t y, uint32_t w, uint32_t scale, const char *s, uint32_t fg, uint32_t bg)
{
    uint32_t i, sg = fg * 31u + bg;
    for (i = 0; s[i] && i < 40u; i++) sg = sg * 131u + (uint8_t)s[i];
    sg ^= x * 7u + y * 977u + w;
    if (!ui.force && ui.sig[400u + slot] == sg)
        return;
    ui.sig[400u + slot] = sg;
    draw_text(x, y, w, s, scale, c565(fg), c565(bg));
}

/* ------------------------------------------------------------- cells -- */
typedef struct {
    uint32_t bg, fg, mark;                 /* rgb; mark: a corner dot (0 none) */
    char txt[6];
    int8_t tick;                           /* -64..64: the human residual, drawn as a stroke (127 none) */
    uint8_t bar;                           /* 0..100: a bar from the bottom (255 none) */
    uint32_t barc;
} cell_t;

static void cell_clear(cell_t *c) { c->bg = 0x101010u; c->fg = 0xC0C0C0u; c->mark = 0; c->txt[0] = 0; c->tick = 127; c->bar = 255; c->barc = 0; }

static void ui_cell(uint32_t slot, uint32_t x, uint32_t y, uint32_t w, uint32_t h, const cell_t *c)
{
    uint32_t sg = c->bg * 3u + c->fg * 5u + c->mark * 7u + (uint32_t)(c->tick + 200) * 131u + c->bar * 977u + c->barc, i;
    for (i = 0; c->txt[i]; i++) sg = sg * 31u + (uint8_t)c->txt[i];
    sg ^= x * 65537u + y * 257u + w * 3u + h;
    if (!ui.force && ui.sig[slot] == sg)
        return;
    ui.sig[slot] = sg;
    lcd_fill(x, y, w, h, c565(c->bg));
    if (c->bar != 255u) {
        uint32_t bh = (h - 2u) * c->bar / 100u;
        if (bh) lcd_fill(x + 1u, y + h - 1u - bh, w - 2u, bh, c565(c->barc));
    }
    if (c->tick != 127) {
        int32_t cx = (int32_t)(x + w / 2u) + c->tick * (int32_t)(w / 2u - 1u) / 64;
        lcd_fill((uint32_t)cx, y + 1u, 1, h > 8u ? 5u : h - 2u, c565(0xFFFFFFu));
    }
    if (c->mark) lcd_fill(x + w - 4u, y + 1u, 3, 3, c565(c->mark));
    if (c->txt[0] && h >= 9u && w >= 12u) {
        uint32_t tw = text_width(c->txt, 1), tx = x + (w > tw ? (w - tw) / 2u : 0u);
        draw_text(tx, y + (h - 8u) / 2u + (h > 30u ? 4u : 0u), tw < w ? tw : w, c->txt, 1, c565(c->fg), c565(c->bg));
    }
}

/* ------------------------------------------------------------- the data views -- */
static evl_t *ui_list(void) { return ui.list_src ? &seq_tbl[ui.list_src - 1u] : seq_list(os.sel); }

static uint32_t ui_step_of(uint32_t i) { return (uint32_t)ui.spage * 16u + i; }

static int ui_step_held(uint32_t step)
{
    uint32_t p;
    for (p = 0; p < SMK_NPAD; p++)
        if (ui.pad_was[p] && ui_step_of(p) == step) return 1;
    return 0;
}

/* STEP: what a step looks like (and the pads, at 2 x 8) */
static void cell_step(uint32_t i, cell_t *c)
{
    const trk_t *t = &os.trk[os.sel];
    const evl_t *l = seq_list(os.sel);
    uint32_t s = ui_step_of(i), n = trk_steps(t), j, nn = 0, nl = 0, vmax = 0, low = 255;
    int32_t off = 0;
    cell_clear(c);
    if (s >= n) { c->bg = 328965u /* RGB #050505, not MMIO */; return; }
    for (j = evl_lower(l, s); j < l->n && l->e[j].step == s; j++) {
        const ev_t *e = &l->e[j];
        if (e->kind == EV_NOTE) {
            nn++;
            if (e->b > vmax) vmax = e->b;
            if (e->a < low) { low = e->a; off = e->off; }
            if (e->d & 15u) c->mark = 0xFFE040u;
        } else nl++;
    }
    if (nn) {
        c->bg = rgb_pct(TRK_RGB[os.sel], 35u + vmax * 50u / 127u);
        c->fg = 0x000000u;
        if (t->mach == MA_MULTI && t->eff[MU_MAP]) {         /* a kit: the sound's name, not a note */
            int32_t si = os_clampi((int32_t)t->eff[MU_SMP] + (int32_t)low - 48, 0, (int32_t)OS_LIB_COUNT - 1);
            uint32_t q;
            for (q = 0; q < 4u && OS_LIB_NAMES[si][q]; q++) c->txt[q] = OS_LIB_NAMES[si][q];
            c->txt[q] = 0;
            if (nn > 1u) { c->txt[q] = '+'; c->txt[q + 1u] = 0; }
        } else
        note_name(c->txt, low);
        if (nn > 1u && c->txt[3] == 0) { c->txt[3] = '+'; c->txt[4] = (char)('0' + (nn - 1u > 9u ? 9u : nn - 1u)); c->txt[5] = 0; }
        if (off) c->tick = (int8_t)os_clampi(off * 64 / 2048, -64, 64);
    } else if (nl) {
        c->bg = rgb_pct(TRK_RGB[os.sel], 14u);
    } else if ((s & 3u) == 0u) {
        c->bg = 0x202020u;
    }
    if (nl && !c->mark) c->mark = 0x40E0FFu;
    if (os.playing && (uint32_t)t->cur_step == s) c->bg = rgb_mix(c->bg, 0xFFFFFFu, 45u);
    if (ui_step_held(s)) c->bg = 0xFFFFFFu, c->fg = 0x000000u;
}

/* ROLL: 16 steps x 24 pitches */
static uint8_t roll_map[16][24];          /* 0 empty, 1 note start, 2 held */
static int8_t roll_tick[16][24];

static void roll_build(void)
{
    const evl_t *l = seq_list(os.sel);
    const trk_t *t = &os.trk[os.sel];
    uint32_t j, s0 = (uint32_t)ui.spage * 16u, L = trk_steplen(t);
    (void)L;
    memset(roll_map, 0, sizeof roll_map);
    for (j = 0; j < l->n; j++) {
        const ev_t *e = &l->e[j];
        int32_t p = (int32_t)e->a - ui.roll_pitch, s, len;
        if (e->kind != EV_NOTE || p < 0 || p >= 24) continue;
        len = e->c == LEN_HOLD ? 16 : ((int32_t)e->c + 7) / 8;
        if (len < 1) len = 1;
        for (s = 0; s < len; s++) {
            int32_t c = (int32_t)e->step + s - (int32_t)s0;
            if (c < 0 || c >= 16) continue;
            if (!s) { roll_map[c][p] = 1; roll_tick[c][p] = (int8_t)os_clampi(e->off * 64 / 2048, -64, 64); }
            else if (!roll_map[c][p]) roll_map[c][p] = 2;
        }
    }
}

static void cell_roll(uint32_t col, uint32_t row, cell_t *c)
{
    const trk_t *t = &os.trk[os.sel];
    uint32_t p = 23u - row, note = ui.roll_pitch + p, s = ui_step_of(col);
    cell_clear(c);
    c->bg = note % 12u == 0u ? 0x262626u : (0x54Au >> (note % 12u) & 1u) ? 0x0A0A0Au : 0x161616u;
    if (s >= trk_steps(t)) c->bg = 263172u; /* RGB #040404, not MMIO */
    if (roll_map[col][p] == 1u) {
        c->bg = rgb_pct(TRK_RGB[os.sel], 95u);
        if (roll_tick[col][p]) c->tick = roll_tick[col][p];
    } else if (roll_map[col][p] == 2u) {
        c->bg = rgb_pct(TRK_RGB[os.sel], 40u);
    }
    if (os.playing && (uint32_t)t->cur_step == s) c->bg = rgb_mix(c->bg, 0xFFFFFFu, 25u);
    if (note == t->last_note) c->bg = rgb_mix(c->bg, 0xFFFFFFu, 18u);
}

/* LANE: one register across the steps (locks bright, the base dim) */
static void cell_lane(uint32_t col, cell_t *c)
{
    const trk_t *t = &os.trk[os.sel];
    const evl_t *l = seq_list(os.sel);
    uint32_t s = ui_step_of(col), r = ui.lane_reg, mx = reg_max(t->mach, r);
    int j = evl_find(l, s, EV_LOCK, r);
    cell_clear(c);
    c->bg = s >= trk_steps(t) ? 263172u /* RGB #040404 */ : (s & 3u) ? 0x0C0C0Cu : 0x181818u;
    if (j >= 0) { c->bar = (uint8_t)(l->e[j].b * 100u / (mx ? mx : 1u)); c->barc = TRK_RGB[os.sel]; }
    else { c->bar = (uint8_t)(t->base[r] * 100u / (mx ? mx : 1u)); c->barc = 0x303030u; }
    if (step_count(l, s, EV_NOTE)) c->mark = rgb_pct(TRK_RGB[os.sel], 70u);
    if (os.playing && (uint32_t)t->cur_step == s) c->bg = rgb_mix(c->bg, 0xFFFFFFu, 20u);
    if (ui_step_held(s)) c->bg = 0x505050u;
}

/* PERF pads: scenes (page 0) or mutes, FILL, CAP (page 1); patterns below */
static void cell_perf_pad(uint32_t p, cell_t *c)
{
    cell_clear(c);
    if (p < 8u && !ui.perf_pg) {                 /* a scene: white held, green by its amount, dim if it sets anything */
        c->bg = ui.scene_held == p + 1u ? 0xFFFFFFu : scs.amt[p] ? rgb_mix(0x184818u, 0x60FF60u, (uint32_t)scs.amt[p] * 100u / 127u)
              : scn_any(p) ? 0x206020u : 0x0C1C0Cu;
        c->txt[0] = 'S'; c->txt[1] = (char)('1' + p); c->txt[2] = 0;
        if (ui.scn_latch >> p & 1u) c->mark = 0xFFFFFFu;
    }
    else if (p < 4u) { c->bg = os.trk[p].mute ? rgb_pct(TRK_RGB[p], 6u) : rgb_pct(TRK_RGB[p], 80u); c->txt[0] = (char)('1' + p); c->txt[1] = 0; }
    else if (p < 6u) c->bg = 0x080808u;
    else if (p == 6u) { c->bg = os.fill ? 0xFFE040u : 0x302810u; os_fmt_str(c->txt, "FILL"); }
    else if (p == 7u) { c->bg = 0x202020u; os_fmt_str(c->txt, "CAP"); }
    if (p >= 8u) {
        uint32_t q = p - 8u, k, any = 0;
        for (k = 0; k < NTRACK; k++) any |= seq_pat[q][k].n;
        c->bg = q == os.pat ? 0xF0F0F0u : q == os.pat_next ? ((fm1_ms / 150u) & 1u ? 0xF2A93Bu : 0x402800u) : any ? 0x404040u : 0x101010u;
        c->txt[0] = 'P'; c->txt[1] = (char)('1' + q); c->txt[2] = 0;
    }
    c->fg = (c->bg & 0xF0F0F0u) > 0x808080u ? 0x000000u : 0xE0E0E0u;
}

/* MACH pads: machines on top, samples of the bank below */
static void cell_mach_pad(uint32_t p, cell_t *c)
{
    const trk_t *t = &os.trk[os.sel];
    cell_clear(c);
    if (p < 4u) {
        c->bg = t->mach == p ? TRK_RGB[os.sel] : rgb_pct(TRK_RGB[os.sel], 12u);
        os_fmt_str(c->txt, MACH[p].name);
    } else if (p >= 8u) {
        uint32_t si = ui.mach_bank * 8u + p - 8u;
        if (si < OS_LIB_COUNT) {
            c->bg = t->base[0] == si ? 0xF0F0F0u : 0x203040u;
            os_fmt_str(c->txt, OS_LIB_NAMES[si]);
            c->txt[5] = 0;
        } else c->bg = 328965u; /* RGB #050505 */
    } else c->bg = 328965u; /* RGB #050505 */
    c->fg = (c->bg & 0xF0F0F0u) > 0x808080u ? 0x000000u : 0xE0E0E0u;
}

static void pad_cell(uint32_t p, cell_t *c)
{
    switch (ui.view) {
    case V_PERF: cell_perf_pad(p, c); break;
    case V_MACH: cell_mach_pad(p, c); break;
    default: cell_step(p, c); break;
    }
}

/* -------------------------------------------------------------- pads (LEDs) -- */
static void ui_leds(void)
{
    uint32_t p, k;
    for (p = 0; p < SMK_NPAD; p++) {
        cell_t c;
        uint32_t rgb;
        pad_cell(p, &c);
        rgb = rgb_pct(c.bg, 28u);                    /* the pads are bright: the screen colour, dimmed */
        padled_set(p, (uint8_t)(rgb >> 16), (uint8_t)(rgb >> 8), (uint8_t)rgb);
    }
    for (k = 0; k < SMK_NLED; k++)
        fm1_led_key(k, 0);
    fm1_led_key(B_PLAY, os.playing);
    fm1_led_key(B_REC, os.rec);
    fm1_led_key(B_FX, ui.fx_page || ui.page == P_FX || ui.page == P_VERB);
    fm1_led_key(VIEW_BTN[ui.view], 1);
    fm1_led_key(B_KBANK, ui.page != 0u);
    fm1_led_key(B_NREP, os.fill);
}

/* ------------------------------------------------------------- input -- */
static int shift_held(void) { return (fm1_in.buttons >> B_BT & 1u) != 0; }

static void ui_set_view(uint32_t v)
{
    ui.view = (uint8_t)v;
    ui.force = 1;
}

static void list_field(int32_t f, int32_t e);

/* SHIFT + PLAY: the kit into its slot. Stopped, any time; playing, when no erase is needed (the vault keeps
 * erased room ahead while stopped and silent); not while recording. An area holding another firmware's data
 * is only erased on a second SHIFT + PLAY within 4 s, stopped */
static void ui_kit_save(void)
{
    int r;
    char b[40], *q;
    if (vt.foreign) {
        if (os.playing) { ui_say("STOP FIRST"); return; }
        if (ui.fmt_t && fm1_ms - ui.fmt_t < 4000u) {
            ui.fmt_t = 0;
            ui_say(vault_format() == VT_OK ? "STORE ERASED: OURS NOW" : "STORE ERROR");
        } else {
            ui.fmt_t = fm1_ms ? fm1_ms : 1u;
            ui_say("OTHER DATA IN STORE: SHIFT+PLAY ERASES");
        }
        return;
    }
    if (os.playing && os.rec) { ui_say("STOP RECORDING TO SAVE"); return; }
    r = vault_kit_save(ui.kit_slot, !os.playing);
    if (r == VT_OK) {
        uint32_t used, room;
        vault_space(&used, &room);
        q = os_fmt_str(b, "KIT ");
        q = os_fmt_int(q, ui.kit_slot + 1, 1, 0);
        q = os_fmt_str(q, " SAVED, ");
        q = os_fmt_int(q, (int32_t)(room >> 10), 1, 0);
        os_fmt_str(q, " KB FREE");
        ui_say(b);
    } else
        ui_say(r == VT_BUSY ? "STOP TO SAVE (NEEDS AN ERASE)" : r == VT_FULL ? "STORE FULL" : "STORE ERROR");
}

static void ui_buttons(void)
{
    uint32_t rel, p = fm1_input_edges(&rel), v;
    int sh = shift_held();
    if (sh && (p & (1u << B_PATCH))) {                         /* SHIFT + PATCH: the second core on / off */
#if OS_CPU2
        os.cpu2 = (uint8_t)(!os.cpu2 && fm1_c1_on);
        ui_say(os.cpu2 ? "SECOND CORE ON" : fm1_c1_on ? "SECOND CORE OFF" : "SECOND CORE NOT ANSWERING");
#else
        ui_say("ONE-CORE BUILD (BUILD.PY --CPU2)");
#endif
        p &= ~(1u << B_PATCH);
    }
    for (v = 0; v < V_N; v++)
        if (p & (1u << VIEW_BTN[v])) {
            if (v == V_PERF && ui.view == V_PERF) ui.perf_pg ^= 1u;   /* PERF again: scenes <-> mutes */
            ui_set_view(v);
        }
    if ((p & (1u << B_PLAY)) && sh) ui_kit_save();        /* SHIFT + PLAY: the kit into the vault */
    else if (p & (1u << B_PLAY))
        ENGINE_LOCKED(seq_play(!os.playing));
    if (p & (1u << B_REC)) {
        if (sh) {
            uint32_t n;
            ENGINE_LOCKED(n = seq_capture());
            ui_say(n ? "CAPTURED THE LAST LOOP" : "NOTHING TO CAPTURE");
        } else {
            os.rec ^= 1u;
        }
    }
    if (p & (1u << B_FX)) {                                   /* the track's FX, its VERB, MASTER, back */
        if (sh) os.fx_on ^= 1u;                               /* SHIFT + FX: every track's effects in / out */
        else if (ui.fx_page) { ui.fx_page = 0; ui.page = ui.fx_ret; }
        else if (ui.page == P_FX) ui.page = P_VERB;
        else if (ui.page == P_VERB) ui.fx_page = 2u;
        else { ui.fx_ret = ui.page; ui.page = P_FX; }
    }
    if (p & (1u << B_KBANK)) {
        ui.fx_page = 0;
        ui.page = (uint8_t)((ui.page + (sh ? NPAGE - 1u : 1u)) % NPAGE);
    }
    if (p & (1u << B_LEFT) || p & (1u << B_RIGHT)) {
        int d = p & (1u << B_RIGHT) ? 1 : -1;
        if (ui.view == V_LIST) {
            if (sh) { ui.list_src = (uint8_t)((ui.list_src + 9u + (uint32_t)d) % 9u); ui.list_cur = ui.list_top = 0; ui.force = 1; }
            else ui.list_cur = (int16_t)(ui.list_cur + d * 19);
        } else if (ui.view == V_MACH) {
            ui.mach_bank = (uint8_t)os_clampi(ui.mach_bank + d, 0, (int32_t)(OS_LIB_COUNT - 1u) / 8);
        } else {
            uint32_t pages = (trk_steps(&os.trk[os.sel]) + 15u) / 16u;
            ui.spage = (uint8_t)os_clampi(ui.spage + d, 0, (int32_t)pages - 1);
        }
    }
    if ((p & (1u << B_OCTD)) && !(fm1_in.buttons & (1u << B_OCTU)) && ui.oct > -3) { ui.oct--; ui.roll_pitch = (uint8_t)(ui.roll_pitch - 12u); }
    if ((p & (1u << B_OCTU)) && !(fm1_in.buttons & (1u << B_OCTD)) && ui.oct < 3) { ui.oct++; ui.roll_pitch = (uint8_t)(ui.roll_pitch + 12u); }
    if (ui.view == V_LIST && (p & (1u << B_SCALE))) {          /* SCALE in LIST: delete the row */
        evl_t *l = ui_list();
        ENGINE_LOCKED(evl_delete(l, (uint32_t)ui.list_cur));
    }
    os.fill = (uint8_t)((fm1_in.buttons >> B_NREP & 1u) || (ui.view == V_PERF && ui.perf_pg && ui.pad_was[6]));
    if (ui.view == V_PERF && !ui.perf_pg)                       /* a held scene: pressed harder, toward 127 */
        for (v = 0; v < NSCN; v++)
            if (ui.pad_was[v]) {
                uint32_t a = fm1_in.pad_vel[v] ? fm1_in.pad_vel[v] : 127u;
                ENGINE_LOCKED(scene_on(v, a + (127u - a) * fm1_in.pad_press[v] / 127u));
            }
}

/* hold + turn: the knob writes wherever the focus is */
static void knob_edit(uint32_t kn, int32_t e)
{
    trk_t *t = &os.trk[os.sel];
    uint32_t r = PAGES[ui.page][kn], mx, p, any = 0;
    if (ui.view == V_LIST) { list_field((int32_t)kn, e); return; }
    if (r == P_NONE && ui.fx_page != 2u) return;
    mx = r < NREG ? reg_max(t->mach, r) : 0u;
    if (ui.fx_page == 2u) {                                  /* MASTER */
        switch (kn) {
        case 0: os.m_glu = (uint8_t)os_clampi(os.m_glu + e, 0, 100); break;
        case 1: os.m_air = (uint8_t)os_clampi(os.m_air + e, 0, 100); break;
        case 2: os.m_wid = (uint8_t)os_clampi(os.m_wid + e, 0, 200); break;
        case 3: os.m_cel = (uint8_t)os_clampi(os.m_cel + e, 0, 120); break;
        case 4: os.hf = (uint8_t)os_clampi(os.hf + e, 0, 100); break;
        case 5: break;                                      /* GR: the glue's reduction, to read */
        case 6: ENGINE_LOCKED(seq_set_bpb((uint32_t)((int32_t)os.bpb - e))); break;
        default: os.master = (uint8_t)os_clampi(os.master + e, 0, 127); break;
        }
        return;
    }
    if (shift_held()) {                                     /* SHIFT + knob: this register is the lane */
        ui.lane_reg = (uint8_t)r;
        ui_say("LANE REGISTER PICKED");
        return;
    }
    if (ui.view == V_PERF && ui.scene_held) {
        uint32_t s = ui.scene_held - 1u, v = SCN_HAS(s, os.sel, r) ? scn[s].v[os.sel][r] : t->base[r];
        ENGINE_LOCKED(scene_write(s, os.sel, r, (uint32_t)os_clampi((int32_t)v + e, 0, (int32_t)mx)));
        ui.pad_used[s] = 1;                                 /* (an edit: its release is not a tap) */
        return;
    }
    if (ui.view == V_STEP || ui.view == V_ROLL || ui.view == V_LANE) {
        evl_t *l = seq_list(os.sel);
        for (p = 0; p < SMK_NPAD; p++) {
            uint32_t s = ui_step_of(p);
            int j;
            uint32_t v;
            if (!ui.pad_was[p] || s >= trk_steps(t)) continue;
            j = evl_find(l, s, EV_LOCK, r);
            v = j >= 0 ? l->e[j].b : t->base[r];
            ENGINE_LOCKED(seq_put_lock(l, s, r, (uint32_t)os_clampi((int32_t)v + e, 0, (int32_t)mx)));
            ui.pad_used[p] = 1;
            any = 1;
        }
        if (any) { ui.lane_reg = (uint8_t)r; return; }
    }
    if (os.playing && os.rec && !ui.held_n) {               /* REC + a knob while playing: motion record */
        uint32_t s = (uint32_t)(t->cur_step >= 0 ? t->cur_step : 0);
        uint32_t v = (uint32_t)os_clampi((int32_t)t->eff[r] + e, 0, (int32_t)mx);
        ENGINE_LOCKED(seq_put_lock(seq_list(os.sel), s, r, v));
        ui.lane_reg = (uint8_t)r;
    }
    t->base[r] = (uint8_t)os_clampi((int32_t)t->base[r] + e, 0, (int32_t)mx);
}

static void ui_knobs(void)
{
    uint32_t i;
    for (i = 0; i < FM1_NENC; i++) {
        int32_t e = fm1_enc_take(i);
        if (!e) continue;
        if (e > 2 || e < -2) e *= 3;                        /* a fast turn travels */
        knob_edit(i, e);
    }
}

/* a tap on a step: chord stamp if keys are down, else toggle */
static void step_tap(uint32_t s)
{
    trk_t *t = &os.trk[os.sel];
    evl_t *l = seq_list(os.sel);
    uint32_t k;
    if (s >= trk_steps(t)) return;
    if (ui.keys_down) {
        ENGINE_LOCKED(step_clear(l, s, EV_NOTE));
        for (k = 0; k < FM1_NKEY; k++)
            if (ui.keys_down >> k & 1u) {
                uint32_t note = (uint32_t)os_clampi(48 + (int32_t)k + ui.oct * 12, 0, 127);
                ENGINE_LOCKED(seq_put_note(l, s, note, ui.key_vel[k] ? ui.key_vel[k] : 100u, 0, 8, 0));
            }
        return;
    }
    if (ui.view == V_ROLL) {                                /* ROLL: the note at the playing row */
        int j = evl_find(l, s, EV_NOTE, t->last_note);
        if (j >= 0) ENGINE_LOCKED(evl_delete(l, (uint32_t)j));
        else ENGINE_LOCKED(seq_put_note(l, s, t->last_note, t->last_vel, 0, 8, 0));
        return;
    }
    if (step_count(l, s, EV_NOTE)) ENGINE_LOCKED(step_clear(l, s, -1));
    else ENGINE_LOCKED(seq_put_note(l, s, t->last_note, t->last_vel, 0, 8, 0));
}

static void ui_pads(void)
{
    uint32_t p;
    int sh = shift_held(), clr = (fm1_in.buttons >> B_SCALE & 1u) != 0;
    for (p = 0; p < SMK_NPAD; p++) {
        uint8_t on = (uint8_t)((fm1_in.pad_st[p] & 0x80u) != 0);
        if (on == ui.pad_was[p]) continue;
        ui.pad_was[p] = on;
        if (on) {
            ui.pad_t[p] = fm1_ms;
            ui.pad_used[p] = 0;
            ui.keyset_step[p] = 0;
            ui.held_n++;
            if (sh && p < 4u) { os.sel = (uint8_t)p; ui.pad_used[p] = 1; ui.force = 1; continue; }
            switch (ui.view) {
            case V_PERF:
                if (p < 8u && !ui.perf_pg) {
                    uint32_t a = fm1_in.pad_vel[p] ? fm1_in.pad_vel[p] : 127u;
                    if (clr) {                                   /* CLR + a scene: it sets nothing now */
                        ENGINE_LOCKED({ scene_clear(p); scene_off(p); });
                        ui.scn_latch &= (uint8_t)~(1u << p);
                        ui.pad_used[p] = 1;
                        ui_say("SCENE CLEARED");
                        break;
                    }
                    ui.scene_held = (uint8_t)(p + 1u);
                    ui.scn_last = (uint8_t)p;
                    ui.scn_was = (uint8_t)((ui.scn_was & ~(1u << p)) | (ui.scn_latch & (1u << p)));
                    ENGINE_LOCKED(scene_on(p, a));
                    ui.force = 1;
                    break;                                       /* (its release decides: a tap, or a hold) */
                }
                else if (p < 4u) os.trk[p].mute ^= 1u;
                else if (p == 7u) { uint32_t n; ENGINE_LOCKED(n = seq_capture()); ui_say(n ? "CAPTURED THE LAST LOOP" : "NOTHING TO CAPTURE"); }
                else if (p >= 8u) { ENGINE_LOCKED(seq_pat_select(p - 8u)); ui.force = 1; }
                ui.pad_used[p] = 1;
                break;
            case V_MACH:
                if (p < 4u) { ENGINE_LOCKED(trk_set_machine(&os.trk[os.sel], p)); ui.force = 1; }
                else if (p >= 8u && ui.mach_bank * 8u + p - 8u < OS_LIB_COUNT) os.trk[os.sel].base[0] = (uint8_t)(ui.mach_bank * 8u + p - 8u);
                ui.pad_used[p] = 1;
                break;
            case V_LIST: {                                   /* LIST: a pad inserts an event at its step */
                evl_t *l = ui_list();
                trk_t *t = &os.trk[os.sel];
                uint32_t s = ui_step_of(p);
                int i;
                ENGINE_LOCKED(seq_put_note(l, s, t->last_note, t->last_vel, 0, 8, 0));
                i = evl_find(l, s, EV_NOTE, t->last_note);
                if (i >= 0) ui.list_cur = (int16_t)i;
                ui.pad_used[p] = 1;
                break;
            }
            default:
                if (clr) { ENGINE_LOCKED(step_clear(seq_list(os.sel), ui_step_of(p), -1)); ui.pad_used[p] = 1; }
                break;
            }
        } else {
            if (ui.held_n) ui.held_n--;
            if (ui.view == V_PERF && !ui.perf_pg && p < 8u) {    /* a scene pad up: a tap latches, a hold was momentary */
                uint32_t bit = 1u << p, a = fm1_in.pad_vel[p] ? fm1_in.pad_vel[p] : 127u;
                int tapped = !ui.pad_used[p] && fm1_ms - ui.pad_t[p] < 250u;
                if (ui.scene_held == p + 1u) ui.scene_held = 0;
                if (tapped && (ui.scn_was & bit)) { ui.scn_latch &= (uint8_t)~bit; ENGINE_LOCKED(scene_off(p)); }
                else if (tapped) { ui.scn_latch |= (uint8_t)bit; ui.scn_lat_amt[p] = (uint8_t)a; ENGINE_LOCKED(scene_on(p, a)); }
                else if (ui.scn_was & bit) ENGINE_LOCKED(scene_on(p, ui.scn_lat_amt[p]));
                else if (!(ui.scn_latch & bit)) ENGINE_LOCKED(scene_off(p));
                ui.force = 1;
            }
            if (!ui.pad_used[p] && fm1_ms - ui.pad_t[p] < 500u &&
                (ui.view == V_STEP || ui.view == V_ROLL || ui.view == V_LANE))
                step_tap(ui_step_of(p));
        }
    }
}

static void ui_faders(void)
{
    uint32_t i;
    if (fm1_in.frames < 200u) return;
    for (i = 0; i < 4u; i++) {
        uint8_t v = fm1_in.fader[i];
        if (ui.fad_last[i] == 0xFF) { ui.fad_last[i] = v; continue; }   /* take over once it moves */
        if (v != ui.fad_last[i]) { ui.fad_last[i] = v; os.trk[i].base[R_LEV] = v > 127u ? 127u : v; }
    }
}

static void ui_wheels(void)                         /* self-calibrating, as the SMK layer's ports do */
{
    enum { DEAD = 12, SPAN0 = 80, MOD_LO = 485, MOD_HI = 615 };
    int32_t p = fm1_in.wheel[0], m = fm1_in.wheel[1], d, mw;
    float x = 0.0f;
    if (fm1_in.frames < 300u) return;
    if (!ui.pc) { ui.pc = p; ui.plo = p - SPAN0; ui.phi = p + SPAN0; ui.mlo = m < MOD_LO ? m : MOD_LO; ui.mhi = m > MOD_HI ? m : MOD_HI; }
    if (p < ui.plo) ui.plo = p;
    if (p > ui.phi) ui.phi = p;
    if (m < ui.mlo) ui.mlo = m;
    if (m > ui.mhi) ui.mhi = m;
    d = p - ui.pc;
    if (d > -DEAD && d < DEAD) {
        if (++ui.rest > 200) { ui.pc += d > 0 ? 1 : d < 0 ? -1 : 0; ui.rest = 0; }
    } else {
        ui.rest = 0;
        x = d > 0 ? (float)(d - DEAD) / (float)(ui.phi - ui.pc - DEAD > 1 ? ui.phi - ui.pc - DEAD : 1)
                  : (float)(d + DEAD) / (float)(ui.pc - ui.plo - DEAD > 1 ? ui.pc - ui.plo - DEAD : 1);
        x = os_clampf(x, -1.0f, 1.0f);
    }
    ENGINE_LOCKED(os_set_warp(x >= 0.0f ? 1.0f + 0.1224620f * x : 1.0f + 0.1090900f * x));   /* WARP: +-2 semitones */
    mw = ui.mhi - m <= DEAD ? 0 : (ui.mhi - m - DEAD) * 127 / (ui.mhi - ui.mlo - DEAD > 1 ? ui.mhi - ui.mlo - DEAD : 1);
    os.morph = (uint8_t)os_clampi(mw, 0, 127);
    if (ui.wheel_last == 0xFFu) ui.wheel_last = os.morph;                                        /* (where it rests at boot) */
    else if (os.morph != ui.wheel_last && (os.morph + 1u - ui.wheel_last > 2u || !os.morph || os.morph == 127u)) {
        uint32_t s = ui.scn_last;                                 /* the wheel: the last scene touched, in by its amount */
        ui.wheel_last = os.morph;
        if (os.morph) { ui.scn_latch |= (uint8_t)(1u << s); ui.scn_lat_amt[s] = os.morph; ENGINE_LOCKED(scene_on(s, os.morph)); }
        else { ui.scn_latch &= (uint8_t)~(1u << s); ENGINE_LOCKED(scene_off(s)); }
    }
}

/* key edges, stamped with the transport position heard at the press */
static void ui_keys(void)
{
    while (kq_r != kq_w) {
        uint32_t i = kq_r % 32u, k = kq[i].key, note, p, held = 0;
        note = (uint32_t)os_clampi(48 + (int32_t)k + ui.oct * 12, 0, 127);
        if (kq[i].on) {
            ui.keys_down |= (uint64_t)1 << k;
            ui.key_vel[k] = kq[i].vel;
            for (p = 0; p < SMK_NPAD; p++) {                 /* a held step takes the keys as its chord */
                evl_t *l = seq_list(os.sel);
                uint32_t s = ui_step_of(p);
                if (!ui.pad_was[p] || ui.view == V_PERF || ui.view == V_MACH || ui.view == V_LIST || s >= trk_steps(&os.trk[os.sel])) continue;
                if (!ui.keyset_step[p]) { ENGINE_LOCKED(step_clear(l, s, EV_NOTE)); ui.keyset_step[p] = 1; }
                ENGINE_LOCKED(seq_put_note(l, s, note, kq[i].vel, 0, 8, 0));
                ui.pad_used[p] = 1;
                held = 1;
            }
            if (held) ENGINE_LOCKED(mach_note_on(os.sel, note, kq[i].vel, 0, 0, 1));   /* audition, not recorded */
            else ENGINE_LOCKED(seq_key_on(note, kq[i].vel, kq[i].core));
            os.trk[os.sel].last_note = (uint8_t)note;
            os.trk[os.sel].last_vel = kq[i].vel;
        } else {
            ui.keys_down &= ~((uint64_t)1 << k);
            ENGINE_LOCKED(seq_key_off(note, kq[i].core));
        }
        kq_r++;
    }
}

static void ui_input(void)
{
    ui_buttons();
    ui_knobs();
    ui_pads();
    ui_faders();
    ui_wheels();
    ui_keys();
}

/* ------------------------------------------------------------- LIST -- */
static void list_field(int32_t f, int32_t e)
{
    evl_t *l = ui_list();
    ev_t *ev;
    if (f == 0) { ui.list_cur = (int16_t)os_clampi(ui.list_cur + e, 0, l->n ? (int32_t)l->n - 1 : 0); return; }
    if (!l->n || ui.list_cur >= (int16_t)l->n) return;
    ev = &l->e[ui.list_cur];
    {
        uint32_t k0 = fm1__lock();
        ev_t c = *ev;
        switch (f) {
        case 1: c.step = (uint8_t)os_clampi(c.step + e, 0, ui.list_src ? (int32_t)TBL_ROWS - 1 : (int32_t)trk_steps(&os.trk[os.sel]) - 1); break;
        case 2: c.off = (int16_t)os_clampi(c.off + e * 43, -2048, 2047); break;     /* 1/384 of a beat a detent */
        case 3: c.a = (uint8_t)os_clampi(c.a + e, 0, c.kind == EV_LOCK ? (int32_t)NREG - 1 : 127); break;
        case 4: c.b = (uint8_t)os_clampi(c.b + e, 0, 127); break;
        case 5: c.c = (uint8_t)os_clampi(c.c + e, 1, 255); break;
        case 6: c.d = (uint8_t)os_clampi((c.d & 15) + e, 0, CD_N - 1); break;
        default: c.kind = (uint8_t)((c.kind + 3u + (uint32_t)(e > 0 ? 1 : 2)) % 3u);
                 if (c.kind == EV_CMD) c.a = 'R', c.b = 2; else if (c.kind == EV_LOCK) c.a = R_CUT, c.b = 64; else c.a = 60, c.b = 100, c.c = 8;
                 break;
        }
        evl_delete(l, (uint32_t)ui.list_cur);
        ui.list_cur = (int16_t)evl_insert(l, &c);
        fm1__unlock(k0);
    }
}

static void list_row_text(char *b, const ev_t *e, const trk_t *t)
{
    char *q = b;
    q = os_fmt_int(q, e->step + (ui.list_src ? 0 : 1), 3, 0);
    *q++ = ' ';
    if (e->kind == EV_NOTE) {
        q = e->off ? os_fmt_int(q, off_ppq(e->off), 3, 1) : os_fmt_str(q, "   ");
        q = os_fmt_str(q, " NOTE ");
        q = note_name(q, e->a);
        q = os_fmt_str(q, " V");
        q = os_fmt_int(q, e->b, 3, 0);
        q = os_fmt_str(q, " L");
        if (e->c == LEN_HOLD) q = os_fmt_str(q, "HLD");
        else { q = os_fmt_int(q, e->c / 8, 1, 0); { uint32_t f = (e->c % 8u) * 25u / 2u; *q++ = '.'; *q++ = (char)('0' + f / 10u); *q++ = (char)('0' + f % 10u); } }   /* steps */
        if (e->d & 15u) { *q++ = ' '; q = os_fmt_str(q, CD_NAME[e->d & 15u]); }
    } else if (e->kind == EV_LOCK) {

        char v[8];
        q = os_fmt_str(q, "    LOCK ");
        *q++ = reg_label(t->eff, t->mach, e->a % NREG)[0]; *q++ = reg_label(t->eff, t->mach, e->a % NREG)[1]; *q++ = reg_label(t->eff, t->mach, e->a % NREG)[2]; *q++ = ' ';
        reg_text(v, t, e->a % NREG, e->b);
        q = os_fmt_str(q, v);
    } else {
        q = os_fmt_str(q, "    CMD  ");
        *q++ = (char)e->a;
        *q++ = ' ';
        q = os_fmt_int(q, e->b, 3, 0);
        if (e->c) { *q++ = ' '; q = os_fmt_int(q, e->c, 3, 0); }
    }
    *q = 0;
}

/* ------------------------------------------------------------- screen -- */
static void draw_header(void)
{
    char b[48], *q;
    uint32_t k, bpm10 = (300000u + os.bpb / 2u) / os.bpb;
    for (k = 0; k < NTRACK; k++) {
        uint32_t bg = k == os.sel ? rgb_pct(TRK_RGB[k], 45u) : 0x0A0A0Au, fg = k == os.sel ? 0xFFFFFFu : rgb_pct(TRK_RGB[k], 80u);
        q = b;
        *q++ = (char)('1' + k);
        *q++ = os.trk[k].mute ? '-' : ' ';
        os_fmt_str(q, MACH[os.trk[k].mach].name);
        ui_text(k, k * 60u, 1, 59, 1, b, fg, bg);
    }
    q = os_fmt_str(b, "P");
    q = os_fmt_int(q, os.pat + 1, 1, 0);
    if (os.pat_next != 0xFF) { *q++ = '>'; q = os_fmt_int(q, os.pat_next + 1, 1, 0); }
    *q++ = ' ';
    q = os_fmt_int(q, (int32_t)(bpm10 / 10u), 3, 0);
    *q++ = '.';
    q = os_fmt_int(q, (int32_t)(bpm10 % 10u), 1, 0);
    q = os_fmt_str(q, " ");
    q = os_fmt_str(q, VIEW_NAME[ui.view]);
    q = os_fmt_str(q, ui.fx_page ? " MSTR " : " ");
    if (!ui.fx_page) { *q++ = (char)('A' + ui.page); *q++ = ' '; q = os_fmt_str(q, PAGE_NAME[ui.page]); }
    while (q < b + 27) *q++ = ' ';
    q = os_fmt_str(q, os.rec ? "REC" : "   ");
    q = os_fmt_int(q, (int32_t)(os.cpu_q8 * 100u / 256u), 4, 0);       /* the render's share of the core */
    q = os_fmt_str(q, os.c1_mask ? "%2" : "% ");                       /* "2": the second core is rendering */
    os_fmt_str(q, os.playing ? ">" : "#");
    ui_text(4, 0, 13, 240, 1, b, os.rec ? 0xFF6050u : 0xF2A93Bu, 0x000000u);
}

static void draw_strip(void)
{
    trk_t *t = &os.trk[os.sel];
    uint32_t i;
    static const char LSL[8][4] = {"ROW", "STP", "PPQ", "A", "B", "C", "D", "KND"};
    for (i = 0; i < 8u; i++) {
        cell_t c;
        char v[8], lab[4];
        uint32_t x = (i & 3u) * 60u, y = STRIP_Y + (i >> 2) * 25u, r = PAGES[ui.page][i], val = 0, mx = 127;
        uint32_t col = TRK_RGB[os.sel], held_lock = 0;
        cell_clear(&c);
        if (ui.fx_page == 2u) {
            static const char MSL[8][4] = {"GLU", "AIR", "WID", "CEL", "HF ", "GR ", "BPM", "MST"};
            lab[0] = MSL[i][0]; lab[1] = MSL[i][1]; lab[2] = MSL[i][2]; lab[3] = 0;
            switch (i) {
            case 0: val = os.m_glu; mx = 100; os_fmt_int(v, (int32_t)val, 1, 0); break;
            case 1: val = os.m_air; mx = 100; os_fmt_int(v, (int32_t)val, 1, 0); break;
            case 2: { char *q = os_fmt_int(v, os.m_wid, 1, 0); os_fmt_str(q, "%"); val = os.m_wid; mx = 200; break; }
            case 3: { char *q = v; *q++ = '-'; q = os_fmt_int(q, os.m_cel / 10, 1, 0); *q++ = '.'; os_fmt_int(q, os.m_cel % 10, 1, 0); val = os.m_cel; mx = 120; break; }
            case 4: val = os.hf; mx = 100; os_fmt_int(v, (int32_t)val, 1, 0); break;
            case 5: { int32_t g10 = (int32_t)(ms.gr_db * 10.0f + 0.5f); char *q = v; *q++ = '-'; q = os_fmt_int(q, g10 / 10, 1, 0); *q++ = '.'; os_fmt_int(q, g10 % 10, 1, 0); val = (uint32_t)os_clampi(g10, 0, 120); mx = 120; break; }
            case 6: { uint32_t b10 = (300000u + os.bpb / 2u) / os.bpb; char *q = os_fmt_int(v, (int32_t)(b10 / 10u), 1, 0); *q++ = '.'; os_fmt_int(q, (int32_t)(b10 % 10u), 1, 0); val = 500u - os.bpb; mx = 400; break; }
            default: val = os.master; mx = 127; os_fmt_int(v, (int32_t)val, 1, 0); break;
            }
            col = 0xFFB060u;
        } else if (ui.view == V_LIST) {
            const evl_t *l = ui_list();
            lab[0] = LSL[i][0]; lab[1] = LSL[i][1]; lab[2] = LSL[i][2]; lab[3] = 0;
            v[0] = 0;
            if (i == 0u) { os_fmt_int(v, ui.list_cur + 1, 1, 0); }
            else if (l->n && ui.list_cur < (int16_t)l->n) {
                const ev_t *e = &l->e[ui.list_cur];
                switch (i) {
                case 1: os_fmt_int(v, e->step + 1, 1, 0); break;
                case 2: os_fmt_int(v, off_ppq(e->off), 1, 1); break;
                case 3: if (e->kind == EV_NOTE) note_name(v, e->a); else if (e->kind == EV_LOCK) { v[0] = reg_label(t->eff, t->mach, e->a % NREG)[0]; v[1] = reg_label(t->eff, t->mach, e->a % NREG)[1]; v[2] = reg_label(t->eff, t->mach, e->a % NREG)[2]; v[3] = 0; } else { v[0] = (char)e->a; v[1] = 0; } break;
                case 4: os_fmt_int(v, e->b, 1, 0); break;
                case 5: os_fmt_int(v, e->c, 1, 0); break;
                case 6: os_fmt_str(v, (e->d & 15u) ? CD_NAME[e->d & 15u] : "-"); break;
                default: os_fmt_str(v, e->kind == EV_NOTE ? "NOTE" : e->kind == EV_LOCK ? "LOCK" : "CMD"); break;
                }
            }
            col = 0xA0A0A0u;
            val = 0;
        } else if (r == P_NONE) {                          /* an empty knob */
            lab[0] = 0; v[0] = 0; val = 0; col = 0x303030u;
        } else {
            uint32_t p;
            lab[0] = reg_label(t->eff, t->mach, r)[0]; lab[1] = reg_label(t->eff, t->mach, r)[1]; lab[2] = reg_label(t->eff, t->mach, r)[2]; lab[3] = 0;
            val = t->base[r];
            mx = reg_max(t->mach, r);
            if (ui.view == V_PERF && ui.scene_held && SCN_HAS(ui.scene_held - 1u, os.sel, r)) {
                val = scn[ui.scene_held - 1u].v[os.sel][r]; held_lock = 1;
            }
            for (p = 0; p < SMK_NPAD; p++) {                 /* a held step shows its lock */
                int j;
                if (!ui.pad_was[p] || ui.view >= V_LIST) continue;
                j = evl_find(seq_list(os.sel), ui_step_of(p), EV_LOCK, r);
                if (j >= 0) { val = seq_list(os.sel)->e[j].b; held_lock = 1; }
                break;
            }
            reg_text(v, t, r, val);
            if (r == ui.lane_reg) col = rgb_mix(col, 0xFFFFFFu, 40u);
        }
        /* label + value in one 60 x 24 cell: the bar under them */
        c.bg = held_lock ? 0x103848u : 0x0C0C0Cu;
        c.bar = 255;
        {
            char line[12], *q = os_fmt_str(line, lab);
            *q++ = ' ';
            os_fmt_str(q, v);
            ui_text(30u + i, x, y + 3u, 59, 1, line, held_lock ? 0x80F0FFu : 0xE0E0E0u, c.bg);
            c.txt[0] = 0;
            c.bar = (uint8_t)(mx ? val * 100u / mx : 0u);
            c.barc = col;
            ui_cell(464u + i, x, y + 13u, 59, 5, &c);
            {
                cell_t g;
                cell_clear(&g);
                g.bg = c.bg;
                ui_cell(472u + i, x, y, 59, 3, &g);
                ui_cell(480u + i, x, y + 18u, 59, 6, &g);
            }
        }
    }
}

static void draw_body(void)
{
    uint32_t i, j;
    cell_t c;
    char b[48], *q;
    switch (ui.view) {
    case V_STEP:
        for (i = 0; i < 16u; i++) {
            cell_step(i, &c);
            ui_cell(i, (i & 7u) * 30u, BODY_Y + 4u + (i >> 3) * 66u, 29, 64, &c);
        }
        break;
    case V_ROLL:
        roll_build();
        for (i = 0; i < 16u; i++)
            for (j = 0; j < 24u; j++) {
                cell_roll(i, j, &c);
                ui_cell(16u + i * 24u + j, i * 15u, BODY_Y + 4u + j * 6u, 15, 6, &c);
            }
        break;
    case V_LANE:
        for (i = 0; i < 16u; i++) {
            cell_lane(i, &c);
            ui_cell(i, i * 15u, BODY_Y + 4u, 14, 136, &c);
        }
        break;
    case V_LIST: {
        const evl_t *l = ui_list();
        if (ui.list_cur >= (int16_t)l->n) ui.list_cur = l->n ? (int16_t)(l->n - 1u) : 0;
        if (ui.list_cur < 0) ui.list_cur = 0;
        if (ui.list_cur < ui.list_top) ui.list_top = ui.list_cur;
        if (ui.list_cur >= ui.list_top + 18) ui.list_top = (int16_t)(ui.list_cur - 17);
        q = ui.list_src ? os_fmt_str(b, "TABLE ") : os_fmt_str(b, "TRACK ");
        q = os_fmt_int(q, ui.list_src ? ui.list_src : os.sel + 1u, 1, 0);
        q = os_fmt_str(q, ui.list_src ? "  ROW PPQ EVENT" : "  STP PPQ EVENT");
        q = os_fmt_str(q, "   ");
        q = os_fmt_int(q, l->n, 3, 0);
        os_fmt_str(q, " EV");
        ui_text(13, 0, BODY_Y + 2u, 240, 1, b, 0x808080u, 0x000000u);
        for (i = 0; i < 18u; i++) {
            uint32_t row = (uint32_t)ui.list_top + i, sel = row == (uint32_t)ui.list_cur, fg = 0xD0D0D0u;
            const trk_t *t = &os.trk[os.sel];
            if (row < l->n) {
                const ev_t *e = &l->e[row];
                list_row_text(b, e, t);
                fg = e->kind == EV_NOTE ? rgb_mix(TRK_RGB[os.sel], 0xFFFFFFu, 30u) : e->kind == EV_LOCK ? 0x60D8F0u : 0xFFE060u;
                if (!ui.list_src && os.playing && t->cur_step == e->step) fg = 0xFFFFFFu;
            } else b[0] = 0;
            {
                uint32_t y = BODY_Y + 12u + i * 8u;
                uint32_t sg = 0;
                uint32_t n;
                for (n = 0; b[n]; n++) sg = sg * 131u + (uint8_t)b[n];
                sg = sg * 7u + fg + sel * 99991u;
                if (ui.force || ui.sig[100u + i] != sg) {
                    ui.sig[100u + i] = sg;
                    draw_text(0, y, 240, b, 1, c565(sel ? 0x000000u : fg), c565(sel ? fg : 0x000000u));
                }
            }
        }
        break;
    }
    case V_PERF:
        for (i = 0; i < NTRACK; i++) {
            const trk_t *t = &os.trk[i];
            const evl_t *l = seq_list(i);
            uint32_t s, n = trk_steps(t) < 16u ? trk_steps(t) : 16u;
            q = b;
            *q++ = (char)('1' + i);
            *q++ = ' ';
            q = os_fmt_str(q, MACH[t->mach].name);
            q = os_fmt_str(q, t->mute ? " MUTE" : "     ");
            q = os_fmt_str(q, " ");
            q = os_fmt_int(q, (int32_t)trk_steps(t), 3, 0);
            os_fmt_str(q, " ST");
            ui_text(14u + i, 0, BODY_Y + 2u + i * 30u, 240, 1, b, t->mute ? 0x505050u : TRK_RGB[i], 0x000000u);
            for (s = 0; s < 16u; s++) {
                cell_clear(&c);
                c.bg = s >= n ? 263172u /* RGB #040404 */ : step_count(l, s, EV_NOTE) ? rgb_pct(TRK_RGB[i], t->mute ? 20u : 80u) : 0x141414u;
                if (os.playing && t->cur_step == (int16_t)s) c.bg = rgb_mix(c.bg, 0xFFFFFFu, 50u);
                ui_cell(i * 16u + s, s * 15u, BODY_Y + 12u + i * 30u, 14, 14, &c);
            }
        }
        {   /* the scenes in, in their order (the top one last), and the wheel's scene with its amount */
            uint32_t a = scs.amt[ui.scn_last];
            q = os_fmt_str(b, "IN");
            if (!scs.n) q = os_fmt_str(q, " -");
            for (i = 0; i < scs.n; i++) { *q++ = ' '; *q++ = (char)('1' + scs.ord[i]); }
            q = os_fmt_str(q, "  WHEEL S");
            *q++ = (char)('1' + ui.scn_last);
            *q++ = ' ';
            os_fmt_int(q, (int32_t)a, 3, 0);
            ui_text(18, 0, BODY_Y + 124u, 240, 1, b, 0x60D080u, 0x000000u);
            {
                cell_t m;
                cell_clear(&m);
                m.bg = 0x102010u;
                ui_cell(64, 0, BODY_Y + 136u, a * 239u / 127u + 1u, 8, &m);
                m.bg = 0x40C060u;
                ui_cell(65, a * 239u / 127u, BODY_Y + 136u, 2, 8, &m);
            }
        }
        break;
    default: {                                            /* MACH */
        const trk_t *t = &os.trk[os.sel];
        uint32_t pg;
        for (i = 0; i < 16u; i++) {
            cell_mach_pad(i, &c);
            if (i >= 4u && i < 8u) continue;
            ui_cell(i, i < 4u ? i * 60u : (i - 8u) * 30u, BODY_Y + 4u + (i >> 3) * 34u, i < 4u ? 59 : 29, 30, &c);
        }
        uint32_t p0 = ui.page < 2u ? 0u : ui.page > NPAGE - 3u ? NPAGE - 5u : ui.page - 2u;   /* five pages around */
        for (pg = p0; pg < p0 + 5u; pg++) {
            uint32_t row = pg - p0;
            q = b;
            *q++ = (char)('A' + pg);
            *q++ = ' ';
            for (i = 0; i < 8u; i++) {
                uint32_t rr = PAGES[pg][i];
                const char *lb = rr < NREG ? reg_label(t->eff, t->mach, rr) : COMMON[R_E8 - 8u].lab;
                char v[8];
                uint32_t n;
                if (rr < NREG) reg_text(v, t, rr, t->base[rr]); else v[0] = 0;
                if (i == 4u) { *q = 0; ui_text(19u + row * 2u, 0, BODY_Y + 70u + row * 18u, 240, 1, b, pg == ui.page ? 0xFFFFFFu : 0x909090u, 0x000000u); q = os_fmt_str(b, "  "); }
                *q++ = lb[0]; *q++ = lb[1]; *q++ = lb[2]; *q++ = ':';
                for (n = 0; v[n] && n < 4u; n++) *q++ = v[n];
                while (n++ < 5u) *q++ = ' ';
            }
            *q = 0;
            ui_text(20u + row * 2u, 0, BODY_Y + 79u + row * 18u, 240, 1, b, pg == ui.page ? 0xFFFFFFu : 0x909090u, 0x000000u);
        }
        break;
    }
    }
}

static void draw_info(void)
{
    char b[48], *q = b;
    const trk_t *t = &os.trk[os.sel];
    uint32_t p, any = 0;
    if (ui.view >= V_LIST) return;
    if (fm1_ms < ui.msg_until) { ui_text(12, 0, 176, 240, 1, ui.msg, 0xFFE060u, 0x000000u); return; }
    for (p = 0; p < SMK_NPAD && !any; p++) {
        const evl_t *l = seq_list(os.sel);
        uint32_t s = ui_step_of(p), j, nn = 0;
        if (!ui.pad_was[p] || s >= trk_steps(t) || ui.view >= V_LIST) continue;
        any = 1;
        q = os_fmt_str(q, "STEP ");
        q = os_fmt_int(q, s + 1, 2, 0);
        for (j = evl_lower(l, s); j < l->n && l->e[j].step == s && nn < 4u; j++)
            if (l->e[j].kind == EV_NOTE) {
                *q++ = ' ';
                q = note_name(q, l->e[j].a);
                if (!nn && l->e[j].off) { *q++ = ' '; q = os_fmt_int(q, off_ppq(l->e[j].off), 1, 1); }
                nn++;
            }
        if (!nn) q = os_fmt_str(q, " (LOCKS ONLY)");
    }
    if (!any) {
        q = os_fmt_str(q, "STEPS ");
        q = os_fmt_int(q, ui.spage * 16 + 1, 1, 0);
        *q++ = '-';
        q = os_fmt_int(q, (int32_t)(ui.spage * 16u + 16u < trk_steps(t) ? ui.spage * 16u + 16u : trk_steps(t)), 1, 0);
        q = os_fmt_str(q, "/");
        q = os_fmt_int(q, (int32_t)trk_steps(t), 1, 0);
        if (ui.view == V_LANE) { q = os_fmt_str(q, "  LANE "); *q++ = reg_label(t->eff, t->mach, ui.lane_reg)[0]; *q++ = reg_label(t->eff, t->mach, ui.lane_reg)[1]; *q++ = reg_label(t->eff, t->mach, ui.lane_reg)[2]; }
        if (ui.view == V_ROLL) { q = os_fmt_str(q, "  ROWS "); q = note_name(q, ui.roll_pitch); *q++ = '-'; q = note_name(q, ui.roll_pitch + 23u); }
        if (ui.view == V_STEP && t->eff[R_GRV]) { char g[8]; reg_text(g, t, R_GRV, t->eff[R_GRV]); q = os_fmt_str(q, "  GRV "); q = os_fmt_str(q, g); }
        *q = 0;
    }
    ui_text(12, 0, 176, 240, 1, b, any ? 0xFFFFFFu : 0x909090u, 0x000000u);
}

static void ui_draw(void)
{
    if (ui.view != ui.last_view || os.sel != ui.last_sel) {
        ui.last_view = ui.view;
        ui.last_sel = os.sel;
        ui.force = 1;
    }
    if (ui.force)
        lcd_fill(0, 0, 240, 240, T_BG);
    draw_header();
    draw_body();
    draw_info();
    draw_strip();
    ui.force = 0;
}

static void ui_init(void)
{
    uint32_t i;
    for (i = 0; i < 4u; i++) ui.fad_last[i] = 0xFF;
    ui.view = V_STEP;
    ui.lane_reg = R_CUT;
    ui.roll_pitch = 48;
    ui.last_view = 0xFF;
    ui.force = 1;
    ui.wheel_last = 0xFF;
    lcd_fill(0, 0, 240, 240, T_BG);
}
