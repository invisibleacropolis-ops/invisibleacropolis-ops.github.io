/* SPDX-License-Identifier: GPL-3.0-only */
/* The shaper: each track's waveshaper / wavefolder (page L SHAP), one function, called before the track's
 * filter (POS PRE) or after its filter and drive (POST): where it sits costs nothing more.
 *
 *   the chain   input -> LPF (a one-pole before it, the tone; off at 127) -> x INP (0..+36 dB) -> up 2x ->
 *               + BIA -> the model, anti-aliased -> down 2x -> DC blocker -> level matched to the input ->
 *               with the dry, by WET (0: off and no CPU; 64: both full; 127: wet only)
 *   aliasing    a shaper makes harmonics far above the core's 4 kHz, which fold back as inharmonic tones. Measured
 *               against the same chain run alias-free (at 16x, brick-walled to 4 kHz): shaping at 8 kHz leaves the
 *               aliases 10 dB under the harmonics on a high note; first-order anti-derivative anti-aliasing (ADAA)
 *               at 8 kHz takes 4.5 dB off the 2-4 kHz band the air is copied from. So: 2x oversampling (a 23-tap
 *               half-band up), ADAA at 16 kHz, and a 23-tap decimator whose passband also undoes ADAA's average:
 *               aliases 20-40 dB lower than shaping at 8 kHz on high notes, the 2-4 kHz band within 0.2 dB. The
 *               chain delays by exactly 11 samples of its rate (1.4 ms on the core, 0.34 ms on WAVE's 32 kHz);
 *               the dry is delayed to match, so WET mixes without combing
 *   models      each a function and its anti-derivative, written so that nothing cancels in single precision
 *               (u^2 / (sqrt(1 + u^2) + 1), not sqrt(1 + u^2) - 1); A and B mean something per model:
 *                 TAPE  soft algebraic <-> firm cubic knee (A); darkening after it (B)
 *                 TUBE  asymmetric: the negative side harder and lower (A); sag: the bias follows the level (B)
 *                 CLIP  hard clip with a quadratic knee (A); the negative ceiling lower (B)
 *                 FOLD  West Coast folder: triangle <-> sine folds (A); folds x1..x8 (B)
 *                 CHEB  Chebyshev: harmonic 2..7, gliding between orders (A); the fundamental kept (B)
 *                 XOVR  crossover: a gap around zero (A), its softness (B)
 *                 RECT  half <-> full-wave rectifier (A): the octave up
 *                 BITS  bits 16..1 (A), the rate held down to 250 Hz (B); not anti-aliased: the crunch is the point
 *                 POLY  x + E x^2 + O x^3, inside +-1: even (A, bipolar) and odd (B) harmonics, the formula model
 *   level       the wet is matched to the input's level (slow, ~50 ms; -40..+12 dB), so INP changes the character,
 *               not the loudness (XOVR and RECT do not saturate: their INP is undone first)
 *   switching   on: 8 ms unheard (the chain fills, the level match settles), then an 8 ms fade; off: an 8 ms fade
 *   the air     POST, the shaper's harmonics never went through the filter: the air is told how much of the
 *               track is wet (os_hf.c), so it treats that share as unfiltered */

enum { SH_TAPE, SH_TUBE, SH_CLIP, SH_FOLD, SH_CHEB, SH_XOVR, SH_RECT, SH_BITS, SH_POLY, SH_N };

/* 2x up: the half-band's even taps (the odd phase is the centre tap: a delay of 5); 2x down: the decimator,
 * 1/cos(pi f / 16k) in its passband (ADAA's average undone) and a half-sample advance, so the chain is 11 */
static const float SH_UP[12] = {
    -0.030304539f, 0.038593647f, -0.064733303f, 0.109345069f, -0.205102918f, 0.652202044f,
    0.652202044f, -0.205102918f, 0.109345069f, -0.064733303f, 0.038593647f, -0.030304539f};
static const float SH_DN[23] = {
    0.006135431f, 0.017681968f, 0.004625602f, -0.029572459f, -0.018142780f, 0.047592262f, 0.044064061f,
    -0.077548163f, -0.108223872f, 0.144370264f, 0.472043502f, 0.477330397f, 0.149507312f, -0.113412404f,
    -0.082276583f, 0.048922649f, 0.051668658f, -0.022523893f, -0.032709100f, 0.008627121f, 0.019287982f,
    -0.000285329f, -0.007162628f};
#define SH_DELAY 11u

typedef struct {
    float tone, up[16], dn[32], dly[16], u1, f1, dcx, dcy, dark, held, hph;
    uint8_t ui, di;
} sh_ch;
typedef struct {
    sh_ch c[2];
    uint8_t on, ms, model, warm;               /* warm: blocks still to run unheard after switching on */
    float xf;                                   /* 0..1: the shaper faded in (switching on / off: no click) */
    float g, ein, eout, env;                    /* level match; TUBE's sag follower */
    /* this block's parameters */
    float drive, bias, a, b, tone_g, dry, wet, dark_g, hold_inc, fm, k, cpos, cneg, s, w, sx, bits, q, post, p[8], P[9];
} sh_t;
static sh_t shp[NTRACK] __attribute__((section(".pool")));

/* ---------------------------------------------------------------- the models --- */
/* sin(pi/2 x), any x: period 4, odd polynomial on the quarter (|error| < 2e-7) */
static float sh_sinq(float x)
{
    float z;
    x -= 4.0f * (float)(int32_t)(x * 0.25f);
    if (x < -2.0f) x += 4.0f; else if (x >= 2.0f) x -= 4.0f;
    if (x > 1.0f) x = 2.0f - x; else if (x < -1.0f) x = -2.0f - x;
    z = x * 1.57079633f;
    {
        float z2 = z * z;
        return z * (1.0f + z2 * (-0.16666666642f + z2 * (0.0083333293859f + z2 * (-0.00019840874f + z2 * 2.7525562e-6f))));
    }
}

static float sh_soft(float u) { return u / os_sqrt(1.0f + u * u); }
static float sh_soft_F(float u) { float u2 = u * u; return u2 / (os_sqrt(1.0f + u2) + 1.0f); }
static float sh_cub(float u) { float v = os_clampf(u, -1.0f, 1.0f); return 1.5f * v - 0.5f * v * v * v; }
static float sh_cub_F(float u) { float v = u < 0.0f ? -u : u; return v < 1.0f ? v * v * (0.75f - 0.125f * v * v) : v - 0.375f; }

static float sh_kclip(float u, float k)
{
    float v = u < 0.0f ? -u : u, r = v <= 1.0f - k ? v : v < 1.0f + k ? v - (v - 1.0f + k) * (v - 1.0f + k) / (4.0f * k) : 1.0f;
    return u < 0.0f ? -r : r;
}
static float sh_kclip_F(float u, float k)
{
    float v = u < 0.0f ? -u : u, d;
    if (v <= 1.0f - k) return 0.5f * v * v;
    if (v < 1.0f + k) { d = v - 1.0f + k; return 0.5f * v * v - d * d * d / (12.0f * k); }
    return 0.5f * (1.0f + k) * (1.0f + k) - 0.6666667f * k * k + v - 1.0f - k;
}

static float sh_tri(float u)
{
    float t = u + 1.0f;
    t -= 4.0f * (float)(int32_t)(t * 0.25f);
    if (t < 0.0f) t += 4.0f;
    return t < 2.0f ? t - 1.0f : 3.0f - t;
}
static float sh_tri_F(float u)
{
    float t = u + 1.0f;
    t -= 4.0f * (float)(int32_t)(t * 0.25f);
    if (t < 0.0f) t += 4.0f;
    return t < 2.0f ? 0.5f * (t - 1.0f) * (t - 1.0f) - 0.5f : 3.0f * t - 0.5f * t * t - 4.0f;
}

static float sh_poly(const float *p, float x) { return ((((((p[7] * x + p[6]) * x + p[5]) * x + p[4]) * x + p[3]) * x + p[2]) * x + p[1]) * x + p[0]; }
static float sh_polyF(const float *P, float x) { return (((((((P[8] * x + P[7]) * x + P[6]) * x + P[5]) * x + P[4]) * x + P[3]) * x + P[2]) * x + P[1]) * x; }

/* f(u) */
static float sh_f(const sh_t *s, float u)
{
    switch (s->model) {
    case SH_TAPE: return (1.0f - s->a) * sh_soft(u) + s->a * sh_cub(u);
    case SH_TUBE: return u >= 0.0f ? sh_soft(u) : u / os_sqrt(1.0f + s->s * s->s * u * u);
    case SH_CLIP: return u >= 0.0f ? sh_kclip(u, s->k) : s->cneg * sh_kclip(u / s->cneg, s->k);
    case SH_FOLD: return (1.0f - s->a) * sh_tri(u) + s->a * sh_sinq(u);
    case SH_XOVR: return u - s->w * u / os_sqrt(u * u + s->sx * s->sx);
    case SH_RECT: return u >= 0.0f ? u : -s->a * u;
    default: {                                  /* CHEB, POLY: a polynomial inside +-1, held outside */
        float c = os_clampf(u, -1.0f, 1.0f);
        return sh_poly(s->p, c);
    }
    }
}

/* F(u): the anti-derivative (any constant) */
static float sh_F(const sh_t *s, float u)
{
    switch (s->model) {
    case SH_TAPE: return (1.0f - s->a) * sh_soft_F(u) + s->a * sh_cub_F(u);
    case SH_TUBE: { float u2 = u * u; return u >= 0.0f ? sh_soft_F(u) : u2 / (os_sqrt(1.0f + s->s * s->s * u2) + 1.0f); }
    case SH_CLIP: return u >= 0.0f ? sh_kclip_F(u, s->k) : s->cneg * s->cneg * sh_kclip_F(u / s->cneg, s->k);
    case SH_FOLD: return (1.0f - s->a) * sh_tri_F(u) - s->a * 0.63661977f * sh_sinq(u + 1.0f);
    case SH_XOVR: { float u2 = u * u, r = os_sqrt(u2 + s->sx * s->sx); return 0.5f * u2 - s->w * u2 / (r + s->sx); }
    case SH_RECT: return u >= 0.0f ? 0.5f * u * u : -0.5f * s->a * u * u;
    default: {
        float c = os_clampf(u, -1.0f, 1.0f), F = sh_polyF(s->P, c);
        if (u > 1.0f) F += (u - 1.0f) * s->cpos;
        else if (u < -1.0f) F += (u + 1.0f) * s->cneg;
        return F;
    }
    }
}

/* one sample at 16 kHz (the core's 2x): ADAA, or the bit crusher */
static float sh_shape(sh_t *s, sh_ch *c, float u)
{
    float d = u - c->u1, y, F;
    if (s->model == SH_BITS) {                  /* held, then quantised: no ADAA (the crunch is the sound) */
        c->hph += s->hold_inc;
        if (c->hph >= 1.0f) {
            float v = os_clampf(u, -1.0f, 1.0f) * s->q;
            c->hph -= (float)(int32_t)c->hph;
            c->held = (float)(int32_t)(v + (v >= 0.0f ? 0.5f : -0.5f)) / s->q;
        }
        c->u1 = u;
        return c->held;
    }
    F = sh_F(s, u);
    if (d > 1e-3f * (1.0f + (u < 0.0f ? -u : u)) || -d > 1e-3f * (1.0f + (u < 0.0f ? -u : u)))
        y = (F - c->f1) / d;
    else
        y = sh_f(s, 0.5f * (u + c->u1));
    c->u1 = u;
    c->f1 = F;
    return y;
}

/* ---------------------------------------------------------------- the block --- */
static const float SH_CHEB_T[8][8] = {           /* T0..T7, power basis */
    {1, 0, 0, 0, 0, 0, 0, 0}, {0, 1, 0, 0, 0, 0, 0, 0}, {-1, 0, 2, 0, 0, 0, 0, 0}, {0, -3, 0, 4, 0, 0, 0, 0},
    {1, 0, -8, 0, 8, 0, 0, 0}, {0, 5, 0, -20, 0, 16, 0, 0}, {-1, 0, 18, 0, -48, 0, 32, 0}, {0, -7, 0, 56, 0, -112, 0, 64}};

/* the parameters of this block, from the registers; on: the shaper runs (WET > 0, or fading out) */
static void sh_block(uint32_t k)
{
    trk_t *t = &os.trk[k];
    sh_t *s = &shp[k];
    const uint8_t *e = t->eff;
    uint32_t i, model = e[R_SMD] < SH_N ? e[R_SMD] : 0u, sub = t->mach == MA_WAVE ? WIDE : 1u;
    float fs2 = 2.0f * (float)(CORE_SR * sub), m = (float)e[R_SMX] * (1.0f / 127.0f);
    if (!s->on && !e[R_SMX]) { t->shw = 0.0f; return; }
    if (!s->on) {                               /* switched on: from rest */
        memset(s->c, 0, sizeof s->c);
        s->xf = 0.0f; s->g = 1.0f; s->ein = s->eout = 0.0f; s->env = 0.0f;
        s->on = 1;
        s->warm = 4;                            /* 8 ms unheard: the chain fills and the level match settles */
    }
    if (t->ms != s->ms) { memset(&s->c[1], 0, sizeof s->c[1]); s->ms = t->ms; }
    if (!e[R_SMX]) {                            /* fading out: as it was, to the end of the fade */
        t->shw = e[R_SPS] ? s->xf * s->wet / (s->wet + s->dry) : 0.0f;
        return;
    }
    s->a = (float)e[R_SA] * (1.0f / 127.0f);
    s->b = (float)e[R_SB] * (1.0f / 127.0f);
    s->drive = 1.0f / fx_fexp(-(float)e[R_SIN] * (36.0f / 127.0f) * 0.11512925f);
    s->bias = ((float)e[R_SBI] - 64.0f) * (1.0f / 63.0f);
    s->tone_g = 0.0f;
    if (e[R_STN] < 127u) {                      /* the tone: 200 Hz .. 4 kHz, one pole (TPT) */
        float w = 3.14159265f * 200.0f / fx_fexp(-(float)e[R_STN] * (4.32f / 126.0f) * 0.69314718f) / (fs2 * 0.5f);
        if (w > 1.35f) w = 1.35f;
        w = w * (15.0f - w * w) / (15.0f - 6.0f * w * w);
        s->tone_g = w / (1.0f + w);
    }
    s->dry = 2.0f * (1.0f - m); if (s->dry > 1.0f) s->dry = 1.0f;
    s->wet = 2.0f * m; if (s->wet > 1.0f) s->wet = 1.0f;
    s->fm = 1.0f; s->dark_g = 0.0f; s->hold_inc = 1.0f;
    s->post = model == SH_XOVR || model == SH_RECT ? 1.0f / s->drive : 1.0f;   /* (they do not saturate: undo INP) */
    s->model = (uint8_t)model;
    switch (model) {
    case SH_TAPE:
        if (s->b > 0.0f) {                      /* darkening: 4 kHz .. 800 Hz after the shaper */
            float w = 3.14159265f * 4000.0f * fx_fexp(-2.3f * s->b * 0.69314718f) / (fs2 * 0.5f);
            if (w > 1.35f) w = 1.35f;
            w = w * (15.0f - w * w) / (15.0f - 6.0f * w * w);
            s->dark_g = w / (1.0f + w);
        }
        break;
    case SH_TUBE: s->s = 1.0f + 3.0f * s->a; break;
    case SH_CLIP: s->k = 0.01f + 0.89f * s->a; s->cneg = 1.0f - 0.8f * s->b; break;
    case SH_FOLD: s->fm = 1.0f + 7.0f * s->b; break;
    case SH_XOVR: s->w = 0.5f * s->a; s->sx = 0.002f + 0.3f * s->b; break;
    case SH_BITS: {
        float bits = 16.0f - 15.0f * s->a;
        s->q = 1.0f / fx_fexp((1.0f - bits) * 0.69314718f);       /* +-1 in 2^bits steps */
        s->hold_inc = fx_fexp(-6.0f * s->b * 0.69314718f);        /* 16 kHz .. 250 Hz (the core's 2x) */
        break;
    }
    case SH_CHEB: case SH_POLY: {
        float c[8] = {0, 0, 0, 0, 0, 0, 0, 0};
        if (model == SH_CHEB) {
            float h = 2.0f + 5.0f * s->a, fr;
            uint32_t n = (uint32_t)h;
            if (n > 6u) n = 6u;
            fr = h - (float)n;
            for (i = 0; i < 8u; i++) c[i] = (1.0f - s->b) * ((1.0f - fr) * SH_CHEB_T[n][i] + fr * SH_CHEB_T[n + 1u][i]);
            c[1] += s->b;
        } else {
            c[1] = 1.0f;
            c[2] = ((float)e[R_SA] - 64.0f) * (1.0f / 63.0f);
            c[3] = -0.6666667f * s->b;
        }
        for (i = 0; i < 8u; i++) { s->p[i] = c[i]; s->P[i + 1u] = c[i] / (float)(i + 1u); }
        s->P[0] = 0.0f;
        s->cpos = sh_poly(s->p, 1.0f);
        s->cneg = sh_poly(s->p, -1.0f);
        break;
    }
    default: break;
    }
    for (i = 0; i < 2u; i++) s->c[i].f1 = sh_F(s, s->c[i].u1);   /* (the parameters changed: F of the last u again) */
    /* the level match: the block's energies, ~50 ms */
    if (s->ein + s->eout > 0.0f) {
        float gt = os_sqrt((s->ein + 1e-9f) / (s->eout + 1e-9f));
        s->g += (os_clampf(gt, 0.01f, 4.0f) - s->g) * (s->warm ? 0.5f : 0.08f);
    } else if (s->g <= 0.0f) s->g = 1.0f;
    if (s->warm) s->warm--;
    s->ein = s->eout = 0.0f;
    /* the air: POST, this share of the track never went through the filter */
    t->shw = e[R_SPS] ? s->xf * s->wet / (s->wet + s->dry) : 0.0f;
}

/* one channel's sample through the chain (its rate's samples): out = the dry delayed and the wet */
static float sh_tick(sh_t *s, sh_ch *c, float x, float *dry_out)
{
    float v, ue, uo, y, acc = 0.0f;
    uint32_t j;
    c->dly[c->ui & 15u] = x;                                     /* the dry, delayed by the chain's 11 */
    *dry_out = c->dly[(c->ui - SH_DELAY) & 15u];
    if (s->tone_g > 0.0f) {                                      /* the tone: one pole, TPT */
        float d = (x - c->tone) * s->tone_g;
        v = d + c->tone;
        c->tone = v + d;
    } else {
        v = c->tone = x;
    }
    v *= s->drive;
    c->up[c->ui & 15u] = v;
    for (j = 0; j < 12u; j++) acc += SH_UP[j] * c->up[(c->ui - j) & 15u];
    ue = acc;                                                    /* the even 16 kHz sample */
    uo = c->up[(c->ui - 5u) & 15u];                              /* the odd one: the half-band's centre */
    c->ui++;
    {
        float bias = s->bias;
        if (s->model == SH_TUBE && s->b > 0.0f) {                /* sag: the bias follows the level */
            float a = v < 0.0f ? -v : v;
            s->env += (a - s->env) * (a > s->env ? 0.02f : 0.0012f);
            bias -= 0.5f * s->b * s->env;
        }
        c->dn[c->di & 31u] = sh_shape(s, c, ue * s->fm + bias);
        for (j = 0, acc = 0.0f; j < 23u; j++) acc += SH_DN[j] * c->dn[(c->di - j) & 31u];
        c->di++;
        c->dn[c->di & 31u] = sh_shape(s, c, uo * s->fm + bias);
        c->di++;
    }
    acc *= s->post;
    y = acc - c->dcx + 0.9961f * c->dcy;                         /* DC blocker (~5 Hz at 8 kHz) */
    c->dcx = acc;
    c->dcy = y;
    if (s->dark_g > 0.0f) {                                     /* TAPE's darkening */
        float d = (y - c->dark) * s->dark_g;
        y = d + c->dark;
        c->dark = y + d;
    }
    return y;
}

/* the track's n samples (its rate) in place: x the mid (or mono), xs the side or 0 */
static void sh_run(uint32_t k, float *x, float *xs, uint32_t n)
{
    sh_t *s = &shp[k];
    const trk_t *t = &os.trk[k];
    uint32_t i;
    float want = t->eff[R_SMX] && !s->warm ? 1.0f : 0.0f, xs_step = 0.25f / (float)(BLK * (t->mach == MA_WAVE ? WIDE : 1u));
    if (!s->on) return;
    for (i = 0; i < n; i++) {
        float d0, d1, w0, w1, g;
        if (s->xf != want) {                                    /* fade in / out over 4 blocks (8 ms) */
            s->xf += want > s->xf ? xs_step : -xs_step;
            if (s->xf < 0.0f) s->xf = 0.0f; else if (s->xf > 1.0f) s->xf = 1.0f;
        }
        g = s->g * s->wet;
        if (xs) {
            float l = x[i] + xs[i], r = x[i] - xs[i], ol, or_;
            w0 = sh_tick(s, &s->c[0], l, &d0);
            w1 = sh_tick(s, &s->c[1], r, &d1);
            s->ein += d0 * d0 + d1 * d1;
            s->eout += w0 * w0 + w1 * w1;
            ol = d0 * s->dry + w0 * g;
            or_ = d1 * s->dry + w1 * g;
            ol = l + (ol - l) * s->xf;
            or_ = r + (or_ - r) * s->xf;
            x[i] = 0.5f * (ol + or_);
            xs[i] = 0.5f * (ol - or_);
        } else {
            float o;
            w0 = sh_tick(s, &s->c[0], x[i], &d0);
            s->ein += d0 * d0;
            s->eout += w0 * w0;
            o = d0 * s->dry + w0 * g;
            x[i] = x[i] + (o - x[i]) * s->xf;
        }
    }
    if (!t->eff[R_SMX] && s->xf == 0.0f) s->on = 0;            /* faded out: off, no CPU */
}
