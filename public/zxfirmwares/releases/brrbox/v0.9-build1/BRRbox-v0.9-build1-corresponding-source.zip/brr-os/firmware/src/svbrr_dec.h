#ifndef SVBRR_DEC_H
#define SVBRR_DEC_H
#include <stdint.h>
#ifndef SV_API
#define SV_API          /* os.c: static (one translation unit); host tests: extern */
#endif

typedef struct {
    const uint8_t *blob, *dir;
    uint32_t len;
    uint16_t core_sr, kf_len, n;
    uint8_t ver;                       /* 2: keyframes start from silence, 3: from stored seeds */
} sv_lib;

typedef struct {
    uint32_t core_len, kf_off, side_off, loop_start, loop_end;
    uint16_t n_kf, n_frames;
    uint8_t root;
    int8_t hf_off;                     /* side info: the code window's offset, 3 dB steps (directory byte 25) */
} sv_info;

typedef struct {
    const sv_lib *lib;
    sv_info info;
    const uint8_t *seg;
    uint32_t seg_len, bitpos;          /* bitpos: byte position in the segment */
    uint32_t code;                     /* rANS state */
    int32_t p1, p2, bidx;
    int32_t seg_k, per, per_shift;
    int16_t prev_s;
    uint8_t prev_mode, hdr_mode;
    int32_t hdr_half;
    uint32_t stat_blocks, stat_restarts;
    int16_t block[16];                 /* one SV_BLK block */
} sv_reader;

typedef struct {
    sv_reader rd;
    float pos, rate, gain;
    uint32_t loop_start, loop_end;
    uint8_t active;
} sv_voice;

SV_API int sv_open(sv_lib *L, const uint8_t *blob, uint32_t len);
SV_API void sv_sample_info(const sv_lib *L, int si, sv_info *o);
SV_API void sv_reader_init(sv_reader *r, const sv_lib *L, int si);
SV_API const int16_t *sv_block(sv_reader *r, int32_t b);
SV_API void voice_render(sv_voice *v, float *out, int n);
SV_API void sv_side_frame(const sv_lib *L, const sv_info *in, int fr, uint8_t codes[8], uint8_t *ton);
SV_API int sv_decode_all(const sv_lib *L, int si, int16_t *out, uint32_t max);
SV_API unsigned sv_reader_bytes(void);
SV_API unsigned sv_voice_bytes(void);
#endif
