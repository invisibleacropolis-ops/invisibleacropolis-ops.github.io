/* SPDX-License-Identifier: GPL-3.0-only */
/* The vault: presets in the 120 KiB data area (FL_DATA 0x9D000-0xBAFFF) and nowhere else (the user sample
 * area stays the samples'). A log of chunks, written once, found again by reading.
 *
 *   chunk     a 28-byte header (magic, type, id, part, LAST, format version, generation, sequence, length,
 *             payload CRC-32, header CRC-32), then the payload, padded to 4 bytes. A chunk never crosses a 4 KiB
 *             sector, so every sector reads on its own from its first byte
 *   record    a sound or a kit is its chunks 0 .. LAST of one generation (the sequence number it was begun
 *             at). A record is there only once its LAST chunk is: a save cut short by the power leaves the one
 *             before it whole. Only the newest whole generation of a (type, id) counts; a deletion is a
 *             one-chunk generation of its own
 *   the ring  chunks go at the head, sector after sector, round the area. The sector after the head's never
 *             holds anything live: moving into a new sector first copies the live chunks of the one after it
 *             in (they fit: they filled at most a sector), so that one can be erased next time round. Every
 *             sector is erased in turn: the wear is spread by construction. A copy cut short by the power is
 *             finished in place at the next boot (the same bytes again: programming only takes bits to 0)
 *   erasing   an erase stops the audio for tens of ms, so only when allowed (stopped): a save that would need
 *             one while playing is refused before anything is written (a dry run plans it first); when stopped
 *             and silent, vault_idle erases a dead sector ahead now and then, so saves while playing find room
 *   streaming nothing holds a whole record in RAM: a record is made by a producer a window (VT_PIECE) at a
 *             time (the kit encoder writes the kit again and keeps one window), and read back the same way
 *   foreign   an area holding anything that is not ours (Felucca's store, the stock VM) is left alone: nothing
 *             is written until vault_format, which the owner asks for. A blank area is claimed at once with a
 *             small owner record, so a later save cut short is never taken for someone else's bytes
 * What is programmed is always in RAM (the flash cannot be read while it programs). Every flash access goes
 * through st_read / st_erase / st_prog (storage_hw.c on the unit, a simulated NOR on the host), which refuse
 * anything outside the storage areas; the vault itself stays inside FL_DATA. */

#define VT_LO FL_DATA_LO
#define VT_HI FL_DATA_HI
#define VT_SEC 0x1000u
#define VT_NSEC ((VT_HI - VT_LO) / VT_SEC)
#define VT_HDR 28u
#define VT_MAGIC 0x5642u                        /* "BV" */
#define VT_NIDX 384u                            /* chunks the RAM index holds */
#define VT_AHEAD 3u                             /* erased sectors vault_idle keeps ahead of the head */
#define VT_PIECE 1024u                          /* the window records pass through */
#define VT_MAXREC 0xFFFF0u                      /* (a record's length: below this) */
_Static_assert(VT_NSEC <= 32u && VT_NSEC >= 4u, "the vault's sector masks are 32 bits");
_Static_assert(VT_LO >= FL_DATA_LO && VT_HI <= FL_DATA_HI, "the vault stays in FL_DATA");

enum { VT_OK = 0, VT_BUSY = -1, VT_FULL = -2, VT_EIO = -3, VT_NONE = -4, VT_FOREIGN = -5, VT_BIG = -6, VT_MOVED = -7 };
enum { VT_DEL = 0x80u, VT_OWN = 0x7Eu };       /* type bit: a deletion; the owner mark */

typedef struct { uint32_t off, gen, seq; uint16_t id, len; uint8_t type, part, last, live; } vt_ent;
static vt_ent vt_idx[VT_NIDX] __attribute__((section(".pool")));
static uint8_t vt_piece[VT_PIECE] __attribute__((section(".pool")));
static uint32_t vt_repairs;                    /* (counted for the host checks) copies finished at mount */
static struct {
    uint32_t n, hs, head, seq, blank;           /* hs: the head's sector, head in it; blank: sectors known erased */
    uint8_t mounted, foreign, err;
} vt;

/* a record's bytes [lo, lo + n) into dst (RAM); 0, or not */
typedef int (*vt_src_fn)(void *ctx, uint32_t lo, uint8_t *dst, uint32_t n);

/* ---------------------------------------------------------------- helpers --- */
static uint32_t vt_crc(uint32_t c, const uint8_t *p, uint32_t n)   /* CRC-32 (IEEE), bitwise: no table */
{
    uint32_t i;
    c = ~c;
    while (n--) {
        c ^= *p++;
        for (i = 0; i < 8u; i++) c = c >> 1 ^ (0xEDB88320u & (0u - (c & 1u)));
    }
    return ~c;
}
static uint32_t rd32(const uint8_t *p) { return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }
static void wr32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }
static uint32_t vt_sec(uint32_t off) { return (off - VT_LO) / VT_SEC; }
static uint32_t vt_start(uint32_t s) { return VT_LO + s * VT_SEC; }
static uint32_t vt_next(uint32_t s) { return s + 1u < VT_NSEC ? s + 1u : 0u; }
static uint32_t vt_size(uint32_t len) { return (VT_HDR + len + 3u) & ~3u; }

/* n bytes at off all 0xFF */
static int vt_is_blank(uint32_t off, uint32_t n)
{
    uint8_t b[64];
    while (n) {
        uint32_t k = n > sizeof b ? sizeof b : n, i;
        if (st_read(off, b, k)) return 0;
        for (i = 0; i < k; i++) if (b[i] != 0xFFu) return 0;
        off += k; n -= k;
    }
    return 1;
}

/* the bytes at off could still become p (no bit at 0 where p wants 1): a write cut short, to be finished */
static int vt_can_finish(uint32_t off, const uint8_t *p, uint32_t n)
{
    uint8_t b[64];
    uint32_t i;
    while (n) {
        uint32_t k = n > sizeof b ? sizeof b : n;
        if (st_read(off, b, k)) return 0;
        for (i = 0; i < k; i++) if ((uint8_t)~b[i] & p[i]) return 0;
        off += k; p += k; n -= k;
    }
    return 1;
}

/* the CRC of n flash bytes at off */
static int vt_crc_flash(uint32_t off, uint32_t n, uint32_t *crc)
{
    uint8_t b[64];
    uint32_t c = 0;
    while (n) {
        uint32_t k = n > sizeof b ? sizeof b : n;
        if (st_read(off, b, k)) return -1;
        c = vt_crc(c, b, k);
        off += k; n -= k;
    }
    *crc = c;
    return 0;
}

/* the chunk header at off: 1 (good: *e filled, payload checked), 0 (blank), -1 (anything else) */
static int vt_read_hdr(uint32_t off, vt_ent *e)
{
    uint8_t h[VT_HDR];
    uint32_t i, len, c;
    if (st_read(off, h, VT_HDR)) return -1;
    for (i = 0; i < VT_HDR && h[i] == 0xFFu; i++) {}
    if (i == VT_HDR) return 0;
    if ((uint32_t)(h[0] | h[1] << 8) != VT_MAGIC || vt_crc(0, h, 24) != rd32(h + 24)) return -1;
    len = (uint32_t)(h[16] | h[17] << 8);
    if (off + vt_size(len) > vt_start(vt_sec(off)) + VT_SEC) return -1;
    if (vt_crc_flash(off + VT_HDR, len, &c) || c != rd32(h + 20)) return -1;
    e->off = off; e->type = h[2]; e->last = h[3] & 1u; e->id = (uint16_t)(h[4] | h[5] << 8); e->part = h[6];
    e->gen = rd32(h + 8); e->seq = rd32(h + 12); e->len = (uint16_t)len; e->live = 0;
    return 1;
}

/* LAST chunk e's generation is whole: parts 0 .. e->part all there (any copy) */
static int vt_whole(const vt_ent *e)
{
    uint32_t p, j;
    for (p = 0; p < e->part; p++) {
        for (j = 0; j < vt.n; j++) {
            const vt_ent *f = &vt_idx[j];
            if (f->type == e->type && f->id == e->id && f->gen == e->gen && f->part == p && !f->last) break;
        }
        if (j == vt.n) return 0;
    }
    return 1;
}

/* which chunks count: per (type, id) the newest whole generation (a deletion is one too); of it, the newest
 * copy of each part. O(n^2 x parts), n <= VT_NIDX: run between writes */
static void vt_mark(void)
{
    uint32_t i, j;
    for (i = 0; i < vt.n; i++) vt_idx[i].live = 0;
    for (i = 0; i < vt.n; i++)                  /* 2: a LAST chunk of a whole generation */
        if (vt_idx[i].last && vt_whole(&vt_idx[i])) vt_idx[i].live = 2;
    for (i = 0; i < vt.n; i++) {
        vt_ent *e = &vt_idx[i];
        if (e->live != 2) continue;
        for (j = 0; j < vt.n; j++) {             /* a newer whole generation of the same (type, id)? */
            const vt_ent *f = &vt_idx[j];
            if (f->live >= 2 && (f->type & 0x7Fu) == (e->type & 0x7Fu) && f->id == e->id && (int32_t)(f->gen - e->gen) > 0) break;
        }
        e->live = j == vt.n ? 3u : 4u;           /* 3: the current one's LAST; 4: an old one's */
    }
    for (i = 0; i < vt.n; i++) {
        const vt_ent *e = &vt_idx[i];
        if (e->live != 3) continue;
        for (j = 0; j < vt.n; j++) {             /* its parts: the newest copy of each */
            vt_ent *f = &vt_idx[j];
            uint32_t m;
            if (f->type != e->type || f->id != e->id || f->gen != e->gen || f->part > e->part) continue;
            for (m = 0; m < vt.n; m++) {
                const vt_ent *g = &vt_idx[m];
                if (m != j && g->type == f->type && g->id == f->id && g->gen == f->gen && g->part == f->part &&
                    ((int32_t)(g->seq - f->seq) > 0)) break;
            }
            if (m == vt.n && f->live != 3) f->live = 1;
        }
    }
    for (i = 0; i < vt.n; i++) {                 /* the current LASTs: live unless a newer copy of it exists */
        vt_ent *f = &vt_idx[i];
        uint32_t m;
        if (f->live == 4) { f->live = 0; continue; }
        if (f->live != 3) continue;
        for (m = 0; m < vt.n; m++) {
            const vt_ent *g = &vt_idx[m];
            if (m != i && g->type == f->type && g->id == f->id && g->gen == f->gen && g->part == f->part && (int32_t)(g->seq - f->seq) > 0) break;
        }
        f->live = m == vt.n;
    }
}

/* the index without what no longer counts (only between writes: a record being written is not whole yet) */
static void vt_compact(void)
{
    uint32_t i, j = 0;
    vt_mark();
    for (i = 0; i < vt.n; i++) if (vt_idx[i].live) vt_idx[j++] = vt_idx[i];
    vt.n = j;
}

static uint32_t vt_live_in(uint32_t s, uint32_t skip)   /* bytes of live chunks in sector s (not if s is in skip) */
{
    uint32_t i, b = 0;
    if (skip >> s & 1u) return 0;
    for (i = 0; i < vt.n; i++) if (vt_idx[i].live && vt_sec(vt_idx[i].off) == s) b += vt_size(vt_idx[i].len);
    return b;
}

/* ---------------------------------------------------------------- writing chunks --- */
/* one chunk at *head (its room checked by the caller): its payload from src (bytes [lo, lo + len) of the
 * record) a window at a time, then its header; read back. finish: the same chunk was being written there when
 * the power went, so the same bytes again complete it */
static int vt_chunk_at(uint32_t *head, uint32_t *seq, uint32_t type, uint32_t id, uint32_t part, uint32_t last,
                       uint32_t gen, vt_src_fn src, void *ctx, uint32_t lo, uint32_t len, int finish)
{
    uint8_t h[VT_HDR];
    uint32_t off = *head, pad = vt_size(len) - VT_HDR - len, o, crc = 0;
    vt_ent e;
    if (vt.n >= VT_NIDX) return VT_FULL;
    if (!finish && !vt_is_blank(off, vt_size(len))) return VT_EIO;
    if (finish && !vt_is_blank(off + VT_HDR + len, pad)) return VT_EIO;
    for (o = 0; o < len; o += VT_PIECE) {       /* the payload first: a cut here leaves no header, no chunk */
        uint32_t k = len - o < VT_PIECE ? len - o : VT_PIECE;
        if (src(ctx, lo + o, vt_piece, k)) return VT_EIO;
        crc = vt_crc(crc, vt_piece, k);
        if (finish && !vt_can_finish(off + VT_HDR + o, vt_piece, k)) return VT_EIO;
        if (st_prog(off + VT_HDR + o, vt_piece, k)) return VT_EIO;
    }
    h[0] = (uint8_t)VT_MAGIC; h[1] = (uint8_t)(VT_MAGIC >> 8); h[2] = (uint8_t)type; h[3] = (uint8_t)(last | ST_VER << 4);
    h[4] = (uint8_t)id; h[5] = (uint8_t)(id >> 8); h[6] = (uint8_t)part; h[7] = 0xFF;
    wr32(h + 8, gen); wr32(h + 12, *seq);
    h[16] = (uint8_t)len; h[17] = (uint8_t)(len >> 8); h[18] = h[19] = 0xFF;
    wr32(h + 20, crc);
    wr32(h + 24, vt_crc(0, h, 24));
    if (finish && !vt_can_finish(off, h, VT_HDR)) return VT_EIO;
    if (st_prog(off, h, VT_HDR)) return VT_EIO;
    if (vt_read_hdr(off, &e) != 1 || e.seq != *seq) return VT_EIO;
    vt_idx[vt.n++] = e;
    *head += vt_size(len);
    (*seq)++;
    return VT_OK;
}

/* a source of flash bytes: a chunk's payload, for a copy */
static int vt_src_flash(void *ctx, uint32_t lo, uint8_t *dst, uint32_t n)
{
    return st_read(*(const uint32_t *)ctx + lo, dst, n);
}

/* the live chunks of sector m copied to *head in sector hs (they fit: the caller knows), with newer sequence
 * numbers: the originals stop counting. finish: the first copy was cut short there */
static int vt_relocate(uint32_t m, uint32_t hs, uint32_t *head, uint32_t *seq, int finish)
{
    uint32_t i, n0 = vt.n;
    for (i = 0; i < n0; i++) {
        vt_ent e = vt_idx[i];
        uint32_t from = e.off + VT_HDR;
        int r;
        if (!e.live || vt_sec(e.off) != m) continue;
        if (vt_start(hs) + VT_SEC - *head < vt_size(e.len)) return VT_EIO;
        r = vt_chunk_at(head, seq, e.type, e.id, e.part, e.last, e.gen, vt_src_flash, &from, 0, e.len, finish);
        finish = 0;                                              /* (only the first can have been cut) */
        if (r) return r;
        vt_idx[vt.n - 1u].live = 1;
        vt_idx[i].live = 0;
    }
    return VT_OK;
}

/* ---------------------------------------------------------------- mount --- */
static int vault_put_src(uint32_t type, uint32_t id, vt_src_fn src, void *ctx, uint32_t len, int may_erase);
static int vt_src_ram(void *ctx, uint32_t lo, uint8_t *dst, uint32_t n)
{
    const uint8_t *p = ctx;
    uint32_t i;
    for (i = 0; i < n; i++) dst[i] = p[lo + i];
    return 0;
}

/* read the area: the chunks, the head (after the newest chunk), what is erased; then a copy the power cut
 * short finished (the head's next sector still holding live chunks). VT_OK, VT_EIO */
static int vault_mount(void)
{
    uint32_t s, newest = 0, have = 0, dirty = 0;
    vt.n = 0; vt.blank = 0; vt.foreign = 0; vt.err = 0; vt.mounted = 0;
    if (!flash_ok) return VT_EIO;
    for (s = 0; s < VT_NSEC; s++) {
        uint32_t off = vt_start(s), end = off + VT_SEC;
        vt_ent e;
        while (off + VT_HDR <= end && vt_read_hdr(off, &e) == 1) {
            if (vt.n >= VT_NIDX) vt_compact();
            if (vt.n >= VT_NIDX) { vt.err = 1; break; }
            vt_idx[vt.n++] = e;
            if (!have || (int32_t)(e.seq - newest) > 0) { newest = e.seq; vt.hs = s; vt.head = off + vt_size(e.len); }
            have = 1;
            off += vt_size(e.len);
        }
        if (off == vt_start(s) && vt_is_blank(off, VT_SEC)) vt.blank |= 1u << s;
        else if (off == vt_start(s)) dirty = 1;
    }
    vt.foreign = (uint8_t)(!have && dirty);      /* not one chunk of ours, and bytes: another firmware's store */
    vt_compact();
    if (!have) { vt.hs = VT_NSEC - 1u; vt.head = VT_HI; vt.seq = 1; }
    else {
        uint32_t end = vt_start(vt.hs) + VT_SEC, m = vt_next(vt.hs);
        int torn = vt.head < end && !vt_is_blank(vt.head, end - vt.head);
        vt.seq = newest + 1u;
        if (vt_live_in(m, 0) && !vt.err) {      /* a copy cut short: the ring's next sector still live. Finish */
            vt_repairs++;                        /* the cut copy in place, then the rest */
            if (vt_relocate(m, vt.hs, &vt.head, &vt.seq, torn)) vt.err = 1;
            vt_compact();
        } else if (torn) vt.head = end;         /* a chunk of a record cut short: no more room here */
    }
    vt.mounted = 1;
    if (!have && !dirty && !vt.err) {            /* blank: ours from now on */
        static const char OWN[6] = "BRR-OS";
        uint8_t own[6];
        uint32_t i;
        for (i = 0; i < 6u; i++) own[i] = (uint8_t)OWN[i];      /* (from RAM: the flash is busy while it programs) */
        return vault_put_src(VT_OWN, 0, vt_src_ram, own, 6u, 1);
    }
    return vt.err ? VT_EIO : VT_OK;
}

/* ---------------------------------------------------------------- writing records --- */
/* the plan of a write: a dry run keeps its head, sector states and copies here */
typedef struct { uint32_t hs, head, seq, blank, moved, adds; int dry, may_erase; } vt_run;

/* the head into the next sector: it must be erased (or dead: erased now, if allowed); then the live chunks of
 * the sector after it are copied in, so that one holds nothing live */
static int vt_advance(vt_run *w)
{
    uint32_t n = vt_next(w->hs), m = vt_next(n), i;
    if (!(w->blank >> n & 1u)) {
        if (vt_live_in(n, w->moved)) return VT_EIO;             /* (the ring's rule broken: never written so) */
        if (!w->may_erase) return VT_BUSY;
        if (!w->dry && st_erase(vt_start(n))) return VT_EIO;
        w->blank |= 1u << n;
    }
    w->hs = n;
    w->head = vt_start(n);
    w->blank &= ~(1u << n);
    if (w->dry) {                                                /* the copies take their room */
        w->head += vt_live_in(m, w->moved);
        for (i = 0; i < vt.n; i++) if (vt_idx[i].live && vt_sec(vt_idx[i].off) == m) w->adds++;
    } else {
        int r = vt_relocate(m, n, &w->head, &w->seq, 0);
        if (r) return r;
    }
    w->moved |= 1u << m;
    return VT_OK;
}

/* a record's chunks from the head: split to fill each sector, advancing as it goes */
static int vt_write(vt_run *w, uint32_t type, uint32_t id, vt_src_fn src, void *ctx, uint32_t len)
{
    uint32_t pos = 0, part = 0, gen = w->seq, guard = 0;
    for (;;) {
        uint32_t room = vt_start(w->hs) + VT_SEC - w->head, ch;
        int r;
        if (room < vt_size(len - pos) && room < VT_HDR + 64u) {
            if (++guard > 2u * VT_NSEC) return VT_FULL;
            if ((r = vt_advance(w)) != VT_OK) return r;
            continue;
        }
        ch = len - pos;
        if (vt_size(ch) > room) ch = (room - VT_HDR) & ~3u;
        if (part > 255u) return VT_BIG;
        if (w->dry) { w->head += vt_size(ch); w->seq++; w->adds++; }
        else if ((r = vt_chunk_at(&w->head, &w->seq, type, id, part, pos + ch == len, gen, src, ctx, pos, ch, 0)) != VT_OK) return r;
        else vt_idx[vt.n - 1u].live = 1;                         /* (counts while written: a copy round the ring keeps it) */
        pos += ch;
        part++;
        if (pos >= len) return VT_OK;           /* (a deletion: one empty chunk) */
    }
}

/* the live bytes the area may hold: all but two sectors (the head's slack and the one kept dead after it) */
static uint32_t vt_cap(void) { return (VT_NSEC - 2u) * VT_SEC; }

static uint32_t vt_live_total(void)
{
    uint32_t i, b = 0;
    for (i = 0; i < vt.n; i++) if (vt_idx[i].live) b += vt_size(vt_idx[i].len);
    return b;
}

/* a record (type 1..127, id) of len bytes from src: VT_OK, or VT_BUSY (it needs an erase: stop first),
 * VT_FULL, VT_FOREIGN, VT_BIG, VT_EIO. Nothing is written unless the dry run says it will all fit */
static int vault_put_src(uint32_t type, uint32_t id, vt_src_fn src, void *ctx, uint32_t len, int may_erase)
{
    vt_run w;
    int r;
    uint32_t i, gen0, chunks = len / (VT_SEC - VT_HDR - 64u) + 2u;
    if (!vt.mounted || vt.err) return VT_EIO;
    if (vt.foreign) return VT_FOREIGN;
    if (len >= VT_MAXREC) return VT_BIG;
    vt_compact();
    if (vt_live_total() + len + chunks * (VT_HDR + 64u) > vt_cap()) return VT_FULL;
    w.hs = vt.hs; w.head = vt.head; w.seq = vt.seq; w.blank = vt.blank; w.moved = 0; w.adds = 0; w.dry = 1; w.may_erase = may_erase;
    if ((r = vt_write(&w, type, id, src, ctx, len)) != VT_OK) return r;
    if (vt.n + w.adds > VT_NIDX) return VT_FULL;
    w.hs = vt.hs; w.head = vt.head; w.seq = vt.seq; w.blank = vt.blank; w.moved = 0; w.dry = 0;
    gen0 = vt.seq;
    r = vt_write(&w, type, id, src, ctx, len);
    vt.hs = w.hs; vt.head = w.head; vt.seq = w.seq; vt.blank = w.blank;
    vt_compact();
    if (r == VT_OK) {                                            /* it is whole and it is the one now */
        for (i = 0; i < vt.n; i++)
            if (vt_idx[i].live && vt_idx[i].last && vt_idx[i].gen == gen0 && vt_idx[i].id == id && vt_idx[i].type == type) break;
        if (i == vt.n) r = VT_EIO;
    }
    if (r == VT_EIO) vt.err = 1;
    return r;
}

static int vault_put(uint32_t type, uint32_t id, const uint8_t *p, uint32_t len, int may_erase)
{
    return vault_put_src(type, id, vt_src_ram, (void *)p, len, may_erase);
}

static int vault_del(uint32_t type, uint32_t id, int may_erase)
{
    return vault_put_src(type | VT_DEL, id, vt_src_ram, vt_piece, 0, may_erase);
}

/* ---------------------------------------------------------------- reading records --- */
/* a record open for reading: its length; its bytes come through vt_fetch */
typedef struct { uint32_t type, id, len, gen; } vt_rd;

/* the newest whole record (type, id): its length, or VT_NONE */
static int32_t vault_open(uint32_t type, uint32_t id, vt_rd *rd)
{
    uint32_t i, j, n = 0;
    if (!vt.mounted) return VT_EIO;
    vt_mark();
    for (i = 0; i < vt.n; i++) {
        const vt_ent *e = &vt_idx[i];
        if (!e->live || !e->last || (e->type & 0x7Fu) != type || e->id != id) continue;
        if (e->type & VT_DEL) return VT_NONE;
        for (j = 0; j < vt.n; j++)
            if (vt_idx[j].live && vt_idx[j].type == e->type && vt_idx[j].id == id && vt_idx[j].gen == e->gen) n += vt_idx[j].len;
        rd->type = e->type; rd->id = id; rd->gen = e->gen; rd->len = n;
        return (int32_t)n;
    }
    return VT_NONE;
}

/* bytes [off, off + n) of an open record into dst */
static int vt_fetch(void *ctx, uint32_t off, uint8_t *dst, uint32_t n)
{
    const vt_rd *rd = ctx;
    uint32_t part = 0, at = 0, i;
    while (n) {
        const vt_ent *c = 0;
        for (i = 0; i < vt.n; i++)
            if (vt_idx[i].live && vt_idx[i].type == rd->type && vt_idx[i].id == rd->id && vt_idx[i].gen == rd->gen && vt_idx[i].part == part) { c = &vt_idx[i]; break; }
        if (!c) return -1;
        if (off < at + c->len) {
            uint32_t k = at + c->len - off < n ? at + c->len - off : n;
            if (st_read(c->off + VT_HDR + (off - at), dst, k)) return -1;
            dst += k; off += k; n -= k;
        }
        at += c->len;
        part++;
    }
    return 0;
}

/* the record (type, id) into buf: its length, or VT_NONE / VT_BIG / VT_EIO */
static int32_t vault_get(uint32_t type, uint32_t id, uint8_t *buf, uint32_t cap)
{
    vt_rd rd;
    int32_t n = vault_open(type, id, &rd);
    if (n < 0) return n;
    if ((uint32_t)n > cap) return VT_BIG;
    return vt_fetch(&rd, 0, buf, (uint32_t)n) ? VT_EIO : n;
}

/* ---------------------------------------------------------------- upkeep --- */
/* when stopped and silent: one step toward VT_AHEAD erased sectors ahead (at most one erase a call) */
static void vault_idle(void)
{
    uint32_t s, k;
    if (!vt.mounted || vt.err || vt.foreign) return;
    s = vt.hs;
    for (k = 0; k < VT_AHEAD; k++) {
        s = vt_next(s);
        if (vt.blank >> s & 1u) continue;
        if (vt_live_in(s, 0)) return;                           /* live ahead: the next save's advance copies them */
        if (!st_erase(vt_start(s))) vt.blank |= 1u << s;
        return;
    }
}

/* the whole area erased: the owner asked (it may hold another firmware's store). Stopped only */
static int vault_format(void)
{
    uint32_t s;
    for (s = 0; s < VT_NSEC; s++) if (st_erase(vt_start(s))) return VT_EIO;
    return vault_mount();
}

/* the live bytes, and the room for more */
static void vault_space(uint32_t *used, uint32_t *room)
{
    vt_compact();
    *used = vt_live_total();
    *room = vt_cap() > *used ? vt_cap() - *used : 0u;
}

/* ---------------------------------------------------------------- presets in the vault --- */
#define VT_KITS 64u
#define VT_SOUNDS 128u

static int vt_src_kit(void *ctx, uint32_t lo, uint8_t *dst, uint32_t n)
{
    return st_kit_encode(dst, lo, n) == *(const uint32_t *)ctx ? 0 : -1;   /* (changed meanwhile: refused) */
}
static int vt_src_sound(void *ctx, uint32_t lo, uint8_t *dst, uint32_t n)
{
    const uint32_t *a = ctx;
    return st_sound_encode(a[1], dst, lo, n) == a[0] ? 0 : -1;
}

/* the kit into slot (the encoder runs once to measure, then once a window as it is written: a kit can be
 * any size the area takes). Not while recording: the kit would change under it */
static int vault_kit_save(uint32_t slot, int may_erase)
{
    uint32_t n;
    if (slot >= VT_KITS) return VT_NONE;
    n = st_kit_encode(vt_piece, 0, 0);
    return vault_put_src(ST_KIT, slot, vt_src_kit, &n, n, may_erase);
}

static int vault_kit_load(uint32_t slot)
{
    vt_rd rd;
    br_t r;
    int32_t n = vault_open(ST_KIT, slot, &rd);
    if (n < 0) return (int)n;
    r.len = (uint32_t)n; r.bit = 0; r.clo = r.chi = 0; r.err = 0;
    r.fetch = vt_fetch; r.ctx = &rd; r.cache = vt_piece; r.csize = VT_PIECE; r.p = vt_piece;
    return st_kit_load_r(&r) ? VT_EIO : VT_OK;
}

static int vault_sound_save(uint32_t slot, uint32_t k, int may_erase)
{
    uint32_t a[2];
    if (slot >= VT_SOUNDS) return VT_NONE;
    a[1] = k;
    a[0] = st_sound_encode(k, vt_piece, 0, 0);
    return vault_put_src(ST_SOUND, slot, vt_src_sound, a, a[0], may_erase);
}

static int vault_sound_load(uint32_t slot, uint32_t k)
{
    vt_rd rd;
    br_t r;
    int32_t n = vault_open(ST_SOUND, slot, &rd);
    if (n < 0) return (int)n;
    r.len = (uint32_t)n; r.bit = 0; r.clo = r.chi = 0; r.err = 0;
    r.fetch = vt_fetch; r.ctx = &rd; r.cache = vt_piece; r.csize = VT_PIECE; r.p = vt_piece;
    return st_sound_load_r(k, &r) ? VT_EIO : VT_OK;
}
