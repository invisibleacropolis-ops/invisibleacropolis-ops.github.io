/* SPDX-License-Identifier: GPL-3.0-only */
/* The air: each track rebuilds its own highs, on the clock (v0.4; replaces v0.3's rebuild on the mix).
 *
 * The SVBRR core carries 0-4 kHz. Per 16 ms side frame (128 core samples) the library stores, for 8 bands from 4 to
 * 16 kHz, each band's energy relative to the core's 2-4 kHz band (16 codes, 3 dB apart, in a 45 dB window each
 * sample places: a hi-hat's highs sit 20-30 dB above its 2-4 kHz band), plus a 2-bit tonality. Per track:
 *
 *   core domain (8 kHz, per core sample)
 *     1. h = 6th-order high-pass at 2 kHz of the track's sound (after its strip)
 *     2. its energy through the same high-pass again: the encoder's own reference (a zero-phase 2-4 kHz
 *        Butterworth), so the side info's ratios mean what they meant when the library was made
 *     3. a 90-degree pair (two 4-section all-pass chains) makes h analytic; x e^(-j 3pi/4 n) (an 8-entry table)
 *        moves its 2-4 kHz band to complex baseband (+-1 kHz); an elliptic low-pass cleans it
 *   wide domain (32 kHz, 4 per core sample)
 *     4. copy-up: that baseband x six carriers at 5, 7 .. 15 kHz = six copies of the 2-4 kHz band, abutting from
 *        4 to 16 kHz. All six with their gains are one complex table of 32 entries (a 1 ms period: 32 wide
 *        samples = 8 core samples), so the copy-up is 2 multiplies a sample, no band filters at all
 *     5. noise: complex samples at 2 kHz (one every 4 core samples), linearly interpolated: the interpolation's
 *        spectrum is a triangle-squared whose shifted copies sum to flat, so the same carriers make six noise
 *        bands that tile 4-16 kHz without gaps or bumps. It follows the track's 2-4 kHz envelope (1 ms up, 8 down)
 *     6. stereo for free: Im() of the same products is the 90-degree twin of every copy and every noise band;
 *        L and R take the pair rotated by +-psi (WID), so their correlation is cos(2 psi) at full power each
 *   per block (16 core samples): the side frame the lead voice reads (frame-constant, no lag: the library is
 *   known ahead), mapped to the six slots at the voice's playback rate; tonality -> copy / noise; AIR, TLT, TON.
 *
 * The chain's group delay near 3 kHz is ~7 core samples, so the engine plays everything else HF_ADV core samples
 * later instead (os_engine.c): copies land on their transients, and every offset stays a whole clock sample.
 *
 * Also here: the exact 32 -> 44.1 kHz resampler (375 phases: 272 wide samples are exactly 375 DAC frames) and the
 * master bus (M/S air and width, glue compressor, look-ahead limiter). */

/* ------------------------------------------------------------------ constants (computed offline) -- */
/* the core path at 44,117.6 Hz: 4th-order low-pass at 3.9 kHz after the Hermite (drops its images) */
static const float HF_CLP_A[5] = {0.050541704f, 0.101083407f, 0.050541704f, -1.142670233f, 0.344837048f};
static const float HF_CLP_B[5] = {0.062543537f, 0.125087073f, 0.062543537f, -1.414013226f, 0.664187373f};
/* at 8 kHz: Butterworth 6th-order high-pass at 2 kHz (scipy butter(6, 2000, 'high', fs=8000)) */
static const float HF_HP6[3][5] = {
    {0.0295882236f, -0.0591764473f, 0.0295882236f, 0.0f, 0.0173323801f},
    {1.0f, -2.0f, 1.0f, 0.0f, 0.1715728753f},
    {1.0f, -2.0f, 1.0f, 0.0f, 0.5887907065f},
};
/* at 8 kHz: elliptic 4th-order low-pass at 1 kHz, 0.3 dB / 50 dB (the baseband: the 2-4 kHz band at +-1 kHz) */
static const float HF_EL4[2][5] = {
    {0.018752572f, 0.0252465327f, 0.018752572f, -1.2206886392f, 0.4403885588f},
    {1.0f, -0.0487125139f, 1.0f, -1.2037660445f, 0.7806875071f},
};
/* the 90-degree pair (O. Niemitalo): sections y = a (x + y[-2]) - x[-2], a = c^2 */
static const float HF_HA[4] = {0.47940086f, 0.87621849f, 0.97659758f, 0.99749925f};
static const float HF_HB[4] = {0.16175850f, 0.73302893f, 0.94534974f, 0.99059915f};
/* e^(-j 3 pi n / 4), n = 0..7: 3 kHz down to 0 */
static const float HF_SH[8][2] = {
    {1.0f, 0.0f}, {-0.70710678f, -0.70710678f}, {0.0f, 1.0f}, {0.70710678f, -0.70710678f},
    {-1.0f, 0.0f}, {0.70710678f, 0.70710678f}, {0.0f, -1.0f}, {-0.70710678f, 0.70710678f},
};
/* side-info code c (0..15) -> relative energy 10^((-39 + 3c) / 10) */
static const float HF_REL[16] = {
    1.2589254e-4f, 2.5118864e-4f, 5.0118723e-4f, 1.0e-3f, 1.9952623e-3f, 3.9810717e-3f, 7.9432823e-3f, 1.5848932e-2f,
    3.1622777e-2f, 6.3095734e-2f, 1.2589254e-1f, 2.5118864e-1f, 5.0118723e-1f, 1.0f, 1.9952623f, 3.9810717f};
static const float HF_EDGE[9] = {4000.0f, 4800.0f, 5700.0f, 6800.0f, 8100.0f, 9700.0f, 11600.0f, 13800.0f, 16000.0f};

#define HF_NS 6u                       /* slots: 4-6, 6-8 .. 14-16 kHz, carriers at 5, 7 .. 15 */
#define HF_ADV 7u                      /* core samples the rest of the mix waits for the air (group delay) */
/* the noise's envelope: the 2-4 kHz power, 1 ms up and 8 ms down. A noisy band's own envelope is itself random;
 * noise x a random envelope fluctuates twice (dips of 10 dB a hi-hat never had). The slow release keeps the decay
 * smooth; its excess over the true power is measured per block and taken back out (s_own / s_env), so the level
 * still follows the side info */
#ifndef HF_ENA
#define HF_ENA 0.1175f                 /* attack: 1 ms one-pole at 8 kHz */
#endif
#ifndef HF_ENR
#define HF_ENR 0.0155f                 /* release: 8 ms */
#endif

/* ------------------------------------------------------------------ the track's air -- */
typedef struct {
    bq_t hp[3], ref[3], li[2], lq[2];
    float ha[4][4], hb[4][4], hb_d;                /* all-pass sections: x1 x2 y1 y2; branch B one sample late */
    float zi, zq;                                  /* last baseband sample (the wide domain interpolates) */
    float env, e_ref, e_own, s_ref, s_own, e_env, s_env;
    float ni0, nq0, ni1, nq1;
    uint32_t rng;
    float tc[2][32][2], tn[2][32][2];              /* carrier tables, previous and this block: copy, noise */
    float cpsi, spsi;
    float M[HF_NS][8], m_rate;                     /* side band -> slot, for the lead voice's rate */
    sv_info in;
    int16_t si;
    int32_t fr;
    float R[HF_NS], w;                             /* the frame's slot targets, tonality (1 = copy) */
    uint8_t on, live;
    bq_t wq[4];                                    /* WAVE: its own dry highs, measured (2-4, 4-8, 8-12, 12-16 kHz) */
    float we[4];
    /* the track's filter, on the air (os_flt.c): its state (Re, Im), coefficients and glide; the un-filter gain */
    flt_s af[2];
    flt_c acur, adel;
    uint8_t acnt, aok, aon;
    float unf, fcor, g_prev;                       /* the un-filter; the measured over the analytic band gain */
    float shw;                                     /* the shaper POST: the share of the band the filter never saw */
} hf_t;
static hf_t hf[NTRACK] __attribute__((section(".pool")));
static float hf_ex[HF_NS][8][2];                   /* e^(j (2 pi (5 + 2s) m / 32 + pi s^2 / 6)), m = 0..7 */
static float hf_amount = 1.0f;                     /* the global HF knob (FX page), 1 = as encoded */
static int tx_active(uint32_t k);
static float tx_slot_gain(uint32_t k, uint32_t s);
/* at 32 kHz: 2-4, 4-8, 8-12 kHz band-passes and a 12 kHz high-pass, for WAVE's own highs */
static const float HF_WQ[4][5] = {
    {0.165910681f, 0.0f, -0.165910681f, -1.414213562f, 0.668178638f},
    {0.292893219f, 0.0f, -0.292893219f, -0.585786438f, 0.414213562f},
    {0.292893219f, 0.0f, -0.292893219f, 0.585786438f, 0.414213562f},
    {0.097631073f, -0.195262146f, 0.097631073f, 0.942809042f, 0.333333333f},
};

/* which slot each side band's energy lands in when the voice plays at rate r (frequencies scale by r) */
static void hf_matrix(float M[HF_NS][8], float r)
{
    uint32_t s, b;
    float inv = 1.0f / (r > 0.05f ? r : 0.05f);
    for (s = 0; s < HF_NS; s++) {
        float lo = (4000.0f + 2000.0f * (float)s) * inv, hi = (6000.0f + 2000.0f * (float)s) * inv;
        for (b = 0; b < 8u; b++) {
            float a0 = HF_EDGE[b], a1 = HF_EDGE[b + 1u];
            float ov = (hi < a1 ? hi : a1) - (lo > a0 ? lo : a0);
            M[s][b] = ov > 0.0f ? ov / (a1 - a0) : 0.0f;
        }
        if (lo < 4000.0f) M[s][0] += ((hi < 4000.0f ? hi : 4000.0f) - lo) / (HF_EDGE[1] - HF_EDGE[0]);
        if (hi > 16000.0f) M[s][7] += (hi - (lo > 16000.0f ? lo : 16000.0f)) / (HF_EDGE[8] - HF_EDGE[7]);
    }
}

/* side frame fr of h->in, through h->M: the six slot targets and the tonality weight */
static void hf_frame(const float M[HF_NS][8], const sv_info *in, int32_t fr, float *R, float *w)
{
    uint8_t codes[8], ton;
    float rel[8];
    uint32_t s, j;
    float sc = in->hf_off ? hf_exp2((float)in->hf_off * 0.99657843f) : 1.0f;   /* 10^(0.3 off) */
    sv_side_frame(&os.lib, in, fr < 0 ? 0 : (int)fr, codes, &ton);
    for (j = 0; j < 8u; j++) rel[j] = HF_REL[codes[j] & 15u] * sc;
    for (s = 0; s < HF_NS; s++) {
        float a = 0.0f;
        for (j = 0; j < 8u; j++) a += M[s][j] * rel[j];
        R[s] = a;
    }
    *w = (float)ton * (1.0f / 3.0f);
}

static void hf_init(void)
{
    uint32_t k, s, m;
    for (s = 0; s < HF_NS; s++)
        for (m = 0; m < 8u; m++) {
            /* + a Schroeder phase per slot: the six copies of a transient no longer peak together */
            float th = 6.28318531f * (float)(5u + 2u * s) * (float)m / 32.0f + 3.14159265f * (float)(s * s) / (float)HF_NS;
            hf_ex[s][m][0] = hf_cos(th);
            hf_ex[s][m][1] = hf_sin(th);
        }
    memset(hf, 0, sizeof hf);
    for (k = 0; k < NTRACK; k++) {
        hf_t *h = &hf[k];
        for (s = 0; s < 3u; s++) { bq_set(&h->hp[s], HF_HP6[s]); bq_set(&h->ref[s], HF_HP6[s]); }
        for (s = 0; s < 2u; s++) { bq_set(&h->li[s], HF_EL4[s]); bq_set(&h->lq[s], HF_EL4[s]); }
        h->rng = 0x9E3779B9u * (k + 7u);
        h->si = -1;
        h->s_ref = h->s_own = h->s_env = 1e-9f;
        h->cpsi = 1.0f;
        hf_matrix(h->M, 1.0f);
        h->m_rate = 1.0f;
        for (s = 0; s < 4u; s++) bq_set(&h->wq[s], HF_WQ[s]);
    }
}

/* WAVE has real highs: with its effect on, the wet (at the clock rate) gets the air, and the targets are what
 * the dry WAVE itself has above 4 kHz relative to 2-4 kHz, measured here (n wide samples of its mid) */
static void hf_wave_measure(uint32_t k, const float *x, uint32_t n)
{
    hf_t *h = &hf[k];
    uint32_t i, b;
    for (i = 0; i < n; i++)
        for (b = 0; b < 4u; b++) {
            float y = bq_run(&h->wq[b], x[i]);
            h->we[b] += y * y;
        }
}

/* per block, before the block's samples: targets, gains, the two carrier tables */
static void hf_block(uint32_t k)
{
    trk_t *t = &os.trk[k];
    hf_t *h = &hf[k];
    float cr, amt, g2c[HF_NS], g2n[HF_NS], tl, w, r, hs_loc[HF_NS];
    uint32_t s, m, j;
    h->on = t->mach != MA_WAVE || tx_active(k);
    /* the encoder's reference vs ours, over the last block: the side info is relative to its band */
    h->s_ref += (h->e_ref - h->s_ref) * 0.25f;
    h->s_own += (h->e_own - h->s_own) * 0.25f;
    h->s_env += (h->e_env - h->s_env) * 0.25f;
    h->e_ref = h->e_own = h->e_env = 0.0f;
    h->live = h->on && (h->s_own > 1e-11f || h->env > 1e-11f);
    memcpy(h->tc[0], h->tc[1], sizeof h->tc[0]);
    memcpy(h->tn[0], h->tn[1], sizeof h->tn[0]);
    if (!h->on) { memset(h->tc[1], 0, sizeof h->tc[1]); memset(h->tn[1], 0, sizeof h->tn[1]); return; }
    cr = os_clampf(h->s_ref / (h->s_own + 1e-12f), 0.25f, 8.0f);
    if (t->mach == MA_MULTI) {
        /* every sounding voice reads its own frame: the track's targets are their mix, weighted by how much of
         * the 2-4 kHz band each voice is (a hat's ratios must not ride on a kick's attack) */
        float et = 0.0f, Rm[HF_NS] = {0, 0, 0, 0, 0, 0}, wm = 0.0f;
        for (j = 0; j < POLY_MAX; j++) {
            pv_t *p = &pool[k][j];
            float e = p->e_hf;
            p->e_hf = 0.0f;
            if (!p->used || e <= 1e-14f) continue;
            r = p->v.rate < 0.0f ? -p->v.rate : p->v.rate;
            if (r < 0.05f) r = 1.0f;
            {
                int32_t fr = p->v.ip >> SIDE_SHIFT;
                if (fr != p->h_fr || r != p->h_rate) {
                    float M[HF_NS][8];
                    sv_info in;
                    p->h_fr = fr;
                    p->h_rate = r;
                    hf_matrix(M, r);
                    sv_sample_info(&os.lib, p->si, &in);
                    hf_frame((const float (*)[8])M, &in, fr, p->hR, &p->hw);
                }
            }
            for (s = 0; s < HF_NS; s++) Rm[s] += e * p->hR[s];
            wm += e * p->hw;
            et += e;
        }
        if (et > 0.0f) {
            for (s = 0; s < HF_NS; s++) h->R[s] = Rm[s] / et;
            h->w = wm / et;
        }
    } else if (t->mach == MA_WAVE) {
        /* the wet of a WAVE track: its targets are the dry's own measured highs (each band split over its slots) */
        float ref = h->we[0] + 1e-12f;
        if (h->we[0] > 1e-12f)
            for (s = 0; s < HF_NS; s++) h->R[s] = 0.5f * h->R[s] + 0.25f * h->we[1u + s / 2u] / ref;
        h->w = 0.75f;
        h->we[0] = h->we[1] = h->we[2] = h->we[3] = 0.0f;
    } else {
        /* one reader: the frame it reads (frame-constant targets: frames sit on the clock) */
        int32_t fr = (int32_t)t->lead_pos >> SIDE_SHIFT;
        r = t->lead_rate < 0.0f ? -t->lead_rate : t->lead_rate;
        if (r < 0.05f) r = 1.0f;
        if (r > h->m_rate * 1.005f || r < h->m_rate * 0.995f) { hf_matrix(h->M, r); h->m_rate = r; h->fr = -1; }
        if (h->si != t->lead_si) { h->si = t->lead_si; sv_sample_info(&os.lib, t->lead_si, &h->in); h->fr = -1; }
        if (fr != h->fr) { h->fr = fr; hf_frame((const float (*)[8])h->M, &h->in, fr, h->R, &h->w); }
    }
    w = os_clampf(h->w + ((float)t->eff[R_TON] - 64.0f) * (1.0f / 64.0f), 0.0f, 1.0f);
    amt = (float)t->eff[R_AIR] * (1.0f / 64.0f) * hf_amount;
    amt = amt * amt * cr;                                           /* energy */
    /* the response contract (os_flt.c). The strip's filter is realised on the air (hf_run); here the air is
     * un-filtered: divided by what the filter did to the 2-4 kHz band it is copied from (at most +40 dB) */
    h->aon = t->typ != 0u && t->mach != MA_WAVE;
    if (h->aon) {
        float fc = t->fhz_last > 0.0f ? t->fhz_last : reg_cut_hz(os_clampf(t->cut_v, 0.0f, 127.0f));
        float gref = flt_ref_gain(t->typ, fc, 1.0f / t->kq), g;
        /* the analytic gain assumes a flat band; music is not (under a steep low-pass the band's low edge carries
         * it). What the filter really did, measured before and after it, corrects it slowly (~8 ms) */
        if (t->fe_pre > 1e-10f && h->g_prev > 0.0f) {
            float ci = os_clampf(t->fe_post / t->fe_pre / h->g_prev, 0.05f, 20.0f);
            if (h->fcor <= 0.0f) h->fcor = 1.0f;
            h->fcor += (ci - h->fcor) * 0.25f;
        }
        t->fe_pre = t->fe_post = 0.0f;
        h->g_prev = gref;
        g = gref * (h->fcor > 0.0f ? h->fcor : 1.0f);
        /* the shaper after the filter (os_shp.c): its share of the band is new, not filtered. That share is
         * neither un-filtered here nor filtered on the air (hf_run blends the air's filter toward through) */
        h->shw = os_clampf(t->shw, 0.0f, 1.0f);
        g = (1.0f - h->shw) * g + h->shw;
        h->unf = g > 1e-4f ? 1.0f / g : 1e4f;                       /* (energy; at most +40 dB) */
        amt *= h->unf;
    } else {
        h->aok = 0;
        h->fcor = 0.0f;
        h->g_prev = 0.0f;
    }
    /* smooth stages declare their magnitude: the low cut's share of each slot */
    if (t->eff[R_LOC] && t->mach != MA_WAVE) {
        float lf = reg_cut_hz((float)t->eff[R_LOC]);
        for (s = 0; s < HF_NS; s++) hs_loc[s] = flt_slot_gain(FLT_HP, lf, 0.70710678f, 5000.0f + 2000.0f * (float)s);
    } else {
        for (s = 0; s < HF_NS; s++) hs_loc[s] = 1.0f;
    }
    tl = ((float)t->eff[R_TLT] - 64.0f) * (1.0f / 64.0f);          /* +-1: +-6 dB at the ends */
    for (s = 0; s < HF_NS; s++) {
        float e = h->R[s] * amt * hs_loc[s] * (t->mach != MA_WAVE && tx_active(k) ? tx_slot_gain(k, s) : 1.0f) * hf_exp2(tl * ((float)s - 2.5f) * 0.8f);
        g2c[s] = os_sqrt(e * w);
        g2n[s] = os_sqrt(e * (1.0f - w) * 0.75f);                  /* x sqrt(env): the noise's |b|^2 -> power */
    }
    /* the tables: 8 entries per sum, the rest by symmetry (C[m + 8] = j (E - O), C[m + 16] = -C[m]) */
    for (m = 0; m < 8u; m++) {
        float ec[2] = {0, 0}, oc[2] = {0, 0}, en[2] = {0, 0}, on[2] = {0, 0};
        for (s = 0; s < HF_NS; s += 2u) {
            ec[0] += g2c[s] * hf_ex[s][m][0]; ec[1] += g2c[s] * hf_ex[s][m][1];
            en[0] += g2n[s] * hf_ex[s][m][0]; en[1] += g2n[s] * hf_ex[s][m][1];
            oc[0] += g2c[s + 1u] * hf_ex[s + 1u][m][0]; oc[1] += g2c[s + 1u] * hf_ex[s + 1u][m][1];
            on[0] += g2n[s + 1u] * hf_ex[s + 1u][m][0]; on[1] += g2n[s + 1u] * hf_ex[s + 1u][m][1];
        }
        h->tc[1][m][0] = ec[0] + oc[0];        h->tc[1][m][1] = ec[1] + oc[1];
        h->tc[1][m + 8u][0] = -(ec[1] - oc[1]); h->tc[1][m + 8u][1] = ec[0] - oc[0];
        h->tn[1][m][0] = en[0] + on[0];        h->tn[1][m][1] = en[1] + on[1];
        h->tn[1][m + 8u][0] = -(en[1] - on[1]); h->tn[1][m + 8u][1] = en[0] - on[0];
        for (j = 0; j < 2u; j++) {
            h->tc[1][m + 16u][j] = -h->tc[1][m][j]; h->tc[1][m + 24u][j] = -h->tc[1][m + 8u][j];
            h->tn[1][m + 16u][j] = -h->tn[1][m][j]; h->tn[1][m + 24u][j] = -h->tn[1][m + 8u][j];
        }
    }
    {   /* width: the pair rotated by +-psi, psi = WID / 127 x 45 degrees */
        float psi = (float)t->eff[R_WID] * (0.78539816f / 127.0f);
        h->cpsi = hf_cos(psi);
        h->spsi = hf_sin(psi);
    }
}

/* n core samples of track k's sound (x: after the strip, before level and pan) starting on clock sample c, of
 * which the first `in_blk` are already into the current block; gl, gr: the per-sample pan gains.
 * Adds the air at the wide rate to L, R (the air bus: played HF_ADV core samples ahead of the rest). */
static void hf_run(uint32_t k, const float *x, uint32_t n, uint32_t c, const float *gl, const float *gr, float *L, float *R)
{
    hf_t *h = &hf[k];
    uint32_t i, q, s;
    if (!h->on) return;
    for (i = 0; i < n; i++) {
        float v = x[i], a, b, zr, zi, p, amp, cp = h->cpsi, sp = h->spsi;
        uint32_t cc = c + i;
        /* 1-2: the high-pass, and the encoder's reference */
        v = bq_run(&h->hp[2], bq_run(&h->hp[1], bq_run(&h->hp[0], v)));
        {
            float rr = bq_run(&h->ref[2], bq_run(&h->ref[1], bq_run(&h->ref[0], v)));
            h->e_ref += rr * rr;
        }
        /* 3: analytic, to baseband, cleaned */
        a = v;
        for (s = 0; s < 4u; s++) {
            float *z = h->ha[s], y = HF_HA[s] * (a + z[3]) - z[1];
            z[1] = z[0]; z[0] = a; z[3] = z[2]; z[2] = y;
            a = y;
        }
        b = v;
        for (s = 0; s < 4u; s++) {
            float *z = h->hb[s], y = HF_HB[s] * (b + z[3]) - z[1];
            z[1] = z[0]; z[0] = b; z[3] = z[2]; z[2] = y;
            b = y;
        }
        {
            const float *e = HF_SH[cc & 7u];
            float bd = h->hb_d;
            h->hb_d = b;
            zr = a * e[0] - bd * e[1];
            zi = a * e[1] + bd * e[0];
        }
        zr = bq_run(&h->li[1], bq_run(&h->li[0], zr));
        zi = bq_run(&h->lq[1], bq_run(&h->lq[0], zi));
        p = zr * zr + zi * zi;
        h->e_own += 0.5f * p;
        h->env += (p - h->env) * (p > h->env ? HF_ENA : HF_ENR);
        h->e_env += 0.5f * h->env;
        if (!h->live) { h->zi = zr; h->zq = zi; continue; }
        if (h->aon) {                                /* the track's filter at 32 kHz: designed every FLT_CR */
            const trk_t *t = &os.trk[k];
            float fc = t->fhz[i], q = 1.0f / t->kq, fw = (float)(CORE_SR * WIDE);
            if (t->ffast) {                          /* (audio-rate cutoff: bilinear, every clock sample) */
                flt_bilinear(t->typ, fc, q, fw, &h->acur);
                h->acnt = 0;
                h->aok = 2;
            } else {
                if (!h->acnt) {
                    flt_c nx;
                    flt_design(t->typ, fc, q, fw, &nx);
                    if (!h->aok) { h->acur = nx; memset(&h->adel, 0, sizeof h->adel); memset(h->af, 0, sizeof h->af); }
                    else flt_delta(&h->acur, &nx, 1.0f / (float)FLT_CR, &h->adel);
                    h->aok = 1;
                    h->acnt = FLT_CR;
                }
                flt_step(&h->acur, &h->adel);
                h->acnt--;
            }
        }
        amp = os_sqrt(h->env * os_clampf(h->s_own / (h->s_env + 1e-12f), 0.25f, 1.0f));
        /* 4-6: four wide samples */
        for (q = 0; q < WIDE; q++) {
            uint32_t mw = cc * WIDE + q, ix = mw & 31u;
            float u = (float)(q + 1u) * 0.25f;                       /* the baseband, interpolated */
            float bi = h->zi + (zr - h->zi) * u, bq = h->zq + (zi - h->zq) * u;
            float ub = (float)(mw & (BLK * WIDE - 1u)) * (1.0f / (float)(BLK * WIDE));   /* across the block */
            float cr_ = h->tc[0][ix][0] + (h->tc[1][ix][0] - h->tc[0][ix][0]) * ub;
            float ci_ = h->tc[0][ix][1] + (h->tc[1][ix][1] - h->tc[0][ix][1]) * ub;
            float nr_ = h->tn[0][ix][0] + (h->tn[1][ix][0] - h->tn[0][ix][0]) * ub;
            float ni_ = h->tn[0][ix][1] + (h->tn[1][ix][1] - h->tn[0][ix][1]) * ub;
            float mi, mq, nv, re, im;
            if ((mw & 15u) == 0u) {                                  /* a new noise point every 4 core samples */
                h->ni0 = h->ni1; h->nq0 = h->nq1;
                h->rng = h->rng * 1664525u + 1013904223u;
                h->ni1 = ((float)(h->rng >> 8) * (1.0f / 16777216.0f) - 0.5f) * 3.4641016f;
                h->rng = h->rng * 1664525u + 1013904223u;
                h->nq1 = ((float)(h->rng >> 8) * (1.0f / 16777216.0f) - 0.5f) * 3.4641016f;
            }
            nv = (float)(mw & 15u) * (1.0f / 16.0f);
            mi = (h->ni0 + (h->ni1 - h->ni0) * nv) * amp;
            mq = (h->nq0 + (h->nq1 - h->nq0) * nv) * amp;
            re = bi * cr_ - bq * ci_ + mi * nr_ - mq * ni_;
            im = bi * ci_ + bq * cr_ + mi * ni_ + mq * nr_;
            if (h->aon && h->shw > 0.0f) {                          /* part through: the SVF's sum is its input */
                flt_c c = h->acur;
                c.ml += (1.0f - c.ml) * h->shw; c.mb += (c.k - c.mb) * h->shw; c.mh += (1.0f - c.mh) * h->shw;
                re = flt_tick(&h->af[0], &c, re); im = flt_tick(&h->af[1], &c, im);
            } else if (h->aon) { re = flt_tick(&h->af[0], &h->acur, re); im = flt_tick(&h->af[1], &h->acur, im); }
            L[i * WIDE + q] += gl[i] * (cp * re + sp * im);
            R[i * WIDE + q] += gr[i] * (cp * re - sp * im);
        }
        h->zi = zr; h->zq = zi;
    }
}

/* ------------------------------------------------------------------ 32 kHz -> the DAC, exactly -- */
/* 32 taps, Kaiser (beta 4.55, ~50 dB), -6 dB at 15.5 kHz: flat to 14 kHz, images of the air below -53 dB.
 * Phase p/375 (p = 0..374) of a frame; phases above 187 are the mirror of 375 - p, so only 188 are kept */
#define RS_TAPS 32u
#define RS_PH 375u
#define RS_HALF 188u
static float rs_tab[RS_HALF][RS_TAPS] __attribute__((section(".pool")));

static float rs_i0(float x)                         /* modified Bessel I0 by its series */
{
    float s = 1.0f, t = 1.0f, q = x * x * 0.25f;
    uint32_t k;
    for (k = 1; k < 40u; k++) {
        t *= q / (float)(k * k);
        s += t;
        if (t < s * 1e-9f) break;
    }
    return s;
}

static void rs_init(void)
{
    const float fc = 15500.0f / 32000.0f * 2.0f, beta = 4.551f, ib = 1.0f / rs_i0(beta);
    uint32_t p, j;
    for (p = 0; p < RS_HALF; p++) {
        float f = (float)p / (float)RS_PH, sum = 0.0f;
        for (j = 0; j < RS_TAPS; j++) {
            float tt = (float)j - 15.0f - f, u = tt * (1.0f / 16.0f), w, s;
            w = u * u < 1.0f ? rs_i0(beta * os_sqrt(1.0f - u * u)) * ib : 0.0f;
            s = tt == 0.0f ? fc : hf_sin(3.14159265f * fc * tt) / (3.14159265f * tt);
            rs_tab[p][j] = s * w;
            sum += s * w;
        }
        for (j = 0; j < RS_TAPS; j++) rs_tab[p][j] /= sum;
    }
}

/* n frames of L, R from the wide buffers (h samples of history) at wide times 4 x (phase + i x step - d) */
static void rs_run(const float *bl, const float *br, uint32_t h, float phase, float step, float d, float *ol, float *orr, uint32_t n)
{
    uint32_t i, j;
    for (i = 0; i < n; i++) {
        float tt = (float)WIDE * (phase + (float)i * step - d), f, al = 0.0f, ar = 0.0f;
        int32_t s = (int32_t)tt;
        uint32_t p;
        const float *xl, *xr;
        if ((float)s > tt) s--;
        f = tt - (float)s;
        p = (uint32_t)(f * (float)RS_PH + 0.5f);
        if (p >= RS_PH) { p -= RS_PH; s++; }
        xl = bl + (int32_t)h + s - 15;
        xr = br + (int32_t)h + s - 15;
        if (p < RS_HALF) {
            const float *c = rs_tab[p];
            for (j = 0; j < RS_TAPS; j++) { al += xl[j] * c[j]; ar += xr[j] * c[j]; }
        } else {
            const float *c = rs_tab[RS_PH - p] + (RS_TAPS - 1u);
            for (j = 0; j < RS_TAPS; j++) { al += xl[j] * c[-(int32_t)j]; ar += xr[j] * c[-(int32_t)j]; }
        }
        ol[i] = al;
        orr[i] = ar;
    }
}

/* ------------------------------------------------------------------ the master bus -- */
/* at the DAC rate, after the effects:
 *   AIR   M/S: the side gets a shelf above ~7 kHz (up to +6 dB), the mid a third of it
 *   WID   the side's level (0 .. 200 %)
 *   GLU   a stereo-linked RMS compressor: as GLU rises, ratio 1 -> 2:1, threshold -6 -> -24 dB, soft knee, make-up
 *         half the reduction at full scale (so GLU 0 is exactly off); detection 10 ms / 150 ms, the gain stepped
 *         every 16 frames and interpolated
 *   CEL   a 1 ms look-ahead peak limiter: each frame's need (ceiling / peak), the window's minimum (a monotonic
 *         queue), the gain falls into it within the window and rises over ~60 ms. 0 dB = the output's full scale
 *         (Felucca's -6 dBFS of the 24-bit word) */
#define MS_LA 44u                                   /* look-ahead frames (1 ms) */
#define MS_RING 64u
static const float MS_HP7[5] = {0.47740680f, -0.95481360f, 0.47740680f, -0.67549836f, 0.23412884f};   /* 7 kHz, Q .707 */
static struct {
    bq_t hs, hm;
    float env, g, g_step, lg, gr_db;
    float dl[2][MS_RING], need[MS_RING];
    uint32_t dq[MS_RING], dq_h, dq_t, n, w;
} ms;

static void master_init(void)
{
    memset(&ms, 0, sizeof ms);
    bq_set(&ms.hs, MS_HP7);
    bq_set(&ms.hm, MS_HP7);
    ms.g = ms.lg = 1.0f;
}

static void master_process(float *L, float *R, uint32_t n)
{
    float air = (float)os.m_air * (1.0f / 100.0f), wid = (float)os.m_wid * (1.0f / 100.0f);
    float glu = (float)os.m_glu * (1.0f / 100.0f), thr = -6.0f - 18.0f * glu, slope = glu / (1.0f + glu);
    float ceil = hf_db(-(float)os.m_cel * 0.1f), mk = -thr * slope * 0.5f;
    float ma = air * 0.33f, target = (float)os.master / 127.0f;
    uint32_t i;
    target *= target;
    for (i = 0; i < n; i++) {
        float m = 0.5f * (L[i] + R[i]), s = 0.5f * (L[i] - R[i]), l, r, a, pk, nd, gl;
        uint32_t w = ms.w;
        if (air > 0.0f) { s += bq_run(&ms.hs, s) * air; m += bq_run(&ms.hm, m) * ma; }
        s *= wid;
        l = m + s; r = m - s;
        os.master_g += (target - os.master_g) * 0.002f;
        l *= os.master_g; r *= os.master_g;
        if (glu > 0.0f) {                                       /* glue */
            float p = 0.5f * (l * l + r * r);
            ms.env += (p - ms.env) * (p > ms.env ? 0.00226f : 0.000151f);
            if ((ms.n & 15u) == 0u) {
                float over = 3.0103f * hf_log2(ms.env + 1e-12f) - thr, red;
                red = over <= -3.0f ? 0.0f : over >= 3.0f ? over * slope : slope * (over + 3.0f) * (over + 3.0f) / 12.0f;
                ms.gr_db = red;
                ms.g_step = (hf_db(mk - red) - ms.g) * (1.0f / 16.0f);
            }
            ms.g += ms.g_step;
            l *= ms.g; r *= ms.g;
        } else {
            ms.g = 1.0f; ms.g_step = 0.0f; ms.gr_db = 0.0f;
        }
        ms.n++;
        /* the limiter */
        a = l < 0.0f ? -l : l;
        pk = r < 0.0f ? -r : r;
        if (pk > a) a = pk;
        nd = a > ceil ? ceil / a : 1.0f;
        ms.need[w & (MS_RING - 1u)] = nd;
        while (ms.dq_t != ms.dq_h && ms.need[ms.dq[(ms.dq_t - 1u) & (MS_RING - 1u)] & (MS_RING - 1u)] >= nd) ms.dq_t--;
        ms.dq[ms.dq_t & (MS_RING - 1u)] = w;
        ms.dq_t++;
        while (w - ms.dq[ms.dq_h & (MS_RING - 1u)] > MS_LA) ms.dq_h++;
        gl = ms.need[ms.dq[ms.dq_h & (MS_RING - 1u)] & (MS_RING - 1u)];
        if (gl < ms.lg) ms.lg += (gl - ms.lg) * 0.25f;          /* 0.75^44: there in time */
        else ms.lg += (gl - ms.lg) * 0.00038f;
        L[i] = ms.dl[0][(w - MS_LA) & (MS_RING - 1u)] * ms.lg;  /* the frame MS_LA ago: its need is in the window */
        R[i] = ms.dl[1][(w - MS_LA) & (MS_RING - 1u)] * ms.lg;
        ms.dl[0][w & (MS_RING - 1u)] = l;
        ms.dl[1][w & (MS_RING - 1u)] = r;
        ms.w = w + 1u;
    }
}
