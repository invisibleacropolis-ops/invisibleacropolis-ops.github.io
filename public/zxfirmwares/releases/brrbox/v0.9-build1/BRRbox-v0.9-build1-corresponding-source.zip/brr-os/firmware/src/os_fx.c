/* fx.c: smallest useful effects for the FM-1 engine.
 *
 * Design rules: float maths (the chip has an FPU), int16 delay memory to
 * halve RAM, no libm, everything built from three primitives:
 *   fx_dline  : int16 delay line with integer and fractional taps
 *   lfo    : phase accumulator + parabolic sine
 *   onepole: 1-pole lowpass (damping, smoothing)
 *
 * Effects (stereo in/out unless noted, output rate FX_FS):
 *   chorus  : 3 modulated taps per channel, 12 ms +/- 4 ms
 *   flanger : 1 modulated tap per channel, 0.3-4 ms, feedback
 *   reverb  : mono in, 4-line FDN at FX_FS/2 with Householder matrix,
 *             4 input allpasses, per-line damping; optional fx_shimmer:
 *             octave-up pitch shifter inside the feedback loop.
 */
#include <stdint.h>
#include "os_fx.h"

/* ---------------------------------------------------------- primitives -- */
typedef struct { int16_t *buf; int len; int w; } fx_dline;

static inline int16_t fx_sat16(float x)
{
    int v = (int)(x * 32767.0f);
    if (v > 32767) v = 32767;
    if (v < -32768) v = -32768;
    return (int16_t)v;
}
static inline void fx_dl_write(fx_dline *d, float x)
{
    d->buf[d->w] = fx_sat16(x);
    if (++d->w >= d->len) d->w = 0;
}
/* sample written 'delay' writes ago (delay >= 1) */
static inline float fx_dl_tap(const fx_dline *d, int delay)
{
    int i = d->w - delay;
    if (i < 0) i += d->len;
    return d->buf[i] * (1.0f / 32767.0f);
}
static inline float fx_dl_tapf(const fx_dline *d, float delay)
{
    int i = (int)delay;
    float f = delay - (float)i;
    float a = fx_dl_tap(d, i), b = fx_dl_tap(d, i + 1);
    return a + (b - a) * f;
}

/* parabolic sine, phase in [0,1) */
static inline float fx_psin(float ph)
{
    float x = ph * 2.0f - 1.0f;               /* -1..1 */
    float y = 4.0f * x * (1.0f - (x < 0 ? -x : x));
    return -y;                                /* sin(2*pi*ph) shape */
}
static inline float fx_wrap1(float p) { return p >= 1.0f ? p - 1.0f : p; }

/* exp(x) for x <= 0, no libm: 2^(x*log2e) with exponent bits + cubic */
static float fx_fexp(float x)
{
    float y = x * 1.44269504f;
    if (y < -126.0f) return 0.0f;
    int i = (int)y;
    if ((float)i > y) i--;
    float f = y - (float)i;
    float p = 1.0f + f * (0.6951786f + f * (0.2261590f + f * 0.0782636f));
    union { float f; int32_t i; } u;
    u.i = (i + 127) << 23;
    return u.f * p;
}

/* v0.5: the master chorus, flanger and reverb are retired (each track has its own effects: os_tfx.c); kept here,
 * compiled out, for reference */
#ifndef OS_MASTER_FX
#define OS_MASTER_FX 0
#endif
#if OS_MASTER_FX
/* ------------------------------------------------------------ memory -- */
#define fx_CH_LEN  1024           /* chorus: 21 ms at 48 kHz, per channel  */
#define fx_FL_LEN  256            /* flanger: 5.3 ms at 48 kHz, per channel */
static const int fx_FDN_LEN[4] = { 1693, 1867, 2053, 2251 };   /* at 24 kHz */
static const int fx_AP_LEN[4]  = { 113, 162, 241, 337 };
#define fx_PS_LEN  2048           /* fx_shimmer pitch shifter window, 85 ms     */

static int16_t fx_m_ch[2][fx_CH_LEN] __attribute__((section(".pool")));   /* big buffers: the pool */
static int16_t fx_m_fl[2][fx_FL_LEN] __attribute__((section(".pool")));   /* big buffers: the pool */
static int16_t fx_m_fdn[1693 + 1867 + 2053 + 2251] __attribute__((section(".pool")));   /* big buffers: the pool */
static int16_t fx_m_ap[113 + 162 + 241 + 337] __attribute__((section(".pool")));   /* big buffers: the pool */
static int16_t fx_m_ps[fx_PS_LEN] __attribute__((section(".pool")));   /* big buffers: the pool */

/* ------------------------------------------------------------ chorus -- */
static fx_dline fx_ch[2];
static float fx_ch_ph;

void chorus_init(void)
{
    for (int c = 0; c < 2; c++) { fx_ch[c].buf = fx_m_ch[c]; fx_ch[c].len = fx_CH_LEN; fx_ch[c].w = 0; }
    fx_ch_ph = 0;
}

void chorus_process(float *L, float *R, int n, const chorus_p *p)
{
    const float base = 0.012f * FX_FS, depth = p->depth * 0.004f * FX_FS;
    const float inc = p->rate / FX_FS;
    for (int i = 0; i < n; i++) {
        float in[2] = { L[i], R[i] };
        float out[2];
        fx_ch_ph = fx_wrap1(fx_ch_ph + inc);
        for (int c = 0; c < 2; c++) {
            fx_dl_write(&fx_ch[c], in[c]);
            float s = 0;
            for (int v = 0; v < 3; v++) {
                float ph = fx_ch_ph + (float)v * 0.3333333f + (float)c * 0.1666667f;
                if (ph >= 1.0f) ph -= 1.0f;
                if (ph >= 1.0f) ph -= 1.0f;
                s += fx_dl_tapf(&fx_ch[c], base + depth * fx_psin(ph));
            }
            out[c] = in[c] * (1.0f - p->mix) + s * 0.4f * p->mix;
        }
        L[i] = out[0]; R[i] = out[1];
    }
}

/* ----------------------------------------------------------- flanger -- */
static fx_dline fx_fl[2];
static float fx_fl_ph, fx_fl_fb[2];

void flanger_init(void)
{
    for (int c = 0; c < 2; c++) { fx_fl[c].buf = fx_m_fl[c]; fx_fl[c].len = fx_FL_LEN; fx_fl[c].w = 0; fx_fl_fb[c] = 0; }
    fx_fl_ph = 0;
}

void flanger_process(float *L, float *R, int n, const flanger_p *p)
{
    const float lo = 0.0003f * FX_FS, span = 0.0037f * FX_FS * p->depth;
    const float inc = p->rate / FX_FS;
    for (int i = 0; i < n; i++) {
        float in[2] = { L[i], R[i] };
        fx_fl_ph = fx_wrap1(fx_fl_ph + inc);
        for (int c = 0; c < 2; c++) {
            float ph = fx_wrap1(fx_fl_ph + 0.25f * (float)c);
            float tri = ph < 0.5f ? ph * 2.0f : 2.0f - ph * 2.0f;   /* triangle sweeps sound best on flangers */
            float d = lo + span * tri * tri;
            fx_dl_write(&fx_fl[c], in[c] + fx_fl_fb[c] * p->feedback);
            float w = fx_dl_tapf(&fx_fl[c], d + 1.0f);
            fx_fl_fb[c] = w;
            float o = in[c] * (1.0f - 0.5f * p->mix) + w * 0.5f * p->mix;
            if (c == 0) L[i] = o; else R[i] = o;
        }
    }
}

/* ------------------------------------------------- reverb + fx_shimmer -- */
static fx_dline fx_fdn[4], fx_ap[4], fx_ps;
static float fx_lp[4], fx_g[4], fx_damp, fx_ps_ph, fx_ps_lp, fx_half_in, fx_held_l, fx_held_r, fx_prev_l, fx_prev_r;
static int fx_phase2;

void reverb_init(void)
{
    int16_t *m = fx_m_fdn;
    for (int k = 0; k < 4; k++) { fx_fdn[k].buf = m; fx_fdn[k].len = fx_FDN_LEN[k]; fx_fdn[k].w = 0; m += fx_FDN_LEN[k]; fx_lp[k] = 0; }
    m = fx_m_ap;
    for (int k = 0; k < 4; k++) { fx_ap[k].buf = m; fx_ap[k].len = fx_AP_LEN[k]; fx_ap[k].w = 0; m += fx_AP_LEN[k]; }
    fx_ps.buf = fx_m_ps; fx_ps.len = fx_PS_LEN; fx_ps.w = 0;
    fx_ps_ph = 0; fx_ps_lp = 0; fx_phase2 = 0; fx_half_in = 0;
    fx_held_l = fx_held_r = fx_prev_l = fx_prev_r = 0;
    for (int k = 0; k < 4; k++) for (int i = 0; i < fx_FDN_LEN[k]; i++) fx_fdn[k].buf[i] = 0;
    for (int i = 0; i < (int)(sizeof fx_m_ap / 2); i++) fx_m_ap[i] = 0;
    for (int i = 0; i < fx_PS_LEN; i++) fx_m_ps[i] = 0;
}

void reverb_set(const reverb_p *p)
{
    const float fs = FX_FS * 0.5f;
    for (int k = 0; k < 4; k++)               /* RT60: gain = 10^(-3 len / (fs T)) */
        fx_g[k] = fx_fexp(-6.9077553f * (float)fx_FDN_LEN[k] / (fs * p->decay_s));
    fx_damp = p->damp;
}

static inline float fx_allpass(fx_dline *d, float x, float gain)
{
    float z = fx_dl_tap(d, d->len);
    float v = x + gain * z;
    fx_dl_write(d, v);
    return z - gain * v;
}

/* octave-up pitch shift: two heads sweeping a fx_PS_LEN window, crossfaded */
static inline float fx_shimmer(float x)
{
    fx_dl_write(&fx_ps, x);
    fx_ps_ph -= 1.0f / (float)fx_PS_LEN;            /* ratio 2: delay shrinks 1 sample/sample */
    if (fx_ps_ph < 0.0f) fx_ps_ph += 1.0f;
    float ph2 = fx_wrap1(fx_ps_ph + 0.5f);
    float w1 = fx_ps_ph < 0.5f ? fx_ps_ph * 2.0f : 2.0f - fx_ps_ph * 2.0f;
    float w2 = 1.0f - w1;
    float d1 = 2.0f + fx_ps_ph * (fx_PS_LEN - 4), d2 = 2.0f + ph2 * (fx_PS_LEN - 4);
    return fx_dl_tapf(&fx_ps, d1) * w1 + fx_dl_tapf(&fx_ps, d2) * w2;
}

/* mono-ish in (L+R)/2, stereo wet added to L/R. Runs internally at FX_FS/2. */
void reverb_process(float *L, float *R, int n, const reverb_p *p)
{
    for (int i = 0; i < n; i++) {
        float x = 0.5f * (L[i] + R[i]);
        if (!fx_phase2) { fx_half_in = x; fx_phase2 = 1; }
        else {
            fx_phase2 = 0;
            float in = 0.5f * (fx_half_in + x);                 /* 2:1 decimate */
            for (int k = 0; k < 4; k++) in = fx_allpass(&fx_ap[k], in, 0.62f);
            float y[4];
            for (int k = 0; k < 4; k++) {
                float v = fx_dl_tap(&fx_fdn[k], fx_fdn[k].len);
                fx_lp[k] += (v - fx_lp[k]) * (1.0f - fx_damp);        /* damping */
                y[k] = fx_lp[k] * fx_g[k];
            }
            float s = 0.5f * (y[0] + y[1] + y[2] + y[3]);    /* Householder 4x4 */
            float sh = 0.0f;
            if (p->shimmer > 0.0f) {
                float o = fx_shimmer(y[0] + y[1] + y[2] + y[3]);
                fx_ps_lp += (o - fx_ps_lp) * 0.35f;
                float q = fx_ps_lp * p->shimmer * 0.06f;
                sh = q / (1.0f + (q < 0 ? -q : q));            /* soft bound */
            }
            for (int k = 0; k < 4; k++) fx_dl_write(&fx_fdn[k], y[k] - s + in + sh);
            fx_prev_l = fx_held_l; fx_prev_r = fx_held_r;
            fx_held_l = 0.5f * (y[0] - y[1] + y[2] - y[3]);
            fx_held_r = 0.5f * (y[0] + y[1] - y[2] - y[3]);
        }
        /* 1:2 linear upsample of the wet signal */
        float wl = fx_phase2 ? 0.5f * (fx_prev_l + fx_held_l) : fx_held_l;
        float wr = fx_phase2 ? 0.5f * (fx_prev_r + fx_held_r) : fx_held_r;
        L[i] = L[i] * (1.0f - 0.5f * p->mix) + wl * p->mix;
        R[i] = R[i] * (1.0f - 0.5f * p->mix) + wr * p->mix;
    }
}

unsigned fx_ram_bytes(void)
{
    return (unsigned)(sizeof fx_m_ch + sizeof fx_m_fl + sizeof fx_m_fdn + sizeof fx_m_ap + sizeof fx_m_ps);
}
#endif /* OS_MASTER_FX */
