/* svbrr_dec.c: SVBRR container decoder (SVB4: 16-sample blocks, seeded keyframes, 16 ms side frames) + voices.
 * Entropy coder: static rANS (ryg_rans_byte), every table sums to 4096: per symbol one
 * 32x32->32 multiply, shifts and adds. No divide, no 64-bit arithmetic anywhere.
 * Reads the library straight from (memory-mapped) flash. Per-voice state is
 * a few dozen bytes plus one 16-sample block buffer. Must stay bit-exact
 * with svbrr.py; checked from Python via ctypes. */
#include <stdint.h>
#include "svbrr_dec.h"
#include "svbrr_tables.h"

#define SV_SCALE 12
#define SV_M     (1u << SV_SCALE)
#define RANS_L   (1u << 23)

/* ------------------------------------------------------- static tables -- */
static uint16_t sv_cum_mode[5][6], sv_cum_filt[5][SV_NF + 1], sv_cum_sabs[SV_NS + 1],
                sv_cum_ds[2 * SV_NS], sv_cum_r1[3], sv_cum_r2[5], sv_cum_r3[9], sv_cum_r4[17];
typedef struct { const uint16_t *cum; uint8_t n; } sv_model;
static sv_model sv_M_mode[5], sv_M_filt[5], sv_M_sabs, sv_M_ds, sv_M_res[4];

static uint32_t sv_rd_u(const uint8_t *p, int n)
{
    uint32_t v = 0;
    for (int i = n - 1; i >= 0; i--) v = (v << 8) | p[i];
    return v;
}

static int sv_unpack12(const uint8_t *b, int idx)
{
    int bit = idx * 12, by = bit >> 3, sh = bit & 7;
    uint32_t w = ((uint32_t)b[by] << 16) | ((uint32_t)b[by + 1] << 8) | b[by + 2];
    return (int)((w >> (12 - sh)) & 0xFFF);
}

static void sv_build(uint16_t *cum, int n, const uint8_t *tb, int *idx)
{
    cum[0] = 0;
    for (int i = 0; i < n; i++) cum[i + 1] = (uint16_t)(cum[i] + sv_unpack12(tb, (*idx)++));
    cum[n] = SV_M;                              /* the last frequency is implied: every table sums to 4096 */
}

#define sv_TABLE_BYTES 285
SV_API int sv_open(sv_lib *L, const uint8_t *blob, uint32_t len)
{
    if (len < 11 || blob[0] != 'S' || blob[1] != 'V' || blob[2] != 'B' || blob[3] != '4') return -1;   /* SVB4: 16-sample blocks */
    L->ver = 4;
    L->blob = blob;
    L->len = len;
    L->core_sr = (uint16_t)sv_rd_u(blob + 5, 2);
    L->kf_len = (uint16_t)sv_rd_u(blob + 7, 2);
    L->n = (uint16_t)sv_rd_u(blob + 9, 2);
    const uint8_t *tb = blob + 11;
    int idx = 0;
    for (int m = 0; m < 5; m++) { sv_build(sv_cum_mode[m], 5, tb, &idx); sv_M_mode[m].cum = sv_cum_mode[m]; sv_M_mode[m].n = 5; }
    for (int m = 0; m < 5; m++) { sv_build(sv_cum_filt[m], SV_NF, tb, &idx); sv_M_filt[m].cum = sv_cum_filt[m]; sv_M_filt[m].n = SV_NF; }
    sv_build(sv_cum_sabs, SV_NS, tb, &idx); sv_M_sabs.cum = sv_cum_sabs; sv_M_sabs.n = SV_NS;
    sv_build(sv_cum_ds, 2 * SV_NS - 1, tb, &idx); sv_M_ds.cum = sv_cum_ds; sv_M_ds.n = 2 * SV_NS - 1;
    sv_build(sv_cum_r1, 2, tb, &idx); sv_build(sv_cum_r2, 4, tb, &idx); sv_build(sv_cum_r3, 8, tb, &idx); sv_build(sv_cum_r4, 16, tb, &idx);
    sv_M_res[0].cum = sv_cum_r1; sv_M_res[0].n = 2; sv_M_res[1].cum = sv_cum_r2; sv_M_res[1].n = 4;
    sv_M_res[2].cum = sv_cum_r3; sv_M_res[2].n = 8; sv_M_res[3].cum = sv_cum_r4; sv_M_res[3].n = 16;
    L->dir = blob + 11 + sv_TABLE_BYTES;
    return 0;
}

SV_API void sv_sample_info(const sv_lib *L, int si, sv_info *o)
{
    const uint8_t *e = L->dir + 26 * si;
    o->core_len = sv_rd_u(e, 4);
    o->n_kf = (uint16_t)sv_rd_u(e + 4, 2);
    o->kf_off = sv_rd_u(e + 6, 4);
    o->side_off = sv_rd_u(e + 10, 4);
    o->n_frames = (uint16_t)sv_rd_u(e + 14, 2);
    o->loop_start = sv_rd_u(e + 16, 4);
    o->loop_end = sv_rd_u(e + 20, 4);
    o->root = e[24];
    o->hf_off = (int8_t)e[25];
}

/* ------------------------------------------------------------ rANS decoder -- */
static inline uint32_t sv_byte_in(sv_reader *r)
{
    uint32_t i = r->bitpos++;                   /* (byte position) */
    return i < r->seg_len ? r->seg[i] : 0u;
}

static int sv_decode(sv_reader *r, const sv_model *m)
{
    uint32_t x = r->code;
    uint32_t slot = x & (SV_M - 1u);
    const uint16_t *cum = m->cum;
    int s = 0;
    if (m->n > 8) {                             /* binary search on the bigger tables */
        int lo = 0, hi = m->n;
        while (hi - lo > 1) {
            int mid = (lo + hi) >> 1;
            if (cum[mid] <= slot) lo = mid; else hi = mid;
        }
        s = lo;
    } else {
        while (cum[s + 1] <= slot) s++;
    }
    x = (uint32_t)(cum[s + 1] - cum[s]) * (x >> SV_SCALE) + slot - cum[s];
    while (x < RANS_L) x = (x << 8) | sv_byte_in(r);
    r->code = x;
    return s;
}

/* -------------------------------------------------------------- reader -- */
SV_API void sv_reader_init(sv_reader *r, const sv_lib *L, int si)
{
    { uint8_t *z = (uint8_t *)r; for (unsigned i = 0; i < sizeof *r; i++) z[i] = 0; }
    r->lib = L;
    sv_sample_info(L, si, &r->info);
    r->per = L->kf_len >> SV_BLK_SHIFT;       /* blocks per keyframe (kf_len a power of two) */
    r->per_shift = 0;
    while ((1 << r->per_shift) < r->per) r->per_shift++;
    r->seg_k = -1;
    r->bidx = -1;
}

static void sv_start_segment(sv_reader *r, int k)
{
    const uint8_t *t = r->lib->blob + r->info.kf_off;
    uint32_t o0 = sv_rd_u(t + 3 * k, 3), o1 = sv_rd_u(t + 3 * (k + 1), 3);
    const uint8_t *data0 = t + 3 * (r->info.n_kf + 1);
    int32_t s1 = 0, s2 = 0;
    if (r->lib->ver >= 3) {                     /* SVB3: the history this keyframe starts from, 2 x 12 bits */
        uint32_t w = sv_rd_u(data0 + 3 * k, 3);
        s1 = (int32_t)(w & 0xFFFu); s2 = (int32_t)(w >> 12 & 0xFFFu);
        if (s1 >= 2048) s1 -= 4096;
        if (s2 >= 2048) s2 -= 4096;
        data0 += 3 * r->info.n_kf;
    }
    r->seg = data0 + o0;
    r->seg_len = o1 - o0;
    r->bitpos = 0;
    r->code = 0;
    for (int i = 0; i < 4; i++) r->code |= sv_byte_in(r) << (8 * i);   /* initial state, little-endian */
    r->seg_k = k;
    r->prev_mode = 0;
    r->prev_s = -1;
    r->p1 = s1 * 16;
    r->p2 = s2 * 16;
    r->stat_restarts++;
}

static void sv_next_block(sv_reader *r)
{
    int mode = sv_decode(r, &sv_M_mode[r->prev_mode]);
    int f = sv_decode(r, &sv_M_filt[mode]);
    int half = 0, off = 0;
    int ks[SV_BLK];
    if (mode > 0) {
        int s = (r->prev_s < 0) ? sv_decode(r, &sv_M_sabs) : sv_decode(r, &sv_M_ds) + r->prev_s - (SV_NS - 1);
        r->prev_s = s;
        half = SV_HALF[s];
        off = 1 << (mode - 1);
        for (int j = 0; j < SV_BLK; j++) ks[j] = sv_decode(r, &sv_M_res[mode - 1]) - off;
    }
    int32_t p1 = r->p1, p2 = r->p2;
    for (int j = 0; j < SV_BLK; j++) {
        int32_t pred = (SV_A1[f] * p1 + SV_A2[f] * p2 + 2048) >> 12;
        int32_t v = mode ? pred + (2 * ks[j] + 1) * half : pred;
        if (v > 32767) v = 32767;
        if (v < -32768) v = -32768;
        r->block[j] = (int16_t)v;
        p2 = p1; p1 = v;
    }
    r->p1 = p1; r->p2 = p2;
    r->prev_mode = (uint8_t)mode;
    r->hdr_mode = (uint8_t)mode;
    r->hdr_half = half;
    r->stat_blocks++;
}

SV_API const int16_t *sv_block(sv_reader *r, int32_t b)
{
    if (b == r->bidx) return r->block;
    int k = b >> r->per_shift;
    int32_t cur;
    if (k != r->seg_k || b < r->bidx) { sv_start_segment(r, k); cur = k * r->per - 1; }
    else cur = r->bidx;
    while (cur < b) { sv_next_block(r); cur++; }
    r->bidx = b;
    return r->block;
}

static inline float sv_smp(sv_reader *r, int32_t i)
{
    if (i < 0) i = 0;
    if (i >= (int32_t)r->info.core_len) i = (int32_t)r->info.core_len - 1;
    return sv_block(r, i / SV_BLK)[i % SV_BLK] * (1.0f / 32767.0f);
}

/* ---------------------------------------------------------------- voices -- */
/* One playback voice: position in core samples (float), rate in core samples
 * per output sample, optional loop. Hermite interpolation. */
SV_API void voice_render(sv_voice *v, float *out, int n)
{
    for (int i = 0; i < n; i++) {
        if (!v->active) return;
        int32_t ip = (int32_t)v->pos;
        if ((float)ip > v->pos) ip--;
        float f = v->pos - (float)ip;
        float ym1 = sv_smp(&v->rd, ip - 1), y0 = sv_smp(&v->rd, ip), y1 = sv_smp(&v->rd, ip + 1), y2 = sv_smp(&v->rd, ip + 2);
        float c1 = 0.5f * (y1 - ym1), c2 = ym1 - 2.5f * y0 + 2.0f * y1 - 0.5f * y2, c3 = 0.5f * (y2 - ym1) + 1.5f * (y0 - y1);
        out[i] += (((c3 * f + c2) * f + c1) * f + y0) * v->gain;
        v->pos += v->rate;
        if (v->loop_end > v->loop_start) {
            if (v->pos >= (float)v->loop_end) v->pos -= (float)(v->loop_end - v->loop_start);
            else if (v->pos < (float)v->loop_start) v->pos += (float)(v->loop_end - v->loop_start);
        } else if (v->pos < 0 || v->pos >= (float)v->rd.info.core_len - 2) {
            v->active = 0;
        }
    }
}

/* side-info frame: 8 band codes + tonality, direct random access */
SV_API void sv_side_frame(const sv_lib *L, const sv_info *in, int fr, uint8_t codes[8], uint8_t *ton)
{
    if (fr < 0) fr = 0;
    if (fr >= in->n_frames) fr = in->n_frames - 1;
    uint32_t bit = (uint32_t)fr * 34u;
    const uint8_t *p = L->blob + in->side_off + (bit >> 3);
    /* 34 bits from bit offset 'bit', MSB first, without 64-bit maths: read them one by one */
    uint32_t sh = bit & 7u, k, hi = 0, lo = 0;
    for (k = 0; k < 34u; k++) {
        uint32_t pos = sh + k;
        uint32_t b = (p[pos >> 3] >> (7u - (pos & 7u))) & 1u;
        if (k < 32u) hi = (hi << 1) | b; else lo = (lo << 1) | b;
    }
    for (int b = 0; b < 8; b++) codes[b] = (uint8_t)((hi >> (28 - 4 * b)) & 15u);
    *ton = (uint8_t)(lo & 3u);
}

/* host-side test helper: sv_decode a whole sample */
SV_API int sv_decode_all(const sv_lib *L, int si, int16_t *out, uint32_t max)
{
    sv_reader r;
    sv_reader_init(&r, L, si);
    uint32_t n = r.info.core_len < max ? r.info.core_len : max;
    for (uint32_t i = 0; i < n; i += SV_BLK) {
        const int16_t *b = sv_block(&r, (int32_t)(i / SV_BLK));
        for (int j = 0; j < SV_BLK && i + j < n; j++) out[i + j] = b[j];
    }
    return (int)n;
}

SV_API unsigned sv_reader_bytes(void) { return (unsigned)sizeof(sv_reader); }
SV_API unsigned sv_voice_bytes(void) { return (unsigned)sizeof(sv_voice); }
