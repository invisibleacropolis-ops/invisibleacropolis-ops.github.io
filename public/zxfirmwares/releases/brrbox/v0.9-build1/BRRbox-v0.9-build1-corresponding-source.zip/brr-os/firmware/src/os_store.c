/* SPDX-License-Identifier: GPL-3.0-only */
/* Presets as bits: a SOUND (one track's machine and registers) and a KIT (four sounds, 8 patterns, 8 tables,
 * 8 scenes, the song, the tempo and the master bus), each a bit stream read in one pass with no tables.
 *
 *   template  a sound is its machine (2 bits) and only the registers that differ from that machine's frozen
 *             template (TPL_V1): a register gap, then the value as a small signed step from the template or
 *             raw. A template is never edited: a new firmware whose defaults change adds TPL_V2 and keeps V1
 *             for the records made under it (the record header carries the version)
 *   fields    every other value goes through a field coder with its own context: '0' = the same as the last
 *             value of that field, '10' + exp-Golomb = a small step from it, '11' + raw. So a column of equal
 *             velocities costs a bit each, a bass line a few bits a note, a lock lane (predicted from the last
 *             value of its own register) a few bits a step
 *   lists     step groups: the gap to the step, then how many notes, locks and commands it has (a bit each
 *             when 1, 0, 0), then each event's residual (0: 1 bit; a live note: 14) and its four fields. Every
 *             field of every event is kept (a lock edited in LIST to carry a residual keeps it): lossless
 *   loading   twice: a dry pass checks the record (bounds, counts, the heap's room) and changes nothing; only
 *             a record that passed is written. A broken record never leaves a half-loaded kit
 * A sound is recalled exactly as a lock is applied: bytes into the base registers, the strip re-derived. */

#define ST_VER 1u
enum { ST_SOUND = 1, ST_KIT = 2 };

/* the machines' registers as a fresh track has them (format version 1; PAN centred): frozen. (Remade once
 * before any unit ran v0.8, when the shaper took the register file to 96: no record was made under the old one) */
static const uint8_t TPL_V1[MA_N][NREG] = {
    {0,0,4,64,0,0,0,1,127,0,0,64,0,70,127,40,64,64,96,0,0,112,
     15,3,100,64,0,0,101,127,127,0,64,64,64,64,0,0,0,0,40,64,40,40,
     0,64,0,0,80,60,50,0,30,90,0,0,0,0,60,0,40,1,96,64,0,70,
     0,40,0,96,64,1,64,3,0,1,0,96,64,3,0,0,0,0,42,64,0,64,
     127,0,0,0,0,0,0,0},   /* TAPE */
    {8,1,64,64,0,0,0,0,127,0,0,64,0,70,127,40,64,64,96,0,0,112,
     15,3,100,64,0,0,101,127,127,0,64,64,64,64,40,0,0,0,40,64,40,40,
     0,64,0,0,80,60,50,0,30,90,0,0,0,0,60,0,40,1,96,64,0,70,
     0,40,0,96,64,1,64,3,0,1,0,96,64,3,0,0,5,0,42,64,0,64,
     127,0,0,0,0,0,0,0},   /* MULTI */
    {1,40,72,60,70,64,30,0,127,0,0,64,0,70,127,40,64,64,96,0,0,112,
     15,3,100,64,0,0,101,127,127,0,64,64,64,64,72,0,0,0,40,64,40,40,
     0,64,0,0,80,60,50,0,30,90,0,0,0,0,60,0,40,1,96,64,0,70,
     0,40,0,96,64,1,64,3,0,1,0,96,64,3,0,0,0,0,42,64,0,64,
     127,0,0,0,0,0,0,0},   /* GRAN */
    {16,0,2,64,0,64,64,0,127,0,0,64,0,70,127,40,64,64,96,0,0,112,
     15,3,100,64,0,0,101,127,127,0,64,64,64,64,48,0,0,0,40,64,40,40,
     0,64,0,0,80,60,50,0,30,90,0,0,0,0,60,0,40,1,96,64,0,70,
     0,40,0,96,64,1,64,3,0,1,0,96,64,3,0,0,3,0,42,64,0,64,
     127,0,0,0,0,0,0,0},   /* WAVE */
};

/* which registers a record leaves alone: the pattern's (STP SPD, in its header), and for a SOUND also the
 * track's way of playing (FEEL WIN VFL GRV, TBL TSP): a sound loaded onto a track keeps those */
static int st_skip(uint32_t r, int sound)
{
    if (r == R_STP || r == R_SPD) return 1;
    return sound && (r == R_FEL || r == R_WIN || r == R_VFL || r == R_GRV || r == R_TBL || r == R_TSP);
}

/* ---------------------------------------------------------------- bits --- */
/* the writer keeps only the bytes [lo, hi) of what it writes, at p (strict: past hi is an error; else it just
 * counts on). So a record bigger than any buffer is made a window at a time: written again, kept in part */
typedef struct { uint8_t *p; uint32_t lo, hi, bit; uint8_t err, strict; } bw_t;
/* the reader: the whole record at p, or through fetch, a window of it at a time into cache */
typedef int (*br_fetch_fn)(void *ctx, uint32_t off, uint8_t *dst, uint32_t n);
typedef struct {
    const uint8_t *p; uint32_t len, bit, clo, chi; uint8_t err;
    br_fetch_fn fetch; void *ctx; uint8_t *cache; uint32_t csize;
} br_t;

static void bw_put(bw_t *w, uint32_t v, uint32_t n)        /* n <= 31, most significant first */
{
    while (n--) {
        uint32_t by = w->bit >> 3;
        if (by >= w->hi && w->strict) { w->err = 1; return; }
        if (by >= w->lo && by < w->hi) {
            if (!(w->bit & 7u)) w->p[by - w->lo] = 0;
            if (v >> n & 1u) w->p[by - w->lo] |= (uint8_t)(0x80u >> (w->bit & 7u));
        }
        w->bit++;
    }
}

static uint32_t br_get(br_t *r, uint32_t n)
{
    uint32_t v = 0;
    while (n--) {
        uint32_t by = r->bit >> 3;
        if (by >= r->len) { r->err = 1; return 0; }
        if (by < r->clo || by >= r->chi) {                   /* (fetching: the next window) */
            uint32_t k = r->len - by < r->csize ? r->len - by : r->csize;
            if (!r->fetch || r->fetch(r->ctx, by, r->cache, k)) { r->err = 1; return 0; }
            r->p = r->cache; r->clo = by; r->chi = by + k;
        }
        v = v << 1 | (uint32_t)(r->p[by - r->clo] >> (7u - (r->bit & 7u)) & 1u);
        r->bit++;
    }
    return v;
}
static void br_ram(br_t *r, const uint8_t *p, uint32_t len)
{
    r->p = p; r->len = len; r->bit = 0; r->clo = 0; r->chi = len; r->err = 0; r->fetch = 0;
}
static void br_rewind(br_t *r)
{
    r->bit = 0; r->err = 0;
    if (r->fetch) r->clo = r->chi = 0;
}

/* exp-Golomb: 0 -> 1 bit, 1-2 -> 3, 3-6 -> 5, 7-14 -> 7 ... */
static uint32_t eg_len(uint32_t u)
{
    uint32_t n = 0;
    u++;
    while (u >> (n + 1u)) n++;
    return 2u * n + 1u;
}
static void bw_eg(bw_t *w, uint32_t u)
{
    uint32_t n = (eg_len(u) - 1u) / 2u;
    bw_put(w, 0, n);
    bw_put(w, u + 1u, n + 1u);
}
static uint32_t br_eg(br_t *r)
{
    uint32_t n = 0;
    while (!br_get(r, 1)) if (++n > 24u || r->err) { r->err = 1; return 0; }
    return ((1u << n) | br_get(r, n)) - 1u;
}
static uint32_t zz(int32_t d) { return d >= 0 ? (uint32_t)d * 2u : (uint32_t)(-d) * 2u - 1u; }
static int32_t unzz(uint32_t z) { return z & 1u ? -(int32_t)((z + 1u) >> 1) : (int32_t)(z >> 1); }

/* the field coder: the same as the last ('0'), a small step from it ('10' + exp-Golomb), or raw ('11') */
static void fc_put(bw_t *w, int32_t *prev, int32_t v, uint32_t bits)
{
    if (v == *prev) bw_put(w, 0, 1);
    else {
        uint32_t z = zz(v - *prev);
        if (eg_len(z) <= bits) { bw_put(w, 2, 2); bw_eg(w, z); }
        else { bw_put(w, 3, 2); bw_put(w, (uint32_t)v & ((1u << bits) - 1u), bits); }
    }
    *prev = v;
}
static int32_t fc_get(br_t *r, int32_t *prev, uint32_t bits)
{
    int32_t v = *prev;
    if (br_get(r, 1)) v = br_get(r, 1) ? (int32_t)br_get(r, bits) : v + unzz(br_eg(r));
    *prev = v;
    return v;
}

/* a value that differs from a known one (a template, the base): its step ('0' + exp-Golomb) or raw ('1') */
static void dv_put(bw_t *w, int32_t ref, int32_t v)
{
    uint32_t z = zz(v - ref);
    if (eg_len(z) < 8u) { bw_put(w, 0, 1); bw_eg(w, z); }
    else { bw_put(w, 1, 1); bw_put(w, (uint32_t)v & 255u, 8); }
}
static int32_t dv_get(br_t *r, int32_t ref)
{
    return br_get(r, 1) ? (int32_t)br_get(r, 8) : ref + unzz(br_eg(r));
}

/* a residual (Q12 of a step): 0 -> '0'; within +-2048 -> '10' + 12 bits; else '11' + 16 bits */
static void off_put(bw_t *w, int32_t o)
{
    if (!o) bw_put(w, 0, 1);
    else if (o >= -2048 && o < 2048) { bw_put(w, 2, 2); bw_put(w, (uint32_t)o & 0xFFFu, 12); }
    else { bw_put(w, 3, 2); bw_put(w, (uint32_t)o & 0xFFFFu, 16); }
}
static int32_t off_get(br_t *r)
{
    uint32_t v;
    if (!br_get(r, 1)) return 0;
    if (!br_get(r, 1)) { v = br_get(r, 12); return (int32_t)(v ^ 0x800u) - 0x800; }
    v = br_get(r, 16);
    return (int32_t)(v ^ 0x8000u) - 0x8000;
}

/* ---------------------------------------------------------------- registers --- */
static void regs_put(bw_t *w, const uint8_t *v, const uint8_t *tpl, int sound)
{
    uint32_t r, n = 0;
    int32_t last = -1;
    for (r = 0; r < NREG; r++) n += (uint32_t)(!st_skip(r, sound) && v[r] != tpl[r]);
    bw_eg(w, n);
    for (r = 0; r < NREG; r++) {
        if (st_skip(r, sound) || v[r] == tpl[r]) continue;
        bw_eg(w, (uint32_t)((int32_t)r - last - 1));
        dv_put(w, tpl[r], v[r]);
        last = (int32_t)r;
    }
}

/* into v (when not 0): the template, then the registers that differ; the skipped ones are left as they are */
static void regs_get(br_t *r, uint8_t *v, uint32_t mach, int sound)
{
    uint32_t n = br_eg(r), i, reg;
    int32_t last = -1;
    if (v)
        for (reg = 0; reg < NREG; reg++) if (!st_skip(reg, sound)) v[reg] = TPL_V1[mach][reg];
    if (n > NREG) { r->err = 1; return; }
    for (i = 0; i < n && !r->err; i++) {
        int32_t x;
        reg = (uint32_t)(last + 1 + (int32_t)br_eg(r));
        if (reg >= NREG || st_skip(reg, sound)) { r->err = 1; return; }
        x = dv_get(r, TPL_V1[mach][reg]);
        if (x < 0 || x > 255) { r->err = 1; return; }
        if (v) v[reg] = (uint8_t)(x > (int32_t)reg_max(mach, reg) ? (int32_t)reg_max(mach, reg) : x);
        last = (int32_t)reg;
    }
}

/* ---------------------------------------------------------------- lists --- */
typedef struct { int32_t f[3][4], gap, cnt[3]; int32_t lane[NREG]; } lctx_t;

static void lctx_init(lctx_t *c)
{
    uint32_t r;
    static const int32_t F0[3][4] = {{60, 100, 8, 0}, {R_CUT, 64, 0, 0}, {'R', 0, 0, 0}};
    memcpy(c->f, F0, sizeof c->f);
    c->gap = 0; c->cnt[0] = 1; c->cnt[1] = 0; c->cnt[2] = 0;
    for (r = 0; r < NREG; r++) c->lane[r] = 64;
}

static void ev_put(bw_t *w, lctx_t *c, const ev_t *e)
{
    uint32_t k = e->kind;
    off_put(w, e->off);
    fc_put(w, &c->f[k][0], e->a, 8);
    fc_put(w, k == EV_LOCK && e->a < NREG ? &c->lane[e->a] : &c->f[k][1], e->b, 8);
    fc_put(w, &c->f[k][2], e->c, 8);
    fc_put(w, &c->f[k][3], e->d & (k == EV_NOTE ? (uint8_t)~EV_FRESH : 0xFFu), 8);   /* (FRESH: this pass only) */
}

static void list_put(bw_t *w, const evl_t *l)
{
    uint32_t i, j, ng = 0;
    int32_t prev = -1;
    lctx_t c;
    for (i = 0; i < l->n; i++) ng += (uint32_t)(!i || l->e[i].step != l->e[i - 1u].step);
    bw_eg(w, ng);
    lctx_init(&c);
    for (i = 0; i < l->n; i = j) {
        uint32_t cnt[3] = {0, 0, 0}, st = l->e[i].step;
        for (j = i; j < l->n && l->e[j].step == st; j++) cnt[l->e[j].kind < 3u ? l->e[j].kind : 2u]++;
        fc_put(w, &c.gap, (int32_t)st - prev - 1, 8);        /* the gap and the counts: '0' when as the last group's */
        fc_put(w, &c.cnt[0], (int32_t)cnt[0], 16); fc_put(w, &c.cnt[1], (int32_t)cnt[1], 16); fc_put(w, &c.cnt[2], (int32_t)cnt[2], 16);
        for (; i < j; i++) ev_put(w, &c, &l->e[i]);
        i = j;
        prev = (int32_t)st;
    }
}

/* a list: written (write) at the heap's end, which must be where l starts; *room: events the heap has left */
static void list_get(br_t *r, evl_t *l, int write, uint32_t *room)
{
    uint32_t ng = br_eg(r), g, k, i;
    int32_t prev = -1;
    lctx_t c;
    if (ng > 256u) { r->err = 1; return; }
    lctx_init(&c);
    if (write) { l->e = seq_heap + seq_used; l->n = 0; }
    for (g = 0; g < ng && !r->err; g++) {
        int32_t gp = fc_get(r, &c.gap, 8), c0 = fc_get(r, &c.cnt[0], 16), c1 = fc_get(r, &c.cnt[1], 16), c2 = fc_get(r, &c.cnt[2], 16);
        uint32_t cnt[3], st = (uint32_t)(prev + 1 + gp);
        cnt[0] = (uint32_t)c0; cnt[1] = (uint32_t)c1; cnt[2] = (uint32_t)c2;
        if (gp < 0 || c0 < 0 || c1 < 0 || c2 < 0 || st > 255u || cnt[0] + cnt[1] + cnt[2] > *room || !(cnt[0] + cnt[1] + cnt[2])) { r->err = 1; return; }
        for (k = 0; k < 3u; k++)
            for (i = 0; i < cnt[k]; i++) {
                ev_t e;
                int32_t a, b;
                e.step = (uint8_t)st;
                e.kind = (uint8_t)k;
                e.off = (int16_t)off_get(r);
                a = fc_get(r, &c.f[k][0], 8);
                if (a < 0 || a > 255) { r->err = 1; return; }
                b = fc_get(r, k == EV_LOCK && a < (int32_t)NREG ? &c.lane[a] : &c.f[k][1], 8);
                e.a = (uint8_t)a; e.b = (uint8_t)b;
                e.c = (uint8_t)fc_get(r, &c.f[k][2], 8);
                e.d = (uint8_t)fc_get(r, &c.f[k][3], 8);
                if (r->err) return;
                if (write) { seq_heap[seq_used++] = e; l->n++; }
                (*room)--;
            }
        prev = (int32_t)st;
    }
}

/* ---------------------------------------------------------------- SOUND --- */
/* track k's sound, bytes [lo, lo + n) of it into buf: its whole length */
static uint32_t st_sound_encode(uint32_t k, uint8_t *buf, uint32_t lo, uint32_t n)
{
    bw_t w = {buf, lo, lo + n, 0, 0, 0};
    const trk_t *t = &os.trk[k];
    bw_put(&w, t->mach, 2);
    regs_put(&w, t->base, TPL_V1[t->mach], 1);
    return (w.bit + 7u) >> 3;
}

/* track k's sound into buf: its length in bytes (0: it did not fit) */
static uint32_t st_sound_save(uint32_t k, uint8_t *buf, uint32_t cap)
{
    uint32_t n = st_sound_encode(k, buf, 0, cap);
    return n <= cap ? n : 0u;
}

/* a sound onto track k (its STP SPD, FEEL, TBL kept): 0, or -1 (a broken record: nothing changed) */
static int st_sound_load_r(uint32_t k, br_t *rd)
{
    br_t r = *rd;
    trk_t *t = &os.trk[k];
    uint32_t mach = br_get(&r, 2);
    regs_get(&r, 0, mach, 1);
    if (r.err || mach >= MA_N) return -1;
    br_rewind(&r);
    br_get(&r, 2);
    if (t->mach != mach) mach_kill(k);
    t->mach = (uint8_t)mach;
    regs_get(&r, t->base, mach, 1);
    trk_resolve(t, k);
    strip_coeffs(t);
    mach_retune(k, 0);
    return 0;
}

/* ---------------------------------------------------------------- KIT --- */
/* a scene value is stored as a step from the track's own (STP SPD: from the middle, they load later) */
static int32_t scn_ref(uint32_t k, uint32_t r) { return st_skip(r, 0) ? 64 : os.trk[k].base[r]; }

static void kit_put(bw_t *w)
{
    uint32_t k, p, s, i, r;
    pat_sync_out();
    bw_put(w, os.bpb, 9);
    bw_put(w, os.hf, 8); bw_put(w, os.m_glu, 8); bw_put(w, os.m_air, 8); bw_put(w, os.m_wid, 8); bw_put(w, os.m_cel, 8);
    for (k = 0; k < NTRACK; k++) {                           /* the sounds, and each track's learned pocket */
        const trk_t *t = &os.trk[k];
        int32_t pn = 0;
        bw_put(w, t->mach, 2);
        regs_put(w, t->base, TPL_V1[t->mach], 0);
        for (i = 0; i < 16u; i++) {
            fc_put(w, &pn, t->lrn_n[i], 8);
            if (t->lrn_n[i]) off_put(w, t->lrn[i]);
        }
    }
    for (p = 0; p < NPAT; p++) {                             /* the patterns: header, then the four lists */
        int32_t ps = 15, pp = 3;
        bw_eg(w, seq_hdr[p].bars);
        for (k = 0; k < NTRACK; k++) { fc_put(w, &ps, seq_hdr[p].stp[k], 8); fc_put(w, &pp, seq_hdr[p].spd[k], 8); }
        for (k = 0; k < NTRACK; k++) list_put(w, &seq_pat[p][k]);
    }
    for (i = 0; i < NTBL; i++) list_put(w, &seq_tbl[i]);
    for (s = 0; s < NSCN; s++)                               /* the scenes: per track, a value off the base */
        for (k = 0; k < NTRACK; k++) {
            uint32_t n = 0;
            int32_t last = -1;
            for (r = 0; r < NREG; r++) n += SCN_HAS(s, k, r);
            bw_eg(w, n);
            for (r = 0; r < NREG; r++) {
                if (!SCN_HAS(s, k, r)) continue;
                bw_eg(w, (uint32_t)((int32_t)r - last - 1));
                dv_put(w, scn_ref(k, r), scn[s].v[k][r]);
                last = (int32_t)r;
            }
        }
    bw_eg(w, seq_song_n);
    for (i = 0; i < seq_song_n; i++) bw_put(w, seq_song[i], 8);
}

/* the kit, bytes [lo, lo + n) of it into buf: its whole length (the same each time while nothing changes) */
static uint32_t st_kit_encode(uint8_t *buf, uint32_t lo, uint32_t n)
{
    bw_t w = {buf, lo, lo + n, 0, 0, 0};
    kit_put(&w);
    return (w.bit + 7u) >> 3;
}

/* the kit in buf: its length in bytes (0: it did not fit) */
static uint32_t st_kit_save(uint8_t *buf, uint32_t cap)
{
    bw_t w = {buf, 0, cap, 0, 0, 1};
    kit_put(&w);
    return w.err ? 0u : (w.bit + 7u) >> 3;
}

static int kit_get(br_t *r, int write)
{
    uint32_t k, p, s, i, reg, room = EV_HEAP, bpb, m[5], mach[NTRACK];
    bpb = br_get(r, 9);
    for (i = 0; i < 5u; i++) m[i] = br_get(r, 8);
    if (bpb < 100u || bpb > 500u) r->err = 1;
    if (write) {
        seq_play(0);
        os.bpb = (uint16_t)bpb;
        os.hf = (uint8_t)m[0]; os.m_glu = (uint8_t)m[1]; os.m_air = (uint8_t)m[2]; os.m_wid = (uint8_t)m[3]; os.m_cel = (uint8_t)m[4];
    }
    for (k = 0; k < NTRACK && !r->err; k++) {
        trk_t *t = &os.trk[k];
        int32_t pn = 0;
        mach[k] = br_get(r, 2);
        if (write) { mach_kill(k); t->mach = (uint8_t)mach[k]; }
        regs_get(r, write ? t->base : 0, mach[k], 0);
        for (i = 0; i < 16u; i++) {
            int32_t n = fc_get(r, &pn, 8), o = n ? off_get(r) : 0;
            if (n < 0 || n > 255) r->err = 1;
            if (write) { t->lrn_n[i] = (uint8_t)n; t->lrn[i] = (int16_t)o; }
        }
    }
    if (write) seq_used = 0;
    for (p = 0; p < NPAT && !r->err; p++) {
        int32_t ps = 15, pp = 3, st, sp;
        uint32_t bars = br_eg(r);
        if (bars > PAT_BARS) r->err = 1;
        if (write) seq_hdr[p].bars = (uint8_t)bars;
        for (k = 0; k < NTRACK; k++) {
            st = fc_get(r, &ps, 8); sp = fc_get(r, &pp, 8);
            if (st < 0 || st > 127 || sp < 0 || sp > 5) r->err = 1;
            if (write) { seq_hdr[p].stp[k] = (uint8_t)st; seq_hdr[p].spd[k] = (uint8_t)sp; }
        }
        for (k = 0; k < NTRACK && !r->err; k++) list_get(r, &seq_pat[p][k], write, &room);
    }
    for (i = 0; i < NTBL && !r->err; i++) list_get(r, &seq_tbl[i], write, &room);
    if (write) memset(scn, 0, sizeof scn);
    for (s = 0; s < NSCN && !r->err; s++)
        for (k = 0; k < NTRACK && !r->err; k++) {
            uint32_t n = br_eg(r);
            int32_t last = -1, x;
            if (n > NREG) { r->err = 1; break; }
            for (i = 0; i < n && !r->err; i++) {
                reg = (uint32_t)(last + 1 + (int32_t)br_eg(r));
                if (reg >= NREG) { r->err = 1; break; }
                x = dv_get(r, write ? scn_ref(k, reg) : TPL_V1[mach[k]][reg]);
                if (write) { SCN_SET(s, k, reg); scn[s].v[k][reg] = (uint8_t)x; }
                last = (int32_t)reg;
            }
        }
    {
        uint32_t n = br_eg(r);
        if (n > SONG_N) r->err = 1;
        else {
            if (write) seq_song_n = (uint8_t)n;
            for (i = 0; i < n; i++) { uint32_t v = br_get(r, 8); if (write) seq_song[i] = (uint8_t)v; }
        }
    }
    if (r->err || !write) return r->err ? -1 : 0;
    scs.n = 0;
    memset(scs.amt, 0, sizeof scs.amt);
    os.song_row = os.song_rep = 0;
    os.pat = 0;
    os.pat_next = 0xFF;
    pat_enter(0, 0);
    for (k = 0; k < NTRACK; k++) {
        trk_t *t = &os.trk[k];
        for (reg = 0; reg < NREG; reg++) t->lock[reg] = t->tlk[reg] = 0xFF;
        trk_resolve(t, k);
        strip_coeffs(t);
        mach_retune(k, 0);
    }
    seq_edits++;
    return 0;
}

/* a kit in (the transport stops): 0, or -1 (a broken record: nothing changed) */
static int st_kit_load_r(br_t *r)
{
    if (kit_get(r, 0)) return -1;
    br_rewind(r);
    return kit_get(r, 1);
}
static int st_kit_load(const uint8_t *p, uint32_t len)
{
    br_t r;
    br_ram(&r, p, len);
    return st_kit_load_r(&r);
}
static int st_sound_load(uint32_t k, const uint8_t *p, uint32_t len)
{
    br_t r;
    br_ram(&r, p, len);
    return st_sound_load_r(k, &r);
}
