#ifndef FX_H
#define FX_H
#ifndef FX_FS
#define FX_FS 44117.647f        /* the SMK-37 DAC rate (24 MHz / 544) */
#endif

typedef struct { float rate, depth, mix; } chorus_p;             /* Hz, 0..1, 0..1 */
typedef struct { float rate, depth, feedback, mix; } flanger_p;  /* Hz, 0..1, -0.95..0.95, 0..1 */
typedef struct { float decay_s, damp, shimmer, mix; } reverb_p;  /* s, 0..0.9, 0..1, 0..1 */

void chorus_init(void);
void chorus_process(float *L, float *R, int n, const chorus_p *p);
void flanger_init(void);
void flanger_process(float *L, float *R, int n, const flanger_p *p);
void reverb_init(void);
void reverb_set(const reverb_p *p);
void reverb_process(float *L, float *R, int n, const reverb_p *p);
unsigned fx_ram_bytes(void);
#endif
