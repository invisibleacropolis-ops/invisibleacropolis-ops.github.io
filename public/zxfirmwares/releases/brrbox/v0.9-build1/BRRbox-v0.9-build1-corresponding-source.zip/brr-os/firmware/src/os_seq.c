/* SPDX-License-Identifier: GPL-3.0-only */
/* The sequencer: one event list, one clock, locked to the codec's own grid.
 *   time    the core sample (125 us) is the tick: notes, locks, commands, retrigs and table rows land on any
 *           sample (event-driven: each track knows the next sample anything is due); the tempo is codec blocks
 *           per beat, so a beat is whole 2 ms blocks and a 16th is always bpb x 4 core samples
 *   events  8 bytes, per track and pattern, sorted by step: NOTE, LOCK, CMD; a lane is "LOCK events of
 *           one register"; a table is a pattern clocked by the tick. The kit's 40 lists (8 patterns x 4
 *           tracks, 8 tables) are slices of one heap of EV_HEAP events, in that order: a dense pattern takes
 *           what the others leave
 *   feel    a live note is stored as grid step + human residual (Q12 of a step), so it is quantised and
 *           lossless at once; FEEL / WIN / VFL / GRV shape it at playback (registers: lockable, morphable)
 * Locks belong to their step: they apply before any of the step's notes sound, even an early one, and
 * hold until the next step that has events (a step with only locks is a trigless lock). */
enum { EV_NOTE, EV_LOCK, EV_CMD };
enum { CD_ALWAYS, CD_P50, CD_P25, CD_P75, CD_1_2, CD_2_2, CD_1_4, CD_2_4, CD_3_4, CD_4_4, CD_FILL, CD_NFILL, CD_1ST, CD_N };
static const char CD_NAME[CD_N][5] = {"", "50%", "25%", "75%", "1:2", "2:2", "1:4", "2:4", "3:4", "4:4", "FILL", "!FIL", "1ST"};
#define EV_FRESH 0x80u                  /* NOTE.d: recorded during this pass, do not fire it again now */
#define LEN_HOLD 255u

typedef struct { uint8_t step, kind; int16_t off; uint8_t a, b, c, d; } ev_t;
typedef struct { uint16_t n; ev_t *e; } evl_t;

#define NLIST (NPAT * NTRACK + NTBL)
static ev_t seq_heap[EV_HEAP] __attribute__((section(".pool")));
static evl_t seq_all[NLIST];                    /* in heap order: the patterns' (pattern-major), then the tables */
static uint32_t seq_used;                       /* events in the heap */
static evl_t (*const seq_pat)[NTRACK] = (evl_t (*)[NTRACK])seq_all;
static evl_t *const seq_tbl = &seq_all[NPAT * NTRACK];

/* a pattern's own settings: each track's length and speed (STP, SPD: the registers show the playing
 * pattern's), and its length in bars (0 = AUTO: its longest track, rounded up to bars, 1 .. 8) */
typedef struct { uint8_t stp[NTRACK], spd[NTRACK], bars; } pat_hdr;
static pat_hdr seq_hdr[NPAT];

/* the song: rows of a pattern (bits 0-2) and its repeats - 1 (bits 3-7: 1 .. 32); it loops */
static uint8_t seq_song[SONG_N];
static uint8_t seq_song_n;
#define SONG_ROW(p, rep) ((uint8_t)(((rep) - 1u) << 3 | ((p) & 7u)))
#define SONG_PAT(r) ((uint32_t)(r) & 7u)
#define SONG_REP(r) (((uint32_t)(r) >> 3) + 1u)

/* retro capture: every note played on the keys, recording or not */
#define CAP_N 128u
static struct { uint8_t trk, note, vel, open; uint32_t on, off; } cap[CAP_N];
static uint32_t cap_w;
static struct { uint8_t on, trk, note, step; uint32_t at; } rec_open[10];

static evl_t *seq_list(uint32_t k) { return &seq_pat[os.pat][k]; }
static volatile uint32_t seq_edits, seq_edits_seen;   /* any list edit: the due lists are rebuilt (os_render) */

/* ---------------------------------------------------------------- the list --- */
static uint32_t evl_lower(const evl_t *l, uint32_t step)
{
    uint32_t lo = 0, hi = l->n;
    while (lo < hi) {
        uint32_t m = (lo + hi) >> 1;
        if (l->e[m].step < step) lo = m + 1u; else hi = m;
    }
    return lo;
}

/* the heap: an event in or out at e moves everything after it, and the lists after l */
static void heap_shift(evl_t *l, ev_t *at, int32_t d)
{
    uint32_t j;
    ev_t *end = seq_heap + seq_used;
    ev_t *q;
    if (d > 0) for (q = end; q > at; q--) q[0] = q[-1];     /* (no memmove on the device: whole events) */
    else for (q = at; q + 1 < end; q++) q[0] = q[1];
    for (j = (uint32_t)(l - seq_all) + 1u; j < NLIST; j++) seq_all[j].e += d;
    seq_used = (uint32_t)((int32_t)seq_used + d);
}

/* sorted by step, then kind (notes, locks, commands), then residual; equal ones in the order they came */
static int evl_insert(evl_t *l, const ev_t *ev)
{
    uint32_t i = evl_lower(l, ev->step);
    if (seq_used >= EV_HEAP || l->n >= 0xFFFFu)
        return -1;
    while (i < l->n && l->e[i].step == ev->step &&
           (l->e[i].kind > ev->kind ? 0 : l->e[i].kind < ev->kind ? 1 : l->e[i].off <= ev->off))
        i++;
    heap_shift(l, l->e + i, 1);
    l->e[i] = *ev;
    l->n++;
    seq_edits++;
    return (int)i;
}

/* every event of l out (in one move) */
static void evl_clear(evl_t *l)
{
    uint32_t j, n = l->n;
    ev_t *q, *end = seq_heap + seq_used;
    if (!n) return;
    for (q = l->e; q + n < end; q++) q[0] = q[n];
    for (j = (uint32_t)(l - seq_all) + 1u; j < NLIST; j++) seq_all[j].e -= n;
    seq_used -= n;
    l->n = 0;
    seq_edits++;
}

static void evl_delete(evl_t *l, uint32_t i)
{
    if (i >= l->n) return;
    heap_shift(l, l->e + i, -1);
    l->n--;
    seq_edits++;
}

/* -1 = none */
static int evl_find(const evl_t *l, uint32_t step, uint32_t kind, uint32_t a)
{
    uint32_t i;
    for (i = evl_lower(l, step); i < l->n && l->e[i].step == step; i++)
        if (l->e[i].kind == kind && l->e[i].a == a)
            return (int)i;
    return -1;
}

static uint32_t step_count(const evl_t *l, uint32_t step, uint32_t kind)
{
    uint32_t i, c = 0;
    for (i = evl_lower(l, step); i < l->n && l->e[i].step == step; i++)
        if (l->e[i].kind == kind) c++;
    return c;
}

static void step_clear(evl_t *l, uint32_t step, int kind)   /* kind < 0: everything */
{
    uint32_t i = evl_lower(l, step);
    while (i < l->n && l->e[i].step == step) {
        if (kind < 0 || l->e[i].kind == (uint32_t)kind) evl_delete(l, i);
        else i++;
    }
}

static void seq_put_note(evl_t *l, uint32_t step, uint32_t note, uint32_t vel, int32_t off, uint32_t len8, uint32_t flags)
{
    ev_t e;
    int i = evl_find(l, step, EV_NOTE, note);
    if (i >= 0) evl_delete(l, (uint32_t)i);
    e.step = (uint8_t)step; e.kind = EV_NOTE; e.off = (int16_t)off;
    e.a = (uint8_t)note; e.b = (uint8_t)vel; e.c = (uint8_t)len8; e.d = (uint8_t)flags;
    evl_insert(l, &e);
}

static void seq_put_lock(evl_t *l, uint32_t step, uint32_t reg, uint32_t val)
{
    ev_t e;
    int i = evl_find(l, step, EV_LOCK, reg);
    if (i >= 0) { l->e[i].b = (uint8_t)val; seq_edits++; return; }
    e.step = (uint8_t)step; e.kind = EV_LOCK; e.off = 0; e.a = (uint8_t)reg; e.b = (uint8_t)val; e.c = e.d = 0;
    evl_insert(l, &e);
}

static void seq_put_cmd(evl_t *l, uint32_t step, uint32_t letter, uint32_t arg, uint32_t c)
{
    ev_t e;
    int i = evl_find(l, step, EV_CMD, letter);
    if (i >= 0) evl_delete(l, (uint32_t)i);
    e.step = (uint8_t)step; e.kind = EV_CMD; e.off = 0; e.a = (uint8_t)letter; e.b = (uint8_t)arg; e.c = (uint8_t)c; e.d = 0;
    evl_insert(l, &e);
}

/* ---------------------------------------------------------------- track timing --- */
static uint32_t trk_steps(const trk_t *t) { return (uint32_t)t->base[R_STP] + 1u; }

/* a step in core samples: a 16th (bpb x 4) scaled by the speed (1/8 .. 4X: always whole samples) */
static uint32_t trk_steplen(const trk_t *t)
{
    uint32_t s = t->base[R_SPD] < 6 ? t->base[R_SPD] : 3u, l = (uint32_t)os.bpb * 4u;
    return s < 3u ? l << (3u - s) : l >> (s - 3u);
}

static uint32_t trk_looplen(const trk_t *t) { return trk_steps(t) * trk_steplen(t); }

/* the transport position of clock sample c */
static uint32_t seq_pos(uint32_t c) { return c - os.play_c0; }

/* a track's position in its loop: from the pattern's start (where every track restarts), plus a hop */
static uint32_t trk_pos(const trk_t *t, uint32_t c) { return (seq_pos(c) - os.pat_p0 + t->anchor) % trk_looplen(t); }

/* ---------------------------------------------------------------- patterns and the song --- */
static uint32_t seq_bar(void) { return (uint32_t)os.bpb * BLK * 4u; }

/* the playing pattern's settings: the tracks' STP, SPD into its header (before a switch, a save) */
static void pat_sync_out(void)
{
    uint32_t k;
    for (k = 0; k < NTRACK; k++) {
        seq_hdr[os.pat].stp[k] = os.trk[k].base[R_STP];
        seq_hdr[os.pat].spd[k] = os.trk[k].base[R_SPD];
    }
}

/* pattern p's length in clock samples */
static uint32_t pat_len(uint32_t p)
{
    uint32_t bar = seq_bar(), b = seq_hdr[p].bars, k;
    if (!b) {                                     /* AUTO: the longest track */
        uint32_t lmax = 0;
        for (k = 0; k < NTRACK; k++) {            /* (the playing one: its tracks' registers, as edited) */
            uint32_t sp = p == os.pat ? os.trk[k].base[R_SPD] : seq_hdr[p].spd[k];
            uint32_t st = p == os.pat ? os.trk[k].base[R_STP] : seq_hdr[p].stp[k];
            uint32_t s = sp < 6u ? sp : 3u, l = (uint32_t)os.bpb * 4u;
            l = (s < 3u ? l << (3u - s) : l >> (s - 3u)) * (st + 1u);
            if (l > lmax) lmax = l;
        }
        b = (lmax + bar - 1u) / bar;
    }
    return (b < 1u ? 1u : b > PAT_BARS ? PAT_BARS : b) * bar;
}

/* pattern p becomes the playing one at transport position pos: its settings in, every track from its step 1;
 * the passes (1:2, 1ST ...) count on while the same pattern plays again, and from 0 for a new one */
static void pat_enter(uint32_t p, uint32_t pos)
{
    uint32_t k, again = os.playing && p == os.pat && pos != 0u;
    os.pat = (uint8_t)p;
    os.pat_p0 = pos;
    for (k = 0; k < NTRACK; k++) {
        trk_t *t = &os.trk[k];
        t->base[R_STP] = seq_hdr[p].stp[k];
        t->base[R_SPD] = seq_hdr[p].spd[k];
        t->anchor = 0;
        if (!again) t->loops = 0xFFFFFFFFu;      /* (the first pass: 0) */
        t->lp_at = 0xFFFFFFFFu;
        t->lock_step = -1;
        t->hop_to = -1;
        t->due_dirty = 1;
    }
}

/* the pattern after the playing one ends: the song's next, else the cued one, else itself */
static uint32_t pat_after(void)
{
    if (os.song_on && seq_song_n) {
        if (os.song_row >= seq_song_n) os.song_row = 0;
        if (++os.song_rep >= SONG_REP(seq_song[os.song_row])) {
            os.song_rep = 0;
            if (++os.song_row >= seq_song_n) os.song_row = 0;
        }
        os.pat_next = 0xFF;
        return SONG_PAT(seq_song[os.song_row]);
    }
    if (os.pat_next != 0xFF) { uint32_t p = os.pat_next; os.pat_next = 0xFF; return p; }
    return os.pat;
}

/* clock samples from c0 to the playing pattern's end (m or more: not in this half) */
static uint32_t pat_to_end(uint32_t c0)
{
    uint32_t pl = pat_len(os.pat), in = seq_pos(c0) - os.pat_p0;
    return in >= pl ? 0u : pl - in;
}

/* at the playing pattern's end (clock sample c): the next one comes in, on that sample */
static void pat_end(uint32_t c)
{
    pat_sync_out();
    pat_enter(pat_after(), seq_pos(c));
}

/* choose a pattern: stopped, it is the one now; playing, it comes in when this one ends */
static void seq_pat_select(uint32_t p)
{
    p &= 7u;
    if (os.playing) { os.pat_next = (uint8_t)p; return; }
    pat_sync_out();
    pat_enter(p, 0);
    os.pat_next = 0xFF;
}


/* ---------------------------------------------------------------- grooves --- */
/* the groove of a TAPE track's loop from the encoder's onset map: per 16th slot the strength-weighted
 * residual of the onsets near it, relative to the downbeats' (so the loop's own pocket, not its phase) */
static void groove_from_audio(uint32_t k)
{
    trk_t *t = &os.trk[k];
    uint32_t ls, len, si = t->eff[TA_SMP], l16 = (uint32_t)os.bpb * 4u, sig, i;
    int32_t acc[16], wsum[16], ref = 0, refw = 0;
    if (t->mach != MA_TAPE) { for (i = 0; i < 16u; i++) t->agr[i] = 0; t->agr_sig = 0; return; }
    tape_region(t, &ls, &len);
    sig = si * 2654435761u ^ ls * 40503u ^ len ^ (uint32_t)os.bpb << 20;
    if (sig == t->agr_sig) return;
    t->agr_sig = sig;
    for (i = 0; i < 16u; i++) acc[i] = wsum[i] = 0;
    for (i = OS_ONSET_IDX[si]; i < OS_ONSET_IDX[si + 1u]; i++) {
        uint32_t o = OS_ONSET_POS[i], slot;
        int32_t rel, res;
        if (o < ls || o >= ls + len) continue;
        rel = (int32_t)(o - ls);
        slot = (uint32_t)(rel + (int32_t)l16 / 2) / l16;
        res = rel - (int32_t)(slot * l16);
        if (res * 4 > (int32_t)l16 || -res * 4 > (int32_t)l16) continue;   /* only onsets near a slot */
        acc[slot & 15u] += res * OS_ONSET_STR[i];
        wsum[slot & 15u] += OS_ONSET_STR[i];
    }
    for (i = 0; i < 16u; i += 4u) { ref += acc[i]; refw += wsum[i]; }
    ref = refw ? ref / refw : 0;
    for (i = 0; i < 16u; i++)
        t->agr[i] = (int16_t)os_clampi(wsum[i] ? ((acc[i] / wsum[i] - ref) * 4096) / (int32_t)l16 : 0, -683, 683);   /* +-1/6 step */
}

/* the audio grooves, before each render (core 0 only: a track may read another track's) */
static void groove_update(void)
{
    uint32_t k;
    for (k = 0; k < NTRACK; k++) {
        uint32_t g = os.trk[k].eff[R_GRV];
        if (g >= 6u) groove_from_audio(g - 6u);
    }
}

static int32_t groove_at(const trk_t *t, uint32_t step)
{
    static const int16_t SWING[4] = {328, 655, 983, 1311};   /* 54 58 62 66 %: (2s - 1) x 4096 */
    uint32_t g = t->eff[R_GRV], slot = step & 15u;
    if (!g) return 0;
    if (g <= 4u) return step & 1u ? SWING[g - 1u] : 0;
    if (g == 5u) return t->lrn_n[slot] ? t->lrn[slot] : 0;
    return os.trk[g - 6u].agr[slot];             /* (computed on core 0 before the render: groove_update) */
}

/* where an event plays, in core samples into the track's loop (not yet wrapped) */
static int32_t ev_time(const trk_t *t, const ev_t *e, uint32_t L)
{
    int32_t o = e->off, sh;
    if (e->kind == EV_NOTE) {
        int32_t win = (int32_t)t->eff[R_WIN] * 2048 / 127, fe = reg_feel_pct(t->eff[R_FEL]) * 256 / 100;   /* Q8: -1 .. +1.5 */
        if (o <= win && -o <= win)
            o = o * fe / 256;
        sh = o + groove_at(t, e->step);
        sh = os_clampi(sh, -3000, 3000);
    } else {
        sh = 0;
    }
    return (int32_t)(e->step * L) + sh * (int32_t)L / 4096;
}

static int cond_ok(trk_t *t, uint32_t c)
{
    static const uint8_t A[] = {0, 0, 0, 0, 1, 2, 1, 2, 3, 4}, B[] = {1, 1, 1, 1, 2, 2, 4, 4, 4, 4};
    switch (c) {
    case CD_ALWAYS: return 1;
    case CD_P50: return (os_rng(&t->rng) & 255u) < 128u;
    case CD_P25: return (os_rng(&t->rng) & 255u) < 64u;
    case CD_P75: return (os_rng(&t->rng) & 255u) < 192u;
    case CD_FILL: return os.fill;
    case CD_NFILL: return !os.fill;
    case CD_1ST: return t->loops == 0;
    default: return c < CD_FILL && (t->loops % B[c]) == (uint32_t)(A[c] - 1u);
    }
}

/* ---------------------------------------------------------------- firing --- */
/* registers changed by an event: resolve and the strip at once (not at the next block) */
static void trk_refresh(uint32_t k)
{
    trk_resolve(&os.trk[k], k);
    strip_coeffs(&os.trk[k]);
    mach_retune(k, 0);
}

static void seq_step_locks(uint32_t k, uint32_t step)
{
    trk_t *t = &os.trk[k];
    const evl_t *l = seq_list(k);
    uint32_t i, r;
    for (r = 0; r < NREG; r++) t->lock[r] = 0xFF;
    for (i = evl_lower(l, step); i < l->n && l->e[i].step == step; i++)
        if (l->e[i].kind == EV_LOCK) t->lock[l->e[i].a % NREG] = l->e[i].b;
    t->lock_step = (int16_t)step;
    t->rt_iv = 0;
    t->cut_cnt = 0;
    t->rt_n = 0;
    trk_refresh(k);
}

static void seq_cmd(uint32_t k, uint32_t letter, uint32_t b, uint32_t c, uint32_t at)
{
    trk_t *t = &os.trk[k];
    uint32_t i;
    switch (letter) {
    case 'R':                                    /* retrig every 2^(b/16) samples: b < 64 is audio rate */
        t->rt_iv = (uint16_t)os_clampi((int32_t)reg_samples(b), 1, 65535);
        t->rt_at = at + t->rt_iv;
        t->rt_drop = (uint8_t)c;
        break;
    case 'C': t->cut_cnt = 1; t->cut_at = at + reg_samples(b); break;
    case 'T':
        if (b && b <= NTBL) {
            t->tb_on = 1; t->tb_idx = (uint8_t)(b - 1u); t->tb_row = 0; t->tb_at = at; t->tb_note = 0;
            for (i = 0; i < NREG; i++) t->tlk[i] = 0xFF;
        }
        break;
    case 'H': t->hop_to = (int16_t)b; break;
    case 'K': mach_kill(k); break;
    case 'N': t->tb_note = (int8_t)((int32_t)b - 64); mach_retune(k, 0); break;
    default: break;
    }
}

static void seq_fire(uint32_t k, ev_t *e, uint32_t at, uint32_t L)
{
    trk_t *t = &os.trk[k];
    if (t->lock_step != e->step)
        seq_step_locks(k, e->step);
    if (e->kind == EV_NOTE) {
        uint32_t vel, len;
        if (!cond_ok(t, e->d & 15u)) return;
        vel = (uint32_t)os_clampi(100 + ((int32_t)e->b - 100) * (int32_t)t->eff[R_VFL] / 127, 1, 127);
        len = e->c == LEN_HOLD ? 0u : (uint32_t)e->c * L / 8u;
        mach_note_on(k, e->a, vel, at, len ? len : (e->c == LEN_HOLD ? 0u : 1u), 0);
        if (t->rt_n < 6u) { t->rt_note[t->rt_n] = e->a; t->rt_vel[t->rt_n] = (uint8_t)vel; t->rt_n++; }
    } else if (e->kind == EV_CMD) {
        seq_cmd(k, e->a, e->b, e->c, at);
    }
}

/* one table row; a row is a step of the table's list */
static void seq_table_row(uint32_t k, uint32_t at)
{
    trk_t *t = &os.trk[k];
    const evl_t *l = &seq_tbl[t->tb_idx];
    uint32_t i, row = t->tb_row, wrote = 0;
    int hop = -1;
    for (i = evl_lower(l, row); i < l->n && l->e[i].step == row; i++) {
        const ev_t *e = &l->e[i];
        if (e->kind == EV_LOCK) { t->tlk[e->a % NREG] = e->b; wrote = 1; }
        else if (e->kind == EV_CMD) {
            if (e->a == 'H') hop = e->b;
            else if (e->a == 'R') { uint32_t n; for (n = 0; n < t->rt_n; n++) mach_retrig(k, t->rt_note[n], t->rt_vel[n], at, reg_samples(t->base[R_TSP]) + 1u); }
            else seq_cmd(k, e->a, e->b, e->c, at);
        } else if (e->kind == EV_NOTE) {
            mach_note_on(k, e->a, e->b, at, e->c == LEN_HOLD ? 0u : reg_samples(t->base[R_TSP]) * (1u + e->c), 0);
        }
    }
    if (wrote) trk_refresh(k);
    t->tb_row = (uint8_t)(hop >= 0 ? (uint32_t)hop % TBL_ROWS : (row + 1u) % TBL_ROWS);
    t->tb_at = at + reg_samples(t->base[R_TSP]);
}

/* this step's due list: the events of the steps around it that play inside it, by clock sample */
static void seq_due_build(uint32_t k, uint32_t c)
{
    trk_t *t = &os.trk[k];
    evl_t *l = seq_list(k);
    uint32_t L = trk_steplen(t), n = trk_steps(t), TL = n * L, tp = trk_pos(t, c), s = tp / L, cc, st0;
    uint32_t lp = (seq_pos(c) - os.pat_p0 + t->anchor) / TL;
    if (lp != t->lp_at) {                         /* a new pass: recorded notes play again from now on */
        uint32_t i;
        t->lp_at = lp;
        t->loops++;
        for (i = 0; i < l->n; i++) l->e[i].d &= (uint8_t)~EV_FRESH;
    }
    if ((int32_t)s != t->cur_step && t->hop_to >= 0) {    /* H: jump the playhead, keep the grid */
        uint32_t to = (uint32_t)t->hop_to % n;
        t->anchor = (t->anchor + (to + n - s) * L) % TL;
        t->hop_to = -1;
        tp = trk_pos(t, c);
        s = tp / L;
    }
    t->cur_step = (int16_t)s;
    st0 = c - (tp - s * L);                       /* the clock sample this step starts on */
    t->due_end = st0 + L;
    t->due_n = t->due_i = 0;
    t->due_dirty = 0;
    for (cc = 0; cc < (n < 3u ? n : 3u); cc++) {
        uint32_t step = (s + n - 1u + cc) % n, i;
        for (i = evl_lower(l, step); i < l->n && l->e[i].step == step; i++) {
            int32_t T = ev_time(t, &l->e[i], L) % (int32_t)TL;
            uint32_t d, at, j;
            if (T < 0) T += (int32_t)TL;
            d = ((uint32_t)T + TL - s * L) % TL;
            if (d >= L) continue;
            at = st0 + d;
            if ((int32_t)(at - c) < 0 || t->due_n >= DUE_MAX) continue;      /* already past (a rebuild mid-step) */
            for (j = t->due_n; j > 0 && (int32_t)(t->due[j - 1u].at - at) > 0; j--) t->due[j] = t->due[j - 1u];
            t->due[j].at = at;
            t->due[j].ei = (uint16_t)i;
            t->due_n++;
        }
    }
}

/* everything due on track k at clock sample c */
static void seq_at(uint32_t k, uint32_t c)
{
    trk_t *t = &os.trk[k];
    if (os.playing) {
        evl_t *l = seq_list(k);
        if (t->due_dirty || (int32_t)(c - t->due_end) >= 0)
            seq_due_build(k, c);
        while (t->due_i < t->due_n && t->due[t->due_i].at == c) {
            ev_t *e = &l->e[t->due[t->due_i].ei];
            t->due_i++;
            if (e->d & EV_FRESH) { e->d &= (uint8_t)~EV_FRESH; continue; }
            seq_fire(k, e, c, trk_steplen(t));
        }
        if (t->rt_iv && t->rt_n && t->rt_at == c) {   /* R: retrig the step's notes */
            uint32_t i;
            for (i = 0; i < t->rt_n; i++) {
                t->rt_vel[i] = (uint8_t)os_clampi((int32_t)t->rt_vel[i] - t->rt_drop, 1, 127);
                mach_retrig(k, t->rt_note[i], t->rt_vel[i], c, t->rt_iv + 1u);
            }
            t->rt_at = c + t->rt_iv;
        }
        if (t->cut_cnt && t->cut_at == c) { t->cut_cnt = 0; mach_kill(k); }
    }
    if (t->tb_on && t->tb_at == c) seq_table_row(k, c);
    mach_offs(k, c);
}

/* the next clock sample after c that anything on track k is due (at most 'lim') */
static uint32_t seq_next(uint32_t k, uint32_t c, uint32_t lim)
{
    const trk_t *t = &os.trk[k];
    uint32_t nx = lim, o;
#define SEQ_MIN(x) do { uint32_t _x = (x); if ((int32_t)(_x - c) > 0 && (int32_t)(_x - nx) < 0) nx = _x; } while (0)
    if (os.playing) {
        if (t->due_i < t->due_n) SEQ_MIN(t->due[t->due_i].at);
        SEQ_MIN(t->due_end);
        if (t->rt_iv && t->rt_n) SEQ_MIN(t->rt_at);
        if (t->cut_cnt) SEQ_MIN(t->cut_at);
    }
    if (t->tb_on) SEQ_MIN(t->tb_at);
    o = mach_next_off(k, c);
    if (o != 0xFFFFFFFFu) SEQ_MIN(o);
#undef SEQ_MIN
    return nx;
}

/* ---------------------------------------------------------------- transport --- */
static void seq_play(int on)
{
    uint32_t k, r;
    if (on && !os.playing) {
        os.play_c0 = os.clock;                   /* the next sample rendered is step 0 */
        pat_sync_out();
        if (os.song_on && seq_song_n) { os.song_row = os.song_rep = 0; os.pat_next = 0xFF; }
        pat_enter(os.song_on && seq_song_n ? SONG_PAT(seq_song[0]) : os.pat_next != 0xFF ? os.pat_next : os.pat, 0);
        os.pat_next = 0xFF;
        for (k = 0; k < NTRACK; k++) {
            trk_t *t = &os.trk[k];
            t->cur_step = -1;
            t->rt_iv = 0;
            t->cut_cnt = 0;
            tape_jump[k] = 0;
        }
        os.playing = 1;
    } else if (!on && os.playing) {
        os.playing = 0;
        for (k = 0; k < NTRACK; k++) {
            mach_kill(k);
            for (r = 0; r < NREG; r++) os.trk[k].lock[r] = 0xFF;
            os.trk[k].tb_on = 0;
            os.trk[k].cur_step = -1;
        }
    }
}

/* tempo: codec blocks per beat, BPM = 30000 / bpb (150 = 200, 120 = 250); 300 .. 60 BPM */
static void seq_set_bpb(uint32_t bpb)
{
    uint32_t k;
    os.bpb = (uint16_t)os_clampi((int32_t)bpb, 100, 500);
    for (k = 0; k < NTRACK; k++) os.trk[k].due_dirty = 1;
}

/* the list of a track changed (an edit): its due list is rebuilt at the next sample */
static void seq_touch(uint32_t k) { os.trk[k].due_dirty = 1; }

/* ---------------------------------------------------------------- live recording --- */
/* a key went down at core position 'at' (the transport position you heard): play it now, keep it for
 * retro capture, and when recording store it as grid step + residual */
static void seq_key_on(uint32_t note, uint32_t vel, uint32_t at)
{
    uint32_t k = os.sel, i;
    trk_t *t = &os.trk[k];
    mach_note_on(k, note, vel, os.clock, 0, 1);
    t->last_note = (uint8_t)note;
    t->last_vel = (uint8_t)vel;
    i = cap_w++ % CAP_N;
    cap[i].trk = (uint8_t)k; cap[i].note = (uint8_t)note; cap[i].vel = (uint8_t)vel;
    cap[i].on = at; cap[i].off = at; cap[i].open = 1;
    if (!(os.playing && os.rec))
        return;
    {
        uint32_t L = trk_steplen(t), n = trk_steps(t), tp = trk_pos(t, at), s = (tp + L / 2u) / L, slot;
        int32_t off = (int32_t)tp - (int32_t)(s * L);
        if (s >= n) s -= n;
        off = off * 4096 / (int32_t)L;
        seq_put_note(seq_list(k), s, note, vel, off, LEN_HOLD, EV_FRESH);
        t->due_dirty = 1;
        slot = s & 15u;                          /* learn the pocket: a running mean per slot */
        t->lrn[slot] = (int16_t)(t->lrn_n[slot] ? (t->lrn[slot] * 3 + off) / 4 : off);
        if (t->lrn_n[slot] < 255u) t->lrn_n[slot]++;
        for (i = 0; i < 10u; i++)
            if (!rec_open[i].on) {
                rec_open[i].on = 1; rec_open[i].trk = (uint8_t)k; rec_open[i].note = (uint8_t)note;
                rec_open[i].step = (uint8_t)s; rec_open[i].at = at;
                break;
            }
    }
}

static void seq_key_off(uint32_t note, uint32_t at)
{
    uint32_t i, k;
    for (k = 0; k < NTRACK; k++) mach_note_off(k, note);
    for (i = 0; i < CAP_N; i++)
        if (cap[i].open && cap[i].note == note) { cap[i].open = 0; cap[i].off = at; }
    for (i = 0; i < 10u; i++)
        if (rec_open[i].on && rec_open[i].note == note) {
            trk_t *t = &os.trk[rec_open[i].trk];
            evl_t *l = seq_list(rec_open[i].trk);
            int j = evl_find(l, rec_open[i].step, EV_NOTE, note);
            uint32_t L = trk_steplen(t), len8 = ((at - rec_open[i].at) * 8u + L / 2u) / L;
            if (j >= 0) l->e[j].c = (uint8_t)os_clampi((int32_t)len8, 1, 254);
            rec_open[i].on = 0;
        }
}

/* SHIFT + REC: what you played over the last loop of the selected track goes into the pattern */
static uint32_t seq_capture(void)
{
    uint32_t k = os.sel, i, last = 0, got = 0, any = 0;
    trk_t *t = &os.trk[k];
    uint32_t L = trk_steplen(t), n = trk_steps(t), TL = n * L;
    for (i = 0; i < CAP_N; i++)
        if (cap[i].trk == k && cap[i].vel && (!any || (int32_t)(cap[i].on - last) > 0)) { last = cap[i].on; any = 1; }
    if (!any) return 0;
    for (i = 0; i < CAP_N; i++) {
        uint32_t tp, s;
        int32_t off;
        if (cap[i].trk != k || !cap[i].vel || (int32_t)(last - cap[i].on) >= (int32_t)TL) continue;
        tp = trk_pos(t, cap[i].on);
        s = (tp + L / 2u) / L;
        off = (int32_t)tp - (int32_t)(s * L);
        if (s >= n) s -= n;
        seq_put_note(seq_list(k), s, cap[i].note, cap[i].vel, off * 4096 / (int32_t)L,
                     cap[i].open ? LEN_HOLD : (uint32_t)os_clampi((int32_t)(((cap[i].off - cap[i].on) * 8u + L / 2u) / L), 1, 254), 0);
        got++;
    }
    t->due_dirty = 1;
    return got;
}

/* ---------------------------------------------------------------- scenes --- */
/* scene s in at amount a (1..127), on top of the ones in; already in: its amount, its place kept */
static void scene_on(uint32_t s, uint32_t a)
{
    if (s >= NSCN) return;
    if (!scs.amt[s]) scs.ord[scs.n++] = (uint8_t)s;
    scs.amt[s] = (uint8_t)(a < 1u ? 1u : a > 127u ? 127u : a);
}

static void scene_off(uint32_t s)
{
    uint32_t i, j = 0;
    if (s >= NSCN || !scs.amt[s]) return;
    scs.amt[s] = 0;
    for (i = 0; i < scs.n; i++) if (scs.ord[i] != s) scs.ord[j++] = scs.ord[i];
    scs.n = (uint8_t)j;
}

/* its amount: 0 takes it out */
static void scene_amount(uint32_t s, uint32_t a)
{
    if (a) scene_on(s, a); else scene_off(s);
}

/* scene s sets nothing any more (on every track) */
static void scene_clear(uint32_t s)
{
    if (s >= NSCN) return;
    memset(scn[s].mask, 0, sizeof scn[s].mask);
}

static void scene_write(uint32_t s, uint32_t k, uint32_t r, uint32_t v)
{
    SCN_SET(s, k, r);
    scn[s].v[k][r] = (uint8_t)v;
}

static void seq_init(void)
{
    uint32_t p, k;
    for (p = 0; p < NLIST; p++) { seq_all[p].n = 0; seq_all[p].e = seq_heap; }
    seq_used = 0;
    seq_edits++;
    os.pat = 0;
    os.pat_next = 0xFF;
    os.pat_p0 = 0;
    for (p = 0; p < NPAT; p++) {
        for (k = 0; k < NTRACK; k++) { seq_hdr[p].stp[k] = 15; seq_hdr[p].spd[k] = 3; }
        seq_hdr[p].bars = 0;
    }
    seq_song_n = 0;
    os.song_on = os.song_row = os.song_rep = 0;
    for (k = 0; k < NTRACK; k++) { os.trk[k].hop_to = -1; os.trk[k].cur_step = -1; os.trk[k].lock_step = -1; }
}
