/* SPDX-License-Identifier: GPL-3.0-only */
/* BRR-OS shared definitions: what the reused Felucca files (usb.c, ota.c, ota_hw.c, storage_hw.c,
 * lcd.c) expect from the application, plus the engine constants. */
#pragma once
#include <stdint.h>

#ifndef OS_NAME
#define OS_NAME "BRR-OS"                 /* shown on the splash and the top line; rename freely */
#endif
#ifndef OS_VERSION
#define OS_VERSION "v0.4"
#endif

/* ----------------------------------------------------------- system --- */
#define RING_PUBLISH() __asm__ volatile("" ::: "memory")   /* slot store before the index update */
static volatile uint32_t fm1_ms;          /* milliseconds since boot (TIMER4-based, TIMER5 ISR) */
#define BOOTGUARD_MAGIC 0x42475244u
/* boot-loop guard: two boots in a row that die in the first 30 s -> UBOOT (os_main.c) */
struct { uint32_t magic, failed, pending; } bootguard __attribute__((section(".noinit")));

/* --------------------------------------------------------- audio rate --- */
#define HALF_FRAMES 128u                   /* I2S half buffer: 2.9 ms */
#define OS_FS 44117.647f                   /* 24 MHz / 544 per frame */
#define OS_CORE_SR 8000.0f                 /* the SVBRR core rate */

static inline int32_t os_clampi(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }
static inline float os_clampf(float v, float lo, float hi) { return v < lo ? lo : v > hi ? hi : v; }

/* sqrt without libm: bit-level guess, three Newton steps (relative error < 1e-6 for x > 1e-30) */
static float os_sqrt(float x)
{
    union { float f; uint32_t i; } u;
    float y;
    if (x <= 0.0f)
        return 0.0f;
    u.f = x;
    u.i = 0x1FBD1DF5u + (u.i >> 1);
    y = u.f;
    y = 0.5f * (y + x / y);
    y = 0.5f * (y + x / y);
    y = 0.5f * (y + x / y);
    return y;
}

/* ------------------------------------------------- display shims --- */
/* ota_hw.c draws its progress with Felucca's names: map them onto os_font.c */
typedef struct { uint8_t scale; } os_font_t;
static const os_font_t AF_M = {2}, AF_S = {1};
#define T_BG 0x0000u
#define T_TEXT 0xFFFFu
#define T_THEME 0xFD20u                   /* amber */
static void draw_text_box(uint32_t x, uint32_t y, uint32_t w, const os_font_t *f, const char *s,
                          uint16_t color, int center);

/* storage_hw.c forward-declares two storage.c helpers for erases in USRFLASH (the stock mapping's end marker).
 * BRR-OS writes only FL_DATA (the vault, os_vault.c), never USRFLASH (kept for the user samples), so they are
 * inert. The day samples are written there, st_stock_release must do what Felucca's storage.c does. */
static void st_stock_release(void) {}
static int st_in_usrflash(uint32_t off) { (void)off; return 0; }

/* the filter (os_flt.c): a TPT state-variable filter's coefficients (a1..a3 from g and k) and the mix of its LP,
 * BP and HP outputs, and its state */
enum { FLT_OFF, FLT_LP, FLT_BP, FLT_HP };
typedef struct { float a1, a2, a3, k, ml, mb, mh; } flt_c;
typedef struct { float s1, s2; } flt_s;

/* a biquad (transposed direct form II) */
typedef struct { float b0, b1, b2, a1, a2, z1, z2; } bq_t;

static inline float bq_run(bq_t *f, float x)
{
    float y = f->b0 * x + f->z1;
    f->z1 = f->b1 * x - f->a1 * y + f->z2;
    f->z2 = f->b2 * x - f->a2 * y;
    return y;
}

static void bq_set(bq_t *f, const float *c)
{
    f->b0 = c[0]; f->b1 = c[1]; f->b2 = c[2]; f->a1 = c[3]; f->a2 = c[4];
    f->z1 = f->z2 = 0.0f;
}
