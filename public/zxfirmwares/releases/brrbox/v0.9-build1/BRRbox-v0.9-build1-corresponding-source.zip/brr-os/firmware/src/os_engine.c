/* SPDX-License-Identifier: GPL-3.0-only */
/* The render, on one clock. The whole engine runs at the codec's 8 kHz: a track renders core samples, and
 * anything due (a note, a lock, a retrig, a table row) lands on its exact sample. Each half buffer:
 *   1. control, on core 0: pattern changes at the bar, audio grooves
 *   2. the tracks: each one alone (its own voices, state and scratch), so some can go to the second core;
 *      one core does it all when there is no second core, or when it stops answering. A track is a stereo
 *      submix: machine (M, and S when spread) -> strip -> low cut -> compressor -> multi-effect -> reverb (os_tfx.c)
 *      -> level / pan; its core part
 *      goes to the core bus (8 kHz: sums are linear, so one upsampler serves all four tracks exactly as four
 *      would), its rebuilt highs to the air bus (32 kHz, os_hf.c), WAVE to the wide bus (32 kHz)
 *   3. up to the DAC: the core bus by Hermite at the exact ratio (375 frames = 68 core samples), the wide and
 *      air buses by the 375-phase resampler (272 wide samples = 375 frames); WARP scales both, so the whole
 *      clock domain plays faster or slower together. The air is read OS_LAT - HF_ADV core samples late, the
 *      rest OS_LAT: the air's own group delay makes up the difference, so copies sit on their transients
 *   4. the master bus (os_hf.c), then the DAC. The effects are inside each track (os_tfx.c), before its air */
#ifndef OS_CPU2
#define OS_CPU2 0
#endif

typedef struct {
    float l[MAXCORE], r[MAXCORE];                               /* core domain: L, R */
    float wl[MAXCORE * WIDE], wr[MAXCORE * WIDE];
    float al[MAXCORE * WIDE], ar[MAXCORE * WIDE];               /* the air (os_hf.c) */
    float tb[MAXCORE * WIDE], ts[MAXCORE * WIDE];               /* a track's scratch: mid, side */
    float g_l[BLK], g_r[BLK];                                   /* a segment's pan gains, per core sample */
    float xm[BLK], xs[BLK];                                     /* WAVE: its wet, at the clock rate (os_tfx.c) */
    mbus_t mb;                                                  /* a track's modulation bus (os_mod.c) */
    uint8_t wide, air;                                          /* WAVE wrote the wide buses / a track the air */
} bus_t;
static bus_t bus[2] __attribute__((section(".pool")));          /* one per core */

#define OS_LAT (5u + HF_ADV)                                    /* core samples from the clock to the DAC input */
#define UP_HC (OS_LAT + 1u)                                     /* history: the Hermite reaches OS_LAT + 1 back */
#define UP_HW (WIDE * OS_LAT + 16u)                             /* the resampler: 15 taps back of WIDE x OS_LAT */
static float up_c[2][UP_HC + MAXCORE] __attribute__((section(".pool")));
static float up_w[2][UP_HW + MAXCORE * WIDE] __attribute__((section(".pool")));
static float ob_l[HALF_FRAMES], ob_r[HALF_FRAMES], ow_l[HALF_FRAMES], ow_r[HALF_FRAMES];
static uint8_t wide_tail;                                       /* halves the wide buses still ring for */

/* ------------------------------------------------------------ the second core -- */
#if OS_CPU2
#define C1_ON() (fm1_c1_on && os.cpu2)
#define C1_RUN(fn, arg) fm1_cpu1_run(fn, arg)
#define C1_WAIT() fm1_cpu1_wait()
#define OS_TICKS() fm1_ticks()
#elif defined(OS_HOST_DUAL)                                     /* the host: core 1's part, run in turn */
static uint32_t host_c1_mask;
#define C1_ON() 1
#define C1_RUN(fn, arg) (host_c1_mask = (arg), 1)
#define C1_WAIT() (c1_job(host_c1_mask), 0)
#define OS_TICKS() 0u
#else
#define C1_ON() 0
#define C1_RUN(fn, arg) 0
#define C1_WAIT() 0
#define OS_TICKS() 0u
#endif

static void os_set_warp(float w) { os.warp = os_clampf(w, 0.5f, 2.0f); }

static int os_engine_init(void)
{
    uint32_t k;
    if (sv_open(&os.lib, OS_LIB, (uint32_t)sizeof OS_LIB))
        return -1;
    seq_set_bpb((uint32_t)(30000.0f / (float)OS_SCENE_BPM + 0.5f));
    os_set_warp(1.0f);
    os.master = 100;
    os.fx_on = 1;
    os.hf = 50;
    os.morph = 0;
    os.cpu2 = OS_CPU2;
    os.m_glu = 20;
    os.m_air = 25;
    os.m_wid = 100;
    os.m_cel = 5;                                    /* -0.5 dB */
    for (k = 0; k < NTRACK; k++) {
        static const uint8_t M[NTRACK] = {MA_TAPE, MA_MULTI, MA_WAVE, MA_GRAN};
        trk_t *t = &os.trk[k];
        trk_defaults(t, M[k], k);
        if (M[k] == MA_TAPE) {
            uint32_t bc = beat_core();
            t->base[TA_STR] = (uint8_t)((OS_SCENE[k].start + bc / 2u) / bc);   /* the grid: whole beats */
            t->base[TA_LEN] = OS_SCENE[k].beats >= 32 ? 5 : OS_SCENE[k].beats >= 16 ? 4 : OS_SCENE[k].beats >= 8 ? 3 : 2;
        }
        t->last_note = 60;
        t->last_vel = 100;
        t->l2.rnd = 0x9E3779B9u * (k + 1u);
        t->l1m.rnd = t->vl1.rnd = 0x6C8E9CF5u * (k + 3u);
        t->rng = 0x2545F491u * (k + 1u);
        gran[k].rng = 0x85EBCA6Bu * (k + 1u);
        wave[k].fk[0] = wave[k].fk[1] = -1;
        trk_resolve(t, k);
        strip_coeffs(t);
    }
    os.trk[1].last_note = 48;                       /* the kit: C3 is the kick */
    seq_init();
    hf_init();
    rs_init();
    master_init();
    for (k = 0; k < NTRACK; k++) { os.trk[k].cmp_g = 1.0f; os.trk[k].lead_rate = 1.0f; }
    tx_init();
    memset(shp, 0, sizeof shp);
    return 0;
}

/* --------------------------------------------------------------- a track -- */
static void trk_block(uint32_t k, uint32_t c)
{
    trk_t *t = &os.trk[k];
    float lv, p;
    mod_block(k, c);                                 /* the modulators first: their register targets resolve */
    trk_resolve(t, k);
    mach_block(k, c);
    sh_block(k);
    {   /* a side: voice spread, or a voice source on PAN */
        uint8_t ms = t->mach != MA_TAPE && (t->eff[R_SPR] > 0u || t->rt[MS_ENV1].kind == MK_PAN || t->rt[MS_LFO1].kind == MK_PAN);
        if (ms && !t->ms) t->fst[1].s1 = t->fst[1].s2 = 0.0f;
        t->ms = ms;
    }
    trk_post_block(t);
    tx_block(k, c);
    hf_block(k);
    lv = (float)t->eff[R_LEV] / 127.0f;
    p = (float)t->eff[R_PAN] / 127.0f;
    lv *= lv;
    t->gl_t = lv * (1.0f - p * p);
    t->gr_t = lv * (1.0f - (1.0f - p) * (1.0f - p));
}

/* track k for clock samples c0 .. c0 + m - 1 into bus b at offset o: everything due lands on its sample */
static void trk_run(uint32_t k, uint32_t c0, uint32_t m, bus_t *b, uint32_t o)
{
    trk_t *t = &os.trk[k];
    uint32_t c = c0, end = c0 + m, sub = t->mach == MA_WAVE ? WIDE : 1u;
    uint32_t t0 = OS_TICKS();
    int fx, st;
    while (c != end) {
        uint32_t nx, n, i, lim;
        if ((c & (BLK - 1u)) == 0u)
            trk_block(k, c);
        seq_at(k, c);
        lim = (c | (BLK - 1u)) + 1u;                 /* the next block boundary */
        if ((int32_t)(end - lim) < 0) lim = end;
        nx = seq_next(k, c, lim);
        n = nx - c;
        mod_track_run(k, n, &b->mb);                 /* ENV2, LFO2, the free LFO1: every clock sample */
        for (i = 0; i < n * sub; i++) b->tb[i] = 0.0f;
        if (t->ms) for (i = 0; i < n * sub; i++) b->ts[i] = 0.0f;
        mach_render(k, b->tb, t->ms ? b->ts : 0, n, &b->mb);
        if (shp[k].on && !t->eff[R_SPS]) sh_run(k, b->tb, t->ms ? b->ts : 0, n * sub);   /* the shaper PRE */
        strip_render(k, b->tb, t->ms ? b->ts : 0, n, &b->mb);
        if (shp[k].on && t->eff[R_SPS]) sh_run(k, b->tb, t->ms ? b->ts : 0, n * sub);    /* POST */
        trk_post(t, b->tb, t->ms ? b->ts : 0, n);
        fx = tx_active(k);
        st = t->ms;
        if (fx && sub == 1u) {                       /* the effects, in place; their output is stereo */
            if (!st) for (i = 0; i < n; i++) b->ts[i] = 0.0f;
            tx_run(k, b->tb, b->ts, n, c);
            st = 1;
        } else if (fx) {                             /* WAVE: the dry stays 32 kHz, the wet runs on the clock */
            tx_decim(k, b->tb, b->xm, n, 0);
            if (st) tx_decim(k, b->ts, b->xs, n, 1);
            else for (i = 0; i < n; i++) b->xs[i] = 0.0f;
            hf_wave_measure(k, b->tb, n * WIDE);
            for (i = 0; i < n; i++) { b->g_l[i] = b->xm[i]; b->g_r[i] = b->xs[i]; }   /* (the dry's copy) */
            tx_run(k, b->xm, b->xs, n, c);
            for (i = 0; i < n; i++) {                /* wet only here; the dry goes on at 32 kHz, scaled */
                float dm = tx[k].on ? tx[k].dmix : 1.0f, dr = tx[k].rv_on ? tx[k].rdry : 1.0f;
                b->xm[i] -= b->g_l[i] * dm * dr;
                b->xs[i] -= b->g_r[i] * dm * dr;
            }
        }
        if (st || fx) tx_image(k, fx && sub > 1u ? b->xm : b->tb, fx && sub > 1u ? b->xs : b->ts, n);
        {   /* gains: slewed toward the block's targets; an LFO on LEV acts here. L = M + S, R = M - S */
            float *L = sub > 1u ? b->wl + (o * WIDE) : b->l + o, *R = sub > 1u ? b->wr + (o * WIDE) : b->r + o;
            float dg = fx && sub > 1u ? (tx[k].on ? tx[k].dmix : 1.0f) * (tx[k].rv_on ? tx[k].rdry : 1.0f) : 1.0f;
            float il = st || fx ? tx[k].imgL : 1.0f, ir = st || fx ? tx[k].imgR : 1.0f;
            uint32_t q;
            for (i = 0; i < n; i++) {
                float am = b->mb.lev_on ? b->mb.lev[i] : 1.0f;    /* ENV2 / LFO2 on LEV, every sample */
                float gl, gr;
                t->gl += (t->gl_t - t->gl) * 0.02f;
                t->gr += (t->gr_t - t->gr) * 0.02f;
                gl = t->gl * am; gr = t->gr * am;
                for (q = 0; q < sub; q++) {
                    float x = b->tb[i * sub + q], y = st ? b->ts[i * sub + q] : 0.0f;
                    L[i * sub + q] += (x + y) * gl * dg;
                    R[i * sub + q] += (x - y) * gr * dg;
                }
                if (fx && sub > 1u) {                /* the WAVE wet: into the core bus */
                    b->l[o + i] += (b->xm[i] + b->xs[i]) * gl;
                    b->r[o + i] += (b->xm[i] - b->xs[i]) * gr;
                }
                b->g_l[i] = gl * il;                 /* the air follows the image (os_tfx.c) */
                b->g_r[i] = gr * ir;
            }
            if (sub == 1u) {
                hf_run(k, b->tb, n, c, b->g_l, b->g_r, b->al + (o * WIDE), b->ar + (o * WIDE));
                if (hf[k].live) b->air = 1;
            } else {
                b->wide = 1;
                if (fx) {
                    hf_run(k, b->xm, n, c, b->g_l, b->g_r, b->al + (o * WIDE), b->ar + (o * WIDE));
                    if (hf[k].live) b->air = 1;
                }
            }
        }
        o += n;
        c = nx;
    }
    t->cost = OS_TICKS() - t0;
}

/* --------------------------------------------------------------- the split -- */
static struct { uint32_t c0, m, o; } c1_part;

static void c1_job(uint32_t mask)                    /* on the second core: its tracks into bus[1] */
{
    uint32_t k;
    for (k = 0; k < NTRACK; k++)
        if (mask >> k & 1u) trk_run(k, c1_part.c0, c1_part.m, &bus[1], c1_part.o);
}

/* which tracks go to the second core: the split of last half's costs that leaves the busier core the least;
 * none when that saves less than the handover costs */
#define C1_HAND 2400u                                   /* ticks (100 us at 24 MHz): handing over, waiting */
static uint32_t c1_split(void)
{
#ifdef OS_HOST_DUAL
    return 0xCu;                                        /* (host: tracks 3 and 4, to check the split is exact) */
#else
    uint32_t m, k, best = 0, all = 0, lo;
    for (k = 0; k < NTRACK; k++) all += os.trk[k].cost;
    lo = all;
    for (m = 1; m < (1u << NTRACK) - 1u; m++) {
        uint32_t c1 = C1_HAND, c0;
        for (k = 0; k < NTRACK; k++) if (m >> k & 1u) c1 += os.trk[k].cost;
        c0 = all - (c1 - C1_HAND);
        if ((c0 > c1 ? c0 : c1) < lo) { lo = c0 > c1 ? c0 : c1; best = m; }
    }
    return best;
#endif
}

/* clock samples c0 .. c0 + m - 1 of every track into bus[0], at offset o */
static void render_range(uint32_t c0, uint32_t m, uint32_t o)
{
    uint32_t k, mask = C1_ON() ? c1_split() : 0u, i;
    if (!m) return;
    if (mask) {
        for (i = 0; i < m; i++) bus[1].l[o + i] = bus[1].r[o + i] = 0.0f;
        for (i = 0; i < m * WIDE; i++) {
            bus[1].wl[o * WIDE + i] = bus[1].wr[o * WIDE + i] = 0.0f;
            bus[1].al[o * WIDE + i] = bus[1].ar[o * WIDE + i] = 0.0f;
        }
        bus[1].wide = bus[1].air = 0;
        c1_part.c0 = c0; c1_part.m = m; c1_part.o = o;
        if (!C1_RUN(c1_job, mask)) mask = 0;
    }
    os.c1_mask = (uint8_t)mask;
    for (k = 0; k < NTRACK; k++)
        if (!(mask >> k & 1u)) trk_run(k, c0, m, &bus[0], o);
    if (mask) {
        if (C1_WAIT()) {                                 /* it stopped answering (held from now on): its part here */
            os.cpu2 = 0;
            c1_job(mask);
        }
        for (i = 0; i < m; i++) {
            bus[0].l[o + i] += bus[1].l[o + i]; bus[0].r[o + i] += bus[1].r[o + i];
        }
        if (bus[1].wide) {
            for (i = 0; i < m * WIDE; i++) {
                bus[0].wl[o * WIDE + i] += bus[1].wl[o * WIDE + i];
                bus[0].wr[o * WIDE + i] += bus[1].wr[o * WIDE + i];
            }
            bus[0].wide = 1;
        }
        if (bus[1].air) {
            for (i = 0; i < m * WIDE; i++) {
                bus[0].al[o * WIDE + i] += bus[1].al[o * WIDE + i];
                bus[0].ar[o * WIDE + i] += bus[1].ar[o * WIDE + i];
            }
            bus[0].air = 1;
        }
    }
}

/* --------------------------------------------------------------- the upsampler -- */
/* n frames from buf (h samples of history, then the new ones) at times scale x (phase + i x step - d) */
static void upsample(const float *buf, uint32_t h, float scale, float phase, float step, float d, float *out, uint32_t n)
{
    uint32_t i;
    for (i = 0; i < n; i++) {
        float tt = scale * (phase + (float)i * step - d), f;
        int32_t s = (int32_t)tt;
        const float *y;
        float c1, c2, c3;
        if ((float)s > tt) s--;
        f = tt - (float)s;
        y = buf + (int32_t)h + s - 1;                      /* y[0] .. y[3] = times s - 1 .. s + 2 */
        c1 = 0.5f * (y[2] - y[0]);
        c2 = y[0] - 2.5f * y[1] + 2.0f * y[2] - 0.5f * y[3];
        c3 = 0.5f * (y[3] - y[0]) + 1.5f * (y[1] - y[2]);
        out[i] = ((c3 * f + c2) * f + c1) * f + y[1];
    }
}

/* --------------------------------------------------------------- one half -- */
static bq_t clp[2][2];                                  /* the core bus after its Hermite: low-pass 3.9 kHz */
static uint8_t clp_ok;

static void os_render(int32_t *out, uint32_t n)       /* n <= HALF_FRAMES, interleaved L R, 24-bit */
{
    float step = UPS_STEP * os.warp, tot = os.up_phase + (float)n * step;
    uint32_t m = (uint32_t)tot, c0 = os.clock, i, k, m0 = m;
    if (m > MAXCORE) m = MAXCORE;
    if (!clp_ok) { for (k = 0; k < 2u; k++) { bq_set(&clp[k][0], HF_CLP_A); bq_set(&clp[k][1], HF_CLP_B); } clp_ok = 1; }
    /* 1. control */
    groove_update();
    if (seq_edits != seq_edits_seen) {               /* the lists changed: every track rebuilds its due list */
        seq_edits_seen = seq_edits;
        for (k = 0; k < NTRACK; k++) os.trk[k].due_dirty = 1;
    }
    hf_amount = (float)os.hf * (1.0f / 50.0f);
    os.voices = (uint8_t)vb_enforce();               /* the shared voice budget */
    for (i = 0; i < m; i++) bus[0].l[i] = bus[0].r[i] = 0.0f;
    for (i = 0; i < m * WIDE; i++) bus[0].wl[i] = bus[0].wr[i] = bus[0].al[i] = bus[0].ar[i] = 0.0f;
    bus[0].wide = bus[0].air = 0;
    /* 2. the tracks; the next pattern (the song's, or a cued one) lands exactly on the playing one's end */
    if (os.playing) {
        uint32_t to = pat_to_end(c0);
        if (to < m) {
            render_range(c0, to, 0);
            pat_end(c0 + to);
            render_range(c0 + to, m - to, to);
        } else {
            render_range(c0, m, 0);
        }
    } else {
        render_range(c0, m, 0);
    }
    /* 3. up to the DAC rate: the core bus (Hermite, then its low-pass), the wide and air buses (375 phases) */
    for (i = 0; i < m; i++) { up_c[0][UP_HC + i] = bus[0].l[i]; up_c[1][UP_HC + i] = bus[0].r[i]; }
    upsample(up_c[0], UP_HC, 1.0f, os.up_phase, step, (float)OS_LAT, ob_l, n);
    upsample(up_c[1], UP_HC, 1.0f, os.up_phase, step, (float)OS_LAT, ob_r, n);
    for (k = 0; k < 2u; k++)
        for (i = 0; i < UP_HC; i++) up_c[k][i] = up_c[k][m + i];
    for (i = 0; i < n; i++) {
        ob_l[i] = bq_run(&clp[0][1], bq_run(&clp[0][0], ob_l[i]));
        ob_r[i] = bq_run(&clp[1][1], bq_run(&clp[1][0], ob_r[i]));
    }
    if (bus[0].wide || bus[0].air) wide_tail = 8;
    if (wide_tail) {
        uint32_t adv = WIDE * HF_ADV;
        wide_tail -= bus[0].wide || bus[0].air ? 0 : 1;
        for (i = 0; i < m * WIDE; i++) { up_w[0][UP_HW + i] = bus[0].wl[i]; up_w[1][UP_HW + i] = bus[0].wr[i]; }
        if (bus[0].air)                                 /* the air, HF_ADV core samples ahead */
            for (i = 0; i < m * WIDE; i++) { up_w[0][UP_HW + i - adv] += bus[0].al[i]; up_w[1][UP_HW + i - adv] += bus[0].ar[i]; }
        rs_run(up_w[0], up_w[1], UP_HW, os.up_phase, step, (float)OS_LAT, ow_l, ow_r, n);
        for (k = 0; k < 2u; k++)
            for (i = 0; i < UP_HW; i++) up_w[k][i] = up_w[k][m * WIDE + i];
        for (i = 0; i < n; i++) { ob_l[i] += ow_l[i]; ob_r[i] += ow_r[i]; }
    }
    os.up_phase = tot - (float)m0;
    if (os.up_phase < 0.0f) os.up_phase = 0.0f;
    os.clock = c0 + m;
    /* 4. the master bus (the effects are each track's own: os_tfx.c) */
    master_process(ob_l, ob_r, n);
    for (i = 0; i < n; i++) {
        out[2u * i] = (int32_t)(os_clampf(ob_l[i], -1.0f, 1.0f) * 4194303.0f);   /* 24-bit, -6 dBFS ceiling (as Felucca) */
        out[2u * i + 1u] = (int32_t)(os_clampf(ob_r[i], -1.0f, 1.0f) * 4194303.0f);
    }
}
