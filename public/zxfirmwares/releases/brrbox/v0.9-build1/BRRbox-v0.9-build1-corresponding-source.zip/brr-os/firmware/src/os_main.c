/* SPDX-License-Identifier: GPL-3.0-only */
/* Boot and main loop. Boot order and the safety nets follow Felucca's main.c (GPL-3.0, Leo Kuroshita /
 * Hügelton Instruments): watchdog first, boot-loop guard (two early deaths in a row -> UBOOT), fault
 * vectors and guards; then LCD, input (TIMER5, 10 kHz), audio (ALNK0). Kept: the M-UPGRADE update
 * entry over USB MIDI (so the usual installers work), the UBOOT SysEx and OCTAVE- + OCTAVE+ held 5 s. */
extern uint32_t _data_start[], _data_end[], _data_load[], _bss_start[], _bss_end[];
extern uint32_t _pool_start[], _pool_end[], _rt_start[], _rt_end[], _rt_load[];
#if OS_CPU2
extern uint32_t _c1_start[], _c1_end[], _c1_load[];
#endif
static uint8_t flash_ok_boot;

/* TIMER5 outranks ALNK0: the key scan keeps its 100 us pace while a half renders; nested, it only
 * scans and counts ms. USB is polled at 2 kHz outside the render. */
void fm1_timer5_irq(void)
{
    static uint32_t sub, owed;
    uint32_t t0 = fm1_ticks(), usb_due = sub % 5u == 0u;
    fm1_timer5_ack();
    fm1_input_tick();
    {   /* key edges, stamped here (the scan's own pace) with the transport position you heard */
        static uint64_t was;
        uint64_t now = fm1_in.keys, ch = now ^ was;
        if (ch) {
            uint32_t k, at = os_heard_core(t0);
            for (k = 0; k < FM1_NKEY; k++)
                if (ch >> k & 1u) {
                    uint32_t i = kq_w % 32u;
                    if (kq_w - kq_r >= 32u) break;
                    kq[i].key = (uint8_t)k;
                    kq[i].on = (uint8_t)(now >> k & 1u);
                    kq[i].vel = fm1_in.key_vel[k] ? fm1_in.key_vel[k] : 100u;
                    kq[i].core = at;
                    kq_w++;
                }
            was = now;
        }
    }
    {
        static uint32_t last, acc;
        acc += t0 - last;
        last = t0;
        while (acc >= 1000u * FM1_TICKS_PER_US) {
            acc -= 1000u * FM1_TICKS_PER_US;
            fm1_ms++;
        }
    }
    if (usb_due)
        owed |= 1u;
    if (++sub == 10u)
        sub = 0;
    if (os_in_audio) {
        t5_nested_ticks += fm1_ticks() - t0;
        return;
    }
    if (owed & 1u)
        usb_poll();
    owed = 0;
}
extern void isr_timer5(void);

static void hexs(char *b, uint32_t v)
{
    uint32_t i;
    for (i = 0; i < 8u; i++)
        b[i] = "0123456789ABCDEF"[(v >> (28u - 4u * i)) & 15u];
    b[8] = 0;
}

static void fm1_fault(const fm1_crash_t *c)
{
    char b[12];
    uint32_t t0;
    fm1_audio_stop();
    lcd_fill(0, 0, 240, 240, 0x8000u);
    draw_text(8, 8, 224, OS_NAME " CRASH", 2, 0xFFFFu, 0x8000u);
    hexs(b, c->vec);
    draw_text(8, 40, 224, b, 2, 0xFFFFu, 0x8000u);
    hexs(b, c->pc);
    draw_text(8, 60, 224, b, 2, 0xFFFFu, 0x8000u);
    hexs(b, c->rets);
    draw_text(8, 80, 224, b, 2, 0xFFFFu, 0x8000u);
    t0 = fm1_ticks();
    while ((uint32_t)(fm1_ticks() - t0) < 4000u * 1000u * FM1_TICKS_PER_US)
        ;
    fm1_reboot();
}

static void splash(const char *line2, uint16_t c2)
{
    lcd_fill(0, 0, 240, 240, T_BG);
    draw_text_box(0, 96, 240, &AF_M, OS_NAME, T_THEME, 1);
    draw_text_box(0, 124, 240, &AF_S, line2, c2, 1);
}

static void enter_uboot(const char *why)
{
    fm1_audio_stop();
    splash(why, T_TEXT);
    fm1_delay_ms(20);
    usb_detach();
    fm1_delay_ms(30);
    bootguard.pending = 0;                         /* intentional reset: not a failed boot */
    fm1_enter_uboot();
}

static void fm1_main(void)
{
    {   /* flash: the expected part (JEDEC allow-list in hal/fm1_flash_map.h), else run without update entry */
        uint32_t f = irq_save();
        flash_ok = FL_JEDEC_OK(FL_FAR(fl_jedec_ram)());
        irq_restore(f);
        flash_ok_boot = flash_ok;
        if (flash_ok) {
            fl_plain_window_init();                /* the calibration record (0xC1000) reads through XIP */
            ota_boot_cleanup();                    /* staging area left by an update */
        }
    }
    lcd_init();
    ui_init();
    splash(OS_VERSION, T_TEXT);
    fm1_input_init();
    fm1_adc_init();
    if (flash_ok)
        smk_trim_load(fm1_xip_ptr(SMK_TRIM_FLASH));   /* factory key / pad velocity curves: read only */
    if (os_engine_init()) {
        splash("NO LIBRARY", T_THEME);             /* the build embeds one; this means a corrupt image */
        for (;;)
            fm1_wdt_feed();
    }
    if (flash_ok && vault_mount() == VT_OK)        /* the vault (FL_DATA only): the kit in slot 1, if saved */
        vault_kit_load(0);
#if OS_CPU2
    if (!bootguard.failed) {
        /* the second core (hal/fm1_cpu1.h), at power-on, before the audio and the timers (started later it never
         * reaches its entry). It boots through the chip's ROM: the PC limits are open meanwhile. A crash in the
         * last boot's first 30 s, or no answer: never started, one core does everything */
        fm1_guard_pc_open();
        fm1_cpu1_start();
        fm1_guard_enable(FM1_GUARD_PC);
    }
#endif
    audio_init();
    usb_start();
    fm1_timer5_start(isr_timer5, 4);              /* above ALNK0 (3): the scan nests into the render */
    fm1_guard_lock_top();
    fm1_irq_enable_all();
    fm1_delay_ms(400);                             /* the splash */
    ui.force = 1;
    lcd_fill(0, 0, 240, 240, T_BG);

    for (;;) {
        uint32_t m = fm1_ms;
        fm1_wdt_feed();
        usb_retry(fm1_ms);
        if (fm1_ms > 30000u && bootguard.pending) {      /* a crash or hang in the first 30 s counts */
            bootguard.pending = 0;
            bootguard.failed = 0;
        }
        {   /* OCTAVE- + OCTAVE+ held 5 s: UBOOT (recovery / backup), as in Felucca */
            static uint32_t t0;
            uint32_t both = (1u << FM1_BTN_OCT_DOWN) | (1u << FM1_BTN_OCT_UP);
            if ((fm1_in.buttons & both) != both)
                t0 = fm1_ms;
            else if (fm1_ms - t0 > 5000u)
                enter_uboot("UBOOT");
        }
        if (flash_ok_boot) {
            ota_service();                         /* M-UPGRADE handshake (identity, check step) */
            if (usb.ota_req) {                     /* the installer's enter-upgrade command */
                usb.ota_req = 0;
                ota_session();                     /* returns only if nothing was committed */
                ui.force = 1;
                lcd_fill(0, 0, 240, 240, T_BG);
            }
        }
        if (usb.uboot_req)                         /* SysEx F0 22 24 35 7D F7 from the host */
            enter_uboot("UBOOT (USB)");
        while (mi_r != mi_w)                       /* USB MIDI in: not used yet, keep the ring empty */
            mi_r++;
        {   /* stopped and silent for a second: the vault erases a dead sector ahead (an erase stops the audio) */
            static uint32_t quiet;
            if (os.playing || os.voices || ui.keys_down || ui.held_n) quiet = fm1_ms;
            else if (fm1_ms - quiet > 1000u) { quiet = fm1_ms; vault_idle(); }
        }
        ui_input();
        ui_leds();
        padled_flush();                            /* the pads, between LCD transfers */
        ui_draw();
        while (fm1_ms - m < 15u)                   /* ~60 UI frames/s at most; controls stay live */
            ui_input();
    }
}

void fm1_cstart(void)
{
    uint32_t *s, *d, p3, src, wdt;
#if OS_CPU2
    fm1_cpu1_halt();                               /* (as Felucca, after Jangada and X0X): a second core still running
                                                    * from before this reset would read the RAM cleared below */
#endif
    fm1_time_init();
    fm1_reset_reason();
    p3 = fm1_boot.p3_rst;
    src = fm1_boot.rst_src;
    wdt = fm1_boot.wdt_con;
    fm1_wdt_arm(0x0D);
    if (bootguard.magic != BOOTGUARD_MAGIC) {
        bootguard.magic = BOOTGUARD_MAGIC;
        bootguard.failed = 0;
        bootguard.pending = 0;
    }
    if (bootguard.pending)
        bootguard.failed++;
    bootguard.pending = 1;
    if (bootguard.failed >= 2u) {                  /* two boots that died early: straight to UBOOT */
        bootguard.failed = 0;
        bootguard.pending = 0;
        fm1_enter_uboot();
    }
    fm1_irq_init();
    for (d = _bss_start; d < _bss_end; d++)
        *d = 0;
    for (d = _pool_start; d < _pool_end; d++)
        *d = 0;
    for (s = _data_load, d = _data_start; d < _data_end; s++, d++)
        *d = *s;
    for (s = _rt_load, d = _rt_start; d < _rt_end; s++, d++)
        *d = *s;                                   /* flash driver code that must run from RAM */
#if OS_CPU2
    for (s = _c1_load, d = _c1_start; d < _c1_end; s++, d++)
        *d = *s;                                   /* the second core's waiting loop (hal/fm1_cpu1.h) */
#endif
    fm1_mailbox_clear();
    fm1_guard_enable(FM1_GUARD_STACK | FM1_GUARD_WRITE | FM1_GUARD_BUS | FM1_GUARD_PC);
    fm1_boot.p3_rst = (uint8_t)p3;
    fm1_boot.rst_src = src;
    fm1_boot.wdt_con = (uint8_t)wdt;
    fm1_main();
    for (;;)
        ;
}
