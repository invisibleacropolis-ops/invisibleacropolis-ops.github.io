/* SPDX-License-Identifier: GPL-3.0-only */
/* The machines, at the clock's own rate: one core sample in, one core sample out.
 *   TAPE   one voice. SYNC: its read position is the clock (rate exactly 1, an integer read, no interpolation),
 *          so it cannot drift; GATE: notes open it; SLC: notes jump to onset slices (the encoder's map)
 *   MULTI  the track's own voices from a keyframe start (a free seek); CHR chromatic, KIT one sample per key
 *   GRAN   one decode head fills a 256 ms ring of blocks; 8 grains are taps into it (decode once, read many)
 *   WAVE   a keyframe is a wavetable frame: the track holds two decoded frames, voices only phases; it renders
 *          4 samples per core sample (32 kHz), because a synth tone has content above the core band
 * WARP is not here: it is the upsampler's rate, so the whole core domain bends together.
 * Spread (SPR, page E): a voiced machine also renders a side, S = sum of voice x pan, so the track is M/S
 * (L = M + S, R = M - S) and the strip filters both; with SPR at 0 there is no side and no cost.
 * Pitched up, a voice's source runs through two one-poles at 3.2 kHz / rate first (the core band would fold).
 * Every track owns its voices and its state: tracks can render on either core. */
#define GRAN_BLKS 128u                       /* 128 blocks of 16: 256 ms */
#define GRAN_NG 8u
#define WAVE_MAX 512u

static os_voice_t tape_v[NTRACK] __attribute__((section(".pool")));
static struct {
    sv_reader rd;
    int32_t tag[GRAN_BLKS];
    float head, rate_n, spawn, len;               /* len: the sample's core length (POS targets) */
    uint32_t rng;
    struct { float pos, rate, ph, inc, amp, pan; uint8_t on; } g[GRAN_NG];
} gran[NTRACK] __attribute__((section(".pool")));
static int16_t gran_ring[NTRACK][GRAN_BLKS * SV_BLK] __attribute__((section(".pool")));
static struct {
    sv_reader rd;
    int32_t fk[2];                 /* frame held in fb[0] / fb[1] (-1 none) */
    float fpos, scan, nf, frm_blk;                /* nf: frames; frm_blk: the bus's frame offset this block */
} wave[NTRACK] __attribute__((section(".pool")));
static int16_t wave_fb[NTRACK][2][WAVE_MAX] __attribute__((section(".pool")));
static int32_t tape_jump[NTRACK];  /* SYNC + SLC: phase offset (core samples) set by the last slice note */
static float tape_open[NTRACK];    /* GATE OPEN: the declick ramp */
static uint8_t tape_si[NTRACK];    /* the sample tape_v[] was started on */

/* ------------------------------------------------------------- the SVBRR voice -- */
static void voice_start(os_voice_t *v, uint32_t si, float pos, float rate, uint32_t ls, uint32_t le, int oneshot)
{
    int32_t ip = (int32_t)pos;
    if ((float)ip > pos) ip--;
    sv_reader_init(&v->rd, &os.lib, (int)si);
    v->cb = -1;
    v->ip = ip;
    v->fr = pos - (float)ip;
    v->rate = rate;
    v->ls = ls;
    v->le = le;
    v->oneshot = (uint8_t)oneshot;
    v->active = 1;
    v->aa_on = 0;
    v->aa_at = 0x7FFFFFFF;
}

/* core sample i through the two-block window (decodes only when the window moves) */
static inline int32_t voice_at(os_voice_t *v, int32_t i)
{
    int32_t n = (int32_t)v->rd.info.core_len, b, o;
    if (i < 0) i = 0;
    if (i >= n) i = n - 1;
    b = i >> BLK_SHIFT;
    o = b - v->cb;
    if (v->cb < 0 || o < 0 || o > 1) {
        /* keep the block the interpolation still needs: forward keep the one before, back the one after */
        int32_t nb = (n + (int32_t)BLK - 1) >> BLK_SHIFT, k;
        const int16_t *p;
        v->cb = (v->cb >= 0 && o < 0) ? b : b - 1;
        if (v->cb < 0) v->cb = 0;
        if (v->cb + 1 >= nb) v->cb = nb > 1 ? nb - 2 : 0;
        p = sv_block(&v->rd, v->cb);
        for (k = 0; k < (int32_t)BLK; k++) v->win[k] = p[k];
        if (v->cb + 1 < nb) {
            p = sv_block(&v->rd, v->cb + 1);
            for (k = 0; k < (int32_t)BLK; k++) v->win[BLK + (uint32_t)k] = p[k];
        }
        o = b - v->cb;
    }
    return v->win[((uint32_t)o << BLK_SHIFT) + ((uint32_t)i & (BLK - 1u))];
}

/* the band-limited source, fed in the direction of travel up to the interpolation's leading sample */
static inline float aa_get(os_voice_t *v, int32_t i) { return v->aa_h[(uint32_t)i & 3u]; }

static void aa_feed_to(os_voice_t *v, int32_t lead, int32_t dir)
{
    int32_t gap = (lead - v->aa_at) * dir;
    if (v->aa_at == 0x7FFFFFFF || gap > 64 || gap < 0) {     /* start, seek or loop wrap: prime the filter */
        float x = (float)voice_at(v, lead - 6 * dir);
        v->aa1 = v->aa2 = x;
        v->aa_at = lead - 6 * dir;
        gap = 6;
    }
    while (gap-- > 0) {
        float x;
        v->aa_at += dir;
        x = (float)voice_at(v, v->aa_at);
        v->aa1 += (x - v->aa1) * v->aa_k;
        v->aa2 += (v->aa1 - v->aa2) * v->aa_k;
        v->aa_h[(uint32_t)v->aa_at & 3u] = v->aa2;
    }
}

/* pitch for the voice: rate in core samples per core sample; above 1 the anti-alias path is on */
static void voice_rate(os_voice_t *v, float rate)
{
    float r = rate < 0.0f ? -rate : rate;
    v->rate = rate;
    v->aa_on = (uint8_t)(r > 1.02f);
    if (v->aa_on)                                   /* two one-poles at 3.2 kHz / r */
        v->aa_k = 1.0f - fx_fexp(-6.2831853f * 3200.0f / (r * (float)CORE_SR));
}

/* one sample (Hermite; a synced tape at rate 1 is a plain read), then advance; 0 when it ended */
static inline float voice_tick(os_voice_t *v, float rmul)
{
    int32_t ip = v->ip, step;
    float f = v->fr, y, rate = v->rate * rmul;
    if (f == 0.0f && rate == 1.0f) {
        y = (float)voice_at(v, ip);
    } else {
        float ym1, y0, y1, y2, c1, c2, c3;
        if (v->aa_on) {
            int32_t dir = rate < 0.0f ? -1 : 1;
            aa_feed_to(v, dir > 0 ? ip + 2 : ip - 1, dir);
            ym1 = aa_get(v, ip - 1); y0 = aa_get(v, ip); y1 = aa_get(v, ip + 1); y2 = aa_get(v, ip + 2);
        } else {
            ym1 = (float)voice_at(v, ip - 1); y0 = (float)voice_at(v, ip);
            y1 = (float)voice_at(v, ip + 1); y2 = (float)voice_at(v, ip + 2);
        }
        c1 = 0.5f * (y1 - ym1);
        c2 = ym1 - 2.5f * y0 + 2.0f * y1 - 0.5f * y2;
        c3 = 0.5f * (y2 - ym1) + 1.5f * (y0 - y1);
        y = ((c3 * f + c2) * f + c1) * f + y0;
    }
    f += rate;
    step = (int32_t)f;
    if ((float)step > f) step--;
    v->ip = ip + step;
    v->fr = f - (float)step;
    if (v->ip >= (int32_t)v->le) {
        if (v->oneshot) v->active = 0;
        else v->ip -= (int32_t)(v->le - v->ls);
    } else if (v->ip < (int32_t)v->ls) {
        if (v->oneshot) v->active = 0;
        else v->ip += (int32_t)(v->le - v->ls);
    }
    return y * (1.0f / 32767.0f);
}

/* (the envelopes and LFOs: os_mod.c) */

/* the strip's coefficients, from eff[] (each block, and when an event writes one; the envelopes: os_mod.c) */
static void strip_coeffs(trk_t *t)
{
    float fs = t->mach == MA_WAVE ? (float)(CORE_SR * WIDE) : (float)CORE_SR;
    t->typ = t->eff[R_TYP];
    t->cut_v = (float)t->eff[R_CUT];
    t->kq = 2.0f - 1.94f * (float)t->eff[R_RES] * (1.0f / 127.0f);
    t->drv = (float)t->eff[R_DRV];
    (void)fs;                                     /* (an LFO2 on CUT at audio rate: t->ffast, os_mod.c) */
}

/* ------------------------------------------------------------------ sample tools -- */
static void smp_info(uint32_t si, sv_info *in) { sv_sample_info(&os.lib, (int)si, in); }

static uint32_t beat_core(void) { return (uint32_t)os.bpb * BLK; }

/* onset k of sample si at or after core position from (-1: none) */
static int32_t onset_after(uint32_t si, uint32_t from, uint32_t k)
{
    uint32_t i = OS_ONSET_IDX[si], e = OS_ONSET_IDX[si + 1u];
    while (i < e && OS_ONSET_POS[i] < from) i++;
    i += k;
    return i < e ? (int32_t)OS_ONSET_POS[i] : -1;
}

/* TAPE loop region from the registers: start in beats, length in beats (clipped to the sample) */
static void tape_region(const trk_t *t, uint32_t *ls, uint32_t *len)
{
    static const uint8_t BEATS[6] = {1, 2, 4, 8, 16, 32};
    sv_info in;
    uint32_t bc = beat_core(), s, l;
    smp_info(t->eff[TA_SMP], &in);
    s = (uint32_t)t->eff[TA_STR] * bc;
    while (s && s + bc > in.core_len) s -= bc;
    if (s >= in.core_len) s = 0;
    l = (uint32_t)BEATS[t->eff[TA_LEN] < 6 ? t->eff[TA_LEN] : 5] * bc;
    if (s + l > in.core_len) l = in.core_len - s;
    *ls = s;
    *len = l > 64u ? l : 64u;
}

/* ------------------------------------------------------------------ the track's voices -- */
static uint32_t pv_count(uint32_t k)
{
    uint32_t i, n = 0;
    for (i = 0; i < POLY_MAX; i++)
        if (pool[k][i].used && pool[k][i].env.st && pool[k][i].env.st < 3) n++;
    return n;
}

/* the voices: every track owns POLY_MAX slots, and two limits hold.
 *   its own   VOI (1 .. 8) voices, checked at the note: past it, the track's oldest releasing voice
 *             (else its oldest) is choked (1 ms) and the note takes a free slot
 *   all       VOICES (8) at once, a sounding mono track counting one: checked by vb_enforce at the start
 *             of each half, on one core, so it never touches a track another core is rendering.  A note
 *             that lands on a full budget sounds at once; the half after, the oldest releasing voice
 *             anywhere (else the oldest) is choked.  So the budget can run over for one half (2.9 ms)
 *             by the notes that started in it, and never longer.
 * a choking voice counts toward neither */
static uint32_t vb_steals, vb_chokes;           /* (counts, for the host checks) a track over its VOI; the budget */
static int pv_live(const pv_t *p) { return p->used && p->env.st && p->env.st < 4; }

/* a is older than b: started earlier (the clock wraps), then lower age (a chord: its order) */
static int pv_older(const pv_t *a, const pv_t *b)
{
    int32_t d = (int32_t)(a->on_at - b->on_at);
    return d < 0 || (d == 0 && a->age < b->age);
}

static pv_t *pv_alloc(uint32_t k)
{
    uint32_t i, n = 0, lim = (uint32_t)os.trk[k].eff[R_VOI] + 1u;
    pv_t *fr = 0, *rel = 0, *old = 0, *any = 0;
    if (lim > POLY_MAX) lim = POLY_MAX;
    for (i = 0; i < POLY_MAX; i++) {
        pv_t *p = &pool[k][i];
        if (!p->used) { if (!fr) fr = p; continue; }
        if (!any || pv_older(p, any)) any = p;
        if (!pv_live(p)) continue;
        n++;
        if (p->env.st == 3 && (!rel || pv_older(p, rel))) rel = p;
        if (!old || pv_older(p, old)) old = p;
    }
    if (n >= lim) {                              /* at its limit: the oldest one goes */
        pv_t *v = rel ? rel : old;
        vb_steals++;
        if (!fr) return v;                       /* no slot to fade in: it restarts */
        v->env.st = 4;
    }
    return fr ? fr : any;
}

/* a mono machine's one voice is sounding */
static int mono_busy(uint32_t k)
{
    const trk_t *t = &os.trk[k];
    switch (t->mach) {
    case MA_TAPE: return tape_v[k].active;
    case MA_GRAN: return t->env.st != 0;
    default: return 0;
    }
}

/* the shared budget, at the start of a half (see above); returns the voices sounding */
static uint32_t vb_enforce(void)
{
    uint32_t k, i, n = 0;
    for (k = 0; k < NTRACK; k++) {
        if (MACH[os.trk[k].mach].poly < 2u) { n += (uint32_t)(mono_busy(k) != 0); continue; }
        for (i = 0; i < POLY_MAX; i++) n += (uint32_t)pv_live(&pool[k][i]);
    }
    while (n > VOICES) {
        pv_t *rel = 0, *old = 0;
        for (k = 0; k < NTRACK; k++) {
            if (MACH[os.trk[k].mach].poly < 2u) continue;
            for (i = 0; i < POLY_MAX; i++) {
                pv_t *p = &pool[k][i];
                if (!pv_live(p)) continue;
                if (p->env.st == 3 && (!rel || pv_older(p, rel))) rel = p;
                if (!old || pv_older(p, old)) old = p;
            }
        }
        if (!old) break;                         /* (mono tracks only: four at most) */
        (rel ? rel : old)->env.st = 4;
        vb_chokes++;
        n--;
    }
    return n;
}

static float note_amp(uint32_t vel)
{
    float v = (float)vel * (1.0f / 127.0f);
    return 0.12f + 0.88f * v * v;
}

static float wave_inc(const trk_t *t, float semis)
{
    return 440.0f * os_semis(semis + (float)t->tb_note) * (float)(64u << t->eff[WA_CYC]) / (float)(CORE_SR * WIDE);
}

/* ------------------------------------------------------------------ note on / off -- */
/* at: the clock sample it starts on; len: core samples (0 = held until note-off) */
static void mach_note_on(uint32_t k, uint32_t note, uint32_t vel, uint32_t at, uint32_t len, int live)
{
    trk_t *t = &os.trk[k];
    const uint8_t *e = t->eff;
    if (t->mute && !live)
        return;
    tx_trig(k, at);                            /* the reverb's gate opens */
    if (t->base[R_TBL] && !live) {             /* a table starts with every note */
        uint32_t r;
        t->tb_on = 1; t->tb_idx = (uint8_t)(t->base[R_TBL] - 1u); t->tb_row = 0; t->tb_cnt = 0; t->tb_note = 0;
        for (r = 0; r < NREG; r++) t->tlk[r] = 0xFF;
    }
    switch (t->mach) {
    case MA_TAPE: {
        uint32_t ls, len_;
        tape_region(t, &ls, &len_);
        if (e[TA_SYN]) {                         /* in sync: a slice note moves the phase, the clock keeps it */
            if (e[TA_SLC]) {
                int32_t o = onset_after(e[TA_SMP], ls, (uint32_t)e[TA_SLC] - 1u + (note >= 60 ? note - 60u : 0u));
                if (o >= 0 && (uint32_t)o < ls + len_)
                    tape_jump[k] = (int32_t)((uint32_t)o - ls) - (int32_t)((at - os.play_c0) % len_);
            }
        } else {                                 /* free tape: notes restart it, at the slice the key picks */
            float st = (float)ls, r = os_semis((float)((int32_t)note - 60 + e[TA_PIT] - 64 + t->tb_note));
            if (e[TA_SLC]) {
                int32_t o = onset_after(e[TA_SMP], ls, (uint32_t)e[TA_SLC] - 1u + (note >= 60 ? note - 60u : 0u));
                if (o >= 0) st = (float)o;
            }
            voice_start(&tape_v[k], e[TA_SMP], e[TA_DIR] ? (float)(ls + len_ - 1u) : st, 0.0f, ls, ls + len_, 0);
            voice_rate(&tape_v[k], e[TA_DIR] ? -r : r);
            tape_si[k] = e[TA_SMP];
        }
        mod_note_on(k, &t->ve1, &t->vl1, !t->held);
        adsr_gate(&t->env);
        t->held = 1;
        t->mono_note = (uint8_t)note;
        break;
    }
    case MA_GRAN:
        if (!t->held || !live) {                 /* a new phrase: the head back to POS */
            sv_info in;
            smp_info(e[GR_SMP], &in);
            gran[k].head = (float)e[GR_POS] * (1.0f / 127.0f) * (float)in.core_len;
            gran[k].len = (float)in.core_len;
        }
        gran[k].rate_n = (float)note - 60.0f;
        mod_note_on(k, &t->ve1, &t->vl1, !t->held);
        adsr_gate(&t->env);
        t->held = 1;
        t->mono_note = (uint8_t)note;
        break;
    default: {                                   /* MULTI, WAVE: the track's own voices */
        uint32_t i;
        pv_t *p;
        for (i = 0; i < POLY_MAX; i++)           /* the same note again: choke it (hats, retrigs) */
            if (pool[k][i].used && pool[k][i].note == note && pool[k][i].env.st && pool[k][i].env.st < 3)
                pool[k][i].env.st = 4;
        p = pv_alloc(k);
        p->used = 1;
        p->note = (uint8_t)note;
        p->vel = (uint8_t)vel;
        p->live = (uint8_t)(live != 0);
        p->age = ++t->voice_age;
        p->on_at = at;
        p->off_at = len ? at + len : 0xFFFFFFFFu;
        p->amp = note_amp(vel);
        p->env.v = 0.0f;
        p->env.st = 1;
        mod_note_on(k, &p->e1, &p->l1, 1);
        if (t->mach == MA_MULTI) {
            sv_info in;
            uint32_t si = e[MU_SMP], ls, le;
            float semis = (float)((int32_t)e[MU_PIT] - 64) + (float)((int32_t)e[MU_TUN] - 64) * (1.0f / 64.0f);
            if (e[MU_MAP]) {                     /* KIT: C3 = SMP, one sample per key */
                int32_t s = (int32_t)si + (int32_t)note - 48;
                si = (uint32_t)os_clampi(s, 0, (int32_t)OS_LIB_COUNT - 1);
            } else {
                semis += (float)note - 60.0f;
            }
            smp_info(si, &in);
            {   /* start and length: the register, plus ENV1 / LFO1 aimed at them (read as the voice starts) */
                int32_t st = os_clampi((int32_t)e[MU_STR] + (int32_t)mod_at_start(t, MK_STR, p->e1.v, p->l1.mode_x), 0, 127);
                int32_t ln = (int32_t)e[MU_LEN];
                float dl = mod_at_start(t, MK_LEN, p->e1.v, p->l1.mode_x);
                if (dl != 0.0f) ln = os_clampi((ln ? ln : 127) + (int32_t)dl, 1, 127);
                ls = (uint32_t)st * in.n_kf / 128u * os.lib.kf_len;     /* a keyframe: no decode to get there */
                if (ls >= in.core_len) ls = 0;
                le = ln ? ls + (in.core_len - ls) * (uint32_t)ln / 127u : in.core_len;
            }
            if (le <= ls + 64u) le = ls + 64u < in.core_len ? ls + 64u : in.core_len;
            p->semis = semis;
            voice_start(&p->v, si, e[MU_RVS] ? (float)(le - 2u) : (float)ls, 0.0f, ls, le, !e[MU_LOP]);
            p->si = (uint8_t)si;
            p->hz1 = p->hz2 = p->e_hf = 0.0f;
            p->h_fr = -1;
            {
                float r = os_semis(semis + (float)t->tb_note);
                voice_rate(&p->v, e[MU_RVS] ? -r : r);
            }
            t->lead_si = (uint8_t)si;
        } else {                                 /* WAVE */
            float semis = (float)note - 69.0f + (float)((int32_t)e[WA_PIT] - 64) + (float)((int32_t)e[WA_TUN] - 64) * (1.0f / 64.0f);
            p->semis = semis;
            p->inc_to = wave_inc(t, semis);
            p->inc = (!e[WA_GLD] || t->last_note == 0xFF) ? p->inc_to
                     : wave_inc(t, (float)t->last_note - 69.0f + (float)((int32_t)e[WA_PIT] - 64));
            p->ph = 0.0f;
            p->ph2 = (float)(64u << e[WA_CYC]) * 0.37f;
        }
        break;
    }
    }
    t->last_note = (uint8_t)note;
}

/* a retrig, tracker style: the voice already playing this note jumps back to its start (WAVE: its phase to 0,
 * a hard sync); its envelope keeps going, so a fast retrig is an exact period, a pitch of 8000 / n Hz */
static void mach_retrig(uint32_t k, uint32_t note, uint32_t vel, uint32_t at, uint32_t len)
{
    trk_t *t = &os.trk[k];
    pv_t *p = 0;
    uint32_t i;
    if (t->mach == MA_MULTI || t->mach == MA_WAVE)
        for (i = 0; i < POLY_MAX; i++)
            if (pool[k][i].used && pool[k][i].note == note && pool[k][i].env.st && pool[k][i].env.st < 4 &&
                (!p || pool[k][i].age > p->age))
                p = &pool[k][i];
    if (!p) { mach_note_on(k, note, vel, at, len, 0); return; }
    if (t->mach == MA_MULTI) {
        os_voice_t *v = &p->v;
        v->ip = v->rate < 0.0f ? (int32_t)v->le - 2 : (int32_t)v->ls;
        v->fr = 0.0f;
        v->active = 1;
        v->aa_at = 0x7FFFFFFF;
    } else {
        p->ph = 0.0f;
        p->ph2 = (float)(64u << t->eff[WA_CYC]) * 0.37f;
    }
    if (p->env.st == 3) p->env.st = 2;
    p->amp = note_amp(vel);
    p->off_at = len ? at + len : 0xFFFFFFFFu;
}

/* ENV2 closes when no note is held on the track any more */
static void mod_track_off(uint32_t k)
{
    trk_t *t = &os.trk[k];
    uint32_t i;
    if (t->mach == MA_TAPE || t->mach == MA_GRAN) { if (!t->held) adsr_release(&t->e2); return; }
    for (i = 0; i < POLY_MAX; i++)
        if (pool[k][i].used && pool[k][i].env.st && pool[k][i].env.st < 3) return;
    adsr_release(&t->e2);
}

static void voice_release(pv_t *p) { adsr_release(&p->env); adsr_release(&p->e1); }

static void mach_note_off(uint32_t k, uint32_t note)
{
    trk_t *t = &os.trk[k];
    uint32_t i;
    if (t->mach == MA_TAPE || t->mach == MA_GRAN) {
        if (t->mono_note == note) { t->held = 0; adsr_release(&t->env); adsr_release(&t->ve1); }
        mod_track_off(k);
        return;
    }
    for (i = 0; i < POLY_MAX; i++)
        if (pool[k][i].used && pool[k][i].note == note) voice_release(&pool[k][i]);
    mod_track_off(k);
}

static void mach_kill(uint32_t k)
{
    uint32_t i;
    trk_t *t = &os.trk[k];
    for (i = 0; i < POLY_MAX; i++)
        if (pool[k][i].used) voice_release(&pool[k][i]);
    adsr_release(&t->env);
    adsr_release(&t->ve1);
    adsr_release(&t->e2);
    t->held = 0;
}

/* the earliest voice release still due (0xFFFFFFFF: none) */
static uint32_t mach_next_off(uint32_t k, uint32_t now)
{
    uint32_t i, best = 0xFFFFFFFFu, bd = 0xFFFFFFFFu;
    for (i = 0; i < POLY_MAX; i++) {
        const pv_t *p = &pool[k][i];
        if (p->used && p->off_at != 0xFFFFFFFFu && p->env.st && p->env.st < 3) {
            uint32_t d = p->off_at - now;
            if ((int32_t)d < 0) d = 0;
            if (d < bd) { bd = d; best = p->off_at; }
        }
    }
    return best;
}

static void mach_offs(uint32_t k, uint32_t now)
{
    uint32_t i;
    for (i = 0; i < POLY_MAX; i++) {
        pv_t *p = &pool[k][i];
        if (p->used && p->off_at != 0xFFFFFFFFu && (int32_t)(now - p->off_at) >= 0) {
            voice_release(p);
            p->off_at = 0xFFFFFFFFu;
            mod_track_off(k);
        }
    }
}

/* ------------------------------------------------------------------ once a block (2 ms) -- */
static void gran_fill(uint32_t k, const trk_t *t)
{
    sv_info in;
    int32_t hb, lo, hi, b, nb, done = 0, reach;
    smp_info(t->eff[GR_SMP], &in);
    if (gran[k].rd.info.core_len != in.core_len || gran[k].rd.lib == 0) {
        uint32_t i;
        sv_reader_init(&gran[k].rd, &os.lib, t->eff[GR_SMP]);
        for (i = 0; i < GRAN_BLKS; i++) gran[k].tag[i] = -1;
    }
    nb = (int32_t)((in.core_len + BLK - 1u) >> BLK_SHIFT);
    hb = (int32_t)gran[k].head >> BLK_SHIFT;
    reach = 2 + (int32_t)((float)t->eff[GR_SPR] * (2000.0f / 127.0f) / (float)BLK) + (int32_t)t->eff[GR_SIZ] / 4;
    if (reach > 60) reach = 60;
    lo = hb - reach;
    hi = hb + reach;
    for (b = lo; b <= hi && done < 8; b++) {         /* in order: sequential decodes cost one block each */
        int32_t bb = b < 0 ? b + nb : b >= nb ? b - nb : b, slot = bb & (int32_t)(GRAN_BLKS - 1u);
        const int16_t *p;
        uint32_t j;
        if (gran[k].tag[slot] == bb) continue;
        p = sv_block(&gran[k].rd, bb);
        for (j = 0; j < BLK; j++) gran_ring[k][(uint32_t)slot * BLK + j] = p[j];
        gran[k].tag[slot] = bb;
        done++;
    }
}

static void wave_frames(uint32_t k, const trk_t *t)
{
    sv_info in;
    int32_t k0, need[2], i;
    smp_info(t->eff[WA_SMP], &in);
    if (wave[k].rd.info.core_len != in.core_len || wave[k].rd.lib == 0) {
        sv_reader_init(&wave[k].rd, &os.lib, t->eff[WA_SMP]);
        wave[k].fk[0] = wave[k].fk[1] = -1;
    }
    wave[k].scan += ((float)t->eff[WA_SCN] - 64.0f) * (1.0f / 16.0f) * ((float)BLK / (float)CORE_SR);   /* +-4 frames a second */
    {
        float n = (float)(in.n_kf > 1u ? in.n_kf - 1u : 1u), f = (float)t->eff[WA_FRM] * (1.0f / 127.0f) * n + wave[k].scan;
        wave[k].nf = n;
        wave[k].frm_blk = t->frm_now;                       /* ENV2 / LFO2 on FRM: at the block, then per sample */
        f += t->frm_now * (1.0f / 127.0f) * n;
        while (f < 0.0f) f += n;
        while (f >= n) f -= n;
        wave[k].fpos = f;
    }
    k0 = (int32_t)wave[k].fpos;
    need[0] = k0;
    need[1] = k0 + 1 < (int32_t)in.n_kf ? k0 + 1 : k0;
    if (wave[k].fk[1] == need[0] && wave[k].fk[0] != need[0]) {   /* scanned forward: the next becomes the first */
        uint32_t j;
        for (j = 0; j < WAVE_MAX; j++) wave_fb[k][0][j] = wave_fb[k][1][j];
        wave[k].fk[0] = need[0];
        wave[k].fk[1] = -1;
    }
    for (i = 0; i < 2; i++) {
        uint32_t b0, j, b;
        if (wave[k].fk[i] == need[i]) continue;
        b0 = (uint32_t)need[i] * (os.lib.kf_len >> BLK_SHIFT);
        for (b = 0; b < WAVE_MAX / BLK; b++) {           /* one keyframe: 32 blocks in sequence from its start */
            const int16_t *p = sv_block(&wave[k].rd, (int32_t)(b0 + b));
            for (j = 0; j < BLK; j++) wave_fb[k][i][b * BLK + j] = p[j];
        }
        wave[k].fk[i] = need[i];
        break;                                           /* at most one frame a block */
    }
}

/* pitch of every voice from its note, the table transpose and the pitch registers: at each block, and at
 * once when an event changes them (a table row can retune every sample) */
static void mach_retune(uint32_t k, int glide)
{
    trk_t *t = &os.trk[k];
    const uint8_t *e = t->eff;
    uint32_t i;
    for (i = 0; i < POLY_MAX; i++) {
        pv_t *p = &pool[k][i];
        if (!p->used) continue;
        if (t->mach == MA_MULTI) {
            float semis = (float)((int32_t)e[MU_PIT] - 64) + (float)((int32_t)e[MU_TUN] - 64) * (1.0f / 64.0f);
            float r;
            if (!e[MU_MAP]) semis += (float)p->note - 60.0f;
            p->semis = semis;
            r = os_semis(semis + (float)t->tb_note);
            voice_rate(&p->v, p->v.rate < 0.0f ? -r : r);
        } else if (t->mach == MA_WAVE) {
            p->semis = (float)p->note - 69.0f + (float)((int32_t)e[WA_PIT] - 64) + (float)((int32_t)e[WA_TUN] - 64) * (1.0f / 64.0f);
            p->inc_to = wave_inc(t, p->semis);
            if (glide && e[WA_GLD]) p->inc += (p->inc_to - p->inc) * (1.0f - fx_fexp(-4.0f / (reg_time_s(e[WA_GLD]) * ((float)CORE_SR / (float)BLK) + 1.0f)));
            else if (!e[WA_GLD]) p->inc = p->inc_to;
        }
    }
    if (t->mach == MA_TAPE && !e[TA_SYN] && tape_v[k].active) {
        float r = os_semis((float)((int32_t)t->mono_note - 60 + e[TA_PIT] - 64 + t->tb_note));
        voice_rate(&tape_v[k], tape_v[k].rate < 0.0f ? -r : r);
    }
}

/* now: the clock sample this block starts on */
static void mach_block(uint32_t k, uint32_t now)
{
    trk_t *t = &os.trk[k];
    const uint8_t *e = t->eff;
    uint32_t i;
    strip_coeffs(t);
    mach_retune(k, 1);
    switch (t->mach) {
    case MA_TAPE: {
        uint32_t ls, len;
        os_voice_t *v = &tape_v[k];
        tape_region(t, &ls, &len);
        t->lead_si = e[TA_SMP];
        if (e[TA_SYN]) {
            if (os.playing) {
                int32_t ph = (int32_t)((now - os.play_c0) % len) + tape_jump[k];
                while (ph < 0) ph += (int32_t)len;
                while (ph >= (int32_t)len) ph -= (int32_t)len;
                if (!v->active || tape_si[k] != e[TA_SMP] || v->ls != ls || v->le != ls + len) {
                    voice_start(v, e[TA_SMP], 0.0f, 0.0f, ls, ls + len, 0);
                    tape_si[k] = e[TA_SMP];
                }
                /* locked to the clock: an integer position, rate exactly +-1 */
                v->ip = e[TA_DIR] ? (int32_t)(ls + len) - 1 - ph : (int32_t)ls + ph;
                v->fr = 0.0f;
                voice_rate(v, e[TA_DIR] ? -1.0f : 1.0f);
            }
        }
        t->lead_pos = (float)v->ip;
        t->lead_rate = v->active ? v->rate : 1.0f;
        break;
    }
    case MA_GRAN: {
        sv_info in;
        smp_info(e[GR_SMP], &in);
        gran[k].head += ((float)e[GR_SCN] - 64.0f) * (1.0f / 32.0f) * (float)BLK;   /* +-2x */
        while (gran[k].head < 0.0f) gran[k].head += (float)in.core_len;
        while (gran[k].head >= (float)in.core_len) gran[k].head -= (float)in.core_len;
        gran_fill(k, t);
        t->lead_pos = gran[k].head;
        t->lead_si = e[GR_SMP];
        t->lead_rate = os_semis((float)((int32_t)e[GR_PIT] - 64) + gran[k].rate_n + (float)t->tb_note);
        break;
    }
    case MA_WAVE:
        wave_frames(k, t);
        t->lead_si = e[WA_SMP];
        t->lead_pos = wave[k].fpos * (float)os.lib.kf_len;
        break;
    default:
        for (i = 0; i < POLY_MAX; i++)
            if (pool[k][i].used && pool[k][i].env.st && pool[k][i].env.st < 3) {
                t->lead_pos = (float)pool[k][i].v.ip;   /* any sounding voice: the side info follows it */
                t->lead_rate = pool[k][i].v.rate;
                t->lead_si = pool[k][i].si;
            }
        break;
    }
}

/* ------------------------------------------------------------------ render, per sample -- */
static inline float gran_at(uint32_t k, int32_t i)
{
    int32_t b = i >> BLK_SHIFT, slot = b & (int32_t)(GRAN_BLKS - 1u);
    if (i < 0 || gran[k].tag[slot] != b) return 0.0f;
    return gran_ring[k][(uint32_t)slot * BLK + ((uint32_t)i & (BLK - 1u))] * (1.0f / 32767.0f);
}

/* n core samples of track k's raw sound into out (cleared by the caller); WAVE writes n x WIDE.
 * mb: the track's modulation bus (os_mod.c); a voice's own ENV1 / LFO1 run here, per voice */
static void mach_render(uint32_t k, float *out, float *side, uint32_t n, const mbus_t *mb)
{
    vmod_t vm = {0.0f, 1.0f, 0.0f, 0.0f};
    trk_t *t = &os.trk[k];
    const uint8_t *e = t->eff;
    uint32_t i, j;
    float sp = side ? (float)e[R_SPR] * (1.0f / 127.0f) : 0.0f;     /* (side: 0 unless the track is M/S) */
    switch (t->mach) {
    case MA_TAPE: {
        os_voice_t *v = &tape_v[k];
        int open = !e[TA_GAT] && e[TA_SYN];
        float to = os.playing && !t->mute ? 1.0f : 0.0f;
        if (!v->active) return;
        for (i = 0; i < n; i++) {
            float g, rm = mb->pit_on ? os_semis(mb->pit[i]) : 1.0f;
            if (t->vmod) { mod_voice(t, &t->ve1, &t->vl1, &vm); if (vm.pit != 0.0f) rm *= os_semis(vm.pit); }
            if (open) { tape_open[k] += (to - tape_open[k]) * 0.02f; g = tape_open[k]; }
            else g = env_step(&t->env, &t->ec[0]);
            out[i] += voice_tick(v, rm) * g * vm.lev;
            if (!v->active) break;
        }
        if (!os.playing && e[TA_SYN] && tape_open[k] < 1e-4f && !t->env.st) v->active = 0;
        break;
    }
    case MA_GRAN: {
        float size = 0.010f * fx_fexp((float)e[GR_SIZ] * (3.912f / 127.0f));   /* 10 .. 500 ms */
        float den = 2.0f * fx_fexp((float)e[GR_DEN] * (4.605f / 127.0f));     /* 2 .. 200 a second */
        float spread = (float)e[GR_SPR] * (2000.0f / 127.0f);                  /* +-250 ms of core */
        float jit = (float)e[GR_JIT] * (12.0f / 127.0f);
        float sp = (float)((int32_t)e[GR_PIT] - 64) + gran[k].rate_n + (float)t->tb_note;
        if (!t->env.st) return;
        for (i = 0; i < n; i++) {
            float s = 0.0f, rm = mb->pit_on ? os_semis(mb->pit[i]) : 1.0f;
            if (t->vmod) { mod_voice(t, &t->ve1, &t->vl1, &vm); if (vm.pit != 0.0f) rm *= os_semis(vm.pit); }
            gran[k].spawn += den * (1.0f / (float)CORE_SR);
            if (gran[k].spawn >= 1.0f) {
                gran[k].spawn -= 1.0f;
                for (j = 0; j < GRAN_NG; j++)
                    if (!gran[k].g[j].on) {
                        float r = os_frand(&gran[k].rng), q = os_frand(&gran[k].rng), gsz = size, gpos = 0.0f;
                        if (t->vmod) {                   /* ENV1 / LFO1 on POS, SIZ: read as the grain starts */
                            float dp = mod_at_start(t, MK_POS, t->ve1.v, t->vl1.mode_x), ds = mod_at_start(t, MK_SIZ, t->ve1.v, t->vl1.mode_x);
                            gpos = dp * (1.0f / 127.0f) * gran[k].len;
                            if (ds != 0.0f) gsz = 0.010f * fx_fexp(os_clampf((float)e[GR_SIZ] + ds, 0.0f, 127.0f) * (3.912f / 127.0f));
                        }
                        gran[k].g[j].on = 1;
                        gran[k].g[j].pos = gran[k].head + gpos + (r - 0.5f) * 2.0f * spread;
                        gran[k].g[j].rate = os_semis(sp + (q - 0.5f) * 2.0f * jit) * rm;
                        gran[k].g[j].ph = 0.0f;
                        gran[k].g[j].inc = 1.0f / (gsz * (float)CORE_SR);
                        gran[k].g[j].amp = 0.9f;
                        gran[k].g[j].pan = os_clampf((os_frand(&gran[k].rng) - 0.5f) * 2.0f * sp + vm.pan, -1.0f, 1.0f);
                        break;
                    }
            }
            float sd = 0.0f, eg;
            for (j = 0; j < GRAN_NG; j++) {
                float p, f, a, b, w, ph, y;
                int32_t ip;
                if (!gran[k].g[j].on) continue;
                p = gran[k].g[j].pos;
                ph = gran[k].g[j].ph;
                ip = (int32_t)p;
                if ((float)ip > p) ip--;
                f = p - (float)ip;
                a = gran_at(k, ip);
                b = gran_at(k, ip + 1);
                w = 4.0f * ph * (1.0f - ph);
                y = (a + (b - a) * f) * w * gran[k].g[j].amp;
                s += y;
                sd += y * gran[k].g[j].pan;
                gran[k].g[j].pos += gran[k].g[j].rate;
                gran[k].g[j].ph += gran[k].g[j].inc;
                if (gran[k].g[j].ph >= 1.0f) gran[k].g[j].on = 0;
            }
            eg = env_step(&t->env, &t->ec[0]) * vm.lev;
            out[i] += s * eg;
            if (side) side[i] += sd * eg;
        }
        break;
    }
    case MA_MULTI: {
        float pv[POLY_MAX];
        for (j = 0; j < POLY_MAX; j++) {          /* a voice's place: CHR by pitch (low left), KIT one per key */
            int32_t nt = pool[k][j].note;
            float x = e[MU_MAP] ? (float)((nt * 37) % 9 - 4) * 0.25f : os_clampf((float)(60 - nt) * (1.0f / 24.0f), -1.0f, 1.0f);
            pv[j] = x * sp;
        }
        for (i = 0; i < n; i++) {
            float rm = mb->pit_on ? os_semis(mb->pit[i]) : 1.0f;
            for (j = 0; j < POLY_MAX; j++) {
                pv_t *p = &pool[k][j];
                if (!p->used) continue;
                if (p->v.active) {
                    float rv = rm, y, d;
                    if (t->vmod) { mod_voice(t, &p->e1, &p->l1, &vm); if (vm.pit != 0.0f) rv *= os_semis(vm.pit); }
                    y = voice_tick(&p->v, rv) * env_step(&p->env, &t->ec[0]) * p->amp * vm.lev;
                    out[i] += y;
                    if (side) side[i] += y * os_clampf(pv[j] + vm.pan, -1.0f, 1.0f);
                    d = y - p->hz1; p->hz1 += d * 0.86f;          /* two one-pole high-passes at ~2.5 kHz: */
                    y = d - p->hz2; p->hz2 += y * 0.86f;          /* how much of the 2-4 kHz band is this voice */
                    p->e_hf += y * y;
                }
                if (!p->v.active || !p->env.st) p->used = 0;
            }
        }
        break;
    }
    default: {                                           /* WAVE: WIDE samples per core sample */
        uint32_t cyc = 64u << e[WA_CYC], mask = cyc - 1u, q;
        float fr0 = wave[k].fpos - (float)(int32_t)wave[k].fpos;
        float det = e[WA_DET] ? os_semis((float)e[WA_DET] * (0.5f / 100.0f)) : 0.0f;
        const int16_t *A = wave_fb[k][0], *B = wave[k].fk[1] >= 0 ? wave_fb[k][1] : wave_fb[k][0];
        if (wave[k].fk[0] < 0) return;
        for (i = 0; i < n; i++) {
            float rm = mb->pit_on ? os_semis(mb->pit[i]) : 1.0f, frt = fr0;
            if (mb->frm_on) frt = fr0 + (mb->frm[i] - wave[k].frm_blk) * (1.0f / 127.0f) * wave[k].nf;
            for (j = 0; j < POLY_MAX; j++) {
                pv_t *p = &pool[k][j];
                float g, inc, inc2, fr = frt;
                if (!p->used) continue;
                if (t->vmod) {
                    mod_voice(t, &p->e1, &p->l1, &vm);
                    fr += vm.frm * (1.0f / 127.0f) * wave[k].nf;  /* (a voice morphs within the loaded pair) */
                }
                fr = os_clampf(fr, 0.0f, 1.0f);
                g = env_step(&p->env, &t->ec[0]) * p->amp * vm.lev * (0.7f / 32767.0f);
                inc = p->inc * rm * (vm.pit != 0.0f ? os_semis(vm.pit) : 1.0f);
                inc2 = inc * det;
                {
                float pj = os_clampf((j & 1u ? -0.5f : 0.5f) * sp + vm.pan, -1.0f, 1.0f);   /* voices alternate; a detuned pair splits */
                for (q = 0; q < WIDE; q++) {
                    uint32_t a0 = (uint32_t)p->ph, a1 = (a0 + 1u) & mask;
                    float f = p->ph - (float)a0, x, y, d = 0.0f;
                    x = (float)A[a0] + ((float)A[a1] - (float)A[a0]) * f;
                    y = (float)B[a0] + ((float)B[a1] - (float)B[a0]) * f;
                    x += (y - x) * fr;
                    if (det > 0.0f) {
                        uint32_t c0 = (uint32_t)p->ph2, c1 = (c0 + 1u) & mask;
                        float h = p->ph2 - (float)c0, x2, y2;
                        x2 = (float)A[c0] + ((float)A[c1] - (float)A[c0]) * h;
                        y2 = (float)B[c0] + ((float)B[c1] - (float)B[c0]) * h;
                        x2 += (y2 - x2) * fr;
                        d = 0.5f * (x - x2);
                        x = 0.5f * (x + x2);
                        p->ph2 += inc2;
                        while (p->ph2 >= (float)cyc) p->ph2 -= (float)cyc;
                    }
                    out[i * WIDE + q] += x * g;
                    if (side) side[i * WIDE + q] += (x * pj + d * 0.7f * sp) * g;
                    p->ph += inc;
                    while (p->ph >= (float)cyc) p->ph -= (float)cyc;
                }
                }
                if (!p->env.st) p->used = 0;
            }
        }
        break;
    }
    }
}

/* the drive: x / sqrt(1 + x^2), its aliasing cut by the first-order antiderivative method (ADAA). F(x) =
 * sqrt(1 + x^2) - 1, written x^2 / (sqrt(1 + x^2) + 1) so a quiet signal loses nothing; y = (F(u) - F(u1)) /
 * (u - u1), or the midpoint when u ~ u1. At 8 kHz a plain waveshaper folds every harmonic above 4 kHz back down;
 * this folds 7-9 dB less (measured: a 1.7 kHz sine, DRV 40-127, everything but the fundamental -24 / -19 dB
 * against -15 / -12 for v0.5's x / (1 + |x|)). The air rebuilds the highs the drive would have made */
static inline float drv_F(float u) { float u2 = u * u; return u2 / (os_sqrt(1.0f + u2) + 1.0f); }
static inline float drv_adaa(float u, float *u1)
{
    float d = u - *u1, y;
    if (d > 1e-4f || d < -1e-4f) y = (drv_F(u) - drv_F(*u1)) / d;
    else { float m = 0.5f * (u + *u1); y = m / os_sqrt(1.0f + m * m); }
    *u1 = u;
    return y;
}

/* the strip: the track's filter (os_flt.c: magnitude-matched, its design every FLT_CR clock samples, the
 * coefficients gliding between; an LFO2 on CUT at audio rate uses the bilinear map every sample), then the drive.
 * n samples at the track's rate (WAVE: n x WIDE); the cutoff comes per clock sample from the modulation bus. The
 * cutoff of every clock sample is kept in t->fhz[] for the air's copy of the filter (os_hf.c) */
static void strip_render(uint32_t k, float *x, float *xs, uint32_t n, const mbus_t *mb)
{
    trk_t *t = &os.trk[k];
    uint32_t i, q, sub = t->mach == MA_WAVE ? WIDE : 1u, total = n * sub;
    float fs = (float)(CORE_SR * sub), qv = 1.0f / t->kq;
    for (i = 0; i < n; i++) {
        float cut;
        if (!t->typ) { t->fok = 0; continue; }
        cut = t->cut_v + (mb->cut_on ? mb->cut[i] : 0.0f);  /* ENV2 (x FLT, FEN), ENV2 / LFO2 on CUT: the bus */
        if (t->ffast) {                                      /* audio-rate cutoff: bilinear, every sample */
            t->fhz[i] = reg_cut_hz(os_clampf(cut, 0.0f, 127.0f));
            flt_bilinear(t->typ, t->fhz[i], qv, fs, &t->fcur);
            t->fcnt = 0;
            t->fok = 2;                                      /* (the next matched design glides from here) */
        } else {
            t->fhz[i] = reg_cut_hz(os_clampf(cut, 0.0f, 127.0f));
            if (!t->fcnt) {
                flt_c nx;
                flt_design(t->typ, t->fhz[i], qv, fs, &nx);
                if (!t->fok) {                               /* switched on: from rest, no glide */
                    uint32_t j;
                    t->fcur = nx;
                    memset(&t->fdel, 0, sizeof t->fdel);
                    memset(t->fst, 0, sizeof t->fst);
                    for (j = 0; j < FLT_NMHP; j++) { bq_set(&t->fhp[0][j], FLT_MHP[j]); bq_set(&t->fhp[1][j], FLT_MHP[j]); }
                } else {
                    flt_delta(&t->fcur, &nx, 1.0f / (float)FLT_CR, &t->fdel);
                }
                t->fok = 1;
                t->fcnt = FLT_CR;
            }
            flt_step(&t->fcur, &t->fdel);
            t->fcnt--;
        }
        if (sub == 1u) {                                     /* the 2-4 kHz band before and after (the air) */
            float a = x[i];
            uint32_t j;
            for (j = 0; j < FLT_NMHP; j++) a = bq_run(&t->fhp[0][j], a);
            t->fe_pre += a * a;
        }
        for (q = 0; q < sub; q++) {
            x[i * sub + q] = flt_tick(&t->fst[0], &t->fcur, x[i * sub + q]);
            if (xs) xs[i * sub + q] = flt_tick(&t->fst[1], &t->fcur, xs[i * sub + q]);
        }
        if (sub == 1u) {
            float a = x[i];
            uint32_t j;
            for (j = 0; j < FLT_NMHP; j++) a = bq_run(&t->fhp[1][j], a);
            t->fe_post += a * a;
        }
        t->fhz_last = t->fhz[i];
    }
    if (t->drv > 0.0f) {
        float d = 1.0f + t->drv * (8.0f / 127.0f), m = 1.0f / (0.6f + 0.4f * d);
        for (i = 0; i < total; i++) {
            if (xs) {                                        /* M/S: drive L and R */
                float l = drv_adaa((x[i] + xs[i]) * d, &t->dv[0]) * m, r = drv_adaa((x[i] - xs[i]) * d, &t->dv[1]) * m;
                x[i] = 0.5f * (l + r);
                xs[i] = 0.5f * (l - r);
            } else {
                x[i] = drv_adaa(x[i] * d, &t->dv[0]) * m;
            }
        }
    }
}

/* the submix's own stage (page E), after the strip: low cut (TPT high-pass, 12 dB/oct), then the compressor
 * (feed-forward RMS, 5 ms / 100 ms, its gain stepped at the block: trk_post_block) */
static void trk_post_block(trk_t *t)
{
    uint32_t sub = t->mach == MA_WAVE ? WIDE : 1u;
    float a = (float)t->eff[R_CMP] * (1.0f / 127.0f);
    if (t->eff[R_LOC]) {
        float w = 3.14159265f * reg_cut_hz((float)t->eff[R_LOC]) / (float)(CORE_SR * sub);
        if (w > 1.35f) w = 1.35f;
        t->lc_g = w * (15.0f - w * w) / (15.0f - 6.0f * w * w);
        t->lc_k = 1.41421356f;
    }
    if (a > 0.0f) {
        float r = 1.0f + 3.0f * a, slope = 1.0f - 1.0f / r, thr = -30.0f * a, over, red;
        over = 3.0103f * hf_log2(t->cmp_env + 1e-12f) - thr;
        red = over <= -3.0f ? 0.0f : over >= 3.0f ? over * slope : slope * (over + 3.0f) * (over + 3.0f) / 12.0f;
        t->cmp_step = (hf_db(-thr * slope * 0.5f - red) - t->cmp_g) * (1.0f / (float)BLK);
    } else {
        t->cmp_g = 1.0f;
        t->cmp_step = 0.0f;
    }
}

static void trk_post(trk_t *t, float *x, float *xs, uint32_t n)
{
    uint32_t i, q, sub = t->mach == MA_WAVE ? WIDE : 1u;
    if (t->eff[R_LOC]) {
        float g = t->lc_g, kk = t->lc_k, a1 = 1.0f / (1.0f + g * (g + kk)), a2 = g * a1, a3 = g * a2;
        uint32_t c, nc = xs ? 2u : 1u;
        for (c = 0; c < nc; c++) {
            float *y = c ? xs : x, *s = t->lc[c];
            for (i = 0; i < n * sub; i++) {
                float v3 = y[i] - s[1], v1 = a1 * s[0] + a2 * v3, v2 = s[1] + a2 * s[0] + a3 * v3;
                s[0] = 2.0f * v1 - s[0];
                s[1] = 2.0f * v2 - s[1];
                y[i] = y[i] - kk * v1 - v2;
            }
        }
    }
    if (t->eff[R_CMP]) {
        for (i = 0; i < n; i++) {
            float d = 0.0f, g;
            for (q = 0; q < sub; q++) {
                float m = x[i * sub + q], s = xs ? xs[i * sub + q] : 0.0f;
                d += m * m + s * s;
            }
            d *= 1.0f / (float)sub;
            t->cmp_env += (d - t->cmp_env) * (d > t->cmp_env ? 0.0247f : 0.00125f);
            t->cmp_g += t->cmp_step;
            g = t->cmp_g;
            for (q = 0; q < sub; q++) {
                x[i * sub + q] *= g;
                if (xs) xs[i * sub + q] *= g;
            }
        }
    }
}
