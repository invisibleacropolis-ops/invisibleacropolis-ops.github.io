/* SPDX-License-Identifier: GPL-3.0-only */
/* I2S out (ALNK0 -> codec, hal/fm1_audio.h) and the audio ISR: one half buffer per interrupt,
 * rendered by os_render (os_engine.c). Structure after Felucca's audio.c. */
#define HALF_WORDS (HALF_FRAMES * 2u)
#define CPU_AVG 32u                     /* the load meter averages ~93 ms */

static int32_t abuf[2u * HALF_WORDS] __attribute__((aligned(4)));
static volatile uint8_t os_in_audio;    /* TIMER5 nests into the render: it only scans then (os_main.c) */
static volatile uint32_t t5_nested_ticks;
static uint32_t audio_late, audio_cpu_rem;

/* what you hear: the half the DMA starts at this interrupt was rendered at the previous one, so a key
 * pressed at time w heard clock sample prev + (w - this interrupt) x 8 / ms; minus the DAC's own delay */
#define REC_LAT_FRAMES 16u                 /* DAC pipeline: measure on the unit (docs/DESIGN.md 7) */
static volatile struct { uint32_t q4_prev, q4_cur, t; uint32_t seq; } heard;

static uint32_t os_heard_core(uint32_t w)
{
    uint32_t s, q4, t;
    do {
        s = heard.seq;
        q4 = heard.q4_prev;
        t = heard.t;
    } while (s != heard.seq);
    q4 += (w - t) / FM1_TICKS_PER_US * 128u / 1000u;      /* 8 core samples a ms, Q4 */
    q4 -= (REC_LAT_FRAMES + MS_LA) * 68u * 16u / 375u;      /* the DAC, the limiter's look-ahead */
    return q4 >> 4;
}

void fm1_alnk0_irq(void)                /* via isr_alnk0 (hal/fm1_isr.S) */
{
    uint8_t p;
    uint32_t t0;
    os_in_audio = 1;
    p = fm1_audio_pending();
    t0 = fm1_ticks();
    t5_nested_ticks = 0;
    fm1_audio_ack_aux(p);
    if (p & FM1_AUDIO_HALF) {
        uint32_t half = fm1_audio_free_half(), us, load;
        heard.seq++;
        heard.q4_prev = heard.q4_cur;
        heard.q4_cur = (os.clock - OS_LAT) * 16u + (uint32_t)(os.up_phase * 16.0f);   /* the clock at this half's first frame */
        heard.t = t0;
        heard.seq++;
        os_render(&abuf[half * HALF_WORDS], HALF_FRAMES);
        fm1_audio_ack_half();
        us = (fm1_ticks() - t0 - t5_nested_ticks) / FM1_TICKS_PER_US;
        load = os.cpu_q8 * (CPU_AVG - 1u) + us * 256u / (HALF_FRAMES * 1000000u / 44118u) + audio_cpu_rem;
        os.cpu_q8 = load / CPU_AVG;
        audio_cpu_rem = load % CPU_AVG;
        if (fm1_audio_free_half() != half)
            audio_late++;                   /* the DMA moved on while we rendered */
    }
    os_in_audio = 0;
}
extern void isr_alnk0(void);

static void audio_init(void)
{
    uint32_t i;
    for (i = 0; i < 2u * HALF_WORDS; i++)
        abuf[i] = 0;
    fm1_audio_init(abuf, HALF_WORDS, isr_alnk0, 3);
}
