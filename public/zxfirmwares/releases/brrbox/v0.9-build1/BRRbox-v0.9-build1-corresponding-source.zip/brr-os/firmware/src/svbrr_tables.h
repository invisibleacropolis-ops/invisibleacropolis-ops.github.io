/* generated from vbrr.py */
#define SV_BLK 16                 /* the codec block: 2 ms at 8 kHz (SVB4) */
#define SV_BLK_SHIFT 4
#define SV_SIDE_SHIFT 7           /* a side frame: 128 core samples, 16 ms */
#define SV_NF 8
#define SV_NS 32
static const int32_t SV_A1[SV_NF] = {0,3840,7808,7360,6144,8064,2048,-2048};
static const int32_t SV_A2[SV_NF] = {0,0,-3840,-3328,-2560,-4014,0,0};
static const int32_t SV_HALF[SV_NS] = {1,1,2,3,4,6,8,11,16,23,32,45,64,91,128,181,256,362,512,724,1024,1448,2048,2896,4096,5793,8192,11585,16384,23170,32768,46341};
