/* SPDX-License-Identifier: GPL-3.0-only */
/* Each track's own effects, on the clock (v0.5): one multi-effect and one reverb per track, inserted after the
 * compressor and before level / pan and the air.
 *
 *   machine -> strip -> low cut -> comp -> MULTI-FX -> REVERB -> level / pan -> core bus
 *                                                            \-> the air (os_hf.c), rebuilt from the wet sound
 *
 * Both run at the codec's 8 kHz, one clock sample per sample. The air rebuilds 4-16 kHz from whatever it is fed,
 * so echoes, chorus voices and tails get their highs back; the copy-up shifts (it does not scale), so a comb's
 * spacing and a phaser's notches in 2-4 kHz are carried up as they are.
 *
 * THE MULTI-EFFECT (page F: TIM FBK DEP RAT DIS COL PNG MIX). One structure, one profile at a time; where the
 * knobs sit decides what it is, and every knob is a register (locks, scenes, the LFO all move it):
 *
 *   x -> (+) -> allpass chain (DIS: 6 swept stages) -> delay line (TIM, modulated by DEP at RAT) -> COL -> wet
 *         ^__________________________________ FBK (+-) _____________________________________________/
 *
 *   TIM 0              no delay: the allpass chain alone, mixed with the dry: a PHASER (FBK = resonance)
 *   TIM 0.4 - 10 ms    FLANGER (FBK < 0: hollow)
 *   TIM 10 - 40 ms     CHORUS: a second voice (at 0.73 x, its LFO in anti-phase) fades in from 5 ms and out by
 *                      60 ms, the channels' LFOs 90 degrees apart
 *   TIM synced         DELAY: n/64 of a bar (exactly n x bpb clock samples) or triplets, up to 2 s;
 *                      DEP becomes tape wow, DIS smears the repeats, COL darkens or thins them
 *   TIM glides (100 ms): turning it morphs one character into the next, and a synced time pitches like tape
 *   RAT free (0.02 - 22 Hz) or synced (1/64 note .. 64 bars): a synced LFO's phase is the song position, so a
 *   sweep restarts on PLAY and repeats exactly every pass. WARP bends all of it with the clock.
 *   PNG  ST: two lines, L -> L, R -> R (stereo in, stereo out)
 *        PING: the mono sum into L, L's echo into R, R's back into L: L R L R ..., each echo time up to 2 s
 *   MIX  dry min(1, 2 (1 - m)), wet min(1, 2 m): at 64 both are full (a phaser's deepest notches)
 *
 * Memory: two lines of 16384 samples (2.05 s) per track. The newest 512 samples (64 ms) are kept 16-bit (the
 * chorus, flanger and phaser read only those); the whole line is kept as 8-bit block floating point: one scale
 * per 16-sample codec block (a quarter-octave index) and an int8 per sample, the quantisation ~48 dB under each
 * block's peak, random access at any position. 36 KB a track instead of 64.
 *
 * THE REVERB (page G: SIZ DCY DMP PRE MOD DIF GAT REV). Pre-delay, four input allpasses (DIF), a 4-line FDN
 * (Householder) with damping (DMP) and two modulated lines (MOD); SIZ scales the lines, DCY is RT60 (127 =
 * FREEZE: the tail held, the input shut), GAT closes the wet n steps after the track's last note (clock gated
 * reverb). At 8 kHz the lines are a third as long as at 24 kHz: four reverbs cost about what one master reverb
 * did. */

#define TX_LINE 16384u
#define TX_LMASK (TX_LINE - 1u)
#define TX_HEAD 512u
#define TX_HMASK (TX_HEAD - 1u)
#define TX_NAP 6u
#define TX_HS 8192.0f                         /* the 16-bit head: +-4.0 */

typedef struct {
    int16_t head[2][TX_HEAD];
    int8_t q[2][TX_LINE];
    uint8_t sc[2][TX_LINE / BLK];
} tx_line_t;

#define RV_N 4u
static const uint16_t RV_LEN[RV_N] = {797u, 911u, 1031u, 1163u};
static const uint16_t RV_APL[4] = {31u, 47u, 71u, 109u};
#define RV_TOT (797u + 911u + 1031u + 1163u)
#define RV_APT (31u + 47u + 71u + 109u)
#define RV_PRE 1024u

typedef struct {
    int16_t ln[RV_TOT];
    int16_t ap[RV_APT];
    int16_t pre[RV_PRE];
} rv_mem_t;

static tx_line_t tx_mem[NTRACK] __attribute__((section(".pool")));
static rv_mem_t rv_mem[NTRACK] __attribute__((section(".pool")));
static float tx_step[64];                     /* the block scales: (4 / 127) x 2^((i - 63) / 4) */

typedef struct {
    /* multi-effect */
    float d, dt, A, v2, fc, dep, fbk, dmix, wmix, colk;
    float ap[2][TX_NAP][2], fb[2], col[2];
    float ph, inc;
    uint8_t on, was_on, png, dis, colhp, sync;
    /* reverb */
    float rg[RV_N], rlp[RV_N], rdk, rmod, rph, rdif, rdry, rwet, gate_g, pre;
    uint16_t rlen[RV_N], rw[RV_N], apw[4];
    uint32_t rv_pw, trig_at, gate_n;
    uint8_t rv_on, rv_was, frz, gate;
    /* WAVE: the 32 -> 8 kHz decimator's last three samples */
    float dh[2][3];
    /* the air follows the image: high-passed L, R, M energies this block, and the gains they gave */
    float eL, eR, eM, pL, pR, pM, imgL, imgR;
    /* the response contract (os_flt.c): the wet's share of the output this block, and each air slot's gain */
    float ew, eo, wf, sg[HF_NS], pw[2], po[2];
} tx_t;
static tx_t tx[NTRACK];

static void tx_init(void)
{
    uint32_t i;
    for (i = 0; i < 64u; i++) tx_step[i] = (4.0f / 127.0f) * hf_exp2(((float)i - 63.0f) * 0.25f);
    memset(tx, 0, sizeof tx);
    memset(tx_mem, 0, sizeof tx_mem);
    memset(rv_mem, 0, sizeof rv_mem);
    for (i = 0; i < NTRACK; i++) { tx[i].imgL = tx[i].imgR = 1.0f; tx[i].gate_g = 1.0f; }
}

static uint32_t seq_pos(uint32_t c);

static void tx_trig(uint32_t k, uint32_t at) { tx[k].trig_at = at; }

static inline int16_t tx_sat16(float x)
{
    float v = x * TX_HS;
    if (v > 32767.0f) v = 32767.0f;
    if (v < -32768.0f) v = -32768.0f;
    return (int16_t)v;
}

/* one channel's sample at clock index i, of a line whose newest sample is w - 1 */
static inline float tx_at(const tx_line_t *m, uint32_t ch, uint32_t i, uint32_t w)
{
    if (w - i < TX_HEAD) return (float)m->head[ch][i & TX_HMASK] * (1.0f / TX_HS);
    i &= TX_LMASK;
    return (float)m->q[ch][i] * tx_step[m->sc[ch][i >> BLK_SHIFT]];
}

/* the line read d samples back (d >= 3), Hermite */
static inline float tx_tap(const tx_line_t *m, uint32_t ch, uint32_t w, float d)
{
    float x = (float)w - d, f, y0, y1, y2, y3, c1, c2, c3;
    uint32_t i;
    if (d > (float)(TX_LINE - 8u)) x = (float)w - (float)(TX_LINE - 8u);
    i = (uint32_t)(int32_t)x;
    if ((float)(int32_t)x > x) i--;
    f = x - (float)(int32_t)x;
    if (f < 0.0f) f += 1.0f;
    y0 = tx_at(m, ch, i - 1u, w); y1 = tx_at(m, ch, i, w); y2 = tx_at(m, ch, i + 1u, w); y3 = tx_at(m, ch, i + 2u, w);
    c1 = 0.5f * (y2 - y0);
    c2 = y0 - 2.5f * y1 + 2.0f * y2 - 0.5f * y3;
    c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
    return ((c3 * f + c2) * f + c1) * f + y1;
}

/* the block that ends at clock index w (w & 15 == 15): head -> 8-bit block float */
static void tx_encode(tx_line_t *m, uint32_t ch, uint32_t w)
{
    uint32_t b0 = w - (BLK - 1u), j, si;
    int32_t pk = 0;
    float st, inv;
    for (j = 0; j < BLK; j++) {
        int32_t v = m->head[ch][(b0 + j) & TX_HMASK];
        if (v < 0) v = -v;
        if (v > pk) pk = v;
    }
    if (pk < 1) si = 0;
    else {
        float p = (float)pk * (1.0f / TX_HS), e = 63.0f + 4.0f * hf_log2(p * 0.25f);
        int32_t ie = (int32_t)e;
        if ((float)ie < e) ie++;
        si = (uint32_t)os_clampi(ie, 0, 63);
    }
    st = tx_step[si];
    inv = 1.0f / (st * TX_HS);
    m->sc[ch][(b0 & TX_LMASK) >> BLK_SHIFT] = (uint8_t)si;
    for (j = 0; j < BLK; j++) {
        float q = (float)m->head[ch][(b0 + j) & TX_HMASK] * inv;
        int32_t v = (int32_t)(q + (q < 0.0f ? -0.5f : 0.5f));
        m->q[ch][(b0 + j) & TX_LMASK] = (int8_t)os_clampi(v, -127, 127);
    }
}

static inline float tx_sinp(float u)                 /* a parabolic sine of phase u (any) */
{
    float t = u - (float)(int32_t)u;
    if (t < 0.0f) t += 1.0f;
    return t < 0.5f ? 16.0f * t * (0.5f - t) : -16.0f * (t - 0.5f) * (1.0f - t);
}

/* the loop's guard: exactly linear to 2 (twice full scale: a hot track passes untouched), then a smooth knee
 * toward 3, inside the lines' +-4 (runaway feedback stays bounded) */
static inline float tx_soft(float x)
{
    float a = x < 0.0f ? -x : x, e;
    if (a <= 2.0f) return x;
    e = a - 2.0f;
    e = 2.0f + e / (1.0f + e);
    return x < 0.0f ? -e : e;
}

static int tx_active(uint32_t k)
{
    return os.fx_on && (tx[k].on || tx[k].rv_on);
}

static float tx_slot_gain(uint32_t k, uint32_t s) { return tx[k].on ? tx[k].sg[s] : 1.0f; }

/* the response contract (os_flt.c): what the multi-effect does to each air slot, against the 2-4 kHz band the air
 * is copied from. The air is rebuilt from the effect's output, so without this an echo train darkened by COL
 * would keep the dry's highs, and a phaser's notches in 2-4 kHz would be copied up.
 *   delay / chorus / flanger: COL sits in the loop; an echo train of feedback g gives the wet c / (1 - g^2 c) per
 *     frequency (c = |COL|^2), mixed by the wet's measured share of the output: 1 - w + w C(slot) / C(band);
 *   phaser: dry and wet are coherent, so the whole response, dmix + wmix COL A / (1 - fbk COL A e^-jwT) (A the
 *     6-stage allpass, T one clock sample), analog on the slots and the clock's own on the band */
typedef struct { float re, im; } tx_cx;
static inline tx_cx cx_mul(tx_cx a, tx_cx b) { tx_cx r = {a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re}; return r; }
static inline tx_cx cx_div(tx_cx a, tx_cx b) { float d = b.re * b.re + b.im * b.im + 1e-20f; tx_cx r = {(a.re * b.re + a.im * b.im) / d, (a.im * b.re - a.re * b.im) / d}; return r; }

/* the multi-effect's whole response at f (Hz); dig: the clock's own (8 kHz) filters, else analog */
static tx_cx tx_resp(const tx_t *s, float f, float fap, int dig)
{
    tx_cx col = {1.0f, 0.0f}, a1, ap = {1.0f, 0.0f}, num, den, zm;
    float wT = 6.2831853f * f / (float)CORE_SR, cw = hf_cos(wT), sw = hf_sin(wT);
    uint32_t j;
    zm.re = cw; zm.im = -sw;                                       /* e^-jwT */
    if (s->colk < 1.0f) {
        if (dig) {                                                 /* one pole: k / (1 - (1 - k) z^-1) */
            tx_cx d1 = {1.0f - (1.0f - s->colk) * cw, (1.0f - s->colk) * sw}, n1 = {s->colk, 0.0f};
            col = cx_div(n1, d1);
            if (s->colhp) { col.re = 1.0f - col.re; col.im = -col.im; }
        } else {
            float fc = -(float)CORE_SR * hf_log2(1.0f - s->colk) * (0.69314718f / 6.2831853f);   /* its corner */
            tx_cx d1 = {1.0f, f / fc}, one = {1.0f, 0.0f}, jx = {0.0f, f / fc};
            col = cx_div(s->colhp ? jx : one, d1);
        }
    }
    if (s->dis) {
        if (dig) {                                                 /* (a + z^-1) / (1 + a z^-1) */
            float wv = 3.14159265f * (fap > 3800.0f ? 3800.0f : fap) / (float)CORE_SR, g = wv * (15.0f - wv * wv) / (15.0f - 6.0f * wv * wv);
            float ac = (g - 1.0f) / (g + 1.0f);
            tx_cx n1 = {ac + cw, -sw}, d1 = {1.0f + ac * cw, -ac * sw};
            a1 = cx_div(n1, d1);
        } else {                                                   /* (fa - jf) / (fa + jf) */
            tx_cx n1 = {fap, -f}, d1 = {fap, f};
            a1 = cx_div(n1, d1);
        }
        for (j = 0; j < TX_NAP; j++) ap = cx_mul(ap, a1);
    }
    num = cx_mul(col, ap);
    den = cx_mul(num, zm);
    den.re = 1.0f - s->fbk * den.re; den.im = -s->fbk * den.im;
    num = cx_div(num, den);
    num.re = s->dmix + s->wmix * num.re; num.im *= s->wmix;
    return num;
}

static void tx_slots(uint32_t k)
{
    tx_t *s = &tx[k];
    uint32_t j, n;
    float ref = 0.0f;
    for (j = 0; j < HF_NS; j++) s->sg[j] = 1.0f;
    if (s->eo > 1e-12f) s->wf += (os_clampf(s->ew / s->eo, 0.0f, 1.0f) - s->wf) * 0.25f;
    s->ew = s->eo = 0.0f;
    if (!s->on || !os.fx_on) { s->wf = 0.0f; return; }
    if (s->d < 3.0f) {                                             /* the phaser end: coherent */
        /* the air is built from the mid: both channels' sweeps (90 or 180 degrees apart), in power */
        float fl = s->fc * hf_exp2(s->dep * 2.5f * tx_sinp(s->ph)), fr = s->fc * hf_exp2(s->dep * 2.5f * tx_sinp(s->ph + (s->png ? 0.5f : 0.25f)));
        uint32_t c2;
        for (c2 = 0; c2 < 2u; c2++)
            for (n = 0; n < 4u; n++) { tx_cx r = tx_resp(s, FLT_REF[n], c2 ? fr : fl, 1); ref += r.re * r.re + r.im * r.im; }
        ref *= 0.125f;
        for (j = 0; j < HF_NS; j++) {
            float sc = 5000.0f + 2000.0f * (float)j, a = 0.0f;
            for (c2 = 0; c2 < 2u; c2++)
                for (n = 0; n < 3u; n++) { tx_cx r = tx_resp(s, sc + 667.0f * ((float)n - 1.0f), c2 ? fr : fl, 0); a += r.re * r.re + r.im * r.im; }
            s->sg[j] = a * (1.0f / 6.0f) / (ref + 1e-12f);
        }
    } else if (s->colk < 1.0f) {                                   /* an echo train through COL */
        float g2 = s->fbk * s->fbk, cr = 0.0f, fcol = -(float)CORE_SR * hf_log2(1.0f - s->colk) * (0.69314718f / 6.2831853f);
        for (n = 0; n < 4u; n++) {
            float f = FLT_REF[n], w = 6.2831853f * f / (float)CORE_SR, cw = hf_cos(w), a = 1.0f - s->colk;
            float c = s->colk * s->colk / (1.0f - 2.0f * a * cw + a * a);   /* the one pole at the clock rate */
            if (s->colhp) c = a * a * 2.0f * (1.0f - cw) / (1.0f - 2.0f * a * cw + a * a);
            cr += c / (1.0f - g2 * c);
        }
        cr *= 0.25f;
        for (j = 0; j < HF_NS; j++) {
            float a = 0.0f;
            for (n = 0; n < 3u; n++) {
                float x = (5000.0f + 2000.0f * (float)j + 667.0f * ((float)n - 1.0f)) / fcol, c = s->colhp ? x * x / (1.0f + x * x) : 1.0f / (1.0f + x * x);
                a += c / (1.0f - g2 * c);
            }
            s->sg[j] = 1.0f - s->wf + s->wf * a * (1.0f / 3.0f) / (cr + 1e-12f);
        }
    }
}

/* per block: the registers into coefficients */
static void tx_block(uint32_t k, uint32_t c)
{
    trk_t *t = &os.trk[k];
    tx_t *s = &tx[k];
    uint32_t mix = t->eff[R_MIX], rv = t->eff[R_REV], j;
    float m;
    /* the image the air follows, from the last block */
    if (s->eM > 1e-12f) {
        float gl = os_sqrt(s->eL / s->eM), gr = os_sqrt(s->eR / s->eM);
        s->imgL += (os_clampf(gl, 0.0f, 2.5f) - s->imgL) * 0.5f;
        s->imgR += (os_clampf(gr, 0.0f, 2.5f) - s->imgR) * 0.5f;
    }
    s->eL = s->eR = s->eM = 0.0f;
    /* multi-effect */
    s->on = mix > 0u;
    if (s->on && !s->was_on) {                        /* switched on: no stale echoes */
        memset(&tx_mem[k], 0, sizeof tx_mem[k]);
        memset(s->ap, 0, sizeof s->ap);
        s->fb[0] = s->fb[1] = s->col[0] = s->col[1] = 0.0f;
        s->d = reg_fx_time(t->eff[R_TIM], os.bpb);
    }
    s->was_on = s->on;
    if (s->on) {
        float per;
        s->dt = reg_fx_time(t->eff[R_TIM], os.bpb);
        if (s->dt > (float)(TX_LINE - 8u)) s->dt = (float)(TX_LINE - 8u);
        m = (float)mix * (1.0f / 127.0f);
        s->dmix = m < 0.5f ? 1.0f : 2.0f * (1.0f - m);
        s->wmix = m > 0.5f ? 1.0f : 2.0f * m;
        s->fbk = ((float)t->eff[R_FBK] - 64.0f) * (0.97f / 64.0f);
        s->dep = (float)t->eff[R_DEP] * (1.0f / 127.0f);
        s->dis = t->eff[R_DIS] > 0u;
        s->fc = reg_fx_dis_hz(t->eff[R_DIS]);
        s->png = t->eff[R_PNG] != 0u;
        {   /* COL: < 64 a low-pass 3.8 kHz .. 200 Hz, > 64 a high-pass 20 Hz .. 2 kHz, one pole */
            int32_t cv = (int32_t)t->eff[R_COL] - 64;
            float fc = cv < 0 ? 3800.0f * hf_exp2((float)cv * (4.25f / 64.0f)) : 20.0f * hf_exp2((float)cv * (6.64f / 63.0f));
            s->colhp = cv > 0;
            s->colk = cv == 0 ? 1.0f : 1.0f - fx_fexp(-6.2831853f * fc / (float)CORE_SR);
        }
        per = reg_fx_period(t->eff[R_RAT], os.bpb);
        s->sync = t->eff[R_RAT] >= RAT_SYNC;
        s->inc = 1.0f / per;
        if (s->sync && os.playing) {                  /* the phase is the song position */
            float pos = (float)seq_pos(c);
            s->ph = pos * s->inc;
            s->ph -= (float)(int32_t)s->ph;
        }
    }
    tx_slots(k);
    /* reverb */
    s->rv_on = rv > 0u;
    if (s->rv_on && !s->rv_was) {
        memset(&rv_mem[k], 0, sizeof rv_mem[k]);
        memset(s->rlp, 0, sizeof s->rlp);
    }
    s->rv_was = s->rv_on;
    if (s->rv_on) {
        float size = 0.25f + 0.75f * (float)t->eff[R_SIZ] * (1.0f / 127.0f), rt, fc;
        uint32_t dc = t->eff[R_DCY];
        m = (float)rv * (1.0f / 127.0f);
        s->rdry = m < 0.5f ? 1.0f : 2.0f * (1.0f - m);
        s->rwet = m > 0.5f ? 1.0f : 2.0f * m;
        s->frz = dc >= 127u;
        rt = 0.2f * hf_exp2((float)dc * (1.0f / 14.0f));
        for (j = 0; j < RV_N; j++) {
            s->rlen[j] = (uint16_t)((float)RV_LEN[j] * size);
            if (s->rlen[j] < 40u) s->rlen[j] = 40u;
            if (s->rlen[j] > RV_LEN[j] - 28u) s->rlen[j] = (uint16_t)(RV_LEN[j] - 28u);   /* room for MOD */
            s->rg[j] = s->frz ? 1.0f : hf_exp2(-9.9657843f * (float)s->rlen[j] / (rt * (float)CORE_SR));
        }
        fc = 3800.0f * hf_exp2(-(float)t->eff[R_DMP] * (3.25f / 127.0f));
        s->rdk = s->frz ? 1.0f : 1.0f - fx_fexp(-6.2831853f * fc / (float)CORE_SR);
        s->rmod = (float)t->eff[R_RMD] * (12.0f / 127.0f);
        s->rdif = (float)t->eff[R_DIF] * (0.7f / 127.0f);
        s->pre = (float)t->eff[R_PRE] * 8.0f;
        s->gate = t->eff[R_GAT] > 0u;
        s->gate_n = (uint32_t)t->eff[R_GAT] * 4u * os.bpb;
    }
}

/* the multi-effect on L, R (n samples from clock c), in place. The line is read before this sample is written,
 * so a delay of d is exactly d clock samples and the n-th echo lands on n x d: no drift off the grid */
static void tx_mfx(uint32_t k, float *L, float *R, uint32_t n, uint32_t c)
{
    tx_t *s = &tx[k];
    tx_line_t *m = &tx_mem[k];
    uint32_t i, ch, j;
    for (i = 0; i < n; i++) {
        uint32_t w = c + i;
        float xs[2] = {L[i], R[i]}, wc[2] = {0.0f, 0.0f}, src[2], in[2], A, v2, d, lf[2], u;
        s->d += (s->dt - s->d) * 0.00125f;            /* TIM glides: ~100 ms */
        d = s->d;
        A = s->dep * (d > 3.0f ? (0.9f * (d - 3.0f) < 160.0f ? 0.9f * (d - 3.0f) : 160.0f) : 0.0f);
        /* the chorus voice: in from 5 to 10 ms, out from 40 to 60 ms; its own base (0.73 d), its LFO in anti-phase */
        v2 = os_clampf((d - 40.0f) * (1.0f / 40.0f), 0.0f, 1.0f) * os_clampf((480.0f - d) * (1.0f / 160.0f), 0.0f, 1.0f);
        lf[0] = tx_sinp(s->ph);
        lf[1] = tx_sinp(s->ph + (s->png ? 0.5f : 0.25f));
        s->ph += s->inc;
        if (s->ph >= 1.0f) s->ph -= 1.0f;
        u = d < 3.0f ? d * (1.0f / 3.0f) : 1.0f;      /* 0 at the phaser end, 1 from 3 samples up */
        if (u > 0.0f)
            for (ch = 0; ch < 2u; ch++) {
                float d1 = d + A * lf[ch], wet = tx_tap(m, ch, w, d1 < 3.0f ? 3.0f : d1);
                if (v2 > 0.0f) {                       /* two voices at equal power */
                    float d2 = 0.73f * d - A * lf[ch];
                    wet = (wet + v2 * tx_tap(m, ch, w, d2 < 3.0f ? 3.0f : d2)) * os_sqrt(1.0f / (1.0f + v2 * v2));
                }
                if (s->colk < 1.0f) {                  /* COL, in the loop */
                    s->col[ch] += (wet - s->col[ch]) * s->colk;
                    wet = s->colhp ? wet - s->col[ch] : s->col[ch];
                }
                wc[ch] = wet;
            }
        /* feedback: this sample's echo (the loop is exactly d), or at the phaser end the last wet (z^-1) */
        src[0] = u >= 1.0f ? wc[0] : s->fb[0];
        src[1] = u >= 1.0f ? wc[1] : s->fb[1];
        if (s->png) {
            in[0] = 0.5f * (xs[0] + xs[1]) + s->fbk * src[1];
            in[1] = s->fbk * src[0];
        } else {
            in[0] = xs[0] + s->fbk * src[0];
            in[1] = xs[1] + s->fbk * src[1];
        }
        for (ch = 0; ch < 2u; ch++) {
            float y = tx_soft(in[ch]), wet;
            if (s->dis) {                              /* 6 first-order allpasses at fc x 2^(+-2.5 DEP) */
                float f = s->fc * hf_exp2(s->dep * 2.5f * lf[ch]), wv, g, ac;
                if (f > 3800.0f) f = 3800.0f;
                wv = 3.14159265f * f * (1.0f / (float)CORE_SR);
                g = wv * (15.0f - wv * wv) / (15.0f - 6.0f * wv * wv);
                ac = (g - 1.0f) / (g + 1.0f);
                for (j = 0; j < TX_NAP; j++) {
                    float *z = s->ap[ch][j], o = ac * y + z[0] - ac * z[1];
                    z[0] = y; z[1] = o;
                    y = o;
                }
            }
            m->head[ch][w & TX_HMASK] = tx_sat16(y);
            if (u < 1.0f) {                            /* the phaser end: the chain itself, COL after it */
                wet = y * (1.0f - u) + wc[ch] * u;
                if (s->colk < 1.0f) {
                    s->col[ch] += (wet - s->col[ch]) * s->colk;
                    wet = s->colhp ? wet - s->col[ch] : s->col[ch];
                }
            } else {
                wet = wc[ch];
            }
            s->fb[ch] = wet;
            if (ch == 0) L[i] = xs[0] * s->dmix + wet * s->wmix;
            else R[i] = xs[1] * s->dmix + wet * s->wmix;
            {   /* the wet's share, of the highs: first differences (+6 dB / octave: the 2-4 kHz band leads) */
                float dw = (wet - s->pw[ch]) * s->wmix, o = ch == 0 ? L[i] : R[i], dO = o - s->po[ch];
                s->ew += dw * dw; s->eo += dO * dO;
                s->pw[ch] = wet; s->po[ch] = o;
            }
        }
        if ((w & (BLK - 1u)) == BLK - 1u) { tx_encode(m, 0, w); tx_encode(m, 1, w); }
    }
}

/* a line of the reverb (ring of cap, next write at wpos): the sample `back` behind the next write (back >= 3) */
static inline float rv_read(const int16_t *b, uint32_t cap, uint32_t wpos, float back)
{
    float x = (float)wpos - back, f, y0, y1, y2, y3, c1, c2, c3;
    int32_t i, i0, i2, i3;
    if (x < 0.0f) x += (float)cap;
    i = (int32_t)x;
    f = x - (float)i;
    i0 = i - 1; if (i0 < 0) i0 += (int32_t)cap;
    i2 = i + 1; if (i2 >= (int32_t)cap) i2 -= (int32_t)cap;
    i3 = i2 + 1; if (i3 >= (int32_t)cap) i3 -= (int32_t)cap;
    y0 = (float)b[i0] * (1.0f / TX_HS); y1 = (float)b[i] * (1.0f / TX_HS);
    y2 = (float)b[i2] * (1.0f / TX_HS); y3 = (float)b[i3] * (1.0f / TX_HS);
    c1 = 0.5f * (y2 - y0);
    c2 = y0 - 2.5f * y1 + 2.0f * y2 - 0.5f * y3;
    c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
    return ((c3 * f + c2) * f + c1) * f + y1;
}

static void tx_rev(uint32_t k, float *L, float *R, uint32_t n, uint32_t c)
{
    tx_t *s = &tx[k];
    rv_mem_t *m = &rv_mem[k];
    int16_t *ln[RV_N], *ap[4];
    uint32_t i, j, off = 0;
    for (j = 0; j < RV_N; j++) { ln[j] = m->ln + off; off += RV_LEN[j]; }
    for (off = 0, j = 0; j < 4u; j++) { ap[j] = m->ap + off; off += RV_APL[j]; }
    for (i = 0; i < n; i++) {
        float x = 0.5f * (L[i] + R[i]), o[RV_N], v[RV_N], sum, wl, wr, mo;
        uint32_t pw = s->rv_pw;
        /* pre-delay */
        m->pre[pw & (RV_PRE - 1u)] = tx_sat16(x);
        if (s->pre > 0.0f) x = (float)m->pre[(pw - (uint32_t)s->pre) & (RV_PRE - 1u)] * (1.0f / TX_HS);
        s->rv_pw = pw + 1u;
        if (s->frz) x = 0.0f;
        /* diffusion: four Schroeder allpasses */
        for (j = 0; j < 4u; j++) {
            int16_t *b = ap[j];
            uint32_t p = s->apw[j];
            float bv = (float)b[p] * (1.0f / TX_HS), y = bv - s->rdif * x;
            b[p] = tx_sat16(x + s->rdif * y);
            s->apw[j] = (uint16_t)(p + 1u >= RV_APL[j] ? 0u : p + 1u);
            x = y;
        }
        /* the FDN */
        s->rph += 0.7f / (float)CORE_SR;
        if (s->rph >= 1.0f) s->rph -= 1.0f;
        mo = s->rmod;
        for (j = 0; j < RV_N; j++) {
            float back = (float)s->rlen[j];
            if (mo > 0.0f && (j & 1u) == 0u) back += mo * (1.0f + tx_sinp(s->rph + 0.37f * (float)j));
            o[j] = rv_read(ln[j], RV_LEN[j], s->rw[j], back);
            s->rlp[j] += (o[j] - s->rlp[j]) * s->rdk;
            v[j] = s->rlp[j] * s->rg[j];
        }
        sum = 0.5f * (v[0] + v[1] + v[2] + v[3]);
        for (j = 0; j < RV_N; j++) {
            float in = (j & 1u) ? -x : x;
            ln[j][s->rw[j]] = tx_sat16(tx_soft(v[j] - sum + in * 0.5f));
            s->rw[j] = (uint16_t)(s->rw[j] + 1u >= RV_LEN[j] ? 0u : s->rw[j] + 1u);
        }
        wl = o[0] + 0.6f * o[2];
        wr = o[1] + 0.6f * o[3];
        if (s->gate) {                                /* closes GAT steps after the track's last note */
            float tg = (c + i) - s->trig_at < s->gate_n ? 1.0f : 0.0f;
            s->gate_g += (tg - s->gate_g) * 0.06f;
            wl *= s->gate_g; wr *= s->gate_g;
        }
        L[i] = L[i] * s->rdry + wl * s->rwet;
        R[i] = R[i] * s->rdry + wr * s->rwet;
    }
}

/* the track's effects on its stereo submix, given as M, S (n clock samples from c), in place */
static void tx_run(uint32_t k, float *M, float *S, uint32_t n, uint32_t c)
{
    float L[BLK], R[BLK];
    uint32_t i;
    for (i = 0; i < n; i++) { L[i] = M[i] + S[i]; R[i] = M[i] - S[i]; }
    if (tx[k].on) tx_mfx(k, L, R, n, c);
    if (tx[k].rv_on) tx_rev(k, L, R, n, c);
    for (i = 0; i < n; i++) { M[i] = 0.5f * (L[i] + R[i]); S[i] = 0.5f * (L[i] - R[i]); }
}

/* the image the air follows: high-passed energies of L, R and M (call after the effects) */
static void tx_image(uint32_t k, const float *M, const float *S, uint32_t n)
{
    tx_t *s = &tx[k];
    uint32_t i;
    for (i = 0; i < n; i++) {
        float l = M[i] + S[i], r = M[i] - S[i], dl = l - s->pL, dr = r - s->pR, dm = M[i] - s->pM;
        s->eL += dl * dl; s->eR += dr * dr; s->eM += dm * dm;
        s->pL = l; s->pR = r; s->pM = M[i];
    }
}

/* WAVE: its 32 kHz M, S down to the clock for the effects (a 7-tap triangle, centred on each core sample) */
static void tx_decim(uint32_t k, const float *x, float *y, uint32_t n, uint32_t ch)
{
    float *h = tx[k].dh[ch];
    uint32_t i;
    for (i = 0; i < n; i++) {
        const float *p = x + i * WIDE;
        y[i] = (h[0] + 2.0f * h[1] + 3.0f * h[2] + 4.0f * p[0] + 3.0f * p[1] + 2.0f * p[2] + p[3]) * (1.0f / 16.0f);
        h[0] = p[1]; h[1] = p[2]; h[2] = p[3];
    }
}
