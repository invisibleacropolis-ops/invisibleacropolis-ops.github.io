/* SPDX-License-Identifier: GPL-3.0-only */
/* The modulators (v0.7): one envelope and one LFO, written once and used everywhere.
 *
 *   AMP   envelope, per voice     page C   ATK DEC SUS REL RNG             (the voice's level)
 *   ENV1  envelope, per voice     page D   AT1 DE1 SU1 RE1 RG1 ET1 ED1     (target, depth)
 *   ENV2  envelope, per track     page E   AT2 DE2 SU2 RE2 RG2 ET2 ED2 FLT (FLT: also to the cutoff, x FEN)
 *   LFO1  LFO, per voice          page F   RT1 MU1 SH1 MD1 PH1 LT1 LD1
 *   LFO2  LFO, per track          page G   RT2 MU2 SH2 MD2 PH2 LT2 LD2     (the old LFO, grown)
 *
 * ENVELOPES. Attack linear, decay and release exponential (one-pole toward the target), as before. RNG: LONG,
 * 2 ms .. 4.1 s a stage (pads: ~12 s in all), or SHORT, 0.1 ms .. 330 ms (hits: under 1 s in all); 128 steps
 * either way. A track's ENV2 opens with any note and closes when the last one is released.
 *
 * LFOS. RATE spans two decades, 0.1 .. 10 Hz at 3.7 % a step (fine at every speed), MUL shifts it: 1/64 .. x256,
 * so 0.0016 Hz to 2.56 kHz (audio-rate FM and AM). MUL = SYNC: RATE picks a note value, 1/64T .. 64 bars,
 * straight, dotted and triplet, exact in clock samples at every tempo; a synced FREE LFO's phase IS the song
 * position. Shapes: SIN TRI SQR SAW RMP EXP S&H SMT (smooth random). Modes:
 *   FREE  runs on its own (a voice's LFO1 follows the track's free LFO1, so all voices are in step)
 *   TRIG  restarts at PH with every note
 *   HOLD  takes the free LFO's value at the note and holds it (a random per note with S&H)
 *   ONE   one cycle from PH, then holds (with EXP: one more AD envelope)
 *   HALF  half a cycle, then holds
 * (Square and saw are not band-limited: at audio rate they alias, as on most hardware LFOs.)
 *
 * ROUTES. Every source has one target (any register, or none) and a depth: +-128 register units at the ends,
 * squared, so a step near the centre is 0.03 units (3 cents of pitch) and full depth spans any register. How a
 * target is driven depends on what it is:
 *   - track sources (ENV2, LFO2) drive pitch, tune, cutoff, level and the WAVE frame every clock sample (the
 *     track's modulation bus); every other register at the block, through the resolver
 *   - voice sources (ENV1, LFO1) drive each voice's own pitch, tune, level, pan and WAVE frame morph every clock
 *     sample; a MULTI voice's sample start and length and a GRAN grain's position and size when it starts; any
 *     other register (the filter, the effects: those are the track's) from the newest voice, at the block
 * So every register is a target of every modulator, and nothing needs a matrix. A knob mapped later is one more
 * source of the same kind. */

enum { LM_FREE, LM_TRIG, LM_HOLD, LM_ONE, LM_HALF };

/* ------------------------------------------------------------------ the envelope -- */
/* 1 - e^-a, accurate for small a too (a long stage's one-pole: fx_fexp's 2e-4 error, amplified in 1 - e^-a, made
 * a 4 s decay 1.8 s): the series below 0.05 */
static float os_1mexp(float a)
{
    return a < 0.05f ? a * (1.0f - a * (0.5f - a * (1.0f / 6.0f - a * (1.0f / 24.0f)))) : 1.0f - fx_fexp(-a);
}

static void env_coef(env_c *c, uint32_t a, uint32_t d, uint32_t s, uint32_t r, uint32_t shrt)
{
    float cs = (float)CORE_SR;
    c->atk_inc = 1.0f / (env_time_s(a, shrt) * cs);
    c->dec_k = os_1mexp(5.0f / (env_time_s(d, shrt) * cs));
    c->rel_k = os_1mexp(5.0f / (env_time_s(r, shrt) * cs));
    c->sus = (float)s * (1.0f / 127.0f);
}

static inline float env_step(adsr_t *e, const env_c *c)
{
    switch (e->st) {
    case 1:
        e->v += c->atk_inc;
        if (e->v >= 1.0f) { e->v = 1.0f; e->st = 2; }
        break;
    case 2: e->v += (c->sus - e->v) * c->dec_k; break;
    case 3:
        e->v -= e->v * c->rel_k;
        if (e->v < 1e-4f) { e->v = 0.0f; e->st = 0; }
        break;
    case 4:                                       /* choke: ~1 ms, no click */
        e->v -= e->v * 0.11f;
        if (e->v < 1e-4f) { e->v = 0.0f; e->st = 0; }
        break;
    default: break;
    }
    return e->v;
}

static void adsr_gate(adsr_t *e) { e->st = 1; }
static void adsr_release(adsr_t *e) { if (e->st && e->st < 3) e->st = 3; }

/* ------------------------------------------------------------------ the LFO -- */
static void lfo_coef(lfo_c *c, uint32_t rt, uint32_t mul, uint32_t sh, uint32_t md, uint32_t ph, uint32_t bpb)
{
    float x;
    c->sync = mul >= LFO_SYNC;
    if (c->sync) x = 4294967296.0f * 6.0f / ((float)LFO_SYNC_N[lfo_sync_i(rt)] * (float)bpb);
    else x = lfo_hz(rt, mul) * (4294967296.0f / (float)CORE_SR);
    c->inc = (uint32_t)x;                        /* the step, and its fraction: a 64-bar cycle is exact too */
    c->incf = (uint32_t)((x - (float)c->inc) * 4294967296.0f);
    c->start = (uint32_t)ph << 25;               /* 0 .. 127 -> 0 .. 357 degrees */
    c->shape = (uint8_t)sh;
    c->mode = (uint8_t)md;
}

static inline float lfo_rnd(uint32_t r) { return (float)(r >> 16) * (2.0f / 65535.0f) - 1.0f; }

static inline float lfo_shape(const lfo_s *s, uint32_t ph, uint32_t shape)
{
    float p = (float)(ph >> 8) * (1.0f / 16777216.0f);
    switch (shape) {
    case 0: return fx_psin(p);
    case 1: return p < 0.5f ? 4.0f * p - 1.0f : 3.0f - 4.0f * p;
    case 2: return p < 0.5f ? 1.0f : -1.0f;
    case 3: return 1.0f - 2.0f * p;                                      /* SAW: down */
    case 4: return 2.0f * p - 1.0f;                                      /* RMP: up */
    case 5: return 2.0f * (fx_fexp(-5.0f * p) - 0.0067379f) * (1.0f / 0.9932621f) - 1.0f;   /* EXP: 1 -> -1 */
    case 6: return lfo_rnd(s->rnd);                                      /* S&H */
    default: {                                                           /* SMT: smooth random */
        float a = lfo_rnd(s->rnd0), b = lfo_rnd(s->rnd), u = p * p * (3.0f - 2.0f * p);
        return a + (b - a) * u;
    }
    }
}

static inline float lfo_step(lfo_s *s, const lfo_c *c)
{
    uint32_t p0 = s->ph;
    uint32_t f0 = s->phf;
    if (s->done) return c->mode == LM_HOLD ? s->held : s->x;
    s->phf += c->incf;
    s->ph += c->inc + (s->phf < f0);
    if (s->ph < p0) { s->rnd0 = s->rnd; s->rnd = s->rnd * 1664525u + 1013904223u; }   /* a new cycle */
    if (c->mode >= LM_ONE) {                                             /* one cycle (or half), then hold */
        uint32_t a0 = s->acc;
        s->acc += c->inc;
        if (c->mode == LM_ONE ? s->acc < a0 : s->acc >= 0x80000000u) {
            s->ph = c->mode == LM_ONE ? c->start : c->start + 0x80000000u;
            s->done = 1;
        }
    }
    s->x = lfo_shape(s, s->ph, c->shape);
    return c->mode == LM_HOLD ? s->held : s->x;
}

/* a note: the LFO restarts (TRIG, ONE, HALF), takes the free one's value (HOLD), or follows it (FREE).
 * master: the free LFO to follow (a voice's LFO1: the track's), or 0 (the track's own LFO2) */
static void lfo_trig(lfo_s *s, const lfo_c *c, const lfo_s *master)
{
    switch (c->mode) {
    case LM_FREE:
    case LM_HOLD:
        if (master) { s->ph = master->ph; s->rnd = master->rnd; s->rnd0 = master->rnd0; s->x = master->x; }
        s->held = s->x;
        s->done = 0;
        break;
    default:
        s->ph = c->start;
        s->acc = 0;
        s->done = 0;
        s->rnd0 = s->rnd;
        s->rnd = s->rnd * 1664525u + 1013904223u;
        s->x = lfo_shape(s, s->ph, c->shape);
        break;
    }
}

/* a synced FREE LFO is the song position: its phase, exactly (no 64-bit maths: (6 pos) mod P via pos mod P) */
static void lfo_lock(lfo_s *s, const lfo_c *c, uint32_t rt, uint32_t bpb, uint32_t pos)
{
    uint32_t P = (uint32_t)LFO_SYNC_N[lfo_sync_i(rt)] * bpb, r = pos % P;
    if (!c->sync || c->mode != LM_FREE || !os.playing) return;
    r = (6u * r) % P;
    s->ph = (uint32_t)((float)r / (float)P * 4294967296.0f);
}

/* ------------------------------------------------------------------ routes -- */
static uint32_t mach_pit_reg(uint32_t m) { return m == MA_TAPE ? TA_PIT : m == MA_MULTI ? MU_PIT : m == MA_GRAN ? GR_PIT : WA_PIT; }

static uint8_t mod_kind(const trk_t *t, uint32_t r, int voice)
{
    if (r >= NREG) return MK_NONE;
    if (r == mach_pit_reg(t->mach)) return MK_PIT;
    if ((t->mach == MA_MULTI && r == MU_TUN) || (t->mach == MA_WAVE && r == WA_TUN)) return MK_TUN;
    if (r == R_LEV) return MK_LEV;
    if (t->mach == MA_WAVE && r == WA_FRM) return MK_FRM;
    if (!voice) return r == R_CUT ? MK_CUT : MK_REG;
    if (r == R_PAN && t->mach != MA_TAPE) return MK_PAN;
    if (t->mach == MA_MULTI && r == MU_STR) return MK_STR;
    if (t->mach == MA_MULTI && r == MU_LEN) return MK_LEN;
    if (t->mach == MA_GRAN && r == GR_POS) return MK_POS;
    if (t->mach == MA_GRAN && r == GR_SIZ) return MK_SIZ;
    return MK_REG;                                                       /* (the newest voice drives it) */
}

/* the newest sounding voice's ENV1 and LFO1 (a voice source on a track-only register) */
static void mod_newest(uint32_t k, float *e1, float *l1)
{
    trk_t *t = &os.trk[k];
    const pv_t *b = 0;
    uint32_t i;
    *e1 = t->ve1.v; *l1 = t->vl1.x;
    if (t->mach != MA_MULTI && t->mach != MA_WAVE) return;
    for (i = 0; i < POLY_MAX; i++)
        if (pool[k][i].used && (!b || pool[k][i].age > b->age)) b = &pool[k][i];
    if (b) { *e1 = b->e1.v; *l1 = b->l1.mode_x; }
}

/* per block, before the resolver: coefficients, routes, the register targets' offsets */
static void mod_block(uint32_t k, uint32_t c)
{
    trk_t *t = &os.trk[k];
    const uint8_t *e = t->eff;
    static const uint8_t TGT[MS_N] = {R_ET1, R_ET2, R_LT1, R_LT2}, DEP[MS_N] = {R_ED1, R_ED2, R_LD1, R_LD2};
    uint32_t m;
    float ve1, vl1, val[MS_N];
    env_coef(&t->ec[0], e[R_ATK], e[R_DEC], e[R_SUS], e[R_REL], e[R_ARN]);
    env_coef(&t->ec[1], e[R_AT1], e[R_DE1], e[R_SU1], e[R_RE1], e[R_RG1]);
    env_coef(&t->ec[2], e[R_AT2], e[R_DE2], e[R_SU2], e[R_RE2], e[R_RG2]);
    lfo_coef(&t->lco[0], e[R_RT1], e[R_MU1], e[R_SH1], e[R_MD1], e[R_PH1], os.bpb);
    lfo_coef(&t->lco[1], e[R_RT2], e[R_MU2], e[R_SH2], e[R_MD2], e[R_PH2], os.bpb);
    lfo_lock(&t->l1m, &t->lco[0], e[R_RT1], os.bpb, seq_pos(c));
    lfo_lock(&t->l2, &t->lco[1], e[R_RT2], os.bpb, seq_pos(c));
    t->fen_d = e[R_FLT] ? ((float)e[R_FEN] - 64.0f) * 1.6f : 0.0f;
    mod_newest(k, &ve1, &vl1);
    val[MS_ENV1] = ve1; val[MS_LFO1] = vl1; val[MS_ENV2] = t->e2.v; val[MS_LFO2] = t->l2.mode_x;
    t->tfast = t->fen_d != 0.0f;
    t->vmod = 0;
    for (m = 0; m < MS_N; m++) {
        mroute_t *rt = &t->rt[m];
        int voice = m == MS_ENV1 || m == MS_LFO1;
        rt->r = e[TGT[m]];
        rt->dep = mod_depth(e[DEP[m]]);
        rt->kind = rt->dep != 0.0f ? mod_kind(t, rt->r, voice) : MK_NONE;
        t->roff[m] = rt->kind == MK_REG ? (int32_t)(val[m] * rt->dep + (val[m] * rt->dep < 0.0f ? -0.5f : 0.5f)) : 0;
        if (!voice && rt->kind > MK_REG) t->tfast = 1;
        if (voice && rt->kind != MK_NONE) t->vmod = 1;
    }
    /* an LFO2 on CUT at audio rate: only the plain bilinear map can follow it (os_flt.c) */
    t->ffast = t->rt[MS_LFO2].kind == MK_CUT && !t->lco[1].sync && lfo_hz(e[R_RT2], e[R_MU2]) >= 100.0f;
}

/* the track's modulation bus for n clock samples: ENV2, LFO2 and the free LFO1 run every sample; their
 * per-sample targets are summed (pitch in semitones, cutoff in register units, level as a gain, frame units) */
typedef struct { float pit[BLK], cut[BLK], lev[BLK], frm[BLK]; uint8_t pit_on, cut_on, lev_on, frm_on; } mbus_t;

static void mod_track_run(uint32_t k, uint32_t n, mbus_t *b)
{
    trk_t *t = &os.trk[k];
    const mroute_t *r2 = &t->rt[MS_ENV2], *rl = &t->rt[MS_LFO2];
    uint32_t i;
    b->pit_on = r2->kind == MK_PIT || r2->kind == MK_TUN || rl->kind == MK_PIT || rl->kind == MK_TUN;
    b->cut_on = t->fen_d != 0.0f || r2->kind == MK_CUT || rl->kind == MK_CUT;
    b->lev_on = r2->kind == MK_LEV || rl->kind == MK_LEV;
    b->frm_on = r2->kind == MK_FRM || rl->kind == MK_FRM;
    {   /* a source nothing uses does not run (it picks up where it was; a synced FREE LFO re-locks anyway) */
        int ne2 = t->fen_d != 0.0f || r2->kind != MK_NONE, nl2 = rl->kind != MK_NONE;
        int nl1 = t->rt[MS_LFO1].kind != MK_NONE && (t->lco[0].mode == LM_FREE || t->lco[0].mode == LM_HOLD);
        if (!ne2 && !nl2 && !nl1) return;
        if (!t->tfast) {                             /* (nothing per sample: the sources only advance) */
            for (i = 0; i < n; i++) {
                if (ne2) env_step(&t->e2, &t->ec[2]);
                if (nl2) t->l2.mode_x = lfo_step(&t->l2, &t->lco[1]);
                if (nl1) lfo_step(&t->l1m, &t->lco[0]);
            }
            return;
        }
    }
    for (i = 0; i < n; i++) {
        float ev = env_step(&t->e2, &t->ec[2]), lv = lfo_step(&t->l2, &t->lco[1]), p = 0.0f, c = t->fen_d * ev, l = 0.0f, f = 0.0f;
        lfo_step(&t->l1m, &t->lco[0]);
        t->l2.mode_x = lv;
        if (t->tfast) {
            float v[2] = {ev, lv};
            const mroute_t *rr[2] = {r2, rl};
            uint32_t j;
            for (j = 0; j < 2u; j++) {
                float a = v[j] * rr[j]->dep;
                switch (rr[j]->kind) {
                case MK_PIT: p += a; break;
                case MK_TUN: p += a * (1.0f / 64.0f); break;
                case MK_CUT: c += a; break;
                case MK_LEV: l += a; break;
                case MK_FRM: f += a; break;
                default: break;
                }
            }
        }
        b->pit[i] = p; b->cut[i] = c; b->frm[i] = f;
        t->frm_now = f;
        b->lev[i] = os_clampf(1.0f + l * (1.0f / 64.0f), 0.0f, 2.0f);
    }
}

/* a voice's sources for one clock sample: pitch (semitones), level (gain), pan (-1 .. 1), frame (units) */
typedef struct { float pit, lev, pan, frm; } vmod_t;

static inline void mod_voice(const trk_t *t, adsr_t *e1, lfo_s *l1, vmod_t *o)
{
    const mroute_t *ra = &t->rt[MS_ENV1], *rb = &t->rt[MS_LFO1];
    float ev = env_step(e1, &t->ec[1]), lv = lfo_step(l1, &t->lco[0]), v[2], l = 0.0f;
    const mroute_t *rr[2];
    uint32_t j;
    l1->mode_x = lv;
    v[0] = ev; v[1] = lv; rr[0] = ra; rr[1] = rb;
    o->pit = o->pan = o->frm = 0.0f;
    for (j = 0; j < 2u; j++) {
        float a = v[j] * rr[j]->dep;
        switch (rr[j]->kind) {
        case MK_PIT: o->pit += a; break;
        case MK_TUN: o->pit += a * (1.0f / 64.0f); break;
        case MK_LEV: l += a; break;
        case MK_PAN: o->pan += a * (1.0f / 64.0f); break;
        case MK_FRM: o->frm += a; break;
        default: break;
        }
    }
    o->lev = os_clampf(1.0f + l * (1.0f / 64.0f), 0.0f, 2.0f);
}

/* a voice source's value on a target read when a voice (MULTI) or a grain (GRAN) starts: register units */
static float mod_at_start(const trk_t *t, uint32_t kind, float e1, float l1)
{
    float a = 0.0f;
    if (t->rt[MS_ENV1].kind == kind) a += e1 * t->rt[MS_ENV1].dep;
    if (t->rt[MS_LFO1].kind == kind) a += l1 * t->rt[MS_LFO1].dep;
    return a;
}

/* a note on track k (voice states e1 / l1: a poly voice's, or the mono track's own) */
static void mod_note_on(uint32_t k, adsr_t *e1, lfo_s *l1, int new_voice)
{
    trk_t *t = &os.trk[k];
    if (new_voice) { e1->v = 0.0f; }
    e1->st = 1;
    lfo_trig(l1, &t->lco[0], &t->l1m);
    l1->mode_x = t->lco[0].mode == LM_HOLD ? l1->held : l1->x;
    adsr_gate(&t->e2);                               /* ENV2: from where it is (no click) */
    if (t->lco[1].mode != LM_FREE) lfo_trig(&t->l2, &t->lco[1], 0);
}
