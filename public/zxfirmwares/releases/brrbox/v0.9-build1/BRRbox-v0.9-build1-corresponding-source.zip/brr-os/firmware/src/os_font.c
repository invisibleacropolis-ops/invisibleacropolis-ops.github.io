/* SPDX-License-Identifier: GPL-3.0-only */
/* Text on the 240x240 panel: the 5x7 font (os_font_data.h) at scale 1 or 2, drawn into one
 * strip buffer in RAM and sent with lcd_blit. Kept small on purpose: no anti-aliasing, no
 * proportional spacing, upper case only. */
#include "os_font_data.h"

#define TXT_MAXW 240u
#define TXT_MAXH 16u
static uint16_t txt_strip[TXT_MAXW * TXT_MAXH] __attribute__((section(".pool")));

static uint16_t os_rgb(uint32_t r, uint32_t g, uint32_t b)
{
    /* RGB565, sent high byte first by lcd.c */
    return (uint16_t)(((r & 0xF8u) << 8) | ((g & 0xFCu) << 3) | (b >> 3));
}

static uint32_t text_width(const char *s, uint32_t scale)
{
    uint32_t n = 0;
    while (s[n])
        n++;
    return n ? n * 6u * scale - scale : 0u;
}

/* draw s at (x, y), clipped to width w, background bg; h = 8 * scale rows */
static void draw_text(uint32_t x, uint32_t y, uint32_t w, const char *s, uint32_t scale, uint16_t fg, uint16_t bg)
{
    uint32_t h = 8u * scale, i, cx = 0;
    if (w > TXT_MAXW)
        w = TXT_MAXW;
    if (h > TXT_MAXH || w == 0u)
        return;
    fg = (uint16_t)((fg >> 8) | (fg << 8));        /* lcd_blit sends bytes as stored: high byte first */
    bg = (uint16_t)((bg >> 8) | (bg << 8));
    lcd_sync();                                   /* the last strip may still be going out by DMA */
    for (i = 0; i < w * h; i++)
        txt_strip[i] = bg;
    for (; *s && cx + 5u * scale <= w; s++, cx += 6u * scale) {
        uint32_t c = (uint8_t)*s, col, row, sx, sy;
        if (c >= 'a' && c <= 'z')
            c -= 32u;
        if (c < 32u || c > 95u)
            c = '?';
        for (col = 0; col < 5u; col++) {
            uint32_t bits = OS_FONT[c - 32u][col];
            for (row = 0; row < 7u; row++) {
                if (!(bits >> row & 1u))
                    continue;
                for (sy = 0; sy < scale; sy++)
                    for (sx = 0; sx < scale; sx++)
                        txt_strip[(row * scale + sy) * w + cx + col * scale + sx] = fg;
            }
        }
    }
    lcd_blit(x, y, w, h, txt_strip);
}

/* ota_hw.c's progress screen (os_core.h maps AF_M / AF_S / T_* here) */
static void draw_text_box(uint32_t x, uint32_t y, uint32_t w, const os_font_t *f, const char *s,
                          uint16_t color, int center)
{
    uint32_t sc = f->scale, tw = text_width(s, sc);
    uint32_t x0 = center && tw < w ? x + (w - tw) / 2u : x;
    lcd_fill(x, y, w, 8u * sc, T_BG);
    draw_text(x0, y, tw < w ? tw : w, s, sc, color, T_BG);
}

/* small number formatting without printf */
static char *os_fmt_int(char *p, int32_t v, uint32_t width, int sign)
{
    char tmp[12];
    uint32_t n = 0, u = (uint32_t)(v < 0 ? -v : v);
    do {
        tmp[n++] = (char)('0' + u % 10u);
        u /= 10u;
    } while (u && n < sizeof tmp);
    if (sign || v < 0)
        tmp[n++] = v < 0 ? '-' : '+';
    while (n < width)
        tmp[n++] = ' ';
    while (n)
        *p++ = tmp[--n];
    *p = 0;
    return p;
}

static char *os_fmt_str(char *p, const char *s)
{
    while (*s)
        *p++ = *s++;
    *p = 0;
    return p;
}
