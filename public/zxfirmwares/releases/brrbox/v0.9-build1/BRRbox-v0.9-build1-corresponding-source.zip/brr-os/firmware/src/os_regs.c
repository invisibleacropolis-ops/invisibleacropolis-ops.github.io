/* SPDX-License-Identifier: GPL-3.0-only */
/* The register file: the whole sound of BRR-OS is 4 tracks x 88 one-byte registers (the SID idea).
 * Knobs, faders, parameter locks, tables, the LFO, scenes and MIDI all just write bytes; the resolver folds
 * them into eff[] at every codec block (16 core samples, 2 ms) and at once when an event writes one.
 * One clock: the 8 kHz core sample (0.125 ms) is the atom of time; every unit is a power of two of it
 * (block 16, side frame 128, keyframe 512) and the whole engine runs at that rate (WAVE at 4x).
 *   page A  the machine's own 8 (os_mach.c)
 *   page B  CUT RES TYP FEN ATK DEC SUS REL       the strip: SVF + filter envelope, per-voice ADSR
 *   page C  LFR LFD LFT LFS TBL TSP STP SPD       LFO (any register), table, track length and speed
 *   page D  LEV PAN SND DRV FEL WIN VFL GRV       mix, then the feel of live-recorded notes
 *   page E  WID AIR TLT TON SPR CMP LOC ---       the track's stereo submix: its highs' width, amount, tilt and
 *                                                 tonality (os_hf.c), voice spread, compressor, low cut
 *   page F  TIM FBK DEP RAT DIS COL PNG MIX       the track's multi-effect: phaser / flanger / chorus / delay
 *                                                 by where the knobs sit (os_tfx.c)
 *   page G  SIZ DCY DMP PRE MOD DIF GAT REV       the track's reverb (os_tfx.c)
 *   (v0.7) the modulators (os_mod.c): the AMP envelope's range; ENV1 (voice) and ENV2 (track): ADSR, range,
 *   target, depth (ENV2 also mirrored to the filter, FLT x FEN); LFO1 (voice) and LFO2 (track): rate, multiplier
 *   (or SYNC), shape, mode, start phase, target, depth. LFO2 is the old LFO, grown.
 * Register numbers are the engine's; which register a knob shows is a table (PAGES, os_ui.c), so pages can be
 * rearranged, and later mapped by the user, without touching the engine.
 * Every register is 0..127 (list registers: an index), bipolar ones centred on 64. */
#include "os_library.h"                       /* generated: OS_LIB[], names, scene, onset maps */

#define NTRACK 4u
#define NREG 96u                              /* (91..95: spare; the scene masks hold 96) */
#define R_NONE NREG                           /* a modulator's target: none */
#define POLY_MAX 8u                           /* voice slots a track owns (its VOI limit: 1 .. 8) */
#ifndef VOICES
#define VOICES 8u                             /* voices sounding at once, all tracks (a mono track is one) */
#endif
#define NPAT 8u
#define EV_HEAP 10240u                        /* events of the kit: all 40 lists share them (80 KB) */
#define NTBL 8u
#define SONG_N 64u                            /* song rows: a pattern and its repeats */
#define PAT_BARS 8u                           /* a pattern is 1 .. 8 bars */
#define TBL_ROWS 16u
#define CORE_SR 8000u                         /* the clock: one core sample = 0.125 ms */
#define BLK SV_BLK                            /* the codec block = the control block: 16 samples, 2 ms */
#define BLK_SHIFT SV_BLK_SHIFT
#define SIDE_SHIFT SV_SIDE_SHIFT              /* a side frame: 128 samples, 16 ms */
#define WIDE 4u                               /* WAVE renders 4 samples per core sample (32 kHz) */
#define UPS_STEP (68.0f / 375.0f)             /* core samples per DAC frame (24 MHz / 544): exact */
#define MAXCORE 64u                           /* core samples one half can need (WARP up to 2x) */
#define DUE_MAX 24u

enum { MA_TAPE, MA_MULTI, MA_GRAN, MA_WAVE, MA_N };
enum { RF_NUM, RF_BIP, RF_SMP, RF_LIST, RF_SEMI, RF_PCT, RF_REG, RF_TIME, RF_OFFN, RF_PLUS1, RF_HZ, RF_SAMP, RF_LFOHZ,
       RF_FXT, RF_RATE, RF_DIS, RF_RT, RF_MS, RF_GATE, RF_ETIME, RF_LRATE, RF_DEPTH, RF_VOI, RF_SHA, RF_SHB, RF_SDB, RF_STN };

enum {
    R_CUT = 8, R_RES, R_TYP, R_FEN, R_ATK, R_DEC, R_SUS, R_REL,
    R_LFR = 16, R_LFD, R_LFT, R_LFS, R_TBL, R_TSP, R_STP, R_SPD,
    R_LEV = 24, R_PAN, R_SND, R_DRV, R_FEL, R_WIN, R_VFL, R_GRV,
    R_WID = 32, R_AIR, R_TLT, R_TON, R_SPR, R_CMP, R_LOC, R_E8,
    R_TIM = 40, R_FBK, R_DEP, R_RAT, R_DIS, R_COL, R_PNG, R_MIX,
    R_SIZ = 48, R_DCY, R_DMP, R_PRE, R_RMD, R_DIF, R_GAT, R_REV,
    R_ARN = 56,                                            /* the AMP envelope's range (its ADSR: R_ATK..R_REL) */
    R_AT1 = 57, R_DE1, R_SU1, R_RE1, R_RG1, R_ET1, R_ED1, /* ENV1 (voice) */
    R_AT2 = 64, R_DE2, R_SU2, R_RE2, R_RG2, R_ET2, R_ED2, R_FLT,   /* ENV2 (track) */
    R_RT1 = 72, R_MU1, R_SH1, R_MD1, R_PH1, R_LT1, R_LD1, /* LFO1 (voice) */
    R_MU2 = 79, R_MD2, R_PH2,                              /* LFO2 (track): with R_LFR R_LFS R_LFT R_LFD */
    R_VOI = 82,                                            /* the track's voice limit (poly machines) */
    R_SMD = 83, R_SIN, R_SA, R_SB, R_SBI, R_STN, R_SPS, R_SMX  /* the shaper (os_shp.c): model, input, A, B, bias, tone, PRE/POST, wet */
};
#define R_RT2 R_LFR
#define R_SH2 R_LFS
#define R_LT2 R_LFT
#define R_LD2 R_LFD

typedef struct {
    char lab[4];
    uint8_t fmt, def, max;                    /* max: highest value (lists: count - 1); 0 = sample count */
    const char *list;                         /* RF_LIST: 4 characters per item */
} reg_def;

typedef struct {
    char name[6];
    uint8_t poly;                             /* 1 = mono; else its default voice limit (VOI) */
    reg_def p[8];
} mach_def;

/* page A per machine: 0..7 */
enum { TA_SMP, TA_STR, TA_LEN, TA_PIT, TA_DIR, TA_SLC, TA_GAT, TA_SYN };
enum { MU_SMP, MU_MAP, MU_PIT, MU_TUN, MU_STR, MU_LEN, MU_RVS, MU_LOP };
enum { GR_SMP, GR_POS, GR_SCN, GR_SIZ, GR_DEN, GR_PIT, GR_SPR, GR_JIT };
enum { WA_SMP, WA_FRM, WA_CYC, WA_SCN, WA_DET, WA_PIT, WA_TUN, WA_GLD };

static const char LST_BEATS[] = "1   2   4   8   16  32  ";
static const char LST_DIR[] = "FWD REV ";
static const char LST_GATE[] = "OPENGATE";
static const char LST_SYNC[] = "FREESYNC";
static const char LST_MAP[] = "CHR KIT ";
static const char LST_LOOP[] = "ONE LOOP";
static const char LST_CYC[] = "64  128 256 512 ";
static const char LST_TYP[] = "OFF LP  BP  HP  ";
static const char LST_SPD[] = "1/8 1/4 1/2 1X  2X  4X  ";
static const char LST_GRV[] = "OFF S54 S58 S62 S66 LRN TK1 TK2 TK3 TK4 ";
static const char LST_PNG[] = "ST  PING";
static const char LST_RNG[] = "LONGSHRT";
static const char LST_ONOFF[] = "OFF ON  ";
static const char LST_MUL[] = "1/641/161/4 1X  4X  16X 64X 256XSYNC";
static const char LST_LSH[] = "SIN TRI SQR SAW RMP EXP S&H SMT ";
static const char LST_LMD[] = "FREETRIGHOLDONE HALF";
static const char LST_SHP[] = "TAPETUBECLIPFOLDCHEBXOVRRECTBITSPOLY";
static const char LST_POS[] = "PRE POST";

static const mach_def MACH[MA_N] = {
    {"TAPE", 1, {{"SMP", RF_SMP, 0, 0, 0}, {"STR", RF_NUM, 0, 127, 0}, {"LEN", RF_LIST, 4, 5, LST_BEATS},
                 {"PIT", RF_SEMI, 64, 127, 0}, {"DIR", RF_LIST, 0, 1, LST_DIR}, {"SLC", RF_OFFN, 0, 127, 0},
                 {"GAT", RF_LIST, 0, 1, LST_GATE}, {"SYN", RF_LIST, 1, 1, LST_SYNC}}},
    {"MULTI", 6, {{"SMP", RF_SMP, 8, 0, 0}, {"MAP", RF_LIST, 1, 1, LST_MAP}, {"PIT", RF_SEMI, 64, 127, 0},
                  {"TUN", RF_BIP, 64, 127, 0}, {"STR", RF_NUM, 0, 127, 0}, {"LEN", RF_OFFN, 0, 127, 0},
                  {"RVS", RF_LIST, 0, 1, LST_DIR}, {"LOP", RF_LIST, 0, 1, LST_LOOP}}},
    {"GRAN", 1, {{"SMP", RF_SMP, 1, 0, 0}, {"POS", RF_NUM, 40, 127, 0}, {"SCN", RF_BIP, 72, 127, 0},
                 {"SIZ", RF_NUM, 60, 127, 0}, {"DEN", RF_NUM, 70, 127, 0}, {"PIT", RF_SEMI, 64, 127, 0},
                 {"SPR", RF_NUM, 30, 127, 0}, {"JIT", RF_NUM, 0, 127, 0}}},
    {"WAVE", 4, {{"SMP", RF_SMP, 16, 0, 0}, {"FRM", RF_NUM, 0, 127, 0}, {"CYC", RF_LIST, 2, 3, LST_CYC},
                 {"SCN", RF_BIP, 64, 127, 0}, {"DET", RF_NUM, 0, 127, 0}, {"PIT", RF_SEMI, 64, 127, 0},
                 {"TUN", RF_BIP, 64, 127, 0}, {"GLD", RF_NUM, 0, 127, 0}}},
};

static const reg_def COMMON[NREG - 8u] = {
    {"CUT", RF_HZ, 127, 127, 0}, {"RES", RF_NUM, 0, 127, 0}, {"TYP", RF_LIST, 0, 3, LST_TYP},
    {"FEN", RF_BIP, 64, 127, 0}, {"ATK", RF_ETIME, 0, 127, 0}, {"DEC", RF_ETIME, 70, 127, 0},
    {"SUS", RF_NUM, 127, 127, 0}, {"REL", RF_ETIME, 40, 127, 0},
    {"RT2", RF_LRATE, 64, 127, 0}, {"LD2", RF_DEPTH, 64, 127, 0}, {"LT2", RF_REG, R_NONE, R_NONE, 0},
    {"SH2", RF_LIST, 0, 7, LST_LSH}, {"TBL", RF_OFFN, 0, NTBL, 0}, {"TSP", RF_SAMP, 112, 127, 0},
    {"STP", RF_PLUS1, 15, 127, 0}, {"SPD", RF_LIST, 3, 5, LST_SPD},
    {"LEV", RF_NUM, 100, 127, 0}, {"PAN", RF_BIP, 64, 127, 0}, {"---", RF_NUM, 0, 0, 0},
    {"DRV", RF_NUM, 0, 127, 0}, {"FEL", RF_PCT, 101, 127, 0}, {"WIN", RF_NUM, 127, 127, 0},
    {"VFL", RF_NUM, 127, 127, 0}, {"GRV", RF_LIST, 0, 9, LST_GRV},
    {"WID", RF_NUM, 64, 127, 0}, {"AIR", RF_NUM, 64, 127, 0}, {"TLT", RF_BIP, 64, 127, 0},
    {"TON", RF_BIP, 64, 127, 0}, {"SPR", RF_NUM, 0, 127, 0}, {"CMP", RF_NUM, 0, 127, 0},
    {"LOC", RF_HZ, 0, 127, 0}, {"---", RF_NUM, 0, 0, 0},
    {"TIM", RF_FXT, 40, 127, 0}, {"FBK", RF_BIP, 64, 127, 0}, {"DEP", RF_NUM, 40, 127, 0},
    {"RAT", RF_RATE, 40, 127, 0}, {"DIS", RF_DIS, 0, 127, 0}, {"COL", RF_BIP, 64, 127, 0},
    {"PNG", RF_LIST, 0, 1, LST_PNG}, {"MIX", RF_NUM, 0, 127, 0},
    {"SIZ", RF_NUM, 80, 127, 0}, {"DCY", RF_RT, 60, 127, 0}, {"DMP", RF_NUM, 50, 127, 0},
    {"PRE", RF_MS, 0, 127, 0}, {"MOD", RF_NUM, 30, 127, 0}, {"DIF", RF_NUM, 90, 127, 0},
    {"GAT", RF_GATE, 0, 64, 0}, {"REV", RF_NUM, 0, 127, 0},
    {"RNG", RF_LIST, 0, 1, LST_RNG},
    {"AT1", RF_ETIME, 0, 127, 0}, {"DE1", RF_ETIME, 60, 127, 0}, {"SU1", RF_NUM, 0, 127, 0},
    {"RE1", RF_ETIME, 40, 127, 0}, {"RG1", RF_LIST, 1, 1, LST_RNG}, {"ET1", RF_REG, R_NONE, R_NONE, 0},
    {"ED1", RF_DEPTH, 64, 127, 0},
    {"AT2", RF_ETIME, 0, 127, 0}, {"DE2", RF_ETIME, 70, 127, 0}, {"SU2", RF_NUM, 0, 127, 0},
    {"RE2", RF_ETIME, 40, 127, 0}, {"RG2", RF_LIST, 0, 1, LST_RNG}, {"ET2", RF_REG, R_NONE, R_NONE, 0},
    {"ED2", RF_DEPTH, 64, 127, 0}, {"FLT", RF_LIST, 1, 1, LST_ONOFF},
    {"RT1", RF_LRATE, 64, 127, 0}, {"MU1", RF_LIST, 3, 8, LST_MUL}, {"SH1", RF_LIST, 0, 7, LST_LSH},
    {"MD1", RF_LIST, 1, 4, LST_LMD}, {"PH1", RF_NUM, 0, 127, 0}, {"LT1", RF_REG, R_NONE, R_NONE, 0},
    {"LD1", RF_DEPTH, 64, 127, 0},
    {"MU2", RF_LIST, 3, 8, LST_MUL}, {"MD2", RF_LIST, 0, 4, LST_LMD}, {"PH2", RF_NUM, 0, 127, 0},
    {"VOI", RF_VOI, 3, 7, 0},
    {"MOD", RF_LIST, 0, 8, LST_SHP}, {"INP", RF_SDB, 42, 127, 0}, {"A  ", RF_SHA, 64, 127, 0},
    {"B  ", RF_SHB, 0, 127, 0}, {"BIA", RF_BIP, 64, 127, 0}, {"LPF", RF_STN, 127, 127, 0},
    {"POS", RF_LIST, 0, 1, LST_POS}, {"WET", RF_NUM, 0, 127, 0},
    {"---", RF_NUM, 0, 0, 0}, {"---", RF_NUM, 0, 0, 0}, {"---", RF_NUM, 0, 0, 0},
    {"---", RF_NUM, 0, 0, 0}, {"---", RF_NUM, 0, 0, 0},
};

/* the shaper's A and B: a name per model (os_shp.c) */
static const char SHP_AB[9][2][4] = {
    {"KNE", "DRK"}, {"ASY", "SAG"}, {"KNE", "SPL"}, {"SHP", "FLD"}, {"HRM", "FND"},
    {"GAP", "SFT"}, {"FUL", "---"}, {"BIT", "RAT"}, {"EVN", "ODD"}};

static const reg_def *reg_info(uint32_t mach, uint32_t r)
{
    return r < 8u ? &MACH[mach].p[r] : &COMMON[r - 8u];
}

/* a register's three-letter name on a track (the shaper's A and B are named by its model) */
static const char *reg_label(const uint8_t *eff, uint32_t mach, uint32_t r)
{
    if (r == R_SA || r == R_SB) return SHP_AB[eff[R_SMD] < 9u ? eff[R_SMD] : 0u][r - R_SA];
    return reg_info(mach, r)->lab;
}

static uint32_t reg_max(uint32_t mach, uint32_t r)
{
    const reg_def *d = reg_info(mach, r);
    return d->fmt == RF_SMP ? (uint32_t)OS_LIB_COUNT - 1u : d->max;
}

/* ------------------------------------------------------------ state --- */
typedef struct { float v; uint8_t st; } adsr_t;      /* st: 0 idle, 1 attack, 2 decay/sustain, 3 release */

/* the modulators (os_mod.c): one envelope and one LFO, each a coefficient set (from registers, per block) and a
 * state (per voice or per track), so AMP, ENV1, ENV2, LFO1 and LFO2 are the same code */
typedef struct { float atk_inc, dec_k, sus, rel_k; } env_c;
typedef struct { uint32_t inc, incf, start; uint8_t shape, mode, sync; } lfo_c;   /* incf: the step's fraction */
typedef struct { uint32_t ph, phf, acc, rnd, rnd0; float x, held, mode_x; uint8_t done; } lfo_s;   /* mode_x: its output */
enum { MS_ENV1, MS_ENV2, MS_LFO1, MS_LFO2, MS_N };                  /* the sources */
/* what a target is to a source: a register at the block (MK_REG), or one of the paths that act every sample
 * (track: pitch, tune, cutoff, level, frame; voice: also pan, frame morph, and at the voice's start: sample
 * start, length, grain position, grain size) */
enum { MK_NONE, MK_REG, MK_PIT, MK_TUN, MK_CUT, MK_LEV, MK_PAN, MK_FRM, MK_STR, MK_LEN, MK_POS, MK_SIZ };
typedef struct { uint8_t r, kind; float dep; } mroute_t;          /* target register, its path, depth (units) */

typedef struct {
    sv_reader rd;
    int32_t cb;                    /* first block in win[] (-1 = empty) */
    int16_t win[2u * SV_BLK];      /* blocks cb and cb + 1 */
    int32_t ip;                    /* read position: integer core sample + fraction */
    float fr, rate;                /* rate: core samples per core sample (signed) */
    uint32_t ls, le;               /* region; loops when !oneshot */
    uint8_t active, oneshot, aa_on;
    /* pitched up: the source runs through two one-poles at 3.2 kHz / rate before the interpolation */
    int32_t aa_at;                 /* the last source sample fed (in the read direction) */
    float aa_k, aa1, aa2, aa_h[4];
} os_voice_t;

typedef struct {
    os_voice_t v;
    adsr_t env;                    /* AMP */
    adsr_t e1;                     /* ENV1 */
    lfo_s l1;                      /* LFO1 */
    uint8_t used, note, vel, live, si;
    uint32_t age, off_at;          /* off_at: the clock sample it releases at (0xFFFFFFFF: held) */
    uint32_t on_at;                /* the clock sample it started (the shared budget takes the oldest) */
    float amp, semis;
    float ph, ph2, inc, inc_to;    /* WAVE: phases in the frame, at the wide rate */
    /* the air (os_hf.c): this voice's 2-4 kHz energy this block, and its side frame's slot targets */
    float hz1, hz2, e_hf, hR[6], hw, h_rate;
    int32_t h_fr;
} pv_t;

typedef struct {
    uint8_t mach, mute;
    uint8_t base[NREG], eff[NREG], lock[NREG], tlk[NREG];
    int16_t lock_step;             /* step whose locks are active (-1 none) */
    /* the modulators (os_mod.c) */
    env_c ec[3];                   /* AMP, ENV1, ENV2 */
    lfo_c lco[2];                  /* LFO1, LFO2 */
    lfo_s l2, l1m;                 /* LFO2; LFO1's free-running master (FREE and HOLD voices follow it) */
    adsr_t e2;                     /* ENV2 */
    adsr_t ve1;                    /* a mono machine's (TAPE, GRAN) one voice: its ENV1, LFO1 */
    lfo_s vl1;
    mroute_t rt[MS_N];             /* each source's target */
    int32_t roff[MS_N];            /* a source's offset on a register target, at the block (register units) */
    float fen_d;                   /* ENV2 mirrored to the cutoff: FLT x FEN (register units) */
    float shw;                     /* the shaper POST: the share of the track it made (the air leaves it unfiltered) */
    float frm_now;                 /* the bus's frame offset, last sample (the WAVE frame pair, at the block) */
    uint8_t tfast;                 /* a track source aims at a per-sample path (the bus runs) */
    uint8_t vmod;                  /* a voice source is live (voices run their ENV1 / LFO1) */
    /* table player: rows every TSP-mapped samples */
    uint8_t tb_on, tb_idx, tb_row;
    uint16_t tb_cnt;
    int8_t tb_note;
    /* sequencer */
    uint32_t anchor, loops, lp_at; /* loops: passes since its pattern came in (trig conditions); lp_at: the pass index seen */
    int16_t cur_step, hop_to;
    uint16_t rt_iv, rt_cnt, cut_cnt;
    uint32_t rt_at, tb_at, cut_at;  /* the clock samples the retrig, the next table row and the cut are due */
    uint8_t due_dirty;              /* the list changed: rebuild this step's due list now */
    uint8_t rt_n, rt_drop, rt_note[6], rt_vel[6];
    uint8_t last_note, last_vel;   /* what a tapped step places */
    struct { uint32_t at; uint16_t ei; } due[DUE_MAX];   /* this step's events, by clock sample */
    uint8_t due_n, due_i;
    uint32_t due_end;              /* the clock sample the due list runs to */
    uint32_t rng;
    /* grooves (Q12 step fractions per 16th slot) */
    int16_t lrn[16];
    uint8_t lrn_n[16];
    int16_t agr[16];
    uint32_t agr_sig;
    /* strip */
    float cut_v, kq, drv;
    uint8_t typ;
    float gl, gr, gs, gl_t, gr_t, gs_t;    /* gains now and their block targets (slewed per sample) */
    /* mono machines (TAPE, GRAN): one envelope, the held note */
    adsr_t env;
    uint8_t held, mono_note;
    float lead_pos;                /* where the track reads (side info for the HF rebuild) */
    float lead_rate;               /* at what rate (the side info's bands move with it) */
    uint8_t lead_si;
    /* the submix (page E): the side path of a spread track, low cut, compressor */
    flt_s fst[2];                  /* the strip's filter: mid, side (os_flt.c) */
    flt_c fcur, fdel;              /* its coefficients now, and their glide per clock sample to the next design */
    uint8_t fcnt, fok;             /* clock samples to the next design; 0 = start afresh */
    float fhz[BLK];                /* the cutoff (Hz) at each clock sample of the segment: the air's filter follows */
    float fhz_last;                /* the last cutoff used (the air's un-filter reads it at the block) */
    uint8_t ffast;                 /* an LFO on CUT at 100 Hz or more: the bilinear map, every sample (os_flt.c) */
    float dv[2];                   /* the drive's anti-aliasing: last input, L and R (or mid) */
    bq_t fhp[2][5];                /* the copy band before and after the filter (the air's un-filter measures it) */
    float fe_pre, fe_post;
    float lc[2][2], lc_g, lc_k;    /* low cut: TPT high-pass state (mid, side), coefficients */
    float cmp_env, cmp_g, cmp_step;
    uint8_t ms;                    /* the track renders a side (SPR > 0 on a voiced machine) */
    uint32_t voice_age, cost;      /* cost: last half's render time (the dual-core split) */
} trk_t;

static pv_t pool[NTRACK][POLY_MAX] __attribute__((section(".pool")));

static struct {
    sv_lib lib;
    trk_t trk[NTRACK];
    uint8_t sel;
    uint8_t playing, rec, fill;
    uint16_t bpb;                  /* codec blocks (16 samples) per beat: BPM = 30000 / bpb */
    uint32_t clock;                /* core samples rendered since boot: the one clock */
    uint32_t play_c0;              /* the clock sample the transport started at */
    float warp;                    /* pitch wheel: the whole core domain plays faster or slower */
    float up_phase;                /* the upsampler's fraction */
    uint8_t pat, pat_next;
    uint32_t pat_p0;               /* the transport position the playing pattern started at */
    uint8_t song_on, song_row, song_rep;  /* the song: on, its row, the repeats of that row done */
    uint8_t morph;                 /* mod wheel 0..127 (the UI: the amount of the last scene touched) */
    uint8_t master;
    float master_g;
    uint8_t fx_on, hf;             /* fx_on: every track's effects in (SHIFT + FX); hf: the air's global amount */
    uint8_t m_glu, m_air, m_wid, m_cel;   /* the master bus (os_hf.c): glue, air, width, limiter ceiling (0.1 dB) */
    uint8_t cpu2;                  /* the second core takes tracks (1) or not; it drops to 0 by itself */
    uint8_t c1_mask;               /* the tracks it rendered last */
    uint8_t voices;                /* voices sounding at the start of this half (the shared budget) */
    uint32_t cpu_q8;
} os;

/* the kit's 8 scenes: per track, which registers each one sets (96 bits: NREG <= 96) and to what */
#define NSCN 8u
static struct { uint32_t mask[NTRACK][3]; uint8_t v[NTRACK][NREG]; } scn[NSCN];
/* the scenes in: in the order they came in (the newest last: on top), each at its amount 1..127 (0 = out) */
static struct { uint8_t n, ord[NSCN], amt[NSCN]; } scs;
#define SCN_HAS(s, k, r) ((scn[s].mask[k][(r) >> 5] >> ((r) & 31u)) & 1u)
#define SCN_SET(s, k, r) (scn[s].mask[k][(r) >> 5] |= 1u << ((r) & 31u))
static int scn_any(uint32_t s)
{
    uint32_t k, i;
    for (k = 0; k < NTRACK; k++) for (i = 0; i < 3u; i++) if (scn[s].mask[k][i]) return 1;
    return 0;
}

/* --------------------------------------------------------- helpers --- */
/* 2^(x/12) for fractional semitones (fx_fexp: no libm) */
static inline float os_semis(float x) { return fx_fexp(x * 0.05776227f); }

static uint32_t os_rng(uint32_t *s) { *s = *s * 1664525u + 1013904223u; return *s >> 8; }

static float os_frand(uint32_t *s) { return (float)os_rng(s) * (1.0f / 16777216.0f); }   /* 0..1 */

/* register time curve: 1 ms .. ~6.6 s, 2^(v/10) */
static float reg_time_s(uint32_t v) { return 0.001f * fx_fexp((float)v * 0.0693147f); }

/* FEEL: 2v - 102 percent, held to -100 .. +150 (51 = the grid, 101 = as played) */
static int32_t reg_feel_pct(uint32_t v) { return os_clampi(2 * (int32_t)v - 102, -100, 150); }

static float reg_cut_hz(float v) { return 20.0f * fx_fexp(v * (10.0f / 127.0f) * 0.6931472f); }

/* TIM (page F), in clock samples: 0 none (the phaser); 1..56 free, 3 .. 320 (0.4 .. 40 ms); 57..120 n/64 of a
 * bar, n = 1..64 (n x bpb: whole clock samples at every tempo); 121..127 triplets, 1/64T .. 1/1T */
static float reg_fx_time(uint32_t v, uint32_t bpb)
{
    if (!v) return 0.0f;
    if (v <= 56u) return 3.0f * fx_fexp((float)(v - 1u) * (6.7370f / 55.0f) * 0.69314718f);
    if (v <= 120u) return (float)((v - 56u) * bpb);
    return (float)((2u << (v - 121u)) * bpb) * (1.0f / 3.0f);
}

/* RAT (page F): the LFO's period in clock samples. 0..103 free, 0.02 .. 22 Hz; 104..127 synced: 1/64 note .. 64
 * bars (in bpb units: n/64 of a bar) */
#define RAT_SYNC 104u
static const uint16_t RAT_N[24] = {1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768,
                                   1024, 1536, 2048, 3072, 4096};
static float reg_fx_hz(uint32_t v) { return 0.02f * fx_fexp((float)v * (0.6931472f / 10.2f)); }
static float reg_fx_period(uint32_t v, uint32_t bpb)
{
    return v < RAT_SYNC ? (float)CORE_SR / reg_fx_hz(v) : (float)RAT_N[v - RAT_SYNC] * (float)bpb;
}

/* DIS (page F): the allpass chain's centre, 0 = off, 80 Hz .. 3.6 kHz */
static float reg_fx_dis_hz(uint32_t v) { return 80.0f * fx_fexp((float)(v ? v - 1u : 0u) * (5.49f / 126.0f) * 0.6931472f); }

/* n/64 of a bar as text: 1/4, 3/16, 1B, 2B ... */
static char *reg_bar_text(char *q, uint32_t n)
{
    uint32_t a = n, b = 64u;
    if (n % 64u == 0u) { q = os_fmt_int(q, (int32_t)(n / 64u), 1, 0); *q++ = 'B'; *q = 0; return q; }
    while ((a & 1u) == 0u && (b & 1u) == 0u) { a >>= 1; b >>= 1; }
    q = os_fmt_int(q, (int32_t)a, 1, 0);
    *q++ = '/';
    return os_fmt_int(q, (int32_t)b, 1, 0);
}

/* ------------------------------------------------------------ scenes / resolve --- */
static void trk_defaults(trk_t *t, uint32_t mach, uint32_t k)
{
    uint32_t r;
    t->mach = (uint8_t)mach;
    for (r = 0; r < NREG; r++)
        t->base[r] = reg_info(mach, r)->def;
    if (mach == MA_TAPE && k < 4u)
        t->base[TA_SMP] = OS_SCENE[k].si;
    if (t->base[0] >= OS_LIB_COUNT)
        t->base[0] = (uint8_t)(OS_LIB_COUNT - 1u);
    t->base[R_PAN] = (uint8_t)(k == 0 ? 50 : k == 1 ? 78 : k == 2 ? 58 : 70);
    t->base[R_SPR] = (uint8_t)(mach == MA_MULTI ? 40 : mach == MA_GRAN ? 72 : mach == MA_WAVE ? 48 : 0);
    t->base[R_VOI] = (uint8_t)(MACH[mach].poly - 1u);
    for (r = 0; r < NREG; r++) {
        t->lock[r] = t->tlk[r] = 0xFF;
        t->eff[r] = t->base[r];
    }
}

/* change a track's machine: page A back to that machine's defaults, the rest kept */
static void trk_set_machine(trk_t *t, uint32_t mach)
{
    uint32_t r;
    t->mach = (uint8_t)mach;
    for (r = 0; r < 8u; r++) {
        t->base[r] = reg_info(mach, r)->def;
        t->lock[r] = t->tlk[r] = 0xFF;
    }
    if (t->base[0] >= OS_LIB_COUNT)
        t->base[0] = (uint8_t)(OS_LIB_COUNT - 1u);
}

/* eff = modulators(lock(scenes(base))): each scene in, oldest first, moves the value toward its own by its
 * amount (127: all the way), so a newer scene sits on top of an older one where both set a register */
static void trk_resolve(trk_t *t, uint32_t k)
{
    uint32_t r, m, i;
    for (r = 0; r < NREG; r++) {
        int32_t v = t->base[r];
        for (i = 0; i < scs.n; i++) {
            uint32_t s = scs.ord[i];
            if (SCN_HAS(s, k, r)) {
                int32_t d = ((int32_t)scn[s].v[k][r] - v) * (int32_t)scs.amt[s];
                v += (d + (d < 0 ? -63 : 63)) / 127;
            }
        }
        if (t->lock[r] != 0xFF)
            v = t->lock[r];
        if (t->tlk[r] != 0xFF)
            v = t->tlk[r];
        for (m = 0; m < MS_N; m++)            /* the modulators on register targets (os_mod.c) */
            if (t->rt[m].r == r && t->roff[m]) v += t->roff[m];
        t->eff[r] = (uint8_t)os_clampi(v, 0, (int32_t)reg_max(t->mach, r));
    }
}

/* ---- the modulators' maps (os_mod.c uses them; the strip shows them) ----
 * An envelope stage's time: LONG 2 ms .. 4.1 s (pads: A + D + R up to ~12 s), SHORT 0.1 ms .. 330 ms (hits:
 * under 1 s in all), 2^(v / 11.5): 128 steps, ~6 % apart */
static float env_time_s(uint32_t v, uint32_t shrt)
{
    return shrt ? 0.0001f * fx_fexp((float)v * (11.69f / 127.0f) * 0.6931472f)
                : 0.002f * fx_fexp((float)v * (11.0f / 127.0f) * 0.6931472f);
}
/* which register holds the range of an envelope stage register */
static uint32_t env_rng_reg(uint32_t r)
{
    return r >= R_AT2 && r <= R_RE2 ? R_RG2 : r >= R_AT1 && r <= R_RE1 ? R_RG1 : R_ARN;
}
/* an LFO's rate: the knob spans two decades (0.1 .. 10 Hz, 3.7 % a step), times a multiplier 1/64 .. x256:
 * 0.0016 Hz (a 10-minute cycle) .. 2.56 kHz (audio-rate FM). MUL = SYNC: the knob picks a note value */
static const float LFO_MUL[8] = {0.015625f, 0.0625f, 0.25f, 1.0f, 4.0f, 16.0f, 64.0f, 256.0f};
#define LFO_SYNC 8u
/* synced periods in 1/384 of a bar (bpb / 6 clock samples each: straight, dotted and triplet values exact) */
#define LFO_NSYNC 26u
static const uint16_t LFO_SYNC_N[LFO_NSYNC] = {4, 6, 8, 9, 12, 16, 18, 24, 32, 36, 48, 64, 72, 96, 128, 144, 192,
                                              256, 288, 384, 768, 1536, 3072, 6144, 12288, 24576};
static const char LFO_SYNC_T[LFO_NSYNC][6] = {"1/64T", "1/64", "1/32T", "1/64.", "1/32", "1/16T", "1/32.", "1/16",
                                             "1/8T", "1/16.", "1/8", "1/4T", "1/8.", "1/4", "1/2T", "1/4.", "1/2",
                                             "1/1T", "1/2.", "1B", "2B", "4B", "8B", "16B", "32B", "64B"};
static uint32_t lfo_mul_reg(uint32_t r) { return r == R_RT1 ? R_MU1 : R_MU2; }
static float lfo_hz(uint32_t v, uint32_t mul)
{
    return 0.1f * fx_fexp((float)v * (6.6439f / 127.0f) * 0.6931472f) * LFO_MUL[mul < 8u ? mul : 3u];
}
static uint32_t lfo_sync_i(uint32_t v) { return v * LFO_NSYNC / 128u; }
/* a modulation depth (bipolar register, 64 = 0): +-128 register units at the ends, squared, so small depths are
 * fine (a step near the centre is 0.03 units: 3 cents of pitch) and full depth still spans any register */
static float mod_depth(uint32_t v)
{
    float d = ((float)v - 64.0f) * (1.0f / 63.0f);
    if (d > 1.0f) d = 1.0f;
    return (d < 0.0f ? -d * d : d * d) * 128.0f;
}

/* the old LFO's rate map (kept for the filter's audio-rate test) */
static float reg_lfo_hz(uint32_t v) { return 0.05f * fx_fexp((float)v * (0.6931472f / 8.6f)); }

/* table rows, retrigs, cuts: 2^(v/16) core samples, so 0, 16, 32 ... are exactly 1, 2, 4 ... samples */
static uint32_t reg_samples(uint32_t v) { return (uint32_t)(fx_fexp((float)v * (0.6931472f / 16.0f)) + 0.5f); }

/* which of the four audio-rate paths the LFO's target is (0 = the block path) */



/* value text for the register strip (up to 5 characters) */
static void reg_text(char *b, const trk_t *t, uint32_t r, uint32_t v)
{
    const reg_def *d = reg_info(t->mach, r);
    char *q = b;
    switch (d->fmt) {
    case RF_BIP: os_fmt_int(b, (int32_t)v - 64, 1, 1); break;
    case RF_SEMI: os_fmt_int(b, (int32_t)v - 64, 1, 1); break;
    case RF_SMP: {
        const char *s = OS_LIB_NAMES[v < OS_LIB_COUNT ? v : 0];
        uint32_t i;
        for (i = 0; i < 5u && s[i]; i++)
            b[i] = s[i];
        b[i] = 0;
        break;
    }
    case RF_LIST: {
        uint32_t i;
        for (i = 0; i < 4u && d->list[v * 4u + i] != ' '; i++)
            b[i] = d->list[v * 4u + i];
        b[i] = 0;
        break;
    }
    case RF_PCT: q = os_fmt_int(b, reg_feel_pct(v), 1, 0); os_fmt_str(q, "%"); break;
    case RF_REG: {
        if (v >= NREG) { os_fmt_str(b, "---"); break; }
        { const char *l = reg_label(t->eff, t->mach, v); b[0] = l[0]; b[1] = l[1]; b[2] = l[2]; b[3] = 0; }
        break;
    }
    case RF_ETIME: {                          /* an envelope stage: its time in its envelope's range */
        float sec = env_time_s(v, t->eff[env_rng_reg(r)]);
        if (sec < 0.01f) { q = os_fmt_int(b, (int32_t)(sec * 1000.0f), 1, 0); *q++ = '.'; q = os_fmt_int(q, (int32_t)(sec * 10000.0f) % 10, 1, 0); }
        else if (sec < 1.0f) q = os_fmt_int(b, (int32_t)(sec * 1000.0f + 0.5f), 1, 0);
        else { q = os_fmt_int(b, (int32_t)sec, 1, 0); *q++ = '.'; q = os_fmt_int(q, (int32_t)(sec * 10.0f) % 10, 1, 0); *q++ = 'S'; *q = 0; break; }
        os_fmt_str(q, "MS");
        break;
    }
    case RF_LRATE: {                          /* an LFO's rate: Hz (with its multiplier), or a note value */
        uint32_t mul = t->eff[lfo_mul_reg(r)];
        if (mul >= LFO_SYNC) { os_fmt_str(b, LFO_SYNC_T[lfo_sync_i(v)]); break; }
        {
            float hz = lfo_hz(v, mul);
            if (hz < 0.1f) { q = os_fmt_int(b, (int32_t)(1.0f / hz + 0.5f), 1, 0); *q++ = 'S'; *q = 0; }   /* (a period) */
            else if (hz < 1.0f) { int32_t c = (int32_t)(hz * 100.0f + 0.5f); b[0] = '.'; b[1] = (char)('0' + c / 10 % 10); b[2] = (char)('0' + c % 10); b[3] = 0; }
            else if (hz < 10.0f) { q = os_fmt_int(b, (int32_t)hz, 1, 0); *q++ = '.'; os_fmt_int(q, (int32_t)(hz * 10.0f) % 10, 1, 0); }
            else if (hz < 1000.0f) os_fmt_int(b, (int32_t)(hz + 0.5f), 1, 0);
            else { q = os_fmt_int(b, (int32_t)(hz * 0.001f), 1, 0); *q++ = 'K'; os_fmt_int(q, (int32_t)(hz * 0.01f) % 10, 1, 0); }
        }
        break;
    }
    case RF_DEPTH: os_fmt_int(b, (int32_t)v - 64, 1, 1); break;
    case RF_TIME: {
        float s = reg_time_s(v);
        if (s < 1.0f) { q = os_fmt_int(b, (int32_t)(s * 1000.0f + 0.5f), 1, 0); os_fmt_str(q, "MS"); }
        else { q = os_fmt_int(b, (int32_t)s, 1, 0); *q++ = '.'; q = os_fmt_int(q, (int32_t)(s * 10.0f) % 10, 1, 0); os_fmt_str(q, "S"); }
        break;
    }
    case RF_HZ: {
        float hz = reg_cut_hz((float)v);
        if (r == R_LOC && !v) { os_fmt_str(b, "OFF"); break; }
        if (hz < 1000.0f) os_fmt_int(b, (int32_t)hz, 1, 0);
        else { q = os_fmt_int(b, (int32_t)(hz * 0.001f), 1, 0); *q++ = 'K'; if (hz < 10000.0f) { os_fmt_int(q, (int32_t)(hz * 0.01f) % 10, 1, 0); } else *q = 0; }
        break;
    }
    case RF_OFFN: if (!v) os_fmt_str(b, "OFF"); else os_fmt_int(b, (int32_t)v, 1, 0); break;
    case RF_SAMP: {                           /* samples of the clock: shown as time */
        uint32_t n = reg_samples(v), us = n * 125u;
        if (us < 1000u) { q = os_fmt_int(b, (int32_t)us, 1, 0); os_fmt_str(q, "US"); }
        else { q = os_fmt_int(b, (int32_t)(us / 1000u), 1, 0); if (us < 10000u) { *q++ = '.'; q = os_fmt_int(q, (int32_t)(us / 100u % 10u), 1, 0); } os_fmt_str(q, "MS"); }
        break;
    }
    case RF_LFOHZ: {
        float hz = reg_lfo_hz(v);
        if (hz < 10.0f) { q = os_fmt_int(b, (int32_t)hz, 1, 0); *q++ = '.'; q = os_fmt_int(q, (int32_t)(hz * 10.0f) % 10, 1, 0); }
        else q = os_fmt_int(b, (int32_t)hz, 1, 0);
        os_fmt_str(q, hz < 1000.0f ? "HZ" : "");
        break;
    }
    case RF_PLUS1: os_fmt_int(b, (int32_t)v + 1, 1, 0); break;
    case RF_VOI: if (MACH[t->mach].poly < 2u) os_fmt_str(b, "MONO"); else os_fmt_int(b, (int32_t)v + 1, 1, 0); break;
    case RF_SDB: {                            /* the shaper's input: +0.0 .. +36.0 dB */
        int32_t d = (int32_t)v * 360 / 127;
        *q++ = '+';
        q = os_fmt_int(q, d / 10, 1, 0);
        *q++ = '.';
        os_fmt_int(q, d % 10, 1, 0);
        break;
    }
    case RF_STN:                              /* its tone: 200 Hz .. 4 kHz, OFF at 127 */
        if (v >= 127u) os_fmt_str(b, "OFF");
        else {
            int32_t hz = (int32_t)(200.0f / fx_fexp(-(float)v * (4.32f / 126.0f) * 0.69314718f));
            if (hz < 1000) os_fmt_int(b, hz, 1, 0);
            else { q = os_fmt_int(b, hz / 1000, 1, 0); *q++ = 'K'; os_fmt_int(q, hz / 100 % 10, 1, 0); }
        }
        break;
    case RF_SHA: case RF_SHB: {               /* the shaper's A, B: per model */
        uint32_t m = t->eff[R_SMD], isb = d->fmt == RF_SHB;
        if (m == 4u && !isb) {                /* CHEB: the harmonic, 2.0 .. 7.0 */
            int32_t h = 20 + (int32_t)v * 50 / 127;
            q = os_fmt_int(b, h / 10, 1, 0); *q++ = '.'; os_fmt_int(q, h % 10, 1, 0);
        } else if (m == 7u && !isb) {         /* BITS: 16 .. 1 */
            int32_t h = 160 - (int32_t)v * 150 / 127;
            q = os_fmt_int(b, h / 10, 1, 0); *q++ = '.'; os_fmt_int(q, h % 10, 1, 0);
        } else if (m == 7u) {                 /* BITS: the rate, 16 kHz .. 250 Hz */
            int32_t hz = (int32_t)(16000.0f * fx_fexp(-6.0f * (float)v * (1.0f / 127.0f) * 0.69314718f));
            if (hz < 1000) os_fmt_int(b, hz, 1, 0);
            else { q = os_fmt_int(b, hz / 1000, 1, 0); *q++ = 'K'; os_fmt_int(q, hz / 100 % 10, 1, 0); }
        } else if (m == 3u && isb) {          /* FOLD: x1.0 .. x8.0 */
            int32_t f = 10 + (int32_t)v * 70 / 127;
            *q++ = 'X'; q = os_fmt_int(q, f / 10, 1, 0); *q++ = '.'; os_fmt_int(q, f % 10, 1, 0);
        } else if (m == 8u && !isb) os_fmt_int(b, (int32_t)v - 64, 1, 1);   /* POLY: even, bipolar */
        else if (m == 6u && isb) os_fmt_str(b, "---");
        else os_fmt_int(b, (int32_t)v, 1, 0);
        break;
    }
    case RF_FXT:                              /* page F TIM */
        if (!v) { os_fmt_str(b, "0"); break; }
        if (v <= 56u) {
            float ms = reg_fx_time(v, os.bpb) * 0.125f;
            if (ms < 10.0f) { q = os_fmt_int(b, (int32_t)ms, 1, 0); *q++ = '.'; os_fmt_int(q, (int32_t)(ms * 10.0f) % 10, 1, 0); }
            else os_fmt_int(b, (int32_t)(ms + 0.5f), 1, 0);
            break;
        }
        if (v <= 120u) { reg_bar_text(b, v - 56u); break; }
        q = os_fmt_str(b, "1/");
        q = os_fmt_int(q, (int32_t)(64u >> (v - 121u)), 1, 0);
        os_fmt_str(q, "T");
        break;
    case RF_RATE:                             /* page F RAT */
        if (v >= RAT_SYNC) { reg_bar_text(b, RAT_N[v - RAT_SYNC]); break; }
        {
            float hz = reg_fx_hz(v);
            if (hz < 10.0f) { q = os_fmt_int(b, (int32_t)hz, 1, 0); *q++ = '.'; os_fmt_int(q, (int32_t)(hz * 100.0f) % 100, 2, 0); }
            else os_fmt_int(b, (int32_t)hz, 1, 0);
        }
        break;
    case RF_DIS:
        if (!v) { os_fmt_str(b, "OFF"); break; }
        {
            float hz = reg_fx_dis_hz(v);
            if (hz < 1000.0f) os_fmt_int(b, (int32_t)hz, 1, 0);
            else { q = os_fmt_int(b, (int32_t)(hz * 0.001f), 1, 0); *q++ = 'K'; os_fmt_int(q, (int32_t)(hz * 0.01f) % 10, 1, 0); }
        }
        break;
    case RF_RT:                               /* page G DCY: RT60 */
        if (v >= 127u) { os_fmt_str(b, "FRZ"); break; }
        {
            float s = 0.2f * fx_fexp((float)v * (0.6931472f / 14.0f));
            if (s < 10.0f) { q = os_fmt_int(b, (int32_t)s, 1, 0); *q++ = '.'; q = os_fmt_int(q, (int32_t)(s * 10.0f) % 10, 1, 0); }
            else q = os_fmt_int(b, (int32_t)s, 1, 0);
            os_fmt_str(q, "S");
        }
        break;
    case RF_MS: q = os_fmt_int(b, (int32_t)v, 1, 0); os_fmt_str(q, "MS"); break;
    case RF_GATE: if (!v) os_fmt_str(b, "OFF"); else { q = os_fmt_int(b, (int32_t)v, 1, 0); os_fmt_str(q, "ST"); } break;
    default: os_fmt_int(b, (int32_t)v, 1, 0);
    }
}
