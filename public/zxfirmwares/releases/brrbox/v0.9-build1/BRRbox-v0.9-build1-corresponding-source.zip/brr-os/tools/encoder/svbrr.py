"""SVBRR: seekable VBRR + multi-sample container.

Differences from vbrr.py
- Keyframe every KF samples: predictor history and coder restart there, so
  decoding can start at any keyframe with no other state.
- Static symbol statistics, trained over the whole container and stored once
  in its header (no per-sample tables, no adaptation to replay).
- No repetition copies (they would point outside the keyframe).
- Side info fixed-rate (34 bits per 20 ms frame): any frame is directly
  addressable.

Container layout (all little-endian)
  'SVBR' u8 version  u16 core_sr  u16 kf_len  u16 n_samples      (11 B)
  static tables, 12-bit frequencies, 190 entries                   (285 B)
  directory, 26 B per sample:
    u32 core_len  u16 n_kf  u32 kf_table_off  u32 side_off  u16 n_frames
    u32 loop_start  u32 loop_end  u8 root_note  u8 flags
  per sample: (n_kf+1) x u24 segment offsets, segments, side info bits
"""
import bisect
import struct

import numpy as np

import codec as C
import rangecoder as rc
import vbrr

BLK = vbrr.BLK
NS = vbrr.NS
CORE_SR = 8000
FRAME_CORE = 160             # 20 ms at 8 kHz = one side-info frame
SIDE_BITS = 34


# ------------------------------------------------------------------ models --
class CountModel:
    def __init__(self, n):
        self.n = n
        self.c = [0] * n


class StaticModel:
    def __init__(self, freqs):
        self.n = len(freqs)
        self.f = list(freqs)
        self.cum = [0]
        for v in self.f:
            self.cum.append(self.cum[-1] + v)
        self.total = self.cum[-1]

    def lo_hi(self, s):
        return self.cum[s], self.cum[s + 1]

    def find(self, v):
        s = bisect.bisect_right(self.cum, v) - 1
        return s, self.cum[s], self.cum[s + 1]

    def update(self, s):
        pass


def model_shapes():
    return dict(mode=[5] * 5, filt=[vbrr.NF] * 5, sabs=[NS], ds=[2 * NS - 1],
                res=[1 << m for m in range(1, 5)])


def make(factory):
    return {k: [factory(n) for n in v] for k, v in model_shapes().items()}


class CountCoder:
    def code(self, m, s):
        m.c[s] += 1
        return s


def quantise(counts, total=4096):
    n = len(counts)
    s = sum(counts)
    if s == 0:
        return [1] * n
    return [1 + (c * (total - n)) // s for c in counts]


def tables_from_counts(cm):
    return {k: [StaticModel(quantise(m.c)) for m in v] for k, v in cm.items()}


def pack_tables(tm):
    vals = [f for k in model_shapes() for m in tm[k] for f in m.f]
    bits = ''.join(format(v, '012b') for v in vals)
    bits += '0' * ((-len(bits)) % 8)
    return bytes(int(bits[i:i + 8], 2) for i in range(0, len(bits), 8))


def unpack_tables(b):
    bits = ''.join(format(x, '08b') for x in b)
    out, i = {}, 0
    for k, shapes in model_shapes().items():
        out[k] = []
        for n in shapes:
            f = [int(bits[(i + j) * 12:(i + j + 1) * 12], 2) for j in range(n)]
            i += n
            out[k].append(StaticModel(f))
    return out


TABLE_BYTES = (sum(sum(v) for v in model_shapes().values()) * 12 + 7) // 8


# ------------------------------------------------------------------ syntax --
def seg_syntax(Cd, M, blocks, n_blocks, out_blocks=None):
    """One keyframe segment. blocks: list of (mode,f,s,ks) or None (decoder).
    Returns list of (mode, f, half, ks)."""
    prev_mode = 0
    prev_s = None
    res = []
    for i in range(n_blocks):
        b = blocks[i] if blocks is not None else None
        mode = Cd.code(M['mode'][prev_mode], b[0] if b else 0)
        f = Cd.code(M['filt'][mode], b[1] if b else 0)
        ks = np.zeros(BLK, np.int64)
        half = 0
        if mode > 0:
            if prev_s is None:
                s = Cd.code(M['sabs'][0], b[2] if b else 0)
            else:
                s = Cd.code(M['ds'][0], (b[2] - prev_s + NS - 1) if b else 0) + prev_s - (NS - 1)
            prev_s = s
            half = int(vbrr.HALF[s])
            off = 1 << (mode - 1)
            rm = M['res'][mode - 1]
            for j in range(BLK):
                ks[j] = Cd.code(rm, (int(b[3][j]) + off) if b else 0) - off
        res.append((mode, f, half, ks))
        prev_mode = mode
    return res


# ----------------------------------------------------------------- encoder --
def search(core, q, kf_len):
    """Closed-loop block decisions with history reset at every keyframe."""
    n = len(core)
    nb = -(-n // BLK)
    xp = np.zeros(nb * BLK, np.int64)
    xp[:n] = core
    tg = vbrr.block_targets(xp, q)
    dec = np.zeros(nb * BLK, np.int64)
    blocks = []
    p1 = p2 = 0
    out = np.zeros(BLK, np.int64)
    per = kf_len // BLK
    modes = [0] * 5
    for b in range(nb):
        if b % per == 0:
            p1 = p2 = 0
        i0 = b * BLK
        mode, f, s, ks, _ = vbrr._search(xp[i0:i0 + BLK], p1, p2, tg[b])
        half = int(vbrr.HALF[s]) if mode else 0
        p1, p2 = vbrr._synth(p1, p2, f, mode, half, ks, out)
        dec[i0:i0 + BLK] = out
        blocks.append((mode, f, s, ks.copy()))
        modes[mode] += BLK
    return blocks, dec[:n], modes


def build(samples, kf_len=512, core_sr=CORE_SR):
    """samples: list of dicts with 'blocks','core_len','side'(bytes),'n_frames',
    'loop'(start,end),'root'. Two passes: count symbols, then code with the
    static tables. Returns container bytes and per-part byte counts."""
    per = kf_len // BLK
    cm = make(CountModel)
    cc = CountCoder()
    for sm in samples:
        bl = sm['blocks']
        for k in range(0, len(bl), per):
            seg_syntax(cc, cm, bl[k:k + per], len(bl[k:k + per]))
    tm = tables_from_counts(cm)
    hdr = b'SVBR' + struct.pack('<BHHH', 1, core_sr, kf_len, len(samples))
    tables = pack_tables(tm)
    dir_size = 26 * len(samples)
    body = bytearray()
    entries = []
    parts = dict(header=len(hdr) + len(tables), directory=dir_size, kf_tables=0, segments=0, side=0)
    base = len(hdr) + len(tables) + dir_size
    for sm in samples:
        bl = sm['blocks']
        segs = []
        for k in range(0, len(bl), per):
            E = rc.Encoder()
            seg_syntax(E, tm, bl[k:k + per], len(bl[k:k + per]))
            segs.append(E.finish())
        n_kf = len(segs)
        kf_off = base + len(body)
        offs = [0]
        for s in segs:
            offs.append(offs[-1] + len(s))
        tbl = b''.join(struct.pack('<I', o)[:3] for o in offs)
        body += tbl
        for s in segs:
            body += s
        side_off = base + len(body)
        body += sm['side']
        parts['kf_tables'] += len(tbl)
        parts['segments'] += offs[-1]
        parts['side'] += len(sm['side'])
        entries.append(struct.pack('<IHIIHIIBB', sm['core_len'], n_kf, kf_off, side_off, sm['n_frames'],
                                   sm['loop'][0], sm['loop'][1], sm['root'], 0))
    blob = hdr + tables + b''.join(entries) + bytes(body)
    assert len(hdr) + len(tables) + sum(len(e) for e in entries) == base
    return blob, parts


# ----------------------------------------------------------------- decoder --
class Container:
    def __init__(self, blob):
        self.blob = blob
        assert blob[:4] == b'SVBR'
        _, self.core_sr, self.kf_len, n = struct.unpack('<BHHH', blob[4:11])
        self.tables = unpack_tables(blob[11:11 + TABLE_BYTES])
        self.samples = []
        p = 11 + TABLE_BYTES
        for i in range(n):
            v = struct.unpack('<IHIIHIIBB', blob[p:p + 26])
            self.samples.append(dict(core_len=v[0], n_kf=v[1], kf_off=v[2], side_off=v[3], n_frames=v[4],
                                     loop=(v[5], v[6]), root=v[7]))
            p += 26

    def seg_bounds(self, si, k):
        s = self.samples[si]
        t = s['kf_off']
        o0 = int.from_bytes(self.blob[t + 3 * k:t + 3 * k + 3], 'little')
        o1 = int.from_bytes(self.blob[t + 3 * (k + 1):t + 3 * (k + 1) + 3], 'little')
        data0 = t + 3 * (s['n_kf'] + 1)
        return data0 + o0, data0 + o1

    def side_frame(self, si, fr):
        """Random access to one side-info frame: 8 band codes + tonality."""
        s = self.samples[si]
        fr = min(max(fr, 0), s['n_frames'] - 1)
        bit = fr * SIDE_BITS
        b0 = s['side_off'] + bit // 8
        chunk = int.from_bytes(self.blob[b0:b0 + 6], 'big')
        sh = 48 - (bit % 8) - SIDE_BITS
        v = (chunk >> sh) & ((1 << SIDE_BITS) - 1)
        codes = [(v >> (SIDE_BITS - 4 * (b + 1))) & 15 for b in range(8)]
        return codes, v & 3


class Reader:
    """One playback head. State: segment decoder + predictor + small block
    buffer. Reads only from the container bytes."""
    stats = dict(blocks=0, symbols=0, seeks=0)

    def __init__(self, ct, si):
        self.ct, self.si = ct, si
        self.s = ct.samples[si]
        self.kf_len = ct.kf_len
        self.per = self.kf_len // BLK
        self.block = None
        self.bidx = -1
        self.dec = None

    def _start_segment(self, k):
        a, b = self.ct.seg_bounds(self.si, k)
        self.dec = _CountingDecoder(memoryview(self.ct.blob)[a:b])
        self.seg = k
        self.inseg = 0
        self.prev_mode = 0
        self.prev_s = None
        self.p1 = self.p2 = 0
        Reader.stats['seeks'] += 1

    def _next_block(self):
        M = self.ct.tables
        Cd = self.dec
        mode = Cd.code(M['mode'][self.prev_mode])
        f = Cd.code(M['filt'][mode])
        ks = np.zeros(BLK, np.int64)
        half = 0
        if mode > 0:
            if self.prev_s is None:
                s = Cd.code(M['sabs'][0])
            else:
                s = Cd.code(M['ds'][0]) + self.prev_s - (NS - 1)
            self.prev_s = s
            half = int(vbrr.HALF[s])
            off = 1 << (mode - 1)
            rm = M['res'][mode - 1]
            for j in range(BLK):
                ks[j] = Cd.code(rm) - off
        out = np.zeros(BLK, np.int64)
        self.p1, self.p2 = vbrr._synth(self.p1, self.p2, f, mode, half, ks, out)
        self.prev_mode = mode
        self.inseg += 1
        Reader.stats['blocks'] += 1
        self.hdr = (mode, f, half)
        return out

    def block_at(self, b):
        """Decoded 32-sample block number b (int16 values)."""
        if b == self.bidx:
            return self.block
        k = b // self.per
        if self.dec is None or k != self.seg or b < self.bidx:
            self._start_segment(k)
            cur = k * self.per - 1
        else:
            cur = self.bidx
        while cur < b:
            self.block = self._next_block()
            cur += 1
        self.bidx = b
        return self.block

    def sample(self, pos):
        pos = int(pos)
        return int(self.block_at(pos // BLK)[pos % BLK])


class _CountingDecoder(rc.Decoder):
    def code(self, m, s_ignored=None):
        Reader.stats['symbols'] += 1
        return super().code(m)


def decode_all(ct, si):
    r = Reader(ct, si)
    n = ct.samples[si]['core_len']
    nb = -(-n // BLK)
    return np.concatenate([r.block_at(b) for b in range(nb)])[:n]
