"""SVBRR v2: same block decisions and container shape as svbrr.py, but the
entropy coder is static rANS (ryg_rans_byte) with every table summing to
exactly 4096. Decoding needs one 32x32->32 multiply, shifts and adds per
symbol: no divide, no 64-bit arithmetic (the pi32v2 erratum and the soft
64-bit divide both disappear).

Container 'SVB2' (little-endian), as v1 except:
  - magic 'SVB2'; tables are 12-bit frequencies, each model sums to 4096
  - each keyframe segment is one rANS stream: 4-byte LE initial state,
    then renormalisation bytes read forward.

Container 'SVB3' (version 3) adds keyframe seeds: after the 3-byte offset table, 3 bytes per keyframe
hold the predictor history the segment starts from (the two previous decoded samples, 12 bits each,
<< 4 on use). v2 reset that history to zero at every keyframe, so a keyframe in a quiet decaying tail
could click (a jump of up to -27 dBFS every 64 ms); seeded, the history carries across (rounding
<= 16 / 32768) and random access stays exact. Cost: 3 bytes per 64 ms.

Container 'SVB4' (version 4) is the one-clock layout of BRR-OS v0.3: SVB3 with 16-sample blocks (2 ms) and
side frames of 128 core samples (16 ms), so every unit is a power of two of the 8 kHz sample: block 16,
side frame 128, keyframe 512. Older containers have 32-sample blocks: re-encode them.
"""
import struct

import numpy as np

import svbrr
import vbrr

BLK, NS = svbrr.BLK, svbrr.NS
SCALE = 12
M = 1 << SCALE
RANS_L = 1 << 23


def seedq(v):
    """a decoded sample as a keyframe seed: 12 bits (floor shift), used << 4"""
    return int(v) >> 4


def search(core, q, kf_len, seeded=True):
    """closed-loop block decisions; seeded: each keyframe starts from the quantised previous two decoded
    samples (SVB3), else from zero (SVB2). Returns blocks, decoded core, mode counts and the seeds."""
    n = len(core)
    nb = -(-n // BLK)
    xp = np.zeros(nb * BLK, np.int64)
    xp[:n] = core
    tg = vbrr.block_targets(xp, q)
    dec = np.zeros(nb * BLK, np.int64)
    blocks, seeds = [], []
    p1 = p2 = 0
    out = np.zeros(BLK, np.int64)
    per = kf_len // BLK
    modes = [0] * 5
    for b in range(nb):
        i0 = b * BLK
        if b % per == 0:
            if seeded and b > 0:
                s1, s2 = seedq(dec[i0 - 1]), seedq(dec[i0 - 2])
            else:
                s1 = s2 = 0
            seeds.append((s1, s2))
            p1, p2 = s1 * 16, s2 * 16
        mode, f, s, ks, _ = vbrr._search(xp[i0:i0 + BLK], p1, p2, tg[b])
        half = int(vbrr.HALF[s]) if mode else 0
        p1, p2 = vbrr._synth(p1, p2, f, mode, half, ks, out)
        dec[i0:i0 + BLK] = out
        blocks.append((mode, f, s, ks.copy()))
        modes[mode] += BLK
    if seeded:
        return blocks, dec[:n], modes, seeds
    return blocks, dec[:n], modes


model_shapes = svbrr.model_shapes
FRAME_CORE = svbrr.FRAME_CORE
SIDE_BITS = svbrr.SIDE_BITS


class Model:
    def __init__(self, freqs):
        assert sum(freqs) == M and min(freqs) >= 1, (sum(freqs), min(freqs))
        self.n = len(freqs)
        self.f = list(freqs)
        self.cum = [0]
        for v in self.f:
            self.cum.append(self.cum[-1] + v)


def normalise(counts):
    """counts -> frequencies >= 1 summing to exactly M (largest remainder)."""
    n = len(counts)
    tot = sum(counts)
    if tot == 0:
        base = [M // n] * n
        for i in range(M - sum(base)):
            base[i] += 1
        return base
    avail = M - n
    raw = [c * avail / tot for c in counts]
    f = [1 + int(r) for r in raw]
    rem = M - sum(f)
    order = sorted(range(n), key=lambda i: -(raw[i] - int(raw[i])))
    for i in order[:rem]:
        f[i] += 1
    return f


class Collect:
    """'coder' that records (model, symbol) in forward order."""
    def __init__(self):
        self.seq = []

    def code(self, m, s):
        self.seq.append((m, s))
        return s


class Count:
    def code(self, m, s):
        m.c[s] += 1
        return s


class CountModel:
    def __init__(self, n):
        self.n = n
        self.c = [0] * n


def make(factory):
    return {k: [factory(n) for n in v] for k, v in model_shapes().items()}


def rans_encode(seq):
    """ryg_rans_byte: symbols encoded in reverse, bytes written backwards."""
    x = RANS_L
    rev = []
    for m, s in reversed(seq):
        f, c = m.f[s], m.cum[s]
        x_max = ((RANS_L >> SCALE) << 8) * f
        while x >= x_max:
            rev.append(x & 0xFF)
            x >>= 8
        x = ((x // f) << SCALE) + (x % f) + c
    head = bytes([x & 0xFF, (x >> 8) & 0xFF, (x >> 16) & 0xFF, (x >> 24) & 0xFF])
    return head + bytes(reversed(rev))


class RansDecoder:
    stats = None

    def __init__(self, data):
        self.d = data
        self.x = data[0] | data[1] << 8 | data[2] << 16 | data[3] << 24
        self.p = 4

    def code(self, m, s_ignored=None):
        slot = self.x & (M - 1)
        cum = m.cum
        s = 0
        while cum[s + 1] <= slot:
            s += 1
        self.x = m.f[s] * (self.x >> SCALE) + slot - cum[s]
        while self.x < RANS_L:
            self.x = ((self.x << 8) | (self.d[self.p] if self.p < len(self.d) else 0)) & 0xFFFFFFFF
            self.p += 1
        if RansDecoder.stats is not None:
            RansDecoder.stats['symbols'] += 1
        return s


def pack_tables(tm):
    vals = [f for k in model_shapes() for m in tm[k] for f in m.f]
    bits = ''.join(format(v & 0xFFF, '012b') for v in vals)   # 4096 never fits 12 bits: see note
    bits += '0' * ((-len(bits)) % 8)
    return bytes(int(bits[i:i + 8], 2) for i in range(0, len(bits), 8))


def unpack_tables(b):
    bits = ''.join(format(x, '08b') for x in b)
    out, i = {}, 0
    for k, shapes in model_shapes().items():
        out[k] = []
        for n in shapes:
            f = [int(bits[(i + j) * 12:(i + j + 1) * 12], 2) for j in range(n)]
            i += n
            f[-1] = M - sum(f[:-1])          # the last entry is implied: every table sums to 4096
            out[k].append(Model(f))
    return out


TABLE_BYTES = svbrr.TABLE_BYTES


def build(samples, kf_len=512, core_sr=8000):
    per = kf_len // BLK
    cm = make(CountModel)
    cc = Count()
    for sm in samples:
        bl = sm['blocks']
        for k in range(0, len(bl), per):
            svbrr.seg_syntax(cc, cm, bl[k:k + per], len(bl[k:k + per]))
    tm = {k: [Model(normalise(m.c)) for m in v] for k, v in cm.items()}
    # a 4096-frequency entry (one symbol takes everything) cannot be stored in 12 bits; give the
    # implied last symbol at least 1 so stored values stay <= 4095 (normalise already keeps >= 1 each)
    for v in tm.values():
        for m in v:
            assert max(m.f[:-1] or [0]) <= 4095
    v3 = all('seeds' in sm for sm in samples)
    assert v3 and BLK == 16, 'SVB4: seeded keyframes, 16-sample blocks'
    hdr = b'SVB4' + struct.pack('<BHHH', 4, core_sr, kf_len, len(samples))
    tables = pack_tables(tm)
    base = len(hdr) + len(tables) + 26 * len(samples)
    body = bytearray()
    entries = []
    parts = dict(header=len(hdr) + len(tables), directory=26 * len(samples), kf_tables=0, segments=0, side=0)
    for sm in samples:
        bl = sm['blocks']
        segs = []
        for k in range(0, len(bl), per):
            col = Collect()
            svbrr.seg_syntax(col, tm, bl[k:k + per], len(bl[k:k + per]))
            segs.append(rans_encode(col.seq))
        offs = [0]
        for s in segs:
            offs.append(offs[-1] + len(s))
        kf_off = base + len(body)
        tbl = b''.join(struct.pack('<I', o)[:3] for o in offs)
        if v3:
            assert len(sm['seeds']) == len(segs)
            for a1, a2 in sm['seeds']:
                w = (a1 & 0xFFF) | (a2 & 0xFFF) << 12
                tbl += struct.pack('<I', w)[:3]
        body += tbl
        for s in segs:
            body += s
        side_off = base + len(body)
        body += sm['side']
        parts['kf_tables'] += len(tbl)
        parts['segments'] += offs[-1]
        parts['side'] += len(sm['side'])
        entries.append(struct.pack('<IHIIHIIBB', sm['core_len'], len(segs), kf_off, side_off, sm['n_frames'],
                                   sm['loop'][0], sm['loop'][1], sm['root'], sm.get('hf_off', 0) & 0xFF))
    blob = hdr + tables + b''.join(entries) + bytes(body)
    return blob, parts


class Container(svbrr.Container):
    def __init__(self, blob):
        self.blob = blob
        assert blob[:4] == b'SVB4', 'SVB4 only (16-sample blocks): re-encode older libraries'
        self.ver = 4
        _, self.core_sr, self.kf_len, n = struct.unpack('<BHHH', blob[4:11])
        self.tables = unpack_tables(blob[11:11 + TABLE_BYTES])
        self.samples = []
        p = 11 + TABLE_BYTES
        for i in range(n):
            v = struct.unpack('<IHIIHIIBB', blob[p:p + 26])
            self.samples.append(dict(core_len=v[0], n_kf=v[1], kf_off=v[2], side_off=v[3], n_frames=v[4],
                                     loop=(v[5], v[6]), root=v[7], hf_off=v[8] - 256 if v[8] > 127 else v[8]))
            p += 26

    def seg_bounds(self, si, k):
        s = self.samples[si]
        t = s['kf_off']
        o0 = int.from_bytes(self.blob[t + 3 * k:t + 3 * k + 3], 'little')
        o1 = int.from_bytes(self.blob[t + 3 * (k + 1):t + 3 * (k + 1) + 3], 'little')
        data0 = t + 3 * (s['n_kf'] + 1) + (3 * s['n_kf'] if self.ver >= 3 else 0)
        return data0 + o0, data0 + o1

    def seed(self, si, k):
        if self.ver < 3:
            return 0, 0
        s = self.samples[si]
        p = s['kf_off'] + 3 * (s['n_kf'] + 1) + 3 * k
        w = int.from_bytes(self.blob[p:p + 3], 'little')
        a1, a2 = w & 0xFFF, w >> 12 & 0xFFF
        a1 -= 4096 if a1 >= 2048 else 0
        a2 -= 4096 if a2 >= 2048 else 0
        return a1 * 16, a2 * 16


class Reader(svbrr.Reader):
    def _start_segment(self, k):
        a, b = self.ct.seg_bounds(self.si, k)
        self.dec = RansDecoder(self.ct.blob[a:b])
        self.seg = k
        self.inseg = 0
        self.prev_mode = 0
        self.prev_s = None
        self.p1, self.p2 = self.ct.seed(self.si, k)
        svbrr.Reader.stats['seeks'] += 1


def decode_all(ct, si):
    r = Reader(ct, si)
    n = ct.samples[si]['core_len']
    nb = -(-n // BLK)
    return np.concatenate([r.block_at(b) for b in range(nb)])[:n]
