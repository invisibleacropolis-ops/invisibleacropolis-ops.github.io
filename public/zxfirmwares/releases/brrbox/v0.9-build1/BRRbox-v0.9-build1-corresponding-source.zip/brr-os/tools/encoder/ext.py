"""Bandwidth extension generalised to any core rate, with entropy-coded side info.

Everything above core_sr/2 is rebuilt from the decoded core's top octave
(core_sr/4 .. core_sr/2): SSB copy-up + rectifier exciter, blended with
shaped noise by a per-frame tonality value; per-band energies relative to
that reference octave; temporal shaping from the reference octave."""
import numpy as np
from scipy.signal import hilbert

import codec as C
import rangecoder as rc

FRAME = C.FRAME
Q_STEP, Q_MIN = 3.0, -39.0


def config(core_sr, top=16000):
    lo = core_sr // 2
    if core_sr == 8000:
        edges = [4000, 4800, 5700, 6800, 8100, 9700, 11600, 13800, top]
    elif core_sr == 12000:
        edges = [6000, 6800, 7700, 8700, 9800, 11000, 12000, 13600, top]
    else:
        edges = list(np.geomspace(lo, top, 9).round())
    return dict(core_sr=core_sr, ref=(core_sr // 4, lo), bands=list(zip(edges[:-1], edges[1:])),
                ton_band=(lo, min(2 * lo, top)), top=top)


def flatness(x, lo, hi):
    n = len(x) // FRAME
    fr = x[: n * FRAME].reshape(n, FRAME) * np.hanning(FRAME)
    P = np.abs(np.fft.rfft(fr, axis=1)) ** 2 + 1e-14
    a, b = int(lo / C.OUT_SR * FRAME), int(hi / C.OUT_SR * FRAME)
    P = P[:, a:b]
    return np.exp(np.log(P).mean(1)) / P.mean(1)


def sources(core48, cfg):
    rlo, rhi = cfg['ref']
    w = rhi - rlo
    a = hilbert(C.band(core48, rlo, rhi))
    t = np.arange(len(core48)) / C.OUT_SR
    cp = np.zeros(len(core48))
    k = 1
    while rlo + k * w < cfg['top']:
        cp += np.real(a * np.exp(2j * np.pi * k * w * t))
        k += 1
    hb = C.band(core48, 0.75 * rlo, rhi)
    ex = np.abs(hb) + 0.5 * np.tanh(4 * hb / (np.std(hb) + 1e-9)) * np.abs(hb)
    harm = 0.5 * C._unit(cp) + 0.5 * C._unit(ex)
    noise = np.random.default_rng(7).standard_normal(len(core48))
    return harm, noise


def render(core48, codes, ton, cfg, srcs=None, off=0):
    """off: the sample's side-info offset in Q_STEP units (the code window slides by it)."""
    nf = codes.shape[0]
    ref = C.frame_energy(C.band(core48, *cfg['ref']))[:nf]
    harm, noise = srcs if srcs is not None else sources(core48, cfg)
    tref = C.hop_energy(C.band(core48, *cfg['ref']))
    tw = ton.astype(float) / 3.0
    hf = np.zeros(len(core48))
    for bi, (lo, hi) in enumerate(cfg['bands']):
        tgt = ref * 10 ** ((Q_MIN + (codes[:, bi] + off) * Q_STEP) / 10)
        hf += C.shape_band(harm, lo, hi, tgt * tw + 1e-14, tref)
        hf += C.shape_band(noise, lo, hi, tgt * (1 - tw) + 1e-14, tref)
    return core48 + hf


def side_offset(rel, ref):
    """The sample's window: 16 codes span 45 dB, from Q_MIN + off x Q_STEP. A hi-hat sits 20-30 dB above its
    own 2-4 kHz band, a dull pad 40 dB below it; slide the window to where the sample's ratios are (frames
    within 40 dB of the loudest), least clipping error first, nearest 0 on a tie. 0 = the fixed SVB4 window."""
    act = ref > ref.max() * 1e-4
    r = np.clip(rel[act], -90.0, 60.0)
    if r.size == 0:
        return 0
    def err(o):
        q = np.clip(np.round((r - Q_MIN) / Q_STEP) - o, 0, 15) + o
        return float(np.mean((r - (Q_MIN + q * Q_STEP)) ** 2))
    return min(range(-12, 13), key=lambda o: (round(err(o), 3), abs(o)))


def analyse(x48, core48, cfg, off=0):
    """Encoder: band codes (closed loop vs decoded core) + tonality chosen
    per frame by analysis-by-synthesis. off: a fixed window offset, or 'auto' (then returns it too)."""
    ref = C.frame_energy(C.band(core48, *cfg['ref']))
    rel = np.stack([10 * np.log10(C.frame_energy(C.band(x48, lo, hi)) / (ref + 1e-20) + 1e-20)
                    for lo, hi in cfg['bands']], 1)
    auto = off == 'auto'
    if auto:
        off = side_offset(rel, ref)
    codes = np.clip(np.round((rel - Q_MIN) / Q_STEP) - off, 0, 15).astype(np.int64)
    nf = codes.shape[0]
    srcs = sources(core48, cfg)
    target = flatness(x48, *cfg['ton_band'])[:nf]
    cands = []
    for v in range(4):
        y = render(core48, codes, np.full(nf, v), cfg, srcs, off)
        cands.append(flatness(y, *cfg['ton_band'])[:nf])
    ton = np.argmin(np.abs(np.stack(cands, 1) - target[:, None]), 1).astype(np.int64)
    return (codes, ton, off) if auto else (codes, ton)


def _side_syntax(C_, codes, ton, nf, nb):
    md = rc.Model(31)
    mt = [rc.Model(4) for _ in range(4)]
    prev = [8] * nb
    pt = 0
    oc = np.zeros((nf, nb), np.int64)
    ot = np.zeros(nf, np.int64)
    for f in range(nf):
        for b in range(nb):
            v = (int(codes[f, b]) - prev[b] + 15) if codes is not None else 0
            c = C_.code(md, v) - 15 + prev[b]
            oc[f, b] = c
            prev[b] = c
        t = C_.code(mt[pt], int(ton[f]) if ton is not None else 0)
        ot[f] = t
        pt = t
    return oc, ot


def pack(codes, ton):
    E = rc.Encoder()
    _side_syntax(E, codes, ton, codes.shape[0], codes.shape[1])
    return E.finish()


def unpack(data, nf, nb):
    return _side_syntax(rc.Decoder(data), None, None, nf, nb)
