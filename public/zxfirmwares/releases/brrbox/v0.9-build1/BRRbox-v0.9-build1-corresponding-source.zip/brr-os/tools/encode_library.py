#!/usr/bin/env python3
"""Encode your own samples into a BRR-OS library (SVB3): library/library.svbr + library/manifest.json.

  tools/encode_library.py spec.json            (see library/spec.example.json)
  tools/encode_library.py --wav a.wav b.wav ... [--bpm 120] [--q 18]

Each sample: mono, 48 kHz, peak-normalised, then the 8 kHz VBRR core (q = allowed noise in dB under
the masked signal: 24 cleaner and bigger, 12 grittier and smaller), 64 ms seeded keyframes, and the side info
that rebuilds 4-16 kHz on the device. The whole library must fit the 350 KB budget.
Needs numpy, scipy and numba (pip install numpy scipy numba)."""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly

sys.path.insert(0, str(Path(__file__).resolve().parent / "encoder"))
import codec as C  # noqa: E402
import ext  # noqa: E402
import svbrr2  # noqa: E402

BUDGET = 350_000
ROOT = Path(__file__).resolve().parents[1]


def load(path):
    sr, raw = wavfile.read(path)
    x = raw.astype(np.float64)
    if x.ndim > 1:
        x = x.mean(1)
    if np.issubdtype(raw.dtype, np.integer):
        x /= float(np.iinfo(raw.dtype).max)
    g = np.gcd(int(sr), 48000)
    x = resample_poly(x, 48000 // g, int(sr) // g) if sr != 48000 else x
    pk = np.abs(x).max()
    return x * (0.9 / pk) if pk > 0 else x


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("spec", nargs="?", help="JSON spec (samples, bpm, scene)")
    ap.add_argument("--wav", nargs="*", help="WAV files instead of a spec")
    ap.add_argument("--bpm", type=float, default=120.0)
    ap.add_argument("--q", type=float, default=18.0)
    ap.add_argument("--out", default=str(ROOT / "library"))
    a = ap.parse_args()
    if a.spec:
        spec = json.loads(Path(a.spec).read_text())
        base = Path(a.spec).resolve().parent
        items = [dict(s, file=str(base / s["file"])) for s in spec["samples"]]
        bpm = spec.get("bpm", a.bpm)
        q = spec.get("q", a.q)
        scene = spec.get("scene")
    elif a.wav:
        items = [{"file": f, "name": Path(f).stem[:8].upper()} for f in a.wav]
        bpm, q, scene = a.bpm, a.q, None
    else:
        ap.error("give a spec or --wav files")
    cfg = ext.config(8000)
    samples, names = [], []
    t0 = time.time()
    for it in items:
        x48 = load(it["file"])
        core = C.to_i16(resample_poly(x48, 8000, 48000))
        blocks, dec, _, seeds = svbrr2.search(core, it.get("q", q), 512)
        core48 = resample_poly(C.from_i16(dec), 48000, 8000)[:len(x48)]
        codes, ton, hf_off = ext.analyse(x48, core48, cfg, 'auto')
        side = C.pack_side(codes.astype(np.uint8), ton.astype(np.uint8))
        samples.append(dict(blocks=blocks, core_len=len(core), side=side, n_frames=codes.shape[0], hf_off=hf_off,
                            loop=(0, len(core)), root=60, dec=dec, seeds=seeds))
        names.append(it.get("name", Path(it["file"]).stem)[:8].upper())
        print(f"  {names[-1]:8s} {len(x48) / 48000:6.2f} s", flush=True)
    blob, parts = svbrr2.build(samples, 512)
    blob += bytes(8)
    ct = svbrr2.Container(blob)
    for i, s in enumerate(samples):
        if not np.array_equal(svbrr2.decode_all(ct, i), s["dec"]):
            raise SystemExit(f"sample {i}: decode mismatch (encoder bug)")
    if not scene:
        beat = 8000 * 60 / bpm
        scene = [{"si": min(k, len(samples) - 1), "start": 0,
                  "beats": max(b for b in (1, 2, 4, 8, 16, 32) if b * beat <= max(samples[min(k, len(samples) - 1)]["core_len"], beat))}
                 for k in range(4)]
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "library.svbr").write_bytes(blob)
    (out / "manifest.json").write_text(json.dumps(
        {"bpm": bpm, "samples": [{"name": n} for n in names], "scene": scene}, indent=1))
    import analyse_library                                  # onset maps: slices and audio grooves
    analyse_library.main(str(out / "library.svbr"), str(out / "onsets.json"))
    secs = sum(s["core_len"] for s in samples) / 8000
    print(f"library: {len(blob)} B for {secs:.1f} s ({len(blob) / 1000 / secs * 60:.1f} KB/min), {len(samples)} samples, "
          f"bit-exact; parts {parts} [{time.time() - t0:.0f} s]")
    if len(blob) > BUDGET:
        print(f"WARNING: over the {BUDGET} B budget: shorten samples or lower q", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
