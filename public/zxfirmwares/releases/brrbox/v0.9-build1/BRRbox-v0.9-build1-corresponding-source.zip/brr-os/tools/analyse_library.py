#!/usr/bin/env python3
"""library/library.svbr -> library/onsets.json: the onset map of every sample.

The firmware uses it natively:
  TAPE SLC  jumps to onset slices (keys play slices when SYN is off),
  GRV TK1-4 builds a groove table from the onsets inside a TAPE track's loop,
so the sequencer can play in the pocket of the sampled audio.

Detection runs on the decoded 8 kHz core (what the device actually plays): spectral flux with one
frame every 4 ms (the codec's own grid), refined to the sample.
encode_library.py runs this automatically; run it by hand after editing a library some other way.
Needs numpy (and the encoder modules next to this file)."""
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent / "encoder"))
import svbrr2  # noqa: E402

MAX_ONSETS = 255


def onsets(dec):
    """spectral flux on the 8 kHz core, one frame every 4 ms (two codec blocks): 256-sample Hann
    frames, positive log-magnitude rises summed over bins, an adaptive threshold (moving median +
    margin), local peaks at least 60 ms apart; each refined to the sample where the first difference
    first exceeds 35 % of its local peak."""
    x = dec.astype(np.float64) / 32768.0
    n = len(x)
    if n < 512:
        return [(0, 255)]
    nb = n // 32
    pad = np.concatenate([np.zeros(224), x, np.zeros(256)])
    win = np.hanning(256)
    fr = np.stack([pad[b * 32:b * 32 + 256] * win for b in range(nb)])
    mag = np.abs(np.fft.rfft(fr, axis=1)) ** 0.5            # (a log would amplify the codec noise floor)
    flux = np.concatenate([[mag[0].sum() * 0.25], np.maximum(mag[1:] - mag[:-1], 0.0).sum(1)])
    med = np.array([np.median(flux[max(0, b - 25):b + 6]) for b in range(nb)])
    thr = np.maximum(med + 0.5 * flux.std(), 0.08 * flux.max()) + 1e-6
    d = np.abs(np.diff(x, prepend=x[:1]))
    fe = 10 * np.log10((fr ** 2).sum(1) + 1e-12)
    he = 10 * np.log10((np.diff(fr, axis=1) ** 2).sum(1) + 1e-12)
    floor = fe.max() - 40.0
    out, last = [], -100
    for b in range(nb):
        # a keyframe (every 16 blocks) restarts the predictor: in a quiet decaying tail its noise can change
        # character, so there the flux has to clear twice the threshold
        k = 2.0 if (b % 16 == 0 and b > 0) else 1.0
        if flux[b] <= k * thr[b] or fe[b] < floor or b - last < 15:
            continue
        if flux[b] < flux[max(0, b - 2):b + 3].max():
            continue                                   # not the local peak
        if b > 0 and fe[b] - fe[max(0, b - 8):b].min() < 2.0 and he[b] - he[max(0, b - 8):b].min() < 2.0:
            continue                                   # no energy rise: a steady tone's frames beating
        lo = max(0, b - 2) * 32
        seg = d[lo:(b + 1) * 32 + 32]
        i = lo + int(np.argmax(seg > 0.35 * seg.max())) if seg.max() > 0 else b * 32
        out.append((i, int(min(255, max(1, 64 * flux[b] / (thr[b] + 1e-9))))))
        last = b
    return out[:MAX_ONSETS] or [(0, 255)]


def main(lib="library/library.svbr", out="library/onsets.json"):
    root = Path(__file__).resolve().parents[1]
    lib, out = root / lib if not Path(lib).is_absolute() else Path(lib), root / out if not Path(out).is_absolute() else Path(out)
    ct = svbrr2.Container(lib.read_bytes())
    res = []
    for i in range(len(ct.samples)):
        on = onsets(svbrr2.decode_all(ct, i))
        res.append({"pos": [p for p, _ in on], "str": [s for _, s in on]})
    out.write_text(json.dumps({"onsets": res}))
    print(f"onsets: {sum(len(r['pos']) for r in res)} in {len(res)} samples -> {out}")


if __name__ == "__main__":
    main(*sys.argv[1:])
