#!/usr/bin/env python3
"""Build BRR-OS for the M-Vave SMK-37: the app, the update loader and an installable .fwsc package.

  tools/build.py [--model pro|elite|mke] [--release X.Y] [--sdk PATH]

Outputs in build/: brros.bin (app), loader/ota.bin (update loader), brros-smk37[-elite|-mke].fwsc.
Needs the JieLi Linux toolchain (JIELI_TOOLCHAIN, tools/get_toolchain.sh; native on Linux x86-64,
Docker elsewhere) and the JieLi AC79 SDK checkout (AC79_SDK or --sdk) for three package files.

Adapted from Felucca's tools/build.py (GPL-3.0, Leo Kuroshita / Hügelton Instruments; SMK-37 target by
genkigenki): the loader build, the image layout and the checks are theirs, the app is BRR-OS."""
import argparse
import hashlib
import os
import platform
import re
import shutil
import struct
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
FW = SRC / "firmware"
OUT = SRC / "build"
GEN = OUT / "gen"
LDR = OUT / "loader"
sys.path.insert(0, str(SRC / "tools"))
import fm1pkg_make  # noqa: E402
import lz4blk  # noqa: E402

APP_XIP = 0x02000120                # app.bin offset 0 in the XIP map; the SPL jumps here
LOADER_LOAD = 0x01C0A800
LOADER_NAME = b"usb_hid_ota.bin"    # the file name the SPL looks for
DOCKER_IMAGE = os.environ.get("JIELI_DOCKER_IMAGE", "debian:bookworm-slim")
# AC79NN SDK V1.2.1 wl82 Makefile: AC791N is PI32v2 r3 with FP revision 1.
# Without these target flags the driver defaults to soft-float and link fails (__mulsf3).
CFLAGS = ["-mcpu=r3", "-mfprev1", "-Os", "-ffunction-sections", "-fno-builtin", "-Wall", "-Wno-unused-function"]
LINE = re.compile(r"^\s*([0-9a-f]+):\s+((?:[0-9a-f]{2} )+)\s*\t(.*)$")
SDK_SHA256 = {
    "uboot.boot": "4e3b4c220dc96641cb5a723f41e68ce41d5261ae9434bb33fbd7f2c59976ded4",
    "cfg_tool.bin": "276579954f076886a6a7694f65dc71c034a63a2c204b76749065c0ac7b010d1b",
    "cfg/eq_cfg_hw.bin": "41167491bffed4651750719c973d2758adeb9021a5670d02d6a53c85ed80ea7d",
}
MODELS = {"pro": "SMK-37 Pro", "elite": "SMK-37 Elite", "mke": "MKE-P37"}
BOARD_DEFS = ["-DBOARD_SMK37=1"]
CPU2 = False                     # --cpu2: the second core built in (beta); default: one core, nothing of it
PRODUCT = "SMK-37 Pro_900"
VERSION = None
APP_SLOT = 0


def toolchain():
    tc = os.environ.get("JIELI_TOOLCHAIN")
    if not tc or not (Path(tc) / "pi32v2" / "bin" / "clang").exists():
        raise SystemExit("JIELI_TOOLCHAIN must point at the JieLi Linux toolchain "
                         "(the directory with pi32v2/ and common/; see tools/get_toolchain.sh)")
    return Path(tc).resolve()


def use_docker():
    native = platform.system() == "Linux" and platform.machine() in ("x86_64", "AMD64")
    return os.environ.get("JIELI_DOCKER", "0" if native else "1") == "1"


def tc(tool, *args):
    """run a toolchain binary (pi32v2/bin/..., common/bin/...) with cwd SRC; paths relative to SRC"""
    rel = [str(Path(a).resolve().relative_to(SRC)) if isinstance(a, Path) else a for a in args]
    if tool == "cc":
        tool, rel = "pi32v2/bin/clang", ["-target", "pi32v2", *rel]
    if use_docker():
        cmd = ["docker", "run", "--rm", "--platform", "linux/amd64", "-v", f"{SRC}:/work",
               "-v", f"{toolchain()}:/opt/jieli:ro", "-w", "/work", DOCKER_IMAGE, f"/opt/jieli/{tool}", *rel]
    else:
        cmd = [str(toolchain() / tool), *rel]
    r = subprocess.run(cmd, cwd=SRC, capture_output=True, text=True)
    if r.returncode:
        sys.stderr.write(r.stdout + r.stderr)
        raise SystemExit(f"build: {tool} failed")
    if r.stderr.strip():
        sys.stderr.write(r.stderr)
    return r.stdout


def tc_all(*cmds):
    with ThreadPoolExecutor(len(cmds)) as ex:
        return list(ex.map(lambda c: tc(*c), cmds))


def generate():
    GEN.mkdir(parents=True, exist_ok=True)
    subprocess.run([sys.executable, SRC / "tools" / "gen_font.py", FW / "src" / "os_font_data.h"], check=True)
    subprocess.run([sys.executable, SRC / "tools" / "make_library_h.py", SRC / "library" / "library.svbr",
                    SRC / "library" / "manifest.json", GEN / "os_library.h"], check=True)


# ---- update loader (Felucca's, unchanged; the SMK-37 build)

def crc16(d, c=0):
    for b in d:
        c ^= b << 8
        for _ in range(8):
            c = ((c << 1) ^ 0x1021) if c & 0x8000 else c << 1
        c &= 0xFFFF
    return c


def ldr_head(dcrc, a, b, attr, name):
    body = struct.pack("<HIIBBH16s", dcrc, a, b, attr, 0, 0, name)
    return struct.pack("<H", crc16(body)) + body


def ldr_wrap(image):
    blocks = bytearray()
    for i in range(0, len(image), 4096):
        raw = image[i:i + 4096]
        c = lz4blk.compress(raw)
        if len(c) > 4096 or lz4blk.decompress(c) != raw:
            raise SystemExit(f"loader: block {i // 4096} does not compress below 4096 B")
        blocks += struct.pack("<II", len(c), len(raw)) + c
    inner = ldr_head(crc16(image), len(image), LOADER_LOAD, 0, LOADER_NAME)
    body = inner + bytes(blocks)
    return ldr_head(crc16(body), 0x20, len(body), 0x41, LOADER_NAME) + body


def build_loader():
    LDR.mkdir(parents=True, exist_ok=True)
    src = FW / "loader"
    flags = [*CFLAGS, *BOARD_DEFS, "-Ifirmware/hal", "-Ifirmware/src"]
    tc_all(("cc", "-c", src / "crt0_ldr.S", "-o", LDR / "crt0_ldr.o"),
           ("cc", *flags, "-c", src / "loader.c", "-o", LDR / "loader.o"))
    elf = LDR / "loader.elf"
    tc("pi32v2/bin/ld", "--gc-sections", "-e", "_start", "-T", src / "loader.ld",
       LDR / "crt0_ldr.o", LDR / "loader.o", "-o", elf)
    _, dis, hdr, syms = tc_all(("common/bin/objcopy", "-O", "binary", "-j", ".text", elf, LDR / "loader.bin"),
                               ("common/bin/objdump", "-d", elf),
                               ("common/bin/objdump", "-h", elf),
                               ("common/bin/objdump", "-t", elf))
    (LDR / "loader.dis").write_text(dis)
    for ln in hdr.splitlines():     # the loader rewrites the flash: nothing may run from XIP
        p = ln.split()
        if len(p) > 4 and p[1].startswith(".") and int(p[3], 16) >= 0x02000000 and int(p[2], 16):
            raise SystemExit(f"loader: section {p[1]} at {p[3]} is outside RAM")
    image = (LDR / "loader.bin").read_bytes()
    if not image or len(image) > 0x14000:
        raise SystemExit("loader: image empty or too big")
    ota = ldr_wrap(image)
    (LDR / "ota.bin").write_bytes(ota)
    print(f"loader: image {len(image)} B, ota.bin {len(ota)} B")
    return ota


# ---- app

def ld_regions():
    regs = {}
    for m in re.finditer(r"^\s*(\w+)\s*\([rwx]+\)\s*:\s*ORIGIN\s*=\s*(\w+),\s*LENGTH\s*=\s*(\w+)",
                         (FW / "app.ld").read_text(), re.M):
        n = m.group(3)
        regs[m.group(1)] = (int(m.group(2), 0), int(n[:-1], 0) * 1024 if n.endswith("K") else int(n, 0))
    return regs


def build_app():
    flags = [*CFLAGS, *BOARD_DEFS, "-Ifirmware/hal", "-Ifirmware/src", "-Ibuild/gen", f'-DFELUCCA_ID="{PRODUCT}"',
             f"-DOS_CPU2={1 if CPU2 else 0}"]
    if VERSION:
        flags.append(f'-DOS_VERSION="{VERSION}"')
    (OUT / "fm1_cpu1.o").unlink(missing_ok=True)
    tc_all(("cc", "-c", FW / "crt0.S", "-o", OUT / "crt0.o"),
           ("cc", "-c", FW / "hal" / "fm1_vec.S", "-o", OUT / "fm1_vec.o"),
           ("cc", "-c", FW / "hal" / "fm1_isr.S", "-o", OUT / "fm1_isr.o"),
           *([("cc", "-c", FW / "hal" / "fm1_cpu1.S", "-o", OUT / "fm1_cpu1.o")] if CPU2 else []),
           ("cc", *flags, "-c", FW / "src" / "os.c", "-o", OUT / "os.o"))
    elf = OUT / "brros.elf"
    txt = (FW / "app.ld").read_text()        # the SMK-37 app slot as the XIP length
    if txt.count("LENGTH = 0x8DFBC") != 1:
        raise SystemExit("app.ld: the XIP LENGTH line was not found")
    ld = OUT / "app.ld"
    ld.write_text(txt.replace("LENGTH = 0x8DFBC", f"LENGTH = {APP_SLOT:#x}"))
    tc("pi32v2/bin/ld", "-T", ld, OUT / "crt0.o", OUT / "fm1_vec.o", OUT / "fm1_isr.o",
       *([OUT / "fm1_cpu1.o"] if CPU2 else []), OUT / "os.o", "-o", elf)
    for sect in ("text.bin", "data.bin", "ramtext.bin", "c1text.bin"):
        (OUT / sect).unlink(missing_ok=True)
    *_, syms, dis, rt = tc_all(("common/bin/objcopy", "-O", "binary", "-j", ".text", elf, OUT / "text.bin"),
                               ("common/bin/objcopy", "-O", "binary", "-j", ".data", elf, OUT / "data.bin"),
                               ("common/bin/objcopy", "-O", "binary", "-j", ".ram_text", elf, OUT / "ramtext.bin"),
                               *([("common/bin/objcopy", "-O", "binary", "-j", ".c1_text", elf, OUT / "c1text.bin")]
                                 if CPU2 else []),
                               ("common/bin/objdump", "-t", elf),
                               ("common/bin/objdump", "-d", elf),
                               ("common/bin/objdump", "-d", "-j", ".ram_text", *(("-j", ".c1_text") if CPU2 else ()),
                                elf))
    (OUT / "brros.dis").write_text(dis)

    def symv(name):
        m = re.search(r"^([0-9a-f]+) .*\s" + name + r"$", syms, re.M)
        if not m:
            raise SystemExit(f"symbol {name} missing")
        return int(m.group(1), 16)
    img = bytearray((OUT / "text.bin").read_bytes())
    for sect, lname in (("ramtext.bin", "_rt_load"), ("c1text.bin", "_c1_load"), ("data.bin", "_data_load")):
        load = symv(lname)
        if load % 4:
            raise SystemExit(f"{lname} {load:#x} is not word aligned")
        blob = (OUT / sect).read_bytes() if (OUT / sect).exists() else b""
        if blob:
            if load - APP_XIP < len(img):
                raise SystemExit(f"{lname} overlaps the image")
            img += b"\xff" * (load - APP_XIP - len(img))
            img += blob
    img += b"\xff" * (-len(img) % 4)
    (OUT / "brros.bin").write_bytes(img)
    return bytes(img), syms, dis, rt


def check(img, syms, rt):
    errors, notes = [], []
    m = re.search(r"^([0-9a-f]+) .*\s_start$", syms, re.M)
    if not m or int(m.group(1), 16) != APP_XIP:
        errors.append(f"_start is not at {APP_XIP:#x}")
    if img[:4] != bytes.fromhex("04818000"):
        errors.append(f"image starts with {img[:4].hex()}, not the entry stub")
    # RAM code runs with the flash off: no calls into XIP. The second core's waiting loop (.c1_text) calls only its
    # job, through the pointer core 0 handed it (a register: "call rN")
    sect, rt_calls, c1_calls, c1_insns = None, [], [], 0
    for ln in rt.splitlines():
        mm = re.match(r"^Disassembly of section (\S+):", ln)
        if mm:
            sect = mm.group(1)
            continue
        if not LINE.match(ln):
            continue
        if sect == ".c1_text":
            c1_insns += 1
            if re.search(r"\bcall\b", ln) and not re.search(r"\bcall\s+r\d+\b", ln):
                c1_calls.append(ln.strip())
        elif re.search(r"\bcall\b", ln):
            rt_calls.append(ln.strip())
    if rt_calls:
        errors.append(f".ram_text contains calls: {rt_calls[:3]}")
    c1_syms = re.findall(r"\s(fm1_c1_\w+|_c1_ustack\w*|_c1_sstack\w*)$", syms, re.M)
    if not CPU2:
        if c1_insns or c1_syms:
            errors.append(f"one-core build holds second-core code or data: {sorted(set(c1_syms))[:4]}")
        else:
            notes.append("one core: no second-core code, stack or mailbox")
    elif c1_calls:
        errors.append(f".c1_text calls other than its job: {c1_calls[:3]}")
    elif not c1_insns:
        errors.append(".c1_text: the second core's waiting loop is missing (firmware/hal/fm1_cpu1.h fm1_c1_main)")
    else:
        notes.append(f"second core built in: .c1_text {c1_insns} insns, only its job called")
    if len(img) > APP_SLOT:
        errors.append(f"image {len(img)} B exceeds the app slot {APP_SLOT} B")

    def sym(name):
        mm = re.search(r"^([0-9a-f]+) .*\s" + name + r"$", syms, re.M)
        return int(mm.group(1), 16) if mm else 0
    region = ld_regions()
    ram_org, ram_len = region["RAM"]
    pool_len = region["POOL"][1]
    bss = sym("_bss_end") - ram_org
    pool = sym("_pool_end") - sym("_pool_start")
    lib = sym("OS_LIB")
    notes.append(f"image {len(img)} B of {APP_SLOT} (library {lib and 'in image'}); RAM .data+.bss {bss} B of "
                 f"{ram_len}; pool {pool} B of {pool_len}")
    if ram_len - bss < 4096:
        errors.append(f"RAM headroom {ram_len - bss} B < 4096 B")
    if pool_len - pool < 8192:
        errors.append(f"pool headroom {pool_len - pool} B < 8192 B")
    return errors, notes


# Every register access lives in hal/ (Felucca's rule, kept): no MMIO literal, volatile pointer cast or
# inline asm (except the empty RING_PUBLISH barrier) in src/ and loader/.
MMIO_LIT = re.compile(r"\b0x0*(1[0-3][0-9a-f]{3}|4[0-3][0-9a-f]{3}|5[01][0-9a-f]{3}|1ee[0-9a-f]{4}|"
                      r"1c7f[0-9a-f]{3}|20[0-9a-f]{5})u?l?\b", re.I)
MMIO_CAST = re.compile(r"\(\s*(?:const\s+)?volatile\b[^()]*\*\s*\)(?!\s*&)")
MMIO_ASM = re.compile(r"\b(?:__asm__|asm)\b(?!\s+volatile\s*\(\s*\"\"\s*:::\s*\"memory\"\s*\))")


def mmio_check():
    def strip(s):
        s = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), s, flags=re.S)
        return re.sub(r"//[^\n]*", "", s)
    defs = {}
    for h in sorted((FW / "hal").glob("*.h")):
        for m in re.finditer(r"^#define\s+(\w+)(?:\([^)]*\))?\s+(.*)$", strip(h.read_text()), re.M):
            defs[m.group(1)] = m.group(2)
    regs = {n for n, b in defs.items() if re.search(r"\bvolatile\b", b)}
    while True:
        more = {n for n, b in defs.items() if n not in regs and set(re.findall(r"\w+", b)) & regs}
        if not more:
            break
        regs |= more
    errors = []
    for f in sorted([*(FW / "src").glob("*.[ch]"), *(FW / "loader").glob("*.c")]):
        if f.name == "os_library.h":
            continue
        for no, ln in enumerate(strip(f.read_text()).splitlines(), 1):
            where = f"{f.relative_to(FW)}:{no}"
            for rx, what in ((MMIO_LIT, "register/window address"), (MMIO_CAST, "volatile pointer cast"),
                             (MMIO_ASM, "inline asm")):
                m = rx.search(ln)
                if m:
                    errors.append(f"{where}: {what} outside hal/ ({m.group(0).strip()})")
            used = set(re.findall(r"\b[A-Z_][A-Z0-9_]*\b", ln)) & regs
            if used:
                errors.append(f"{where}: HAL register macro {sorted(used)[0]} outside hal/")
    return errors


def main():
    global PRODUCT, VERSION, APP_SLOT, CPU2
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", choices=sorted(MODELS), default=None, help="pro (default), elite or mke ($MODEL)")
    ap.add_argument("--release", metavar="X.Y", help="release build: identity <model>_9XY, version vX.Y")
    ap.add_argument("--cpu2", action="store_true", help="build the second core in (beta: it takes tracks when it "
                    "answers; on a unit that misreads, it is stopped and one core does everything)")
    ap.add_argument("--sdk", type=Path, help="JieLi AC79 SDK checkout (default: $AC79_SDK)")
    a = ap.parse_args()
    model = (a.model or os.environ.get("MODEL") or "pro").lower()
    if model not in MODELS:
        raise SystemExit(f"MODEL={model}: pro, elite or mke")
    fm1pkg_make.set_board("smk37")
    APP_SLOT = fm1pkg_make.APP_SLOT
    PRODUCT = fm1pkg_make.BOARDS["smk37"][2]
    stem = "brros-smk37"
    if model != "pro":               # the model's name: identity, loader and update record (fm1_cc.h SMK_MODEL)
        BOARD_DEFS.append(f'-DSMK_MODEL="{MODELS[model]}"')
        PRODUCT = PRODUCT.replace(MODELS["pro"], MODELS[model])
        stem += "-" + model
    CPU2 = a.cpu2 or os.environ.get("OS_CPU2") == "1"
    if CPU2:
        stem += "-cpu2"
    name = f"{stem}.fwsc"
    if a.release:
        m = re.fullmatch(r"(\d)\.(\d)(?:\.\d){0,2}(-[A-Za-z0-9]+)?", a.release)
        if not m:
            raise SystemExit(f"--release {a.release}: X.Y, one digit each")
        PRODUCT = f"{MODELS[model]}_9{m[1]}{m[2]}"
        VERSION = "v" + a.release.lower()
        name = f"{stem}-{a.release}.fwsc"
    fm1pkg_make.SDK = a.sdk
    for rel, sha in SDK_SHA256.items():
        if hashlib.sha256(fm1pkg_make.sdk_file(rel)).hexdigest() != sha:
            print(f"warning: SDK {rel} differs from AC79NN_SDK_V1.2.1")
    OUT.mkdir(parents=True, exist_ok=True)
    generate()
    ota = build_loader()
    img, syms, dis, rt = build_app()
    errors, notes = check(img, syms, rt)
    errors += mmio_check()
    for n in notes:
        print("  ok   ", n)
    for e in errors:
        print("  FAIL ", e)
    if errors:
        raise SystemExit("build: checks failed")
    pkg = fm1pkg_make.ufw(fm1pkg_make.flash_image(img, fm1pkg_make.KEY), ota, PRODUCT)
    (OUT / name).write_bytes(pkg)
    print(f"app      {OUT / 'brros.bin'}  {len(img)} B")
    print(f"package  {OUT / name}  {len(pkg)} B, identity {PRODUCT}")
    print(f"sha256   {hashlib.sha256(pkg).hexdigest()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
