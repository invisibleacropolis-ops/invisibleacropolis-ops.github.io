"""4-bit BRR core codec + bandwidth-extension ("make 12 kHz sound like 24 kHz") tricks.

Everything that the decoder needs is written to real byte streams so sizes
are measured, not estimated:
  - BRR core: SNES-style 9-byte blocks (1 header + 16 x 4-bit residuals)
  - Side info: per 20 ms frame, 4-bit relative band energies (+2-bit tonality)
"""
import numpy as np
from scipy.signal import butter, sosfiltfilt, resample_poly, hilbert, lfilter

OUT_SR = 48000

# ----------------------------------------------------------------------------
# BRR (SNES S-DSP style) -----------------------------------------------------
# ----------------------------------------------------------------------------
_F = np.repeat(np.arange(4), 13)          # filter index per combo
_S = np.tile(np.arange(13), 4)            # shift per combo


def _predict(p1, p2, f):
    """Integer predictors exactly as the S-DSP computes them."""
    pr1 = p1 + ((-p1) >> 4)
    pr2 = 2 * p1 + ((-3 * p1) >> 5) - p2 + (p2 >> 4)
    pr3 = 2 * p1 + ((-13 * p1) >> 6) - p2 + ((3 * p2) >> 4)
    return np.where(f == 0, 0, np.where(f == 1, pr1, np.where(f == 2, pr2, pr3)))


def brr_encode(x):
    """x: int array (16-bit range). Returns bytes (9 bytes per 16 samples)."""
    x = np.asarray(x, np.int64)
    pad = (-len(x)) % 16
    x = np.concatenate([x, np.zeros(pad, np.int64)])
    nblk = len(x) // 16
    out = bytearray()
    p1 = p2 = 0
    scale = (2.0 ** _S) / 2.0
    for b in range(nblk):
        blk = x[b * 16:(b + 1) * 16]
        P1 = np.full(52, p1, np.int64)
        P2 = np.full(52, p2, np.int64)
        err = np.zeros(52)
        nibs = np.zeros((52, 16), np.int64)
        for i in range(16):
            pred = _predict(P1, P2, _F)
            r = blk[i] - pred
            nib = np.clip(np.round(r / scale), -8, 7).astype(np.int64)
            d = np.clip(pred + ((nib << _S) >> 1), -32768, 32767)
            e = blk[i] - d
            err += e * e
            nibs[:, i] = nib
            P2, P1 = P1, d
        k = int(np.argmin(err))
        p1, p2 = int(P1[k]), int(P2[k])
        flags = 1 if b == nblk - 1 else 0          # END flag on last block
        out.append((int(_S[k]) << 4) | (int(_F[k]) << 2) | flags)
        nb = nibs[k] & 0xF
        for i in range(0, 16, 2):
            out.append(int((nb[i] << 4) | nb[i + 1]))
    return bytes(out)


def brr_decode(data):
    data = np.frombuffer(data, np.uint8)
    nblk = len(data) // 9
    y = np.zeros(nblk * 16, np.int64)
    p1 = p2 = 0
    for b in range(nblk):
        h = int(data[b * 9])
        s, f = h >> 4, (h >> 2) & 3
        by = data[b * 9 + 1:b * 9 + 9].astype(np.int64)
        nib = np.empty(16, np.int64)
        nib[0::2] = by >> 4
        nib[1::2] = by & 0xF
        nib = np.where(nib > 7, nib - 16, nib)
        for i in range(16):
            pred = int(_predict(np.int64(p1), np.int64(p2), np.int64(f)))
            d = max(-32768, min(32767, pred + ((int(nib[i]) << s) >> 1)))
            y[b * 16 + i] = d
            p2, p1 = p1, d
    return y


# ----------------------------------------------------------------------------
# Helpers --------------------------------------------------------------------
# ----------------------------------------------------------------------------
def to_i16(x):
    return np.clip(np.round(x * 32767), -32768, 32767).astype(np.int64)


def from_i16(y):
    return y.astype(np.float64) / 32767.0


def band(x, lo, hi, sr=OUT_SR, order=6):
    if hi >= sr / 2:
        sos = butter(order, lo, 'high', fs=sr, output='sos')
    else:
        sos = butter(order, [lo, hi], 'band', fs=sr, output='sos')
    return sosfiltfilt(sos, x)


PRE_A = 0.6


def preemph(x, a=PRE_A):
    return lfilter([1.0, -a], [1.0], x) * 0.6   # headroom: max gain 1.6 -> ~0.96


def deemph(x, a=PRE_A):
    return lfilter([1.0], [1.0, -a], x) / 0.6


def core_encode_decode(x48, core_sr, pre=False):
    """Downsample, BRR encode, decode, upsample to 48 kHz. Returns (y48, nbytes)."""
    x = resample_poly(x48, core_sr, OUT_SR)
    if pre:
        x = preemph(x)
    data = brr_encode(to_i16(x))
    y = from_i16(brr_decode(data))[: len(x)]
    if pre:
        y = deemph(y)
    y48 = resample_poly(y, OUT_SR, core_sr)[: len(x48)]
    return y48, data


# ----------------------------------------------------------------------------
# Bandwidth extension --------------------------------------------------------
# ----------------------------------------------------------------------------
FRAME = 768            # 16 ms at 48 kHz = 128 core samples: 4 side frames per keyframe (SVB4)
HOP = 192              # 4 ms analysis hop for temporal shaping (4 per frame)
REF_BAND = (3000, 6000)


def make_bands(top):
    edges = [6000, 6800, 7700, 8700, 9800, 11000, 12000]
    if top > 12000:
        edges += [13600, top]
    return list(zip(edges[:-1], edges[1:]))


def hop_energy(x, hop=HOP):
    n = len(x) // hop
    return (x[: n * hop].reshape(n, hop) ** 2).mean(axis=1) + 1e-12


def frame_energy(x):
    n = len(x) // FRAME
    return (x[: n * FRAME].reshape(n, FRAME) ** 2).mean(axis=1) + 1e-12


def spectral_flatness_frames(x):
    """Per-frame spectral flatness of signal (already band-limited)."""
    n = len(x) // FRAME
    fr = x[: n * FRAME].reshape(n, FRAME) * np.hanning(FRAME)
    P = np.abs(np.fft.rfft(fr, axis=1)) ** 2 + 1e-14
    lo, hi = int(6000 / OUT_SR * FRAME), int(12000 / OUT_SR * FRAME)
    P = P[:, lo:hi]
    return np.exp(np.log(P).mean(1)) / P.mean(1)


# relative-energy quantiser: 4 bits, 3 dB steps, -39 .. +6 dB vs core 3-6 kHz band
Q_STEP, Q_MIN = 3.0, -39.0


def encode_side(x48, core48, bands, tonality=False):
    """Encoder: measure original high-band energies relative to the *decoded*
    core's 3-6 kHz energy (closed loop), quantise to 4 bits per band."""
    ref = frame_energy(band(core48, *REF_BAND))
    codes = []
    for lo, hi in bands:
        e = frame_energy(band(x48, lo, hi))
        rel = 10 * np.log10(e / ref)
        codes.append(np.clip(np.round((rel - Q_MIN) / Q_STEP), 0, 15).astype(np.uint8))
    codes = np.stack(codes, 1)                    # frames x bands
    ton = None
    if tonality:
        sfm = spectral_flatness_frames(band(x48, 6000, 12000))
        # flatness ~1 => noise, ~0 => tonal. map to 4 levels of "tonal weight".
        tw = np.clip(1 - sfm * 2.2, 0, 1)
        ton = np.clip(np.round(tw * 3), 0, 3).astype(np.uint8)
    return codes, ton


def pack_side(codes, ton):
    """Bit-pack side info. Returns bytes."""
    bits = []
    for f in range(codes.shape[0]):
        for c in codes[f]:
            bits.extend((int(c) >> k) & 1 for k in (3, 2, 1, 0))
        if ton is not None:
            bits.extend((int(ton[f]) >> k) & 1 for k in (1, 0))
    bits += [0] * ((-len(bits)) % 8)
    return np.packbits(np.array(bits, np.uint8)).tobytes()


def unpack_side(data, nframes, nbands, tonality):
    bits = np.unpackbits(np.frombuffer(data, np.uint8))
    per = nbands * 4 + (2 if tonality else 0)
    bits = bits[: nframes * per].reshape(nframes, per)
    codes = np.zeros((nframes, nbands), np.uint8)
    for bnd in range(nbands):
        b4 = bits[:, bnd * 4:bnd * 4 + 4]
        codes[:, bnd] = b4[:, 0] * 8 + b4[:, 1] * 4 + b4[:, 2] * 2 + b4[:, 3]
    ton = None
    if tonality:
        t2 = bits[:, nbands * 4:nbands * 4 + 2]
        ton = t2[:, 0] * 2 + t2[:, 1]
    return codes, ton


# --- high-band sources (all generated from the decoded core only) ----------
def src_mirror(core48, top):
    """Spectral image: what an unfiltered 12 kHz->48 kHz upsample produces."""
    t = np.arange(len(core48)) / OUT_SR
    return core48 * np.cos(2 * np.pi * 12000 * t) * 2.0


def src_copy(core48, top):
    """SBR-style patching: single-sideband shift the 3-6 kHz band up by 3k, 6k, (9k)."""
    a = hilbert(band(core48, *REF_BAND))
    t = np.arange(len(core48)) / OUT_SR
    out = np.zeros(len(core48))
    for shift in (3000, 6000, 9000, 12000):
        if 3000 + shift >= top:
            break
        out += np.real(a * np.exp(2j * np.pi * shift * t))
    return out


def src_exciter(core48, top):
    """Harmonic exciter: rectify the upper core band -> real (2f, 4f ...) harmonics."""
    hb = band(core48, 2500, 6000)
    return np.abs(hb) + 0.5 * np.tanh(4 * hb) * np.abs(hb)


def src_noise(core48, top, seed=7):
    return np.random.default_rng(seed).standard_normal(len(core48))


def shape_band(src, lo, hi, target_frame_e, temporal_ref=None):
    """Band-limit a source and scale it so its energy follows the target.
    target_frame_e: per-20 ms target energy. temporal_ref: optional per-5 ms
    energy curve whose *shape* within each frame is imposed (transients)."""
    s = band(_unit(src), lo, hi)
    per = FRAME // HOP
    if temporal_ref is None:
        # frame-level gain: keeps the source's own intra-frame envelope
        fe = frame_energy(s)
        nf = min(len(fe), len(target_frame_e))
        g = np.minimum(np.sqrt(target_frame_e[:nf] / fe[:nf]), 300.0)
        centers = (np.arange(nf) + 0.5) * FRAME
    else:
        # hop-level gain: frame energy from side info, intra-frame shape from
        # the decoded core's 3-6 kHz envelope (temporal envelope shaping)
        he = hop_energy(s)
        nh = len(he)
        nf = nh // per
        r = temporal_ref[: nf * per].reshape(nf, per)
        r = r / r.mean(1, keepdims=True)
        tgt = (target_frame_e[:nf, None] * r).ravel()
        g = np.minimum(np.sqrt(tgt / he[: nf * per]), 300.0)
        centers = (np.arange(nf * per) + 0.5) * HOP
    gs = np.interp(np.arange(len(s)), centers, g)
    return s * gs


def decode_hf(core48, side_bytes, bands, mode, tonality, temporal):
    nframes = len(core48) // FRAME
    codes, ton = unpack_side(side_bytes, nframes, len(bands), tonality)
    ref = frame_energy(band(core48, *REF_BAND))[:nframes]
    top = bands[-1][1]
    srcs = {
        'mirror': lambda: src_mirror(core48, top),
        'copy': lambda: src_copy(core48, top),
        'exciter': lambda: src_exciter(core48, top),
        'noise': lambda: src_noise(core48, top),
    }
    tref = hop_energy(band(core48, *REF_BAND)) if temporal else None
    if mode == 'full':
        harm = 0.5 * _unit(srcs['copy']()) + 0.5 * _unit(srcs['exciter']())
        noise = srcs['noise']()
    else:
        harm = srcs[mode]()
        noise = None
    hf = np.zeros(len(core48))
    for bi, (lo, hi) in enumerate(bands):
        rel = Q_MIN + codes[:, bi].astype(float) * Q_STEP
        tgt = ref * 10 ** (rel / 10)
        if noise is not None and ton is not None:
            tw = ton.astype(float) / 3.0
            h = shape_band(harm, lo, hi, tgt * tw + 1e-14, tref)
            nz = shape_band(noise, lo, hi, tgt * (1 - tw) + 1e-14, tref)
            hf += h + nz
        else:
            hf += shape_band(harm, lo, hi, tgt, tref)
    return core48 + hf


def _unit(x):
    return x / (np.sqrt(np.mean(x ** 2)) + 1e-12)
