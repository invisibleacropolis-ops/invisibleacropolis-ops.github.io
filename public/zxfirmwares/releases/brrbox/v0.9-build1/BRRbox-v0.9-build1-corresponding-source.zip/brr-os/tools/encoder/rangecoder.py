"""Adaptive multi-symbol arithmetic coder (32-bit, carry-less with underflow
handling, after Nayuki's reference design). Encoder and decoder share one
interface, code(model, sym), so a single 'syntax' function drives both."""

STATE_BITS = 32
FULL = 1 << STATE_BITS
HALF = FULL >> 1
QUARTER = HALF >> 1
MASK = FULL - 1


class Model:
    """Adaptive frequency model over symbols 0..n-1."""
    __slots__ = ('n', 'f', 'total', 'inc', 'limit')

    def __init__(self, n, inc=24, limit=1 << 16):
        self.n = n
        self.f = [1] * n
        self.total = n
        self.inc = inc
        self.limit = limit

    def lo_hi(self, s):
        f = self.f
        lo = sum(f[:s])
        return lo, lo + f[s]

    def find(self, value):
        f = self.f
        c = 0
        for s in range(self.n):
            if value < c + f[s]:
                return s, c, c + f[s]
            c += f[s]
        raise ValueError('bad value')

    def update(self, s):
        self.f[s] += self.inc
        self.total += self.inc
        if self.total > self.limit:
            self.f = [(v + 1) >> 1 for v in self.f]
            self.total = sum(self.f)


class _Base:
    def __init__(self):
        self.low = 0
        self.high = MASK

    def _narrow(self, lo, hi, total):
        rng = self.high - self.low + 1
        self.high = self.low + hi * rng // total - 1
        self.low = self.low + lo * rng // total
        while ((self.low ^ self.high) & HALF) == 0:
            self._shift()
            self.low = (self.low << 1) & MASK
            self.high = ((self.high << 1) & MASK) | 1
        while (self.low & ~self.high & QUARTER) != 0:
            self._underflow()
            self.low = (self.low << 1) ^ HALF
            self.high = ((self.high ^ HALF) << 1) | HALF | 1


class Encoder(_Base):
    def __init__(self):
        super().__init__()
        self.bits = []
        self.pending = 0

    def _shift(self):
        b = self.low >> (STATE_BITS - 1)
        self.bits.append(b)
        self.bits.extend([b ^ 1] * self.pending)
        self.pending = 0

    def _underflow(self):
        self.pending += 1

    def code(self, m, s):
        lo, hi = m.lo_hi(s)
        self._narrow(lo, hi, m.total)
        m.update(s)
        return s

    def raw(self, v, nbits):
        """Uniform value, up to 16 bits per call."""
        out = 0
        while nbits > 0:
            k = min(nbits, 16)
            nbits -= k
            part = (v >> nbits) & ((1 << k) - 1)
            self._narrow(part, part + 1, 1 << k)
            out = (out << k) | part
        return out

    def finish(self):
        self.bits.append(1)
        bits = self.bits + [0] * ((-len(self.bits)) % 8)
        out = bytearray()
        for i in range(0, len(bits), 8):
            byte = 0
            for b in bits[i:i + 8]:
                byte = (byte << 1) | b
            out.append(byte)
        return bytes(out)


class Decoder(_Base):
    def __init__(self, data):
        super().__init__()
        self.data = data
        self.pos = 0
        self.code_ = 0
        for _ in range(STATE_BITS):
            self.code_ = (self.code_ << 1) | self._bit()

    def _bit(self):
        i = self.pos
        self.pos += 1
        if i >> 3 >= len(self.data):
            return 0
        return (self.data[i >> 3] >> (7 - (i & 7))) & 1

    def _shift(self):
        self.code_ = ((self.code_ << 1) & MASK) | self._bit()

    def _underflow(self):
        self.code_ = (self.code_ & HALF) | ((self.code_ << 1) & (MASK >> 1)) | self._bit()

    def _value(self, total):
        rng = self.high - self.low + 1
        return ((self.code_ - self.low + 1) * total - 1) // rng

    def code(self, m, s_ignored=None):
        v = self._value(m.total)
        s, lo, hi = m.find(v)
        self._narrow(lo, hi, m.total)
        m.update(s)
        return s

    def raw(self, v_ignored, nbits):
        out = 0
        while nbits > 0:
            k = min(nbits, 16)
            nbits -= k
            part = self._value(1 << k)
            self._narrow(part, part + 1, 1 << k)
            out = (out << k) | part
        return out
