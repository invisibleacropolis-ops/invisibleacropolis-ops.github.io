"""VBRR: variable-bit-rate BRR-style predictive core codec.

Changes from SNES BRR
- Block of 16 samples (2 ms; SVB2/3 used 32); 256-sample macro blocks.
- Per block the encoder picks 0, 1, 2, 3 or 4 bits per sample.
  0 bits: decoder just runs the predictor (silence, decays, held tones).
  1-4 bits: midrise quantiser, levels (2k+1)*half, so 1 bit = +/-half.
- 8 second-order predictors (the 4 SNES ones + 4 more), Q12 integer maths.
- 32 step sizes in 3 dB steps (BRR: 13 shifts in 6 dB steps).
- Perceptual target per block: allowed noise = masked block energy - q dB.
  The encoder takes the fewest bits that meet it.
- Optional lossy repetition: a macro block may be a gain-scaled copy of
  earlier *decoded* audio (lag + gain), if that meets the same target.
- Everything (headers, residuals, copy params) goes through an adaptive
  arithmetic coder. The decoder below parses the real bytes.
"""
import numpy as np
from numba import njit
from scipy.signal import fftconvolve

import rangecoder as rc

BLK = 16                 # the codec block: 2 ms at 8 kHz (BRR-OS v0.3: the one-clock grid)
MB = 256
SUB = MB // BLK
A_FLOAT = [(0, 0), (0.9375, 0), (1.90625, -0.9375), (1.796875, -0.8125),
           (1.5, -0.625), (1.96875, -0.98), (0.5, 0), (-0.5, 0)]
A1 = np.array([round(a * 4096) for a, _ in A_FLOAT], np.int64)
A2 = np.array([round(b * 4096) for _, b in A_FLOAT], np.int64)
NF = len(A_FLOAT)
NS = 32
HALF = np.array([max(1, round(2 ** (s / 2))) for s in range(NS)], np.int64)
GAINS = np.array([10 ** ((g - 12) * 1.5 / 20) for g in range(16)])
LAG_BITS = 18


@njit(cache=True)
def _synth(p1, p2, f, mode, half, ks, out):
    for i in range(BLK):
        pred = (A1[f] * p1 + A2[f] * p2 + 2048) >> 12
        if mode > 0:
            v = pred + (2 * ks[i] + 1) * half
        else:
            v = pred
        if v > 32767:
            v = 32767
        elif v < -32768:
            v = -32768
        out[i] = v
        p2 = p1
        p1 = v
    return p1, p2


@njit(cache=True)
def _search(x, p1, p2, target):
    """Exhaustive search for one 32-sample block.
    Returns mode, filter, scale, ks, err."""
    best_err = np.full(5, 1e30)
    best_f = np.zeros(5, np.int64)
    best_s = np.zeros(5, np.int64)
    ks = np.zeros(BLK, np.int64)
    for f in range(NF):                       # mode 0
        q1, q2, e = p1, p2, 0.0
        for i in range(BLK):
            v = (A1[f] * q1 + A2[f] * q2 + 2048) >> 12
            v = min(32767, max(-32768, v))
            d = x[i] - v
            e += d * d
            q2 = q1
            q1 = v
        if e < best_err[0]:
            best_err[0] = e
            best_f[0] = f
    for mode in range(1, 5):
        kmin = -(1 << (mode - 1))
        kmax = (1 << (mode - 1)) - 1
        for f in range(NF):
            for s in range(NS):
                h = HALF[s]
                q1, q2, e = p1, p2, 0.0
                for i in range(BLK):
                    pred = (A1[f] * q1 + A2[f] * q2 + 2048) >> 12
                    r = x[i] - pred
                    k = int(np.floor(r / (2.0 * h)))
                    k = min(kmax, max(kmin, k))
                    v = pred + (2 * k + 1) * h
                    v = min(32767, max(-32768, v))
                    d = x[i] - v
                    e += d * d
                    if e > best_err[mode]:
                        break
                    q2 = q1
                    q1 = v
                if e < best_err[mode]:
                    best_err[mode] = e
                    best_f[mode] = f
                    best_s[mode] = s
    mode = 4
    for m in range(5):
        if best_err[m] <= target:
            mode = m
            break
    f = best_f[mode]
    s = best_s[mode]
    # re-run the winner to get its residual indices
    if mode > 0:
        kmin = -(1 << (mode - 1))
        kmax = (1 << (mode - 1)) - 1
        h = HALF[s]
        q1, q2 = p1, p2
        for i in range(BLK):
            pred = (A1[f] * q1 + A2[f] * q2 + 2048) >> 12
            k = int(np.floor((x[i] - pred) / (2.0 * h)))
            k = min(kmax, max(kmin, k))
            ks[i] = k
            v = min(32767, max(-32768, pred + (2 * k + 1) * h))
            q2 = q1
            q1 = v
    return mode, f, s, ks, best_err[mode]


def block_targets(x, q, floor_db=-66.0):
    """Allowed squared error per 32-sample block (sum), with simple
    temporal masking (post-masking decays over two blocks, a little pre)."""
    xb = x[: len(x) // BLK * BLK].astype(np.float64).reshape(-1, BLK)
    E = (xb ** 2).mean(1)
    Em = E.copy()
    Em[1:] = np.maximum(Em[1:], 0.5 * E[:-1])
    Em[2:] = np.maximum(Em[2:], 0.25 * E[:-2])
    Em[:-1] = np.maximum(Em[:-1], 0.3 * E[1:])
    floor = (32767 * 10 ** (floor_db / 20)) ** 2
    return np.maximum(Em * 10 ** (-q / 10), floor) * BLK


class Models:
    def __init__(self):
        self.copy = rc.Model(2)
        self.same = rc.Model(2)
        self.gain = rc.Model(16)
        self.mode = [rc.Model(5) for _ in range(5)]      # context: previous mode
        self.filt = [rc.Model(NF) for _ in range(5)]     # context: mode
        self.dscale = rc.Model(2 * NS - 1)
        self.res = [None] + [rc.Model(1 << m) for m in range(1, 5)]


def _syntax(C, n_mb, decisions, dec_out):
    """Shared by encoder and decoder. decisions: list (encoder) or None.
    dec_out: int64 array to fill with decoded samples (decoder side)."""
    M = Models()
    p1 = p2 = 0
    prev_mode = 0
    prev_scale = 16
    prev_lag = 0
    out_blk = np.zeros(BLK, np.int64)
    for mb in range(n_mb):
        d = decisions[mb] if decisions is not None else None
        pos = mb * MB
        is_copy = C.code(M.copy, 1 if (d and d['copy']) else 0)
        if is_copy:
            lag = d['lag'] if d else 0
            same = C.code(M.same, 1 if (d and lag == prev_lag) else 0)
            if same:
                lag = prev_lag
            else:
                lag = C.raw(lag, LAG_BITS)
            g = C.code(M.gain, d['gain'] if d else 0)
            src = dec_out[pos - lag: pos - lag + MB].astype(np.float64)
            seg = np.clip(np.round(GAINS[g] * src), -32768, 32767).astype(np.int64)
            dec_out[pos:pos + MB] = seg
            p1, p2 = int(seg[-1]), int(seg[-2])
            prev_lag = lag
            continue
        for sb in range(SUB):
            b = d['blocks'][sb] if d else None
            mode = C.code(M.mode[prev_mode], b[0] if b else 0)
            f = C.code(M.filt[mode], b[1] if b else 0)
            ks = np.zeros(BLK, np.int64)
            half = 0
            if mode > 0:
                ds = C.code(M.dscale, (b[2] - prev_scale + NS - 1) if b else 0)
                s = prev_scale + ds - (NS - 1)
                prev_scale = s
                half = int(HALF[s])
                off = 1 << (mode - 1)
                rm = M.res[mode]
                for i in range(BLK):
                    ks[i] = C.code(rm, (int(b[3][i]) + off) if b else 0) - off
            p1, p2 = _synth(p1, p2, f, mode, half, ks, out_blk)
            dec_out[pos + sb * BLK: pos + (sb + 1) * BLK] = out_blk
            prev_mode = mode
    return dec_out


def encode(x, q, repeat=False, copy_tol=1.0):
    """x: int64 core samples. Returns (bytes, decoded, stats)."""
    n = len(x)
    n_mb = -(-n // MB)
    xp = np.zeros(n_mb * MB, np.int64)
    xp[:n] = x
    tg = block_targets(xp, q)
    dec = np.zeros(n_mb * MB, np.int64)
    decisions = []
    p1 = p2 = 0
    prev_lag = 0
    stats = dict(mode_samples=[0] * 5, copy_samples=0)
    cum = np.concatenate([[0.0], np.cumsum(np.zeros(0))])
    for mb in range(n_mb):
        pos = mb * MB
        t = xp[pos:pos + MB].astype(np.float64)
        tsum = tg[mb * SUB:(mb + 1) * SUB].sum() * copy_tol
        if repeat and pos >= 2 * MB:
            h = dec[:pos].astype(np.float64)
            best = None
            # cheap check: same lag as last copy
            if prev_lag and pos - prev_lag >= 0:
                cand = [prev_lag]
            else:
                cand = []
            corr = fftconvolve(h, t[::-1], mode='valid')        # index j = start
            e2 = np.concatenate([[0.0], np.cumsum(h * h)])
            hh = e2[MB:] - e2[:-MB]
            hh = hh[: len(corr)]
            j_max = pos - MB                                    # lag >= MB
            corr = corr[: j_max + 1]
            hh = hh[: j_max + 1]
            j_min = max(0, pos - (1 << LAG_BITS) + 1)
            score = np.where(hh > 1e-9, corr * corr / np.maximum(hh, 1e-9), 0)
            score[:j_min] = 0
            if len(score):
                cand.append(pos - int(np.argmax(score)))
            for lag in cand:
                src = h[pos - lag: pos - lag + MB]
                if len(src) < MB:
                    continue
                den = np.dot(src, src)
                if den <= 0:
                    continue
                g_opt = np.dot(t, src) / den
                if g_opt <= 0:
                    continue
                gi = int(np.clip(np.round(20 * np.log10(g_opt) / 1.5 + 12), 0, 15))
                seg = np.clip(np.round(GAINS[gi] * src), -32768, 32767)
                err = np.sum((t - seg) ** 2)
                if err <= tsum and (best is None or err < best[0]):
                    best = (err, lag, gi, seg.astype(np.int64))
                    if lag == prev_lag:
                        break
            if best is not None:
                _, lag, gi, seg = best
                dec[pos:pos + MB] = seg
                p1, p2 = int(seg[-1]), int(seg[-2])
                prev_lag = lag
                decisions.append(dict(copy=True, lag=lag, gain=gi))
                stats['copy_samples'] += MB
                continue
        blocks = []
        out_blk = np.zeros(BLK, np.int64)
        for sb in range(SUB):
            i0 = pos + sb * BLK
            mode, f, s, ks, _ = _search(xp[i0:i0 + BLK], p1, p2, tg[mb * SUB + sb])
            half = int(HALF[s]) if mode > 0 else 0
            p1, p2 = _synth(p1, p2, f, mode, half, ks, out_blk)
            dec[i0:i0 + BLK] = out_blk
            blocks.append((mode, f, s, ks.copy()))
            stats['mode_samples'][mode] += BLK
        decisions.append(dict(copy=False, blocks=blocks))
    E = rc.Encoder()
    _syntax(E, n_mb, decisions, np.zeros(n_mb * MB, np.int64))
    data = E.finish()
    return data, dec[:n], stats


def decode(data, n):
    n_mb = -(-n // MB)
    D = rc.Decoder(data)
    out = _syntax(D, n_mb, None, np.zeros(n_mb * MB, np.int64))
    return out[:n]
