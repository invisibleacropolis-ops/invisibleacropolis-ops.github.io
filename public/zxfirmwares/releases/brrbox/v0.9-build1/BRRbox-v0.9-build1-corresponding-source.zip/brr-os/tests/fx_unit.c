/* SPDX-License-Identifier: GPL-3.0-only */
/* Unit tests of each track's effects (os_tfx.c): echo timing (the n-th echo exactly on n x the time), ping-pong
 * order, the 8-bit block-float line's and the 16-bit head's noise on a decoded loop, the phaser's notches.
 *   gcc -O2 -std=gnu11 -I. -I../firmware/src -I../build/gen -o fx_unit fx_unit.c -lm && ./fx_unit
 * (v0.6: echoes at 3100 6100 9100 12100, x0.5 each; PING L R L R; 48.2 dB and 71.3 dB; writes phaser.f32) */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "host_stubs.h"
#include "os_core.h"
#include "os_font.c"
#define SV_API static
#include "svbrr_dec.c"
#include "os_fx.c"
#include "os_regs.c"
#include "os_flt.c"
#include "os_hf.c"
#include "os_tfx.c"
#include "os_mod.c"
#include "os_mach.c"
#include "os_shp.c"
#include "os_seq.c"
#include "os_engine.c"

#define N 48000
static float L[N], R[N];

static void run(uint32_t k, uint32_t n)
{
    uint32_t c;
    for (c = 0; c < n; c += BLK) {
        float M[BLK], S[BLK];
        uint32_t i;
        tx_block(k, c);
        for (i = 0; i < BLK; i++) { M[i] = 0.5f * (L[c + i] + R[c + i]); S[i] = 0.5f * (L[c + i] - R[c + i]); }
        tx_run(k, M, S, BLK, c);
        for (i = 0; i < BLK; i++) { L[c + i] = M[i] + S[i]; R[c + i] = M[i] - S[i]; }
    }
}

static void setup(void)
{
    memset(&os, 0, sizeof os);
    os_engine_init();
    os.fx_on = 1;
    os.bpb = 250;                                           /* 120 BPM: 1/64 bar = 250 samples */
}

int main(void)
{
    trk_t *t = &os.trk[0];
    uint32_t i, k;
    /* 1. ST delay 3/16 (n = 12: 3000 samples), FBK +0.5, wet only */
    setup(); t = &os.trk[0];
    t->eff[R_TIM] = 56 + 12; t->eff[R_FBK] = 64 + 33; t->eff[R_MIX] = 127; t->eff[R_DEP] = 0; t->eff[R_COL] = 64;
    t->eff[R_RAT] = 40; t->eff[R_DEP] = 0; t->eff[R_DIS] = 0; t->eff[R_DIS] = 0; t->eff[R_PNG] = 0; t->eff[R_REV] = 0;
    memset(L, 0, sizeof L); memset(R, 0, sizeof R); L[100] = R[100] = 0.5f;
    run(0, 16000);
    printf("ST echoes (expect 3100 6100 9100 12100, x0.5 each):");
    for (k = 1; k < 5; k++) { uint32_t best = 0; float bv = 0; for (i = 100 + k * 3000 - 50; i < 100 + k * 3000 + 50; i++) if (fabsf(L[i]) > bv) { bv = fabsf(L[i]); best = i; } printf(" %u(%.3f)", best, bv); }
    printf("\n");
    /* 2. ping-pong: L at d, R at 2d, L at 3d */
    setup(); t = &os.trk[0];
    t->eff[R_TIM] = 56 + 12; t->eff[R_FBK] = 64 + 33; t->eff[R_MIX] = 127; t->eff[R_COL] = 64; t->eff[R_RAT] = 40; t->eff[R_DEP] = 0; t->eff[R_DIS] = 0; t->eff[R_PNG] = 1;
    memset(L, 0, sizeof L); memset(R, 0, sizeof R); L[100] = R[100] = 0.5f;
    run(0, 16000);
    printf("PING:");
    for (k = 1; k < 5; k++) { uint32_t j = 100 + k * 3000; printf(" t=%u L %.3f R %.3f |", j, L[j], R[j]); }
    printf("\n");
    /* 3. block-float noise: a decoded loop through a 1 s delay, wet only, vs the input itself */
    {
        static int16_t raw[200000]; static float x[N];
        uint32_t d = 8000;
        double se = 0, ss = 0;
        setup(); t = &os.trk[0];
        sv_decode_all(&os.lib, 3, raw, 200000);
        for (i = 0; i < N; i++) x[i] = raw[i + 20000] * (1.0f / 32768.0f);
        t->eff[R_TIM] = 56 + 32; t->eff[R_FBK] = 64; t->eff[R_MIX] = 127; t->eff[R_COL] = 64; t->eff[R_RAT] = 40; t->eff[R_DEP] = 0; t->eff[R_DIS] = 0; t->eff[R_PNG] = 0;
        os.bpb = 250;
        for (i = 0; i < N; i++) L[i] = R[i] = x[i];
        run(0, N);
        for (i = d + 100; i < N; i++) { double e = L[i] - x[i - d]; se += e * e; ss += (double)x[i - d] * x[i - d]; }
        printf("block-float line, 1 s delay of a loop: SNR %.1f dB (8-bit, one pass)\n", 10 * log10(ss / se));
        /* the same through the 16-bit head (d = 400) */
        setup(); t = &os.trk[0];
        t->eff[R_TIM] = 56 + 1; t->eff[R_FBK] = 64; t->eff[R_MIX] = 127; t->eff[R_COL] = 64; t->eff[R_RAT] = 40; t->eff[R_DEP] = 0; t->eff[R_DIS] = 0;
        os.bpb = 500; se = ss = 0;
        for (i = 0; i < N; i++) L[i] = R[i] = x[i];
        run(0, N);
        for (i = 500; i < N; i++) { double e = L[i] - x[i - 500]; se += e * e; ss += (double)x[i - 500] * x[i - 500]; }
        printf("16-bit head, 62.5 ms delay: SNR %.1f dB\n", 10 * log10(ss / se));
    }
    /* 4. phaser: white noise, TIM 0, DIS at ~600 Hz, DEP 0, MIX 64: write the output for a spectrum */
    {
        uint32_t s = 1;
        FILE *f;
        setup(); t = &os.trk[0];
        t->eff[R_TIM] = 0; t->eff[R_FBK] = 64; t->eff[R_MIX] = 64; t->eff[R_COL] = 64; t->eff[R_RAT] = 40; t->eff[R_DEP] = 0; t->eff[R_DIS] = 50;
        for (i = 0; i < N; i++) { s = s * 1664525u + 1013904223u; L[i] = R[i] = ((float)(s >> 8) / 16777216.0f - 0.5f) * 0.5f; }
        run(0, N);
        f = fopen("phaser.f32", "wb"); fwrite(L, 4, N, f); fclose(f);
        printf("phaser centre %.0f Hz written\n", reg_fx_dis_hz(50));
    }
    return 0;
}
