/* SPDX-License-Identifier: GPL-3.0-only */
/* Unit tests of patterns and the song (os_seq.c): a song of two patterns of different lengths lands each one
 * on the exact clock sample the last one ends; a cued pattern waits for the playing one's end; each pattern
 * keeps its own STP / SPD; trig conditions count on while a pattern repeats and restart with a new one; a
 * short track restarts with its pattern; a pattern set to 2 bars plays its 1-bar tracks twice.
 *   gcc -O2 -std=gnu11 -I. -I../firmware/src -I../build/gen -o seq_unit seq_unit.c -lm && ./seq_unit */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "host_stubs.h"
#include "os_core.h"
#include "os_font.c"
#define SV_API static
#include "svbrr_dec.c"
#include "os_fx.c"
#include "os_regs.c"
#include "os_flt.c"
#include "os_hf.c"
#include "os_tfx.c"
#include "os_mod.c"
#include "os_mach.c"
#include "os_shp.c"
#include "os_seq.c"
#include "os_engine.c"

static int fails;
static void check(int ok, const char *what) { printf("  [%s] %s\n", ok ? " ok " : "FAIL", what); if (!ok) fails++; }
static int32_t out[HALF_FRAMES * 2u];

/* the notes that started, per track: (clock sample - transport start, note) */
#define LOGN 256
static struct { uint32_t at; uint8_t note; } lg[NTRACK][LOGN];
static uint32_t lgn[NTRACK];

static void run_bars(double bars)
{
    uint32_t end = os.clock + (uint32_t)(bars * (double)seq_bar()), k, i;
    while ((int32_t)(os.clock - end) < 0) {
        uint32_t c0 = os.clock;
        os_render(out, HALF_FRAMES);
        for (k = 0; k < NTRACK; k++)
            for (i = 0; i < POLY_MAX; i++) {
                pv_t *p = &pool[k][i];
                if (p->used && (int32_t)(p->on_at - c0) >= 0 && (int32_t)(p->on_at - os.clock) < 0 && lgn[k] < LOGN) {
                    lg[k][lgn[k]].at = p->on_at - os.play_c0;
                    lg[k][lgn[k]].note = p->note;
                    lgn[k]++;
                }
            }
    }
}
static void fresh(void)
{
    uint32_t k;
    seq_play(0);
    seq_init();
    for (k = 0; k < NTRACK; k++) {
        trk_set_machine(&os.trk[k], MA_WAVE);
        os.trk[k].base[R_VOI] = 7;
        os.trk[k].base[R_STP] = 15;
        os.trk[k].base[R_SPD] = 3;
    }
    memset(lgn, 0, sizeof lgn);
}
/* the log of track k as "bar.step:note" for a message, and as a string to compare */
static const char *show(uint32_t k)
{
    static char b[512];
    uint32_t i, n = 0, st = (uint32_t)os.bpb * 4u;
    b[0] = 0;
    for (i = 0; i < lgn[k] && n < sizeof b - 16u; i++) {
        uint32_t s = lg[k][i].at / st;
        n += (uint32_t)snprintf(b + n, sizeof b - n, "%s%u.%u%s:%u", i ? " " : "", s / 16u, s % 16u, lg[k][i].at % st ? "~" : "", lg[k][i].note);
    }
    return b;
}

int main(void)
{
    char b[640];
    if (os_engine_init()) { fprintf(stderr, "library did not open\n"); return 1; }
    os.bpb = 125;                                 /* 240 BPM: quick bars */

    printf("a song: A (1 bar) x2, B (2 bars, 32 steps) x1, looped\n");
    fresh();
    seq_put_note(&seq_pat[0][0], 0, 60, 100, 0, 4, 0);
    seq_put_note(&seq_pat[1][0], 0, 72, 100, 0, 4, 0);
    seq_put_note(&seq_pat[1][0], 16, 74, 100, 0, 4, 0);
    seq_hdr[1].stp[0] = 31;
    seq_song[0] = SONG_ROW(0, 2); seq_song[1] = SONG_ROW(1, 1); seq_song_n = 2;
    os.song_on = 1;
    seq_play(1);
    run_bars(8.5);
    snprintf(b, sizeof b, "track 1: %s", show(0));
    check(!strcmp(show(0), "0.0:60 1.0:60 2.0:72 3.0:74 4.0:60 5.0:60 6.0:72 7.0:74 8.0:60"), b);
    check(os.trk[0].base[R_STP] == 15u && seq_hdr[1].stp[0] == 31u, "each pattern its own STP: A 16 steps again, B kept its 32");

    printf("a cue waits for the playing pattern's end\n");
    fresh();
    seq_put_note(&seq_pat[0][0], 0, 60, 100, 0, 4, 0);
    seq_put_note(&seq_pat[2][0], 0, 67, 100, 0, 4, 0);
    seq_hdr[0].bars = 2;                          /* A: 2 bars, its 16-step track twice */
    seq_play(1);
    run_bars(0.6);
    seq_pat_select(2);                            /* cued 0.6 bars in: C comes in at bar 2 */
    run_bars(3.0);
    snprintf(b, sizeof b, "A at 2 bars plays its 1-bar track twice, then C: %s", show(0));
    check(!strcmp(show(0), "0.0:60 1.0:60 2.0:67 3.0:67"), b);

    printf("trig conditions\n");
    fresh();
    seq_put_note(&seq_pat[0][0], 0, 60, 100, 0, 4, CD_1_2);
    seq_put_note(&seq_pat[0][0], 8, 62, 100, 0, 4, CD_1ST);
    seq_put_note(&seq_pat[1][0], 0, 72, 100, 0, 4, CD_1_2);
    seq_song[0] = SONG_ROW(0, 3); seq_song[1] = SONG_ROW(1, 3); seq_song_n = 2;
    os.song_on = 1;
    seq_play(1);
    run_bars(6.2);
    snprintf(b, sizeof b, "1:2 counts on through A's three passes, 1ST once, B starts from 0 again, A again from 0: %s", show(0));
    check(!strcmp(show(0), "0.0:60 0.8:62 2.0:60 3.0:72 5.0:72 6.0:60"), b);

    printf("a short track restarts with its pattern\n");
    fresh();
    os.trk[1].base[R_STP] = 2;                    /* 3 steps */
    seq_put_note(&seq_pat[0][1], 0, 60, 100, 0, 2, 0);
    seq_play(1);
    run_bars(1.95);
    snprintf(b, sizeof b, "3 steps in a 1-bar pattern: %s", show(1));
    check(!strcmp(show(1), "0.0:60 0.3:60 0.6:60 0.9:60 0.12:60 0.15:60 1.0:60 1.3:60 1.6:60 1.9:60 1.12:60 1.15:60"), b);
    fresh();
    os.trk[1].base[R_STP] = 2;
    seq_hdr[0].bars = 0;
    seq_put_note(&seq_pat[0][1], 0, 60, 100, 0, 2, 0);
    seq_put_note(&seq_pat[0][0], 0, 50, 100, 0, 2, 0);
    os.trk[0].base[R_STP] = 47;                   /* 48 steps: AUTO is 3 bars */
    seq_play(1);
    run_bars(3.2);
    snprintf(b, sizeof b, "AUTO follows the longest track (48 steps: 3 bars); the 3-step track phases across them, %u notes", lgn[1]);
    check(pat_len(0) == 3u * seq_bar() && lgn[1] == 18u && lg[1][16].at == 3u * seq_bar(), b);

    printf("stopped, a pattern is chosen at once\n");
    fresh();
    os.trk[0].base[R_STP] = 7;
    seq_pat_select(3);
    check(os.pat == 3u && os.trk[0].base[R_STP] == 15u && seq_hdr[0].stp[0] == 7u, "pattern 4 in, pattern 1's 8 steps kept in its header");
    printf("the shared event heap\n");
    {
        uint32_t it, j, bad = 0, full = 0;
        static uint16_t model[NLIST];
        seq_init();
        srand(5);
        for (it = 0; it < 60000u; it++) {
            uint32_t L = (uint32_t)rand() % NLIST, op = (uint32_t)rand() % 10u;
            evl_t *l = &seq_all[L];
            if (op < 7u) {
                ev_t e = {(uint8_t)(rand() % 256), (uint8_t)(rand() % 3), (int16_t)(rand() % 4000 - 2000), (uint8_t)L, (uint8_t)rand(), 0, 0};
                if (evl_insert(l, &e) >= 0) model[L]++; else full++;
            } else if (op < 9u) {
                if (l->n) { evl_delete(l, (uint32_t)rand() % l->n); model[L]--; }
            } else if (rand() % 20 == 0) { evl_clear(l); model[L] = 0; }
            if (it % 997u == 0u || it == 59999u) {              /* contiguous, sorted, each event in its own list */
                uint32_t sum = 0;
                for (j = 0; j < NLIST; j++) {
                    uint32_t i;
                    sum += seq_all[j].n;
                    if (seq_all[j].n != model[j]) bad++;
                    if (j && seq_all[j].e != seq_all[j - 1u].e + seq_all[j - 1u].n) bad++;
                    for (i = 0; i < seq_all[j].n; i++) {
                        const ev_t *x = &seq_all[j].e[i];
                        if (x->a != j) bad++;
                        if (i && (x[-1].step > x->step || (x[-1].step == x->step && x[-1].kind > x->kind))) bad++;
                    }
                }
                if (sum != seq_used || seq_all[0].e != seq_heap) bad++;
            }
        }
        snprintf(b, sizeof b, "60000 random inserts, deletes, clears over the 40 lists: %u in use, %u refused when full, %u faults", seq_used, full, bad);
        check(!bad, b);
        while (evl_insert(&seq_all[(uint32_t)rand() % NLIST], &(ev_t){(uint8_t)(rand() % 256), 0, 0, 60, 100, 8, 0}) >= 0) {}
        snprintf(b, sizeof b, "filled: refused at exactly %u events (EV_HEAP %u)", seq_used, EV_HEAP);
        check(seq_used == EV_HEAP, b);
        seq_init();
    }
    printf("scenes\n");
    fresh();
    {
        trk_t *t = &os.trk[1];
        uint32_t ok = 1, a;
        t->base[R_CUT] = 100;
        scene_write(2, 1, R_CUT, 20); scene_write(5, 1, R_CUT, 60); scene_write(5, 1, R_RES, 90);
        trk_resolve(t, 1);
        check(t->eff[R_CUT] == 100u && t->eff[R_RES] == t->base[R_RES], "no scene in: the base");
        for (a = 0; a <= 127u; a++) {             /* one scene: exact at both ends, rounded to nearest between */
            int32_t want = (int32_t)floor(100.0 + (20.0 - 100.0) * a / 127.0 + 0.5);
            scene_on(2, a ? a : 1); trk_resolve(t, 1);
            if (a && (int32_t)t->eff[R_CUT] != want) ok = 0;
        }
        check(ok && t->eff[R_CUT] == 20u, "scene 3 by its amount: 100 -> 20, nearest at every amount, 20 at 127");
        scene_on(5, 127); trk_resolve(t, 1);
        check(t->eff[R_CUT] == 60u && t->eff[R_RES] == 90u, "scene 6 in after it: on top where both set CUT; its RES too");
        scene_on(5, 64); trk_resolve(t, 1);
        snprintf(b, sizeof b, "scene 6 at half over scene 3 at full: CUT %u (20 + 40 x 64/127 = 40)", t->eff[R_CUT]);
        check(t->eff[R_CUT] == 40u, b);
        scene_off(2); trk_resolve(t, 1);
        snprintf(b, sizeof b, "scene 3 out: scene 6 at half over the base: CUT %u (100 - 40 x 64/127 = 80)", t->eff[R_CUT]);
        check(t->eff[R_CUT] == 80u && scs.n == 1u, b);
        scene_on(2, 127); trk_resolve(t, 1);
        check(t->eff[R_CUT] == 20u && scs.ord[0] == 5u && scs.ord[1] == 2u, "scene 3 back in: now the newest, on top");
        t->lock[R_CUT] = 77; trk_resolve(t, 1);
        check(t->eff[R_CUT] == 77u, "a lock still wins over the scenes");
        t->lock[R_CUT] = 0xFF;
        scene_clear(2); trk_resolve(t, 1);
        check(t->eff[R_CUT] == 80u && !scn_any(2), "scene 3 cleared: it sets nothing");
        scene_off(2); scene_off(5);
    }
    printf("\n%s (%d failed)\n", fails ? "FAILED" : "all passed", fails);
    return fails != 0;
}
