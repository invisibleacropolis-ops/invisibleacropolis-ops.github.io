/* SPDX-License-Identifier: GPL-3.0-only */
/* The filter design (os_flt.c) against the analog prototype: impulses through the designed SVF, their response vs
 * |H| of the prototype over 50 Hz - 3.9 kHz (amplitude-weighted), LP / BP / HP x 16 cutoffs x 5 Q.
 *   gcc -O2 -std=gnu11 -I. -I../firmware/src -o flt_unit flt_unit.c -lm && ./flt_unit   (v0.6: 1.09 dB mean, 7.6 worst) */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "host_stubs.h"
#include "os_core.h"
#include "os_fx.c"
#include "os_flt.c"
#define NI 8192
int main(void)
{
    static const float FC[] = {40, 100, 400, 818, 1500, 2000, 3000, 3300, 3400, 3571, 4500, 6164, 8000, 10074, 16000, 20000};
    static const float Q[] = {0.5f, 0.71f, 2.0f, 5.1f, 16.0f};
    static float h[NI];
    double tot = 0, worst = 0; int cnt = 0;
    uint32_t typ, a, b, i, j;
    for (typ = 1; typ <= 3; typ++) {
        printf("%s", typ == 1 ? "LP" : typ == 2 ? "BP" : "HP");
        for (a = 0; a < sizeof FC / sizeof FC[0]; a++) {
            for (b = 0; b < 5; b++) {
                flt_c c; flt_s s = {0, 0};
                double em = 0, wsum = 0;
                flt_design(typ, FC[a], Q[b], 8000.0f, &c);
                for (i = 0; i < NI; i++) h[i] = flt_tick(&s, &c, i == 0 ? 1.0f : 0.0f);
                for (j = 0; j < 200; j++) {
                    double f = 50 + j * (3850.0 / 199), re = 0, im = 0, t, e, w;
                    for (i = 0; i < NI; i++) { re += h[i] * cos(2 * M_PI * f * i / 8000); im -= h[i] * sin(2 * M_PI * f * i / 8000); }
                    t = flt_ana(typ, FC[a], Q[b], (float)f);
                    if (t < 1e-6) continue;
                    e = fabs(10 * log10(re * re + im * im + 1e-30) - 10 * log10(t));
                    w = sqrt(t); em += e * w; wsum += w;
                }
                em /= wsum; tot += em; cnt++; if (em > worst) worst = em;
            }
        }
        printf(" done\n");
    }
    printf("matched design vs the analog prototype: mean of weighted means %.2f dB, worst %.2f (v0.6: 1.09 / 7.62)\n", tot / cnt, worst);
    return 0;
}
