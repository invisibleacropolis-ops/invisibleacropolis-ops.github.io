/* SPDX-License-Identifier: GPL-3.0-only */
/* Runs BRR-OS v0.8's own code on the host (machines, sequencer, feel, UI, rebuild, effects, decoder) through a
 * scripted session played with the real gestures: pads, hold + turn, held keys, the views. Writes sim.wav
 * (stereo 16-bit at the DAC rate), screen_*.rgb565, sections.txt, timing.txt and stats on stdout.
 *   bars 0-4    programmed: TAPE loop (sync), a KIT (hold step + keys), WAVE chords (keys + tap), a GRAN cloud
 *   bar  4      live-recorded bells on track 4, played with a human feel (stamped like the TIMER5 scan)
 *   bars 5-7    FEEL 100 %  as played          bars 7-9   FEEL 0 %  the machine
 *   bars 9-11   FEEL 150 %  exaggerated        bars 11-13 FEEL -100 % inverted
 *   bars 13-15  FEEL 100 % + the kit takes your pocket (GRV LRN)
 *   bars 15-17  the kit plays in the pocket of the tape loop (GRV TK1, from the encoder's onset map)
 *   bars 17-20  scenes: scene 1 latched in (tight, dark), the mod wheel brings scene 2 (loose, open) in on top
 *   bars 20-23  the submix: the kit spread, its highs wide (page E OUT); the master's glue and air (FX x3 -> MASTER)
 *   bars 23-30  each track's own effects (pages F, G): the kit through a synced ping-pong (3/16), the WAVE chords
 *               in a chorus that TIM morphs into a flanger, the tape loop through a synced phaser, the kit's
 *               reverb gated on the clock, the chords' reverb frozen at the end
 *   bars 29-34  the modulators: the kit's ENV1 on each voice's pitch, the chords' LFO1 vibrato and ENV2 swell
 *               into the filter, an LFO2 sample-and-hold on PAN synced to quarter notes
 *   the end     the kit saved with SHIFT + PLAY into a simulated data area, then loaded as a boot would
 *   gcc -O2 -std=gnu11 -DBOARD_SMK37=1 -I. -I../firmware/src -I../firmware/hal -I../build/gen -o host_sim host_sim.c -lm */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "host_stubs.h"
#include "os_core.h"
#include "os_font.c"
#define SV_API static
#include "svbrr_dec.c"
#include "os_fx.c"
#include "os_regs.c"
#include "os_flt.c"
#include "os_hf.c"
#include "os_tfx.c"
#include "os_mod.c"
#include "os_mach.c"
#include "os_shp.c"
#include "os_seq.c"
#include "os_store.c"
#include "os_engine.c"
#include "host_nor.h"
#include "os_vault.c"
#include "os_ui.c"

static const double FSd = 24e6 / 544.0;
static double BAR_F;                          /* frames per bar */
static double T0_F = 0.0;                     /* the frame transport core 0 is heard at (set at PLAY) */
static long frame_now;
static int16_t *pcm;
static long pcm_n;
static double render_ns, worst_ns;
static long halves_done;
static FILE *trace;

static void save_screen(const char *name)
{
    char fn[64];
    FILE *f;
    snprintf(fn, sizeof fn, "screen_%s.rgb565", name);
    f = fopen(fn, "wb");
    fwrite(FB, 2, 240 * 240, f);
    fclose(f);
}

static void ui_pass(void) { ui_input(); ui_leds(); ui_draw(); }
static void press(int b) { sim_pressed |= 1u << b; ui_pass(); }
static void hold_btn(int b, int on) { if (on) fm1_in.buttons |= 1u << b; else fm1_in.buttons &= ~(1u << b); }
static void pad(int p, int on) { fm1_in.pad_st[p] = on ? 0x80 : 0; ui_pass(); }
static void tap(int p) { pad(p, 1); pad(p, 0); }
static void turn(int k, int n) { sim_enc[k] += n; ui_pass(); }
static void key(int k, int vel, int on, uint32_t core)
{
    uint32_t i = kq_w % 32u;
    kq[i].key = (uint8_t)k; kq[i].vel = (uint8_t)vel; kq[i].on = (uint8_t)on; kq[i].core = core;
    kq_w++;
    ui_pass();
}

/* the mod wheel to amount w: the raw reading the UI maps to it, through its own calibration */
static void wheel_to(int w)
{
    int m;
    ui_pass();
    for (m = ui.mhi; m > ui.mlo; m--) {
        int mw = ui.mhi - m <= 12 ? 0 : (ui.mhi - m - 12) * 127 / (ui.mhi - ui.mlo - 12 > 1 ? ui.mhi - ui.mlo - 12 : 1);
        if (mw >= w) break;
    }
    fm1_in.wheel[1] = (uint16_t)m;
    ui_pass();
}
static void set_view(int btn) { press(btn); }
static void sel_track(int k) { hold_btn(B_BT, 1); tap(k); hold_btn(B_BT, 0); }
static void page_to(int pg) { while (ui.page != pg) press(B_KBANK); }
/* a register to a value through the knob, as a person would (detents; the UI accelerates fast turns) */
static void knob_to(int kn, int target)
{
    int guard = 0;
    while (guard++ < 400) {
        int r = PAGES[ui.page][kn], v = os.trk[os.sel].base[r], d = target - v;
        if (!d) break;
        turn(kn, d > 2 ? 2 : d < -2 ? -2 : d);
    }
}
/* the knob that edits register r: its page shown, the knob returned (the page table, os_ui.c) */
static int kn_of(int r) { int pos = ui_find((uint32_t)r); page_to(pos / 8); return pos % 8; }
static void reg_to(int r, int target) { knob_to(kn_of(r), target); }

/* live keys: scheduled presses, pushed one half late (as the scan would see them), stamped exactly */
typedef struct { double core; int key, vel, on; } kev_t;
static kev_t kev[64];
static int kev_n, kev_i;

static void render_until(double bar)
{
    int32_t out[2 * HALF_FRAMES];
    long target = (long)(bar * BAR_F + T0_F);
    while (frame_now < target) {
        struct timespec a, b;
        double ns;
        int i;
        while (kev_i < kev_n && T0_F + kev[kev_i].core * 375.0 / 68.0 + HALF_FRAMES <= (double)frame_now) {
            key(kev[kev_i].key, kev[kev_i].vel, kev[kev_i].on, os.play_c0 + (uint32_t)(kev[kev_i].core + 0.5));
            kev_i++;
        }
        clock_gettime(CLOCK_MONOTONIC, &a);
        os_render(out, HALF_FRAMES);
        clock_gettime(CLOCK_MONOTONIC, &b);
        ns = (b.tv_sec - a.tv_sec) * 1e9 + (b.tv_nsec - a.tv_nsec);
        render_ns += ns;
        if (ns > worst_ns) worst_ns = ns;
        halves_done++;
        for (i = 0; i < 2 * HALF_FRAMES; i++) {
            int v = out[i] >> 7;
            pcm[pcm_n++] = (int16_t)(v > 32767 ? 32767 : v < -32768 ? -32768 : v);
        }
        frame_now += HALF_FRAMES;
        fm1_ms = (uint32_t)(frame_now * 1000.0 / FSd);
        fm1_in.frames++;
        if (halves_done % 6 == 0) ui_pass();
    }
}

static void write_wav(const char *fn)
{
    FILE *f = fopen(fn, "wb");
    int sr = 44118, bytes = (int)(pcm_n * 2), v;
    short s;
    fwrite("RIFF", 1, 4, f); v = 36 + bytes; fwrite(&v, 4, 1, f); fwrite("WAVEfmt ", 1, 8, f);
    v = 16; fwrite(&v, 4, 1, f); s = 1; fwrite(&s, 2, 1, f); s = 2; fwrite(&s, 2, 1, f);
    fwrite(&sr, 4, 1, f); v = sr * 4; fwrite(&v, 4, 1, f); s = 4; fwrite(&s, 2, 1, f); s = 16; fwrite(&s, 2, 1, f);
    fwrite("data", 1, 4, f); fwrite(&bytes, 4, 1, f); fwrite(pcm, 2, (size_t)pcm_n, f);
    fclose(f);
}

/* where track 4's notes actually started, for timing.txt: the voice start frames */
static void trace_track4(const char *label, double bar0)
{
    uint32_t i;
    const evl_t *l = seq_list(3);
    const trk_t *t = &os.trk[3];
    uint32_t L = trk_steplen(t);
    trk_resolve(&os.trk[3], 3);                               /* (the new knob value: at the next tick) */
    fprintf(trace, "%-12s FEEL %4d%%:", label, (int)reg_feel_pct(t->eff[R_FEL]));
    for (i = 0; i < l->n; i++)
        if (l->e[i].kind == EV_NOTE) {
            double ms = (double)(ev_time(t, &l->e[i], L) - (int32_t)(l->e[i].step * L)) / 8.0;
            fprintf(trace, " %+.1f", ms);
        }
    fprintf(trace, "  ms vs the grid\n");
    (void)bar0;
}

int main(void)
{
    int i;
    FILE *sec;
    if (os_engine_init()) { fprintf(stderr, "library did not open\n"); return 1; }
    BAR_F = 4.0 * os.bpb * 16.0 * 375.0 / 68.0;
    pcm = malloc(sizeof(int16_t) * 2 * (size_t)(FSd * 75.0));
    if (getenv("MODSTRESS")) {                                 /* (timing only: every modulator live on every track) */
        uint32_t k;
        for (k = 0; k < NTRACK; k++) {
            trk_t *t = &os.trk[k];
            t->base[R_LT1] = (uint8_t)mach_pit_reg(t->mach); t->base[R_LD1] = 66; t->base[R_RT1] = 90; t->base[R_SH1] = 7;
            t->base[R_ET1] = R_LEV; t->base[R_ED1] = 70;
            t->base[R_LT2] = R_CUT; t->base[R_LD2] = 70; t->base[R_RT2] = 100;
            t->base[R_ET2] = (uint8_t)mach_pit_reg(t->mach); t->base[R_ED2] = 66;
        }
    }
    trace = fopen("timing.txt", "w");
    sec = fopen("sections.txt", "w");
    ui_init();
    fm1_in.frames = 1000;
    ui_pass();

    /* ---- track 2: the KIT. Hold a step and press keys: that step's chord. Tap: the last key's sound. */
    sel_track(1);
    set_view(B_SEQ);
    key(0, 112, 1, 0); key(0, 0, 0, 0);                       /* C3 = KICK: the note a tap places */
    tap(0); tap(8);
    pad(4, 1); key(0, 112, 1, 0); key(1, 104, 1, 0); key(0, 0, 0, 0); key(1, 0, 0, 0); pad(4, 0);   /* kick + snare */
    pad(12, 1); key(1, 100, 1, 0); key(1, 0, 0, 0); pad(12, 0);
    tap(10);                                                  /* a tap places the last key's sound: the snare */
    key(2, 78, 1, 0); key(2, 0, 0, 0);                        /* HAT */
    tap(2); tap(6); tap(14);
    tap(10);                                                  /* a tap on a full step clears it... */
    tap(10);                                                  /* ...and on an empty one places a hat */
    page_to(0);
    pad(14, 1); turn(2, 2); turn(2, 2); turn(2, 1); pad(14, 0);   /* hold + turn: the last hat 5 semitones up (a lock) */
    seq_put_cmd(seq_list(1), 14, 'R', 138, 8);                /* (entered in LIST: R 138 8, a roll every 2^(138/16) = 394 samples: a 32nd) */
    {   /* a 1:2 condition on step 7 (LIST, D column) */
        int j = evl_find(seq_list(1), 6, EV_NOTE, 50);
        if (j >= 0) seq_list(1)->e[j].d = CD_1_2;
    }
    pad(4, 1); render_until(0.0); save_screen("step_kit");     /* a held step: its notes in the info line */
    pad(4, 0);

    /* ---- track 3: WAVE chords. Hold keys, tap a step: the chord is stamped. */
    sel_track(2);
    set_view(B_CHORD);
    key(9, 90, 1, 0); key(12, 90, 1, 0); key(16, 90, 1, 0); tap(0); key(9, 0, 0, 0); key(12, 0, 0, 0); key(16, 0, 0, 0);
    key(5, 90, 1, 0); key(9, 90, 1, 0); key(12, 90, 1, 0); tap(8); key(5, 0, 0, 0); key(9, 0, 0, 0); key(12, 0, 0, 0);
    set_view(B_FBANK);                                        /* LIST: every chord note 7 steps long (C column) */
    for (i = 0; i < (int)seq_list(2)->n; i++) {
        int j;
        for (j = 0; j < (int)seq_list(2)->n && seq_list(2)->e[j].c != 8; j++) {}
        if (j < (int)seq_list(2)->n) { ui.list_cur = (int16_t)j; turn(5, 16); turn(5, 1); }
    }
    save_screen("list_chords");
    /* the strip: low-pass, resonance, ENV2 on the filter (FLT is on by default; FEN the amount) */
    reg_to(R_TYP, 1); reg_to(R_CUT, 70); reg_to(R_RES, 70); reg_to(R_FEN, 100); reg_to(R_ATK, 40); reg_to(R_REL, 75);
    reg_to(R_AT2, 40);
    reg_to(R_LT2, WA_FRM); reg_to(R_RT2, 43); reg_to(R_LD2, 103);     /* LFO2 scans the wavetable (0.48 Hz) */
    page_to(0);
    knob_to(4, 20);                                           /* detune */
    set_view(B_PARA);
    hold_btn(B_BT, 1); turn(1, 1); hold_btn(B_BT, 0);          /* SHIFT + K2: the lane is FRM */
    pad(8, 1); for (i = 0; i < 12; i++) turn(1, 2); pad(8, 0);  /* hold step 9 + turn: a FRM lock */
    pad(12, 1); for (i = 0; i < 25; i++) turn(1, 2); pad(12, 0); /* a trigless lock on 13 */
    os.trk[2].base[R_LEV] = 88;

    /* ---- track 4: a GRAN cloud under it all */
    sel_track(3);
    set_view(B_SEQ);
    key(12, 80, 1, 0); key(12, 0, 0, 0);
    tap(0);
    seq_list(3)->e[0].c = 120;                                /* 15 steps */
    os.trk[3].base[R_LEV] = 70;
    os.trk[3].base[R_ATK] = 70;
    os.trk[3].base[R_REL] = 80;

    /* ---- go: bars 0-4 programmed */
    for (i = 0; i < (int)NTRACK; i++) mach_kill((uint32_t)i);   /* (the auditions so far fade out) */
    sel_track(1);
    set_view(B_SEQ);
    press(B_PLAY);
    T0_F = (double)frame_now + (2.0 - os.up_phase) / UPS_STEP;   /* core 0 of the transport, as heard */
    render_until(1.3);
    save_screen("step_playing");
    sel_track(2);
    set_view(B_CHORD);
    render_until(2.2);
    save_screen("roll_chords");
    set_view(B_PARA);
    render_until(3.0);
    save_screen("lane_frm");
    render_until(3.75);

    /* ---- bar 4: track 4 becomes a MULTI bell, recorded live with a human hand */
    sel_track(3);
    set_view(B_PATCH);
    tap(1);                                                   /* MULTI */
    ui.mach_bank = 1; tap(13);                                /* BELL */
    page_to(0);
    knob_to(1, 0);                                            /* MAP: chromatic */
    knob_to(2, 64 - 12);                                      /* an octave down */
    evl_clear(seq_list(3));
    os.trk[3].base[R_LEV] = 96; os.trk[3].base[R_ATK] = 0; os.trk[3].base[R_DEC] = 60; os.trk[3].base[R_SUS] = 40; os.trk[3].base[R_REL] = 50;
    render_until(3.95);
    save_screen("mach_bell");
    press(B_OCTU);                                            /* keys from C4 */
    {
        static const int st[8] = {0, 2, 3, 6, 8, 10, 11, 14}, nt[8] = {72, 79, 76, 74, 72, 67, 69, 71};
        static const double ms[8] = {0, 14, -9, 22, 3, 18, -12, 26};
        static const int vel[8] = {112, 70, 88, 62, 106, 74, 92, 66};
        double bar4 = 4.0 * 4.0 * os.bpb * 16.0;              /* core samples to bar 4 */
        for (i = 0; i < 8; i++) {
            double on = bar4 + st[i] * os.bpb * 4.0 + ms[i] * 8.0;
            kev[kev_n++] = (kev_t){on, nt[i] - 60, vel[i], 1};
            kev[kev_n++] = (kev_t){on + os.bpb * 4.0 * 0.8, nt[i] - 60, 0, 0};
        }
        for (i = 0; i < kev_n; i++) {                         /* in time order */
            int j;
            for (j = i + 1; j < kev_n; j++) if (kev[j].core < kev[i].core) { kev_t x = kev[i]; kev[i] = kev[j]; kev[j] = x; }
        }
    }
    set_view(B_SEQ);
    press(B_REC);
    fprintf(sec, "4.0 record\n");
    render_until(5.0);
    press(B_REC);
    trace_track4("recorded", 5);
    save_screen("step_recorded");
    if (getenv("AB_FEEL")) {                                  /* A/B clips: the same 4 bars, one setting each */
        long f0 = pcm_n;
        sel_track(3); reg_to(R_FEL, atoi(getenv("AB_FEEL")));
        if (getenv("AB_GRV")) {
            for (i = 0; i < 16; i++) { os.trk[1].lrn[i] = os.trk[3].lrn[i]; os.trk[1].lrn_n[i] = os.trk[3].lrn_n[i]; }
            sel_track(1); reg_to(R_GRV, atoi(getenv("AB_GRV")));
        }
        render_until(9.0);
        memmove(pcm, pcm + f0, (size_t)(pcm_n - f0) * sizeof *pcm);
        pcm_n -= f0;
        write_wav("ab.wav");
        return 0;
    }
    set_view(B_FBANK);
    render_until(5.2);
    save_screen("list_recorded");
    set_view(B_SEQ);
    fprintf(sec, "5.0 feel 100\n");
    render_until(7.0);
    reg_to(R_FEL, 51); trace_track4("machine", 7); fprintf(sec, "7.0 feel 0\n");
    render_until(9.0);
    reg_to(R_FEL, 127); trace_track4("exaggerated", 9); fprintf(sec, "9.0 feel 150\n");
    render_until(11.0);
    reg_to(R_FEL, 0); trace_track4("inverted", 11); fprintf(sec, "11.0 feel -100\n");
    render_until(13.0);
    reg_to(R_FEL, 101);
    sel_track(1); reg_to(R_GRV, 5);                  /* the kit: GRV LRN, track 2 learns... */
    for (i = 0; i < 16; i++) { os.trk[1].lrn[i] = os.trk[3].lrn[i]; os.trk[1].lrn_n[i] = os.trk[3].lrn_n[i]; }   /* ...track 4's pocket */
    fprintf(sec, "13.0 kit in your pocket\n");
    render_until(15.0);
    reg_to(R_GRV, 6);                                            /* GRV TK1: the tape loop's own pocket */
    fprintf(sec, "15.0 kit in the loop's pocket\n");
    render_until(15.2);
    fprintf(trace, "loop pocket (TK1, ms per 16th):");
    for (i = 0; i < 16; i++) fprintf(trace, " %+.1f", os.trk[0].agr[i] * (double)(os.bpb * 4) / 4096.0 / 8.0);
    fprintf(trace, "\nyour pocket (LRN, ms per 16th):");
    for (i = 0; i < 16; i++) fprintf(trace, " %+.1f", os.trk[3].lrn[i] * (double)(os.bpb * 4) / 4096.0 / 8.0);
    fprintf(trace, "\n");
    render_until(17.0);

    /* ---- scenes (PERF, page 0: scene pads on top): a tap latches scene 1 in; hold a scene pad + turn writes it
     * (a hold is momentary: out again on release); the wheel brings the last scene touched in on top */
    reg_to(R_GRV, 0);
    set_view(B_GLOBE);
    tap(0);                                                                 /* scene 1 in, latched */
    sel_track(2);
    page_to(1);
    pad(0, 1); for (i = 0; i < 10; i++) turn(0, -2); pad(0, 0);            /* 1: WAVE dark */
    pad(1, 1); for (i = 0; i < 10; i++) turn(0, 2); for (i = 0; i < 6; i++) turn(1, 2); pad(1, 0);  /* 2: open, resonant */
    sel_track(3);
    {
        int kf = kn_of(R_FEL);
        pad(0, 1); for (i = 0; i < 25; i++) turn(kf, -2); pad(0, 0);       /* 1: the bells on the grid */
        pad(1, 1); for (i = 0; i < 10; i++) turn(kf, 2); pad(1, 0);        /* 2: looser than played */
    }
    wheel_to(0);
    fprintf(sec, "17.0 scene 1 in; the wheel brings scene 2 in on top\n");
    for (i = 0; i <= 48; i++) {
        wheel_to(i * 127 / 48);
        render_until(17.0 + i * 3.0 / 48.0);
        if (i == 30) save_screen("perf_morph");
    }
    render_until(20.5);

    /* ---- the submix (page E) and the master bus: the kit spread across the field, its highs wide and a
     * little brighter, a touch of compression; the master glued and aired */
    set_view(B_PATCH);
    sel_track(1);
    reg_to(R_SPR, 100);                                       /* SPR: kick centre, hats and toms out */
    reg_to(R_WID, 110);                                       /* WID */
    reg_to(R_AIR, 76);                                        /* AIR: +1.5 dB */
    reg_to(R_CMP, 50);                                        /* CMP */
    fprintf(sec, "20.5 submix: kit spread, wide air, compressed\n");
    render_until(22.0);
    save_screen("mach_out");
    press(B_FX); press(B_FX); press(B_FX);                    /* FX -> VERB -> MASTER */
    for (i = 0; i < 15; i++) turn(0, 2);                      /* GLU 20 -> 50 */
    for (i = 0; i < 10; i++) turn(1, 2);                      /* AIR 25 -> 45 */
    fprintf(sec, "22.0 master: more glue, more air\n");
    render_until(23.0);
    save_screen("master");
    press(B_FX);                                              /* (back to the track's pages) */

    /* ---- each track's effects (os_tfx.c): pages F (the multi-effect) and G (the reverb) */
    sel_track(1);
    reg_to(R_TIM, 56 + 12);                                   /* TIM 3/16: a dotted eighth, on the clock */
    reg_to(R_FBK, 64 + 30);                                   /* FBK */
    reg_to(R_COL, 52);                                        /* COL: a little darker each repeat */
    reg_to(R_PNG, 1);                                         /* PNG: ping-pong */
    reg_to(R_MIX, 45);                                        /* MIX */
    fprintf(sec, "23.0 kit: ping-pong 3/16\n");
    render_until(24.0);
    save_screen("fx_ping");
    sel_track(2);
    reg_to(R_TIM, 48);                                        /* TIM 20 ms: chorus */
    reg_to(R_DEP, 60);                                        /* DEP */
    reg_to(R_RAT, 115);                                       /* RAT: one bar, synced */
    reg_to(R_MIX, 64);
    fprintf(sec, "24.0 chords: chorus\n");
    render_until(25.0);
    reg_to(R_FBK, 64 - 36);                                   /* FBK negative, then TIM down: into a flanger */
    { int kt = kn_of(R_TIM); for (i = 0; i < 24; i++) { turn(kt, -1); render_until(25.0 + (i + 1) * 1.0 / 24.0); } }
    fprintf(sec, "25.0 chords: TIM morphs the chorus into a flanger\n");
    render_until(26.0);
    sel_track(0);
    reg_to(R_TIM, 0);                                         /* TIM 0 + DIS: a phaser */
    reg_to(R_DIS, 60);                                        /* DIS */
    reg_to(R_DEP, 70);
    reg_to(R_RAT, 117);                                       /* RAT: two bars, synced */
    reg_to(R_FBK, 64 + 30);
    reg_to(R_MIX, 64);
    fprintf(sec, "26.0 tape: phaser, synced\n");
    render_until(27.0);
    sel_track(1);
    reg_to(R_DCY, 90);                                        /* DCY */
    reg_to(R_GAT, 6);                                         /* GAT: 6 steps after each hit */
    reg_to(R_REV, 50);                                        /* REV */
    fprintf(sec, "27.0 kit: reverb gated on the clock\n");
    render_until(28.0);
    save_screen("fx_verb");
    sel_track(2);
    reg_to(R_SIZ, 110); reg_to(R_REV, 60);                    /* a big room on the chords */
    fprintf(sec, "28.0 chords: reverb\n");
    render_until(29.0);
    reg_to(R_DCY, 127);                                       /* DCY FRZ: the tail held */
    fprintf(sec, "29.0 chords: freeze\n");
    render_until(29.5);

    /* ---- the modulators (os_mod.c): pages D-G */
    reg_to(R_DCY, 80); reg_to(R_REV, 30);                     /* (the chords' room back to normal) */
    sel_track(1);                                             /* the kit: ENV1 drops each voice's pitch */
    reg_to(R_RG1, 1); reg_to(R_AT1, 0); reg_to(R_DE1, 70); reg_to(R_SU1, 0);
    reg_to(R_ET1, MU_PIT); reg_to(R_ED1, 64 + 25);            /* +5 semitones at the hit, falling in ~40 ms */
    fprintf(sec, "29.5 kit: ENV1 -> pitch, per voice\n");
    save_screen("env1");
    render_until(30.5);
    sel_track(2);                                             /* the chords: vibrato that restarts with each note */
    reg_to(R_REV, 20);
    reg_to(R_LT1, WA_PIT); reg_to(R_RT1, 98); reg_to(R_MD1, 1); reg_to(R_LD1, 64 + 4);   /* ~5 Hz, +-0.5 st */
    reg_to(R_RG2, 0); reg_to(R_AT2, 105); reg_to(R_DE2, 100); reg_to(R_SU2, 60);          /* ENV2: a slow swell */
    reg_to(R_FEN, 64 + 40);                                   /* ... into the filter (FLT on) */
    fprintf(sec, "30.5 chords: LFO1 vibrato (TRIG), ENV2 swell into the filter\n");
    render_until(31.5);
    reg_to(R_LT2, R_PAN); reg_to(R_SH2, 6); reg_to(R_MU2, 8); reg_to(R_RT2, 64); reg_to(R_LD2, 64 + 40);
    fprintf(sec, "31.5 chords: LFO2 S&H on PAN, a quarter note, synced\n");
    save_screen("lfo2");
    render_until(33.5);
    press(B_PLAY);
    render_until(34.5);
    write_wav("sim.wav");
    if (getenv("DUMP")) {                                     /* (the storage prototype: the state, raw) */
        FILE *f = fopen("state.bin", "wb");
        uint32_t k, pt;
        for (k = 0; k < NTRACK; k++) { fwrite(&os.trk[k].mach, 1, 1, f); fwrite(os.trk[k].base, 1, NREG, f); }
        fwrite(scn, sizeof scn, 1, f);
        for (pt = 0; pt < NPAT; pt++)
            for (k = 0; k < NTRACK; k++) { fwrite(&seq_pat[pt][k].n, 2, 1, f); fwrite(seq_pat[pt][k].e, sizeof(ev_t), seq_pat[pt][k].n, f); }
        fclose(f);
        printf("state.bin: sizeof ev_t %u, scn %u\n", (unsigned)sizeof(ev_t), (unsigned)sizeof scn);
    }

    {
        double per = render_ns / (double)halves_done / 1000.0, budget = HALF_FRAMES / FSd * 1e6;

        printf("halves %ld, render %.1f us/half avg (worst %.1f) of %.0f us: %.1f%% of one host core\n",
               halves_done, per, worst_ns / 1000.0, budget, 100.0 * per / budget);
        printf("events: T1 %u T2 %u T3 %u T4 %u; event heap %u B (%u used), voices %u B (%u each)\n",
               seq_list(0)->n, seq_list(1)->n, seq_list(2)->n, seq_list(3)->n, (unsigned)sizeof seq_heap, (unsigned)seq_used, (unsigned)sizeof pool, (unsigned)sizeof(pv_t));
        {   /* the session as presets */
            static uint8_t kb[65536], kb2[65536];
            uint32_t kn = st_kit_save(kb, sizeof kb), sn[NTRACK], k, kn2;
            for (k = 0; k < NTRACK; k++) sn[k] = st_sound_save(k, kb2, sizeof kb2);
            st_kit_load(kb, kn);
            kn2 = st_kit_save(kb2, sizeof kb2);
            printf("presets: the session's kit %u B (%u events), saved again after loading it: %s; its sounds %u %u %u %u B\n",
                   kn, seq_used, kn2 == kn && !memcmp(kb, kb2, kn) ? "the same bytes" : "DIFFERENT", sn[0], sn[1], sn[2], sn[3]);
            memset(nor, 0xFF, sizeof nor);                    /* a fresh data area: SHIFT + PLAY, then a boot */
            vault_mount();
            kn = st_kit_save(kb, sizeof kb);
            hold_btn(B_BT, 1); press(B_PLAY); hold_btn(B_BT, 0);
            printf("vault: SHIFT + PLAY (%s) says \"%s\"; ", os.playing ? "playing" : "stopped", ui.msg);
            vault_mount();
            vault_kit_load(0);
            kn2 = st_kit_save(kb2, sizeof kb2);
            printf("after a boot the kit is %s (%u erases, %u B programmed, nothing outside FL_DATA: %s)\n",
                   kn2 == kn && !memcmp(kb, kb2, kn) ? "back exactly" : "DIFFERENT", erases, progs, outside ? "NO" : "yes");
        }
        printf("voices: %u over a track's VOI (a 1 ms choke), %u choked by the shared budget of %u\n", vb_steals, vb_chokes, VOICES);
        printf("os %u B, trk_t %u B, gran %u B + ring %u B, wave %u B + frames %u B, buses %u B, upsamplers %u B\n", (unsigned)sizeof os, (unsigned)sizeof(trk_t),
               (unsigned)sizeof gran, (unsigned)sizeof gran_ring, (unsigned)sizeof wave, (unsigned)sizeof wave_fb, (unsigned)sizeof bus, (unsigned)(sizeof up_c + sizeof up_w));
    }
    fclose(trace);
    fclose(sec);
    return 0;
}
