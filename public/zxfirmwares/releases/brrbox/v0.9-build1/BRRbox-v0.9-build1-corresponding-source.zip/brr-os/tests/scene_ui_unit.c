/* SPDX-License-Identifier: GPL-3.0-only */
/* The scene pads' gestures (os_ui.c, PERF page 0): a tap latches a scene in at the hit's velocity and a second
 * tap takes it out; a hold is momentary (pressure pushes it toward 127); a hold on a latched scene leaves it
 * latched; hold + turn writes it without latching it; CLR + pad clears it; the wheel sets the amount of the
 * last scene touched; PERF again flips to the mutes page.
 *   gcc -O2 -std=gnu11 -DBOARD_SMK37=1 -I. -I../firmware/src -I../firmware/hal -I../build/gen -o scene_ui_unit scene_ui_unit.c -lm && ./scene_ui_unit */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "host_stubs.h"
#include "os_core.h"
#include "os_font.c"
#define SV_API static
#include "svbrr_dec.c"
#include "os_fx.c"
#include "os_regs.c"
#include "os_flt.c"
#include "os_hf.c"
#include "os_tfx.c"
#include "os_mod.c"
#include "os_mach.c"
#include "os_shp.c"
#include "os_seq.c"
#include "os_store.c"
#include "os_engine.c"
#include "host_nor.h"
#include "os_vault.c"
#include "os_ui.c"

static int fails;
static void check(int ok, const char *what) { printf("  [%s] %s\n", ok ? " ok " : "FAIL", what); if (!ok) fails++; }
static void pass(void) { ui_input(); }
static void pad(int p, int on, int vel) { fm1_in.pad_st[p] = on ? 0x80 : 0; fm1_in.pad_vel[p] = (uint8_t)vel; if (!on) fm1_in.pad_press[p] = 0; pass(); }
static void wait_ms(uint32_t ms) { fm1_ms += ms; pass(); }
static void wheel_to(int w)
{
    int m;
    for (m = ui.mhi; m > ui.mlo; m--) {
        int mw = ui.mhi - m <= 12 ? 0 : (ui.mhi - m - 12) * 127 / (ui.mhi - ui.mlo - 12 > 1 ? ui.mhi - ui.mlo - 12 : 1);
        if (mw >= w) break;
    }
    fm1_in.wheel[1] = (uint16_t)m;
    pass();
}

int main(void)
{
    char b[128];
    if (os_engine_init()) { fprintf(stderr, "library did not open\n"); return 1; }
    ui_init();
    fm1_in.wheel[0] = 512; fm1_in.wheel[1] = 615;          /* the wheels at rest (mod: 0) */
    fm1_ms = 1000;
    fm1_in.frames = 1000;                                   /* (the wheels are read after 300 frames) */
    pass();
    sim_pressed |= 1u << B_GLOBE; pass();                   /* PERF */
    check(ui.view == V_PERF && ui.perf_pg == 0u, "PERF opens on the scenes");

    pad(2, 1, 90); wait_ms(40); pad(2, 0, 90);
    snprintf(b, sizeof b, "a tap: scene 3 latched in at its velocity (%u)", scs.amt[2]);
    check(scs.amt[2] == 90u && scs.n == 1u && (ui.scn_latch & 4u), b);
    pad(2, 1, 30); wait_ms(40); pad(2, 0, 30);
    check(scs.amt[2] == 0u && scs.n == 0u && !(ui.scn_latch & 4u), "a second tap: out");

    pad(4, 1, 64); wait_ms(100);
    check(scs.amt[4] == 64u, "held: scene 5 in at once, at the hit's velocity");
    fm1_in.pad_press[4] = 127; wait_ms(100);
    snprintf(b, sizeof b, "pressed hard: up to %u", scs.amt[4]);
    check(scs.amt[4] == 127u, b);
    fm1_in.pad_press[4] = 64; wait_ms(100);
    snprintf(b, sizeof b, "half the pressure: %u (64 + 63 x 64/127 = 95)", scs.amt[4]);
    check(scs.amt[4] == 95u, b);
    wait_ms(200); pad(4, 0, 64);
    check(scs.amt[4] == 0u && !(ui.scn_latch & 16u), "let go after 500 ms: momentary, out");

    pad(0, 1, 110); wait_ms(30); pad(0, 0, 110);            /* scene 1 latched at 110 */
    pad(0, 1, 50); fm1_in.pad_press[0] = 127; wait_ms(600); pad(0, 0, 50);
    snprintf(b, sizeof b, "a hold on latched scene 1: pushed while held, latched again at its own %u after", scs.amt[0]);
    check(scs.amt[0] == 110u && (ui.scn_latch & 1u), b);

    pad(6, 1, 100); sim_enc[0] = 3; pass(); wait_ms(30); pad(6, 0, 100);
    snprintf(b, sizeof b, "hold + turn: scene 7 written (%d), not latched by the short press", scn_any(6));
    check(scn_any(6) && scs.amt[6] == 0u, b);
    fm1_in.buttons |= 1u << B_SCALE; pad(6, 1, 100); pad(6, 0, 100); fm1_in.buttons &= ~(1u << B_SCALE);
    check(!scn_any(6) && scs.amt[6] == 0u, "CLR + pad: scene 7 sets nothing");

    pad(3, 1, 100); wait_ms(600); pad(3, 0, 100);           /* touch scene 4 (momentary) */
    wheel_to(64);
    snprintf(b, sizeof b, "the wheel: the last scene touched (4) in at its amount, %u, latched, on top", scs.amt[3]);
    check(scs.amt[3] >= 63u && scs.amt[3] <= 65u && (ui.scn_latch & 8u) && scs.ord[scs.n - 1u] == 3u, b);
    wheel_to(0);
    check(scs.amt[3] == 0u && scs.amt[0] == 110u, "wheel down: scene 4 out, scene 1 still in");

    sim_pressed |= 1u << B_GLOBE; pass();
    check(ui.perf_pg == 1u, "PERF again: the mutes page");
    pad(1, 1, 100); pad(1, 0, 100);
    check(os.trk[1].mute == 1u && scs.amt[1] == 0u, "pad 2 there mutes track 2 (no scene)");
    printf("\n%s (%d failed)\n", fails ? "FAILED" : "all passed", fails);
    return fails != 0;
}
