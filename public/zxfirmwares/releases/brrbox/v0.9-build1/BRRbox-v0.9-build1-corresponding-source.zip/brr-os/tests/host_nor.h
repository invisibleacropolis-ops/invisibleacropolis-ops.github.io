/* SPDX-License-Identifier: GPL-3.0-only */
/* A simulated SPI NOR for the host tests, standing in for storage_hw.c: the data area only (FL_DATA), program
 * clears bits only, erase sets a 4 KiB sector to 0xFF; anything outside is refused and counted. A power cut
 * can be set to fall after a number of programmed bytes or erases (it longjmps to 'power'). */
#include <setjmp.h>
#include "fm1_flash_map.h"
#define AREA (FL_DATA_HI - FL_DATA_LO)
static uint8_t nor[AREA];
static uint32_t wear[AREA / 0x1000u], outside, progs, erases;
static long cut = -1;                       /* bytes or erases left before the power goes (-1: never) */
static jmp_buf power;
static uint8_t flash_ok = 1;

static int st_read(uint32_t off, void *dst, uint32_t n)
{
    if (off < FL_DATA_LO || n > FL_DATA_HI - off) { outside++; return -8; }
    memcpy(dst, nor + (off - FL_DATA_LO), n);
    return 0;
}
static int st_erase(uint32_t off)
{
    if (off < FL_DATA_LO || off + 0x1000u > FL_DATA_HI || off % 0x1000u) { outside++; return -8; }
    if (cut >= 0 && cut-- == 0) {               /* cut mid-erase: the sector is anything */
        uint32_t i;
        for (i = 0; i < 0x1000u; i++) nor[off - FL_DATA_LO + i] &= (uint8_t)rand();
        if (rand() & 1) for (i = 0; i < 0x1000u; i++) nor[off - FL_DATA_LO + i] |= (uint8_t)rand();
        longjmp(power, 1);
    }
    memset(nor + (off - FL_DATA_LO), 0xFF, 0x1000u);
    wear[(off - FL_DATA_LO) / 0x1000u]++;
    erases++;
    return 0;
}
static int st_prog(uint32_t off, const void *src, uint32_t n)
{
    const uint8_t *s = src;
    uint32_t i;
    if (off < FL_DATA_LO || n > FL_DATA_HI - off) { outside++; return -8; }
    for (i = 0; i < n; i++) {
        if (cut >= 0 && cut-- == 0) {           /* cut mid-program: this byte half done */
            nor[off - FL_DATA_LO + i] &= (uint8_t)(s[i] | rand());
            longjmp(power, 1);
        }
        nor[off - FL_DATA_LO + i] &= s[i];
        progs++;
    }
    return 0;
}
