/* SPDX-License-Identifier: GPL-3.0-only */
/* Unit tests of the modulators (os_mod.c): envelope stage times in both ranges, LFO rates across the multiplier,
 * synced periods exact to the clock sample and locked to the song, the modes (FREE TRIG HOLD ONE HALF), every
 * shape's range, ENV2's gate across overlapping notes, and a voice's ENV1 on its pitch.
 *   gcc -O2 -std=gnu11 -I. -I../firmware/src -I../build/gen -o mod_unit mod_unit.c -lm && ./mod_unit */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "host_stubs.h"
#include "os_core.h"
#include "os_font.c"
#define SV_API static
#include "svbrr_dec.c"
#include "os_fx.c"
#include "os_regs.c"
#include "os_flt.c"
#include "os_hf.c"
#include "os_tfx.c"
#include "os_mod.c"
#include "os_mach.c"
#include "os_shp.c"
#include "os_seq.c"
#include "os_engine.c"

static int fails;
static void check(int ok, const char *what) { printf("  [%s] %s\n", ok ? " ok " : "FAIL", what); if (!ok) fails++; }

/* samples an envelope takes to cross level x in a stage */
static uint32_t env_until(adsr_t *e, const env_c *c, int rising, float x, uint32_t cap)
{
    uint32_t n = 0;
    while (n < cap) { float v = env_step(e, c); n++; if (rising ? v >= x : v <= x) break; }
    return n;
}

int main(void)
{
    uint32_t i, rng;
    printf("envelopes\n");
    for (rng = 0; rng < 2u; rng++) {
        static const uint32_t V[3] = {0, 64, 127};
        for (i = 0; i < 3u; i++) {
            env_c c; adsr_t e = {0.0f, 1};
            float want = env_time_s(V[i], rng), got_a, got_d;
            char b[96];
            env_coef(&c, V[i], V[i], 0, V[i], rng);
            got_a = (float)env_until(&e, &c, 1, 0.999f, 2000000u) / (float)CORE_SR;
            got_d = (float)env_until(&e, &c, 0, 0.0067f, 2000000u) / (float)CORE_SR;   /* -43 dB: 5 time constants */
            snprintf(b, sizeof b, "%s v%3u: stage %.4f s; attack %.4f s, decay to -43 dB %.4f s", rng ? "SHRT" : "LONG", V[i], want, got_a, got_d);
            check(fabsf(got_a - want) <= 0.0002f + want * 0.02f && fabsf(got_d - want) <= 0.0002f + want * 0.05f, b);
        }
    }
    check(env_time_s(127, 0) * 3.0f > 11.0f && env_time_s(127, 1) * 3.0f < 1.0f, "LONG: A + D + R up to ~12 s; SHORT: under 1 s");

    printf("LFO rates (RT 0 / 64 / 127 at each multiplier): Hz measured from the phase\n");
    for (i = 0; i < 8u; i++) {
        uint32_t v;
        printf("  %-4.4s", LST_MUL + i * 4u);
        for (v = 0; v <= 127u; v += 63u + (v == 63u)) {
            lfo_c c; lfo_s s = {0};
            uint32_t n, wraps = 0, N = 400000u;
            lfo_coef(&c, v, i, 0, LM_FREE, 0, 250);
            for (n = 0; n < N; n++) { uint32_t p0 = s.ph; lfo_step(&s, &c); if (s.ph < p0) wraps++; }
            printf("  %9.4f (%.4f)", ((double)wraps * 4294967296.0 + s.ph) / 4294967296.0 / ((double)N / CORE_SR), lfo_hz(v, i));
        }
        printf("\n");
    }
    check(lfo_hz(0, 0) < 0.002f && lfo_hz(127, 7) > 2500.0f, "the whole span: under 0.002 Hz to over 2.5 kHz");

    printf("synced LFO\n");
    {
        uint32_t bpb, j, bad = 0;
        for (bpb = 200; bpb <= 500; bpb += 37)
            for (j = 0; j < LFO_NSYNC; j++) {
                lfo_c c; lfo_s s = {0};
                uint32_t rt = (j * 128u + 127u) / LFO_NSYNC, n, per6 = LFO_SYNC_N[lfo_sync_i(rt)] * bpb, cyc = 0;
                lfo_coef(&c, rt, LFO_SYNC, 0, LM_FREE, 0, bpb);
                for (n = 0; n < per6 && cyc < 2u; n++) { uint32_t p0 = s.ph; lfo_step(&s, &c); if (s.ph < p0) cyc++; }
                /* after exactly P / 6 samples x 6 the phase has done one cycle, within one sample's step */
                { double cyc6 = ((double)c.inc + (double)c.incf / 4294967296.0) * (double)per6 / 6.0 / 4294967296.0; if (fabs(cyc6 - 1.0) > 1e-6) bad++; }
            }
        check(!bad, "every note value at every tempo: one cycle = N/384 bar = N x bpb / 6 clock samples");
    }
    {   /* a synced FREE LFO's phase is the song position */
        lfo_c c; lfo_s a = {0}, b = {0};
        uint32_t n;
        os.playing = 1; os.play_c0 = 1000; os.bpb = 250;
        lfo_coef(&c, 64, LFO_SYNC, 0, LM_FREE, 0, 250);
        lfo_lock(&a, &c, 64, 250, 0);
        for (n = 0; n < 77777u; n++) lfo_step(&a, &c);
        lfo_lock(&b, &c, 64, 250, 77777u);
        check((int32_t)(a.ph - b.ph) < 4096 && (int32_t)(b.ph - a.ph) < 4096 * 64, "running free for 77777 samples = locked to the song position there");
    }

    printf("modes\n");
    {
        lfo_c c; lfo_s s = {0};
        uint32_t n, per = 800;
        float first, mx = -2.0f, last = 0.0f;
        lfo_coef(&c, 64, 3, 0, LM_TRIG, 32, 250);          /* ~1 Hz, PH 32 = 90 degrees */
        lfo_trig(&s, &c, 0); first = s.x;
        check(fabsf(first - 1.0f) < 0.01f, "TRIG at PH 90 degrees starts at the sine's top");
        lfo_coef(&c, 127, 4, 4, LM_ONE, 0, 250);           /* 40 Hz ramp, one cycle */
        lfo_trig(&s, &c, 0);
        for (n = 0; n < per; n++) { last = lfo_step(&s, &c); if (last > mx) mx = last; }
        check(s.done && mx > 0.99f && fabsf(last - (-1.0f)) < 0.01f, "ONE: one ramp up, then holds at its start");
        lfo_coef(&c, 127, 4, 4, LM_HALF, 0, 250);
        lfo_trig(&s, &c, 0); mx = -2.0f;
        for (n = 0; n < per; n++) { last = lfo_step(&s, &c); if (last > mx) mx = last; }
        check(s.done && fabsf(last) < 0.01f && mx < 0.05f, "HALF: half the ramp (to 0), then holds");
        {
            lfo_s m = {0}, v = {0};
            lfo_coef(&c, 64, 3, 6, LM_HOLD, 0, 250);
            m.rnd = 12345;
            for (n = 0; n < 5000u; n++) lfo_step(&m, &c);
            lfo_trig(&v, &c, &m);
            first = v.mode_x = v.held;
            for (n = 0; n < 20000u; n++) last = lfo_step(&v, &c);
            check(last == first && v.ph != m.ph + 0u, "HOLD: the free LFO's value at the note, held");
        }
    }
    {
        static const char *SH[8] = {"SIN", "TRI", "SQR", "SAW", "RMP", "EXP", "S&H", "SMT"};
        uint32_t sh;
        for (sh = 0; sh < 8u; sh++) {
            lfo_c c; lfo_s s = {0};
            float lo = 9, hi = -9, x;
            uint32_t n;
            char b[64];
            s.rnd = 777;
            lfo_coef(&c, 127, 5, sh, LM_FREE, 0, 250);      /* 160 Hz */
            for (n = 0; n < 40000u; n++) { x = lfo_step(&s, &c); if (x < lo) lo = x; if (x > hi) hi = x; }
            snprintf(b, sizeof b, "shape %s spans %+.2f .. %+.2f", SH[sh], lo, hi);
            check(lo >= -1.001f && hi <= 1.001f && hi - lo > (sh >= 6u ? 1.2f : 1.95f), b);
        }
    }

    printf("ENV2 and a voice's ENV1\n");
    {
        trk_t *t;
        uint32_t n;
        memset(&os, 0, sizeof os);
        memset(pool, 0, sizeof pool);
        os_engine_init();
        t = &os.trk[1];                                     /* the kit (MULTI) */
        t->base[R_AT2] = 0; t->base[R_SU2] = 100; t->base[R_ET1] = MU_PIT; t->base[R_ED1] = 64 + 30; t->base[R_RG1] = 1;
        trk_resolve(t, 1); mod_block(1, os.clock); trk_resolve(t, 1); mod_block(1, os.clock);
        mach_note_on(1, 48, 100, os.clock, 0, 1);
        mach_note_on(1, 50, 100, os.clock, 0, 1);
        for (n = 0; n < 4000u; n++) env_step(&t->e2, &t->ec[2]);
        check(t->e2.st == 2 && t->e2.v > 0.7f, "ENV2 opens with a note and holds at SUS");
        mach_note_off(1, 48);
        check(t->e2.st == 2, "one note of two released: ENV2 still open");
        mach_note_off(1, 50);
        check(t->e2.st == 3, "the last note released: ENV2 closes");
        {
            pv_t *p = 0;
            vmod_t vm;
            float p0, p1;
            uint32_t j;
            mach_note_on(1, 52, 100, os.clock, 0, 1);
            for (j = 0; j < POLY_MAX; j++) if (pool[1][j].used && pool[1][j].note == 52 && pool[1][j].env.st == 1) p = &pool[1][j];
            mod_voice(t, &p->e1, &p->l1, &vm); p0 = vm.pit;
            for (n = 0; n < 400u; n++) mod_voice(t, &p->e1, &p->l1, &vm);
            p1 = vm.pit;
            check(t->rt[MS_ENV1].kind == MK_PIT && p0 > 20.0f && p1 < 1.0f, "a voice's ENV1 on MU_PIT: up at its own hit (+29 st), back down as its envelope decays");
        }
    }
    printf("%s: %d failed\n", fails ? "FAILED" : "all passed", fails);
    return fails != 0;
}
