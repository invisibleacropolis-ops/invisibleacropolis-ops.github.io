/* SPDX-License-Identifier: GPL-3.0-only */
/* Host stand-ins for the SMK-37 board layer: just what os_font.c, os_ui.c and os_engine.c touch.
 * The screen is a 240x240 RGB565 framebuffer, the controls are set by the test script. */
#include <stdint.h>
#include <string.h>
#define SMK_NPAD 16u
#define FM1_NENC 8u
#define FM1_NKEY 37u
#define SMK_NLED 19u
enum { FM1_BTN_OCT_DOWN = 4, FM1_BTN_OCT_UP = 5 };
static struct {
    uint32_t buttons;
    uint64_t keys;
    uint8_t key_vel[37];
    uint8_t pad_st[16];
    uint8_t pad_press[16], pad_vel[16];
    uint8_t fader[4];
    uint16_t wheel[2];
    uint32_t frames;
} fm1_in;
static uint32_t sim_pressed;
static int32_t sim_enc[8];
static uint8_t sim_led[19];
static uint16_t FB[240 * 240];
static uint32_t sim_pad_rgb[16];
static inline uint32_t fm1__lock(void) { return 0; }
static inline void fm1__unlock(uint32_t v) { (void)v; }
static uint32_t fm1_input_edges(uint32_t *rel) { uint32_t p = sim_pressed; sim_pressed = 0; if (rel) *rel = 0; return p; }
static int32_t fm1_enc_take(uint32_t e) { int32_t s = sim_enc[e]; sim_enc[e] = 0; return s; }
static void fm1_led_key(uint32_t id, int on) { if (id < 19u) sim_led[id] = (uint8_t)(on != 0); }
static void lcd_sync(void) {}
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    for (uint32_t j = y; j < y + h && j < 240u; j++)
        for (uint32_t i = x; i < x + w && i < 240u; i++) FB[j * 240u + i] = c;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *px)
{
    for (uint32_t j = 0; j < h; j++)
        for (uint32_t i = 0; i < w; i++) {
            uint16_t v = px[j * w + i];
            if (x + i < 240u && y + j < 240u) FB[(y + j) * 240u + x + i] = (uint16_t)((v >> 8) | (v << 8));
        }
}
static void padled_set(uint32_t pad, uint8_t r, uint8_t g, uint8_t b) { if (pad < 16u) sim_pad_rgb[pad] = (uint32_t)r << 16 | (uint32_t)g << 8 | b; }
static void padled_flush(void) {}
