/* SPDX-License-Identifier: GPL-3.0-only */
/* What the one clock makes possible: BRR-OS's own engine (since v0.3), driven through its event lists and registers.
 *   demo_retrig.wav  a snare retriggered every 512, 256 ... 8, 4 samples: a roll becomes a pitched tone
 *   demo_table.wav   a 6-row transpose table on WAVE, rows every 128 samples ... every sample: arpeggio -> timbre
 *   demo_fm.wav      the LFO on WAVE pitch, from 1.3 Hz vibrato to 1.4 kHz: FM
 *   demo_am.wav      the LFO on a pad's level, from tremolo to 560 Hz: AM sidebands
 *   demo_comb.wav    one snare on two tracks, the second 0, 1, 2, 4, 8, 16 core samples late (a lock per bar)
 *   demo_source.wav  the plain sounds the demos start from: the snare, the WAVE note, the WAVE chord
 *   demo_shape.wav   the shaper (page L): a kit loop through TAPE TUBE CLIP FOLD CHEB XOVR RECT BITS POLY, a bar
 *                    each; then a WAVE note behind a resonant low-pass, folded PRE (2 bars) and POST (2 bars)
 * Each section is 2 bars at 150 BPM. Run from an empty directory. */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "host_stubs.h"
#include "os_core.h"
#include "os_font.c"
#define SV_API static
#include "svbrr_dec.c"
#include "os_fx.c"
#include "os_regs.c"
#include "os_flt.c"
#include "os_hf.c"
#include "os_tfx.c"
#include "os_mod.c"
#include "os_mach.c"
#include "os_shp.c"
#include "os_seq.c"
#include "os_engine.c"

static int16_t pcm[2 * 44118 * 30];
static long pcm_n;

static void render_bars(double bars)
{
    int32_t out[2 * HALF_FRAMES];
    long frames = (long)(bars * 4.0 * os.bpb * 16.0 * 375.0 / 68.0);
    long done = 0;
    int i;
    while (done < frames) {
        os_render(out, HALF_FRAMES);
        for (i = 0; i < 2 * HALF_FRAMES; i++) {
            int v = out[i] >> 7;
            pcm[pcm_n++] = (int16_t)(v > 32767 ? 32767 : v < -32768 ? -32768 : v);
        }
        done += HALF_FRAMES;
    }
}

static void write_wav(const char *fn)
{
    FILE *f = fopen(fn, "wb");
    int sr = 44118, bytes = (int)(pcm_n * 2), v;
    short s;
    fwrite("RIFF", 1, 4, f); v = 36 + bytes; fwrite(&v, 4, 1, f); fwrite("WAVEfmt ", 1, 8, f);
    v = 16; fwrite(&v, 4, 1, f); s = 1; fwrite(&s, 2, 1, f); s = 2; fwrite(&s, 2, 1, f);
    fwrite(&sr, 4, 1, f); v = sr * 4; fwrite(&v, 4, 1, f); s = 4; fwrite(&s, 2, 1, f); s = 16; fwrite(&s, 2, 1, f);
    fwrite("data", 1, 4, f); fwrite(&bytes, 4, 1, f); fwrite(pcm, 2, (size_t)pcm_n, f);
    fclose(f);
    printf("%s: %.1f s\n", fn, pcm_n / 2.0 / 44118.0);
    pcm_n = 0;
}

/* a fresh engine: all four tracks silent, then the demo sets what it needs */
static void fresh(void)
{
    uint32_t k;
    seq_play(0);
    memset(&os, 0, sizeof os);
    memset(pool, 0, sizeof pool);
    os_engine_init();
    for (k = 0; k < NTRACK; k++) os.trk[k].base[R_LEV] = 0;
}

static void kit(uint32_t k)
{
    trk_set_machine(&os.trk[k], MA_MULTI);
    os.trk[k].base[MU_SMP] = 8;                         /* KICK = C3 */
    os.trk[k].base[MU_MAP] = 1;
    os.trk[k].base[R_LEV] = 105;
    os.trk[k].base[R_PAN] = 64;
}

int main(void)
{
    int i;
    /* ---- retrig: R b, every 2^(b/16) samples */
    {
        static const uint8_t B[6] = {144, 112, 80, 64, 48, 32};   /* 512, 128, 32, 16, 8, 4 samples */
        fresh();
        kit(1);
        os.trk[1].base[R_ATK] = 0;
        os.trk[1].base[R_DEC] = 80;
        seq_put_note(seq_list(1), 0, 49, 110, 0, LEN_HOLD, 0);   /* the snare, held */
        seq_put_cmd(seq_list(1), 0, 'R', B[0], 0);
        os.trk[1].base[R_STP] = 31;                       /* 32 steps: the retrig runs 2 bars */
        seq_play(1);
        for (i = 0; i < 6; i++) {                         /* (R fires on step 0: the next value goes in just before) */
            render_bars(1.9);
            if (i < 5) {
                int j = evl_find(seq_list(1), 0, EV_CMD, 'R');
                seq_list(1)->e[j].b = B[i + 1];
                seq_edits++;
            }
            render_bars(0.1);
        }
        write_wav("demo_retrig.wav");
    }
    /* ---- table at audio rate: 6 rows of transposes, rows every 2^(TSP/16) samples */
    {
        static const uint8_t T[6] = {112, 96, 80, 64, 32, 0};      /* 128, 64, 32, 16, 4, 1 samples a row */
        static const int8_t N[6] = {0, 12, 7, 19, 3, 24};
        uint32_t r;
        fresh();
        os.trk[2].base[R_LEV] = 95;
        os.trk[2].base[WA_FRM] = 40;
        os.trk[2].base[R_TBL] = 1;
        os.trk[2].base[R_REL] = 40;
        for (r = 0; r < 6; r++) seq_put_cmd(&seq_tbl[0], r, 'N', (uint32_t)(64 + N[r]), 0);
        seq_put_cmd(&seq_tbl[0], 6, 'H', 0, 0);
        os.trk[2].base[R_STP] = 31;
        seq_put_note(seq_list(2), 0, 45, 100, 0, LEN_HOLD, 0);
        seq_play(1);
        for (i = 0; i < 6; i++) {
            os.trk[2].base[R_TSP] = T[i];
            render_bars(2.0);
        }
        write_wav("demo_table.wav");
    }
    /* ---- the LFO on pitch: vibrato to FM */
    {
        /* LFO2: RATE x MUL (os_mod.c) for 1.1, 6.3, 31, 105, 240, 1400 Hz */
        static const uint8_t R[6] = {66, 114, 120, 115, 100, 110}, M[6] = {3, 3, 4, 5, 6, 7};
        fresh();
        os.trk[2].base[R_LEV] = 95;
        os.trk[2].base[WA_FRM] = 0;
        os.trk[2].base[R_LT2] = WA_PIT;
        os.trk[2].base[R_LD2] = 74;                        /* +-3.2 semitones */
        os.trk[2].base[R_STP] = 31;
        seq_put_note(seq_list(2), 0, 57, 100, 0, LEN_HOLD, 0);
        seq_play(1);
        for (i = 0; i < 6; i++) {
            os.trk[2].base[R_RT2] = R[i];
            os.trk[2].base[R_MU2] = M[i];
            render_bars(2.0);
        }
        write_wav("demo_fm.wav");
    }
    /* ---- the LFO on level: tremolo to AM */
    {
        static const uint8_t R[6] = {92, 98, 93, 115, 100, 123}, M[6] = {3, 4, 5, 5, 6, 6};   /* 2.8 .. 560 Hz */
        fresh();
        os.trk[2].base[R_LEV] = 95;
        os.trk[2].base[WA_FRM] = 60;
        os.trk[2].base[R_LT2] = R_LEV;
        os.trk[2].base[R_LD2] = 107;                       /* +-0.94 of the level */
        os.trk[2].base[R_STP] = 31;
        seq_put_note(seq_list(2), 0, 48, 100, 0, LEN_HOLD, 0);
        seq_put_note(seq_list(2), 0, 55, 100, 0, LEN_HOLD, 0);
        seq_put_note(seq_list(2), 0, 64, 100, 0, LEN_HOLD, 0);
        seq_play(1);
        for (i = 0; i < 6; i++) {
            os.trk[2].base[R_RT2] = R[i];
            os.trk[2].base[R_MU2] = M[i];
            render_bars(2.0);
        }
        write_wav("demo_am.wav");
    }
    /* ---- sub-ms timing as timbre: the same snare on two tracks, the second n samples late */
    {
        static const int D[6] = {0, 1, 2, 4, 8, 16};
        uint32_t s;
        fresh();
        kit(1);
        kit(3);
        os.trk[1].base[R_PAN] = os.trk[3].base[R_PAN] = 64;
        os.trk[1].base[R_LEV] = os.trk[3].base[R_LEV] = 90;
        seq_play(1);
        for (i = 0; i < 6; i++) {
            uint32_t L = trk_steplen(&os.trk[3]);
            int32_t off = (int32_t)((D[i] * 4096 + (int)L - 1) / (int)L);   /* n samples, as a residual */
            evl_clear(seq_list(1)); evl_clear(seq_list(3));
            for (s = 0; s < 16; s += 2) {
                seq_put_note(seq_list(1), s, 49, 105, 0, 4, 0);
                seq_put_note(seq_list(3), s, 49, 105, off, 4, 0);
            }
            render_bars(2.0);
        }
        write_wav("demo_comb.wav");
    }
    /* ---- the sources, plain */
    {
        uint32_t s;
        fresh();
        kit(1);
        for (s = 0; s < 16; s += 2) seq_put_note(seq_list(1), s, 49, 105, 0, 4, 0);
        seq_play(1);
        render_bars(2.0);
        seq_play(0);
        evl_clear(seq_list(1));
        os.trk[1].base[R_LEV] = 0;
        os.trk[2].base[R_LEV] = 95;
        os.trk[2].base[R_STP] = 31;
        seq_put_note(seq_list(2), 0, 57, 100, 0, LEN_HOLD, 0);
        seq_play(1);
        render_bars(2.0);
        seq_play(0);
        evl_clear(seq_list(2));
        os.trk[2].base[WA_FRM] = 60;
        seq_put_note(seq_list(2), 0, 48, 100, 0, LEN_HOLD, 0);
        seq_put_note(seq_list(2), 0, 55, 100, 0, LEN_HOLD, 0);
        seq_put_note(seq_list(2), 0, 64, 100, 0, LEN_HOLD, 0);
        seq_play(1);
        render_bars(2.0);
        write_wav("demo_source.wav");
    }
    /* ---- the shaper: the kit through every model, then a fold before and after a low-pass */
    {
        static const uint8_t SET[SH_N][4] = {{80, 50, 40, 64}, {85, 90, 60, 72}, {100, 10, 50, 64}, {60, 70, 30, 64},
                                            {30, 50, 30, 64}, {40, 90, 20, 64}, {20, 127, 0, 64}, {40, 100, 70, 64},
                                            {20, 110, 80, 64}};
        uint32_t s, m;
        fresh();
        kit(1);
        for (s = 0; s < 16; s++) {
            if (s % 4 == 0) seq_put_note(seq_list(1), s, 48, 112, 0, 6, 0);
            if (s % 8 == 4) seq_put_note(seq_list(1), s, 49, 105, 0, 6, 0);
            seq_put_note(seq_list(1), s, 50, s % 4 == 2 ? 100 : 70, 0, 3, 0);
        }
        seq_play(1);
        render_bars(1.0);                                 /* plain */
        for (m = 0; m < SH_N; m++) {
            trk_t *t = &os.trk[1];
            t->base[R_SMD] = (uint8_t)m; t->base[R_SIN] = SET[m][0]; t->base[R_SA] = SET[m][1];
            t->base[R_SB] = SET[m][2]; t->base[R_SBI] = SET[m][3]; t->base[R_SMX] = 127;
            render_bars(1.0);
        }
        seq_play(0);
        evl_clear(seq_list(1));
        os.trk[1].base[R_LEV] = 0;
        os.trk[1].base[R_SMX] = 0;
        os.trk[2].base[R_LEV] = 95;
        os.trk[2].base[R_STP] = 31;
        os.trk[2].base[R_TYP] = FLT_LP;
        os.trk[2].base[R_CUT] = 40;
        os.trk[2].base[R_RES] = 50;
        os.trk[2].base[R_SMD] = SH_FOLD; os.trk[2].base[R_SIN] = 70; os.trk[2].base[R_SA] = 64;
        os.trk[2].base[R_SB] = 40; os.trk[2].base[R_SMX] = 127;
        seq_put_note(seq_list(2), 0, 45, 100, 0, LEN_HOLD, 0);
        seq_play(1);
        os.trk[2].base[R_SPS] = 0;
        render_bars(2.0);
        os.trk[2].base[R_SPS] = 1;
        render_bars(2.0);
        write_wav("demo_shape.wav");
    }
    return 0;
}
