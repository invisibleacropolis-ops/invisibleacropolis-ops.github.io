/* SPDX-License-Identifier: GPL-3.0-only */
/* Unit tests of the vault (os_vault.c) on a simulated NOR flash (program clears bits only, erase sets a 4 KiB
 * sector to 0xFF): records of 0 .. 24 KiB round the ring thousands of times against a model; remounts; a full
 * area; saves while playing (never an erase: refused before a byte is written, or done); an area holding
 * another firmware's data left alone until formatted; the power cut at random points of thousands of saves:
 * after it every record is its old or its new self and the vault still works; nothing outside FL_DATA touched;
 * the wear spread over the sectors; a real kit and sound through it.
 *   gcc -O2 -std=gnu11 -DBOARD_SMK37=1 -I. -I../firmware/src -I../firmware/hal -I../build/gen -o vault_unit vault_unit.c -lm */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <math.h>
#include "host_stubs.h"
#include "os_core.h"
#include "os_font.c"
#define SV_API static
#include "svbrr_dec.c"
#include "os_fx.c"
#include "os_regs.c"
#include "os_flt.c"
#include "os_hf.c"
#include "os_tfx.c"
#include "os_mod.c"
#include "os_mach.c"
#include "os_shp.c"
#include "os_seq.c"
#include "os_store.c"
#include "os_engine.c"
#include "fm1_flash_map.h"

#include "host_nor.h"
#include "os_vault.c"

static int fails;
static void check(int ok, const char *what) { printf("  [%s] %s\n", ok ? " ok " : "FAIL", what); if (!ok) fails++; }

/* ---------------------------------------------------------------- the model */
#define NKEY 48
typedef struct { int have; uint32_t len; uint8_t *b; } mrec;
static mrec model[NKEY], prev_model;
static uint8_t pay[24576], got[24576];
static uint32_t key_type(uint32_t k) { return k < 16u ? ST_KIT : ST_SOUND; }
static uint32_t key_id(uint32_t k) { return k < 16u ? k : k - 16u; }
static uint32_t rnd(uint32_t n) { return (uint32_t)rand() % n; }

static void make(uint32_t k, uint32_t *len)
{
    uint32_t i, seed = (uint32_t)rand();
    *len = key_type(k) == ST_KIT ? (rnd(4) ? 300u + rnd(6000) : rnd(23000u)) : 8u + rnd(60);
    if (rnd(20) == 0) *len = 0;
    for (i = 0; i < *len; i++) { seed = seed * 1103515245u + 12345u; pay[i] = (uint8_t)(seed >> 16); }
}
static void model_set(uint32_t k, uint32_t len)
{
    free(model[k].b);
    model[k].b = malloc(len ? len : 1);
    memcpy(model[k].b, pay, len);
    model[k].len = len;
    model[k].have = 1;
}
static int matches(uint32_t k, const mrec *m)
{
    int32_t n = vault_get(key_type(k), key_id(k), got, sizeof got);
    if (!m->have) return n == VT_NONE;
    return n == (int32_t)m->len && !memcmp(got, m->b, m->len);
}
static uint32_t all_match(void)
{
    uint32_t k, bad = 0;
    for (k = 0; k < NKEY; k++) bad += !matches(k, &model[k]);
    return bad;
}

int main(void)
{
    uint32_t i, k, bad, okn = 0, busy = 0, full = 0, rounds;
    char b[200];
    if (os_engine_init()) { fprintf(stderr, "library did not open\n"); return 1; }
    srand(21);
    printf("an erased area\n");
    memset(nor, 0xFF, sizeof nor);
    check(vault_mount() == VT_OK && !vt.foreign && vt.n == 1u, "mounts empty: claimed with the owner record");
    check(vault_get(ST_KIT, 0, got, sizeof got) == VT_NONE, "nothing there yet");

    printf("thousands of saves round the ring, against a model\n");
    for (i = 0; i < 6000u; i++) {
        uint32_t len;
        int r;
        k = rnd(NKEY);
        if (rnd(10) == 0) {
            r = vault_del(key_type(k), key_id(k), 1);
            if (r == VT_OK) { model[k].have = 0; okn++; } else if (r == VT_FULL) full++; else { snprintf(b, sizeof b, "delete %u: %d", i, r); check(0, b); break; }
        } else {
            make(k, &len);
            r = vault_put(key_type(k), key_id(k), pay, len, 1);
            if (r == VT_OK) { model_set(k, len); okn++; } else if (r == VT_FULL) full++; else { snprintf(b, sizeof b, "save %u: %d", i, r); check(0, b); break; }
        }
        if (i % 500u == 499u) {
            bad = all_match();
            if (bad) { snprintf(b, sizeof b, "after %u: %u records differ from the model", i + 1u, bad); check(0, b); break; }
            if (vault_mount() != VT_OK || (bad = all_match())) { snprintf(b, sizeof b, "remount after %u: %u differ", i + 1u, bad); check(0, b); break; }
        }
    }
    {
        uint32_t wmin = ~0u, wmax = 0;
        for (k = 0; k < VT_NSEC; k++) { if (wear[k] < wmin) wmin = wear[k]; if (wear[k] > wmax) wmax = wear[k]; }
        snprintf(b, sizeof b, "6000 saves / deletes (%u done, %u full), every 500 all checked and remounted: all match", okn, full);
        check(!all_match(), b);
        snprintf(b, sizeof b, "the wear: every sector erased %u .. %u times (%u erases in all, %.1f MB programmed)", wmin, wmax, erases, progs / 1e6);
        check(wmin > 0u && wmax <= wmin * 2u + 4u, b);
    }

    printf("full\n");
    memset(nor, 0xFF, sizeof nor);
    for (k = 0; k < NKEY; k++) model[k].have = 0;
    vault_mount();
    {
        uint32_t stored = 0, n = 0;
        for (i = 0; i < 200u; i++) {
            uint32_t len = 4000u + rnd(4000);
            int r;
            memset(pay, (int)i, len);
            r = vault_put(ST_KIT, i, pay, len, 1);
            if (r == VT_FULL) break;
            if (r != VT_OK) { check(0, "a save failed"); break; }
            stored += len; n++;
        }
        snprintf(b, sizeof b, "filled with %u records: %u B of %u (%.0f %%), then FULL; every one reads back", n, stored, AREA, 100.0 * stored / AREA);
        for (i = 0, bad = 0; i < n; i++) {
            int32_t g = vault_get(ST_KIT, i, got, sizeof got);
            if (g <= 0 || got[0] != (uint8_t)i || got[g - 1] != (uint8_t)i) bad++;
        }
        check(!bad && stored > AREA * 85u / 100u, b);
        check(vault_del(ST_KIT, 3, 1) == VT_OK && vault_put(ST_KIT, 3, pay, 2000, 1) == VT_OK, "full: a deletion makes room again");
    }

    printf("while playing (no erase allowed)\n");
    memset(nor, 0xFF, sizeof nor);
    for (k = 0; k < NKEY; k++) model[k].have = 0;
    vault_mount();
    {
        uint32_t untouched = 1, done = 0;
        static uint8_t before[AREA];
        for (i = 0; i < 400u; i++) {
            uint32_t len;
            int r;
            k = rnd(NKEY);
            make(k, &len);
            if (i % 3u == 0u) {                              /* playing */
                memcpy(before, nor, AREA);
                r = vault_put(key_type(k), key_id(k), pay, len, 0);
                if (r == VT_BUSY) { busy++; if (memcmp(before, nor, AREA)) untouched = 0; continue; }
                done++;
            } else r = vault_put(key_type(k), key_id(k), pay, len, 1);
            if (r == VT_OK) model_set(k, len);
            if (i % 5u == 4u) vault_idle();                  /* stopped and silent now and then */
        }
        snprintf(b, sizeof b, "of 134 saves while playing: %u done, %u refused (an erase needed): those wrote nothing", done, busy);
        check(untouched && !all_match(), b);
        for (i = 0; i < 2u * VT_AHEAD; i++) vault_idle();
        make(20, &k);
        snprintf(b, sizeof b, "after idle time: a %u B save while playing goes through", k);
        check(vault_put(ST_SOUND, 4, pay, k, 0) == VT_OK, b);
        model_set(20, k);
    }

    printf("another firmware's data\n");
    for (i = 0; i < AREA; i++) nor[i] = (uint8_t)rand();
    memcpy(got, nor, 4096);
    vault_mount();
    check(vt.foreign, "an area of bytes that are not ours: foreign");
    check(vault_put(ST_KIT, 0, pay, 100, 1) == VT_FOREIGN && !memcmp(got, nor, 4096), "a save is refused and nothing is written");
    check(vault_format() == VT_OK && !vt.foreign && vault_put(ST_KIT, 0, pay, 100, 1) == VT_OK, "formatted (the owner's choice): ours");

    printf("the power cut at random points\n");
    memset(nor, 0xFF, sizeof nor);
    for (k = 0; k < NKEY; k++) model[k].have = 0;
    vault_mount();
    rounds = 0;
    {
        uint32_t cuts = 0, torn = 0, errs = 0, newer = 0, older = 0;
        for (i = 0; i < 4000u; i++) {
            uint32_t len;
            int r;
            k = rnd(NKEY);
            make(k, &len);
            prev_model = model[k];
            cut = rnd(3) ? (long)rnd(len + 6000u) : (long)rnd(3);   /* bytes (or erases) until the cut */
            if (setjmp(power) == 0) {
                r = vault_put(key_type(k), key_id(k), pay, len, 1);
                cut = -1;
                if (r == VT_OK) model_set(k, len);
                continue;
            }
            cut = -1;                                       /* the power came back: boot */
            cuts++;
            if (rnd(3) == 0) cut = (long)rnd(300);          /* and goes again during the boot's repair, at times */
            if (vault_mount() != VT_OK) { errs++; continue; }
            cut = -1;
            if (matches(k, &prev_model)) older++;
            else {
                mrec now = {1, len, pay};
                if (matches(k, &now)) { newer++; model_set(k, len); } else torn++;
            }
            model[k].have = model[k].have;              /* (k: the old or the new; everything else as it was) */
            {
                uint32_t j;
                for (j = 0; j < NKEY; j++) if (j != k && !matches(j, &model[j])) torn++;
            }
            rounds++;
        }
        snprintf(b, sizeof b, "%u saves, %u cut (%u in a copy round the ring, finished at boot): after each, the record old (%u) or new (%u), never torn (%u), the vault up (%u failures)",
                 i, cuts, vt_repairs, older, newer, torn, errs);
        check(!torn && !errs && cuts > 1000u, b);
        check(!all_match(), "and after them all, every record as the model has it");
    }
    snprintf(b, sizeof b, "nothing read or written outside FL_DATA (0x%05X-0x%05X): %u attempts", FL_DATA_LO, FL_DATA_HI - 1u, outside);
    check(!outside, b);

    printf("presets through it\n");
    memset(nor, 0xFF, sizeof nor);
    vault_mount();
    {
        static uint8_t k1[65536], k2[65536];
        uint32_t n1, n2;
        os.trk[1].base[R_CUT] = 33;
        seq_put_note(&seq_pat[2][1], 5, 61, 99, 120, 6, 0);
        n1 = st_kit_save(k1, sizeof k1);
        check(vault_kit_save(7, 1) == VT_OK, "the kit saved to slot 8");
        os.trk[1].base[R_CUT] = 90;
        evl_clear(&seq_pat[2][1]);
        check(vault_kit_load(7) == VT_OK, "loaded back");
        n2 = st_kit_save(k2, sizeof k2);
        check(n1 == n2 && !memcmp(k1, k2, n1) && os.trk[1].base[R_CUT] == 33u && seq_pat[2][1].n == 1u, "the same kit");
        {   /* a kit as big as the event heap allows: through the 1 KB window, no buffer of its size anywhere */
            static uint8_t big1[262144], big2[262144];
            uint32_t m1, m2, e;
            for (e = 0; e < 9800u; e++) {
                ev_t x = {(uint8_t)rnd(256), (uint8_t)rnd(2), (int16_t)(rnd(3) ? 0 : (int)rnd(4000) - 2000), (uint8_t)rnd(128), (uint8_t)rnd(128), (uint8_t)rnd(16), 0};
                if (x.kind == EV_LOCK) x.a = (uint8_t)rnd(NREG);
                evl_insert(&seq_all[rnd(NPAT * NTRACK)], &x);
            }
            m1 = st_kit_save(big1, sizeof big1);
            snprintf(b, sizeof b, "a kit of %u events (%u B): saved and loaded back the same", seq_used, m1);
            k = vault_kit_save(9, 1) == VT_OK;
            seq_init();
            k &= vault_kit_load(9) == VT_OK;
            m2 = st_kit_save(big2, sizeof big2);
            check(k && m1 == m2 && !memcmp(big1, big2, m1), b);
        }
        check(vault_sound_save(3, 1, 1) == VT_OK, "track 2's sound saved to slot 4");
        os.trk[2].base[R_CUT] = 5;
        check(vault_sound_load(3, 2) == VT_OK && os.trk[2].base[R_CUT] == 33u && os.trk[2].mach == os.trk[1].mach, "loaded onto track 3");
    }
    printf("\n%s (%d failed)\n", fails ? "FAILED" : "all passed", fails);
    return fails != 0;
}
