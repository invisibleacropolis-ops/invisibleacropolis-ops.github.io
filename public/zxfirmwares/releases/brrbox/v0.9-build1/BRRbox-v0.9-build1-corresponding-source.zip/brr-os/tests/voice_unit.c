/* SPDX-License-Identifier: GPL-3.0-only */
/* Unit tests of the voices (os_mach.c): a track's VOI limit, the shared budget of 8 across the tracks (a
 * sounding mono track counting one), which voice goes (releasing first, then the oldest, anywhere), the soft
 * steal (a choke into a free slot, not a restart), and a note storm that never runs over for more than a half.
 *   gcc -O2 -std=gnu11 -I. -I../firmware/src -I../build/gen -o voice_unit voice_unit.c -lm && ./voice_unit */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "host_stubs.h"
#include "os_core.h"
#include "os_font.c"
#define SV_API static
#include "svbrr_dec.c"
#include "os_fx.c"
#include "os_regs.c"
#include "os_flt.c"
#include "os_hf.c"
#include "os_tfx.c"
#include "os_mod.c"
#include "os_mach.c"
#include "os_shp.c"
#include "os_seq.c"
#include "os_engine.c"

static int fails;
static void check(int ok, const char *what) { printf("  [%s] %s\n", ok ? " ok " : "FAIL", what); if (!ok) fails++; }
static int32_t out[HALF_FRAMES * 2u];

static uint32_t live(uint32_t k)
{
    uint32_t i, n = 0;
    for (i = 0; i < POLY_MAX; i++) n += (uint32_t)pv_live(&pool[k][i]);
    return n;
}
static uint32_t live_all(void)
{
    uint32_t k, n = 0;
    for (k = 0; k < NTRACK; k++) n += MACH[os.trk[k].mach].poly < 2u ? (uint32_t)(mono_busy(k) != 0) : live(k);
    return n;
}
static int has_note(uint32_t k, uint32_t note)
{
    uint32_t i;
    for (i = 0; i < POLY_MAX; i++) if (pv_live(&pool[k][i]) && pool[k][i].note == note) return 1;
    return 0;
}
static void set(uint32_t k, uint32_t r, uint32_t v) { os.trk[k].base[r] = os.trk[k].eff[r] = (uint8_t)v; }
static void half(void) { os_render(out, HALF_FRAMES); }
static void on(uint32_t k, uint32_t note) { mach_note_on(k, note, 100, os.clock, 0, 0); }
static void reset(void)
{
    uint32_t k;
    uint32_t i;
    for (k = 0; k < NTRACK; k++) {
        mach_kill(k);
        for (i = 0; i < POLY_MAX; i++) pool[k][i].env.st = 4;   /* everything chokes out */
        if (os.trk[k].env.st) os.trk[k].env.st = 4;
    }
    for (k = 0; k < 8u; k++) half();
    for (k = 0; k < NTRACK; k++) for (i = 0; i < POLY_MAX; i++) if (pool[k][i].used) printf("  (slot %u.%u still in use)\n", k, i);
}

int main(void)
{
    uint32_t k, i, n, worst = 0, over = 0, run = 0, longest = 0;
    char b[128];
    if (os_engine_init()) { fprintf(stderr, "library did not open\n"); return 1; }
    for (k = 0; k < 3u; k++) {                    /* three WAVE tracks (they hold), one TAPE */
        trk_set_machine(&os.trk[k], MA_WAVE);
        set(k, R_SUS, 127); set(k, R_REL, 40);
    }
    trk_set_machine(&os.trk[3], MA_TAPE);
    set(3, 6, 1);                                 /* TAPE GAT: the env gates it */
    set(3, 7, 0);                                 /* free tape */
    reset();

    printf("a track's own limit\n");
    set(0, R_VOI, 1);                             /* 2 voices */
    on(0, 60); half(); on(0, 62); half(); on(0, 64); half();
    snprintf(b, sizeof b, "VOI 2, three held notes: %u live, the first gone (%d %d %d)", live(0), has_note(0, 60), has_note(0, 62), has_note(0, 64));
    check(live(0) == 2u && !has_note(0, 60) && has_note(0, 62) && has_note(0, 64), b);
    {   /* the third note's steal was soft: the first voice choking, in its own slot, while the new one starts */
        uint32_t ch = 0, us = 0;
        reset();
        on(0, 60); on(0, 62); on(0, 64);
        for (i = 0; i < POLY_MAX; i++) { us += pool[0][i].used; ch += pool[0][i].used && pool[0][i].env.st == 4; }
        snprintf(b, sizeof b, "the steal fades: %u slots in use, %u choking (1 ms), not a restart", us, ch);
        check(us == 3u && ch == 1u, b);
    }
    reset();
    set(0, R_VOI, 0);                             /* 1 voice: a retrigger of the same note */
    on(0, 60); half(); on(0, 60);
    {
        uint32_t us = 0;
        for (i = 0; i < POLY_MAX; i++) us += pool[0][i].used;
        check(us == 2u && live(0) == 1u, "VOI 1, the same note again: the old one chokes in its slot, one live");
    }

    printf("the shared budget\n");
    reset();
    set(0, R_VOI, 7); set(1, R_VOI, 7);           /* both may take 8 */
    for (i = 0; i < 6u; i++) { on(0, 48 + i); half(); }
    for (i = 0; i < 4u; i++) on(1, 72 + i);       /* four at once: two over */
    n = live_all();
    half();
    snprintf(b, sizeof b, "6 + 4 held: %u the moment they land, %u the half after (os.voices %u)", n, live_all(), os.voices);
    check(n == 10u && live_all() == 8u, b);
    snprintf(b, sizeof b, "the two oldest anywhere went (track 1's first two notes): %d %d, track 2 kept all four", has_note(0, 48), has_note(0, 49));
    check(!has_note(0, 48) && !has_note(0, 49) && has_note(0, 50) && live(1) == 4u, b);
    mach_note_off(1, 75);               /* the newest releases */
    half();
    on(2, 36);
    half();
    snprintf(b, sizeof b, "full, one releasing: a new note takes the releasing one, not the oldest held (%d %d)", has_note(1, 75), has_note(0, 50));
    check(!has_note(1, 75) && has_note(0, 50) && has_note(2, 36) && live_all() == 8u, b);

    printf("a mono track counts one\n");
    reset();
    for (i = 0; i < 8u; i++) { on(i < 4u ? 0 : 1, 48 + i); half(); }
    on(3, 60);
    half(); half();
    snprintf(b, sizeof b, "8 poly + the tape: tape sounding %d, poly live %u (the oldest choked)", mono_busy(3), live(0) + live(1));
    check(mono_busy(3) && live(0) + live(1) == 7u && !has_note(0, 48), b);

    printf("a storm\n");
    reset();
    srand(7);
    for (k = 0; k < 3u; k++) set(k, R_VOI, 7);
    for (i = 0; i < 4000u; i++) {
        uint32_t m = (uint32_t)rand() % 4u, j;
        for (j = 0; j < m; j++) {
            uint32_t t = (uint32_t)rand() % 4u, note = 36u + (uint32_t)rand() % 48u;
            if (rand() % 3) on(t, note); else mach_note_off(t, note);
        }
        n = live_all();
        if (n > worst) worst = n;
        half();
        if (live_all() > VOICES) { over++; run++; if (run > longest) longest = run; } else run = 0;
    }
    snprintf(b, sizeof b, "4000 halves of random notes: never over 8 after a half (%u times); %u at most within one", over, worst);
    check(over == 0u, b);
    printf("\n%s (%d failed)\n", fails ? "FAILED" : "all passed", fails);
    return fails != 0;
}
