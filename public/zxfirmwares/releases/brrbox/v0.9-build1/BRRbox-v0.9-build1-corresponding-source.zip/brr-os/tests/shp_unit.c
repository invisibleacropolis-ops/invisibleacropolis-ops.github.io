/* SPDX-License-Identifier: GPL-3.0-only */
/* Unit tests of the shaper (os_shp.c): every model's anti-derivative against its function; the chain's delay is
 * exactly 11 samples and flat to 3.4 kHz (a linear setting comes out as the input, late); WET mixes without
 * combing; the level match; the 1-bit crusher's three levels; switching on and off without a click; and in the
 * engine: WET 0 changes nothing, POST tells the air its share.
 *   gcc -O2 -std=gnu11 -I. -I../firmware/src -I../build/gen -o shp_unit shp_unit.c -lm && ./shp_unit
 * (SHP_DUMP=dir writes each model's output on a loop, for the alias measurement against an alias-free reference) */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "host_stubs.h"
#include "os_core.h"
#include "os_font.c"
#define SV_API static
#include "svbrr_dec.c"
#include "os_fx.c"
#include "os_regs.c"
#include "os_flt.c"
#include "os_hf.c"
#include "os_tfx.c"
#include "os_mod.c"
#include "os_mach.c"
#include "os_shp.c"
#include "os_seq.c"
#include "os_engine.c"

static int fails;
static void check(int ok, const char *what) { printf("  [%s] %s\n", ok ? " ok " : "FAIL", what); if (!ok) fails++; }
static const char *MN[SH_N] = {"TAPE", "TUBE", "CLIP", "FOLD", "CHEB", "XOVR", "RECT", "BITS", "POLY"};

/* track 0 set to a shaper setting; its block parameters made */
static void setp(uint32_t model, uint32_t inp, uint32_t a, uint32_t b, uint32_t bia, uint32_t tone, uint32_t pos, uint32_t wet)
{
    trk_t *t = &os.trk[0];
    t->eff[R_SMD] = t->base[R_SMD] = (uint8_t)model; t->eff[R_SIN] = t->base[R_SIN] = (uint8_t)inp;
    t->eff[R_SA] = t->base[R_SA] = (uint8_t)a; t->eff[R_SB] = t->base[R_SB] = (uint8_t)b;
    t->eff[R_SBI] = t->base[R_SBI] = (uint8_t)bia; t->eff[R_STN] = t->base[R_STN] = (uint8_t)tone;
    t->eff[R_SPS] = t->base[R_SPS] = (uint8_t)pos; t->eff[R_SMX] = t->base[R_SMX] = (uint8_t)wet;
    sh_block(0);
}
/* n samples of x through track 0's shaper (blocks of 16, as the engine does) */
static void run(float *x, uint32_t n)
{
    uint32_t i;
    for (i = 0; i < n; i += BLK) { sh_block(0); sh_run(0, x + i, 0, n - i < BLK ? n - i : BLK); }
}
static double rms(const float *x, uint32_t n) { double s = 0; uint32_t i; for (i = 0; i < n; i++) s += (double)x[i] * x[i]; return sqrt(s / n); }

#define N 32000
static float x[N], y[N];

int main(void)
{
    uint32_t i, m;
    char b[200];
    if (os_engine_init()) { fprintf(stderr, "library did not open\n"); return 1; }
    trk_defaults(&os.trk[0], MA_MULTI, 0);

    printf("the models: F' = f (numerically, every model, three settings)\n");
    for (m = 0; m < SH_N; m++) {
        static const uint8_t AB[3][2] = {{0, 0}, {64, 90}, {127, 127}};
        double worst = 0;
        uint32_t s;
        if (m == SH_BITS) continue;
        for (s = 0; s < 3u; s++) {
            sh_t *p = &shp[0];
            float u;
            setp(m, 0, AB[s][0], AB[s][1], 64, 127, 0, 127);
            for (u = -6.0f; u < 6.0f; u += 0.0137f) {
                float h = 1e-3f, d = (sh_F(p, u + h) - sh_F(p, u - h)) / (2.0f * h), f = sh_f(p, u);
                double e = fabs((double)d - f);
                if (e > worst) worst = e;
            }
        }
        snprintf(b, sizeof b, "%s: largest |F'(u) - f(u)| over -6..6: %.4f", MN[m], worst);
        check(worst < 0.01, b);
    }

    printf("the chain\n");
    for (i = 0; i < N; i++) {                           /* a band-limited test signal: tones up to 3 kHz */
        double t = (double)i / CORE_SR;
        x[i] = (float)(0.2 * sin(2 * M_PI * 510 * t) + 0.15 * sin(2 * M_PI * 1130 * t) + 0.1 * sin(2 * M_PI * 2970 * t));
    }
    shp[0].on = 0;
    setp(SH_POLY, 0, 64, 0, 64, 127, 0, 127);           /* POLY with E = O = 0: x itself */
    for (i = 0; i < N; i++) y[i] = x[i];
    run(y, N);
    {
        double e = 0, s = 0;
        for (i = 4000; i < N; i++) { double d = y[i] - x[i - SH_DELAY]; e += d * d; s += (double)x[i] * x[i]; }
        snprintf(b, sizeof b, "a linear setting: the input %u samples late, to %.1f dB (tones at 510, 1130, 2970 Hz)", SH_DELAY, 10 * log10(s / e));
        check(10 * log10(s / e) > 30.0, b);
    }
    shp[0].on = 0;
    setp(SH_POLY, 0, 64, 0, 64, 127, 0, 64);            /* WET 64: dry and wet both full */
    for (i = 0; i < N; i++) y[i] = x[i];
    run(y, N);
    {
        double r = rms(y + 4000, N - 4000) / rms(x + 4000, N - 4000);
        snprintf(b, sizeof b, "WET 64 of a linear setting: twice the input (%.2f dB, 6.02 if no combing)", 20 * log10(r));
        check(fabs(20 * log10(r) - 6.02) < 0.3, b);
    }
    printf("the level match: INP +36 dB, every model, against the input\n");
    for (m = 0; m < SH_N; m++) {
        double r;
        shp[0].on = 0;
        setp(m, 127, 64, 0, 64, 127, 0, 127);
        for (i = 0; i < N; i++) y[i] = x[i];
        run(y, N);
        r = 20 * log10(rms(y + 16000, N - 16000) / rms(x + 16000, N - 16000));
        snprintf(b, sizeof b, "%s: %+.1f dB", MN[m], r);
        check(fabs(r) < 1.5, b);
    }
    printf("BITS\n");
    shp[0].on = 0;
    setp(SH_BITS, 60, 127, 0, 64, 127, 0, 127);         /* 1 bit: -1, 0, +1 */
    {
        sh_t *p = &shp[0];
        uint32_t lv[3] = {0, 0, 0}, other = 0;
        for (i = 0; i < 4000; i++) {
            float v = sh_shape(p, &p->c[0], 2.0f * sinf((float)i * 0.01f));
            if (v == -1.0f) lv[0]++; else if (v == 0.0f) lv[1]++; else if (v == 1.0f) lv[2]++; else other++;
        }
        snprintf(b, sizeof b, "1 bit: three levels (%u %u %u), nothing else (%u)", lv[0], lv[1], lv[2], other);
        check(lv[0] && lv[1] && lv[2] && !other, b);
    }
    printf("switching\n");
    {
        double worst = 0, base = 0;
        shp[0].on = 0;
        for (i = 0; i < N; i++) y[i] = 0.3f * sinf((float)i * 0.1f);
        trk_t *t = &os.trk[0];
        setp(SH_TAPE, 60, 64, 0, 64, 127, 0, 0);
        for (i = 0; i < N; i += BLK) {
            uint32_t j;
            t->eff[R_SMX] = (i / 4000u) & 1u ? 100 : 0;    /* on, off, on ... every half second */
            sh_block(0);
            sh_run(0, y + i, 0, BLK);
            for (j = (i ? i : 1); j < i + BLK; j++) {
                double d = fabs((double)y[j] - y[j - 1]);
                if (d > worst) worst = d;
            }
        }
        {   /* the steepest step of the same sine, shaped, steady (no switching) */
            static float z[N];
            shp[0].on = 0;
            for (i = 0; i < N; i++) z[i] = 0.3f * sinf((float)i * 0.1f);
            t->eff[R_SMX] = 100;
            run(z, N);
            for (i = 8000; i < N; i++) { double d = fabs((double)z[i] - z[i - 1]); if (d > base) base = d; }
            t->eff[R_SMX] = 0;
            for (i = 0; i < 8u; i++) { sh_block(0); sh_run(0, z, 0, BLK); }
        }
        snprintf(b, sizeof b, "on / off every half second: the largest step %.3f, within the shaped sine's own (%.3f) and the dry's (0.030) added: a crossfade, no click", worst, base);
        check(worst < base + 0.03, b);
        check(!shp[0].on || t->eff[R_SMX], "off: it stops running");
    }
    printf("in the engine\n");
    {
        trk_t *t = &os.trk[0];
        hf_t *h = &hf[0];
        shp[0].on = 0;
        t->base[R_SMX] = 100; t->base[R_SPS] = 1; t->base[R_SMD] = SH_FOLD; t->base[R_TYP] = FLT_LP; t->base[R_CUT] = 50;
        t->eff[R_SMX] = 100; t->eff[R_SPS] = 1;
        for (i = 0; i < 40u; i++) os_render((int32_t[HALF_FRAMES * 2u]){0}, HALF_FRAMES);
        snprintf(b, sizeof b, "POST, WET 100 behind a low-pass: the air treats %.0f %% of the track as unfiltered", 100.0 * h->shw);
        check(h->shw > 0.65f && h->shw < 0.75f, b);
        t->base[R_SPS] = 0;
        for (i = 0; i < 10u; i++) os_render((int32_t[HALF_FRAMES * 2u]){0}, HALF_FRAMES);
        check(h->shw == 0.0f, "PRE: the filter sees all of it, the air filters all of it");
        t->base[R_SMX] = 0;
        for (i = 0; i < 10u; i++) os_render((int32_t[HALF_FRAMES * 2u]){0}, HALF_FRAMES);
        check(!shp[0].on, "WET 0: off (no CPU)");
    }
    if (getenv("SHP_DUMP")) {                           /* the loop through each model (the alias measurement) */
        static float in[64000], o[64000];
        FILE *f = fopen("/tmp/q9/loop8k.f32", "rb");
        uint32_t n = f ? (uint32_t)fread(in, 4, 64000, f) : 0u;
        static const uint8_t SET[SH_N][4] = {{90, 38, 0, 64}, {90, 76, 0, 70}, {108, 13, 0, 64}, {69, 64, 0, 64}, {28, 76, 25, 64},
                                            {40, 76, 25, 64}, {12, 127, 0, 64}, {40, 64, 0, 64}, {12, 102, 25, 64}};
        if (f) fclose(f);
        for (m = 0; m < SH_N && n; m++) {
            char fn[128];
            shp[0].on = 0;
            setp(m, SET[m][0], SET[m][1], SET[m][2], SET[m][3], 127, 0, 127);
            for (i = 0; i < n; i++) { float d; o[i] = sh_tick(&shp[0], &shp[0].c[0], in[i], &d); if (!(i & 15u)) sh_block(0); }
            snprintf(fn, sizeof fn, "%s/out_%s.f32", getenv("SHP_DUMP"), MN[m]);
            f = fopen(fn, "wb"); fwrite(o, 4, n, f); fclose(f);
        }
        printf("dumped %u samples a model\n", n);
    }
    printf("\n%s (%d failed)\n", fails ? "FAILED" : "all passed", fails);
    return fails != 0;
}
