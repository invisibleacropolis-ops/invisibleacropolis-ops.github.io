/* SPDX-License-Identifier: GPL-3.0-only */
/* Unit tests of the preset codec (os_store.c): kits and sounds round-trip exactly (every register, event field,
 * residual, scene value, pattern header, song row, learned pocket); sizes of an empty, a typical and a dense kit;
 * a random fuzz of odd events; every truncation and random bit flips of a record are refused or decoded without
 * harm, and a refused record changes nothing; the frozen templates still match the firmware's defaults.
 *   gcc -O2 -std=gnu11 -I. -I../firmware/src -I../build/gen -o store_unit store_unit.c -lm && ./store_unit */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "host_stubs.h"
#include "os_core.h"
#include "os_font.c"
#define SV_API static
#include "svbrr_dec.c"
#include "os_fx.c"
#include "os_regs.c"
#include "os_flt.c"
#include "os_hf.c"
#include "os_tfx.c"
#include "os_mod.c"
#include "os_mach.c"
#include "os_shp.c"
#include "os_seq.c"
#include "os_store.c"
#include "os_engine.c"

static int fails;
static void check(int ok, const char *what) { printf("  [%s] %s\n", ok ? " ok " : "FAIL", what); if (!ok) fails++; }

/* ---------------------------------------------------------------- the kit as plain data */
typedef struct {
    uint16_t bpb; uint8_t m[6];
    uint8_t mach[NTRACK], base[NTRACK][NREG], lrn_n[NTRACK][16]; int16_t lrn[NTRACK][16];
    pat_hdr hdr[NPAT];
    uint16_t n[NLIST]; ev_t ev[EV_HEAP];
    uint32_t mask[NSCN][NTRACK][3]; uint8_t sv[NSCN][NTRACK][NREG];
    uint8_t song_n, song[SONG_N];
} snap_t;
static snap_t A, B;

static void snap(snap_t *s)
{
    uint32_t k, i, j, o = 0, r, sc;
    memset(s, 0, sizeof *s);
    pat_sync_out();
    s->bpb = os.bpb; s->m[0] = os.hf; s->m[1] = os.m_glu; s->m[2] = os.m_air; s->m[3] = os.m_wid; s->m[4] = os.m_cel;
    for (k = 0; k < NTRACK; k++) {
        s->mach[k] = os.trk[k].mach;
        for (r = 0; r < NREG; r++) if (!st_skip(r, 0)) s->base[k][r] = os.trk[k].base[r];
        for (i = 0; i < 16u; i++) { s->lrn_n[k][i] = os.trk[k].lrn_n[i]; s->lrn[k][i] = os.trk[k].lrn_n[i] ? os.trk[k].lrn[i] : 0; }
    }
    memcpy(s->hdr, seq_hdr, sizeof s->hdr);
    for (j = 0; j < NLIST; j++) {
        s->n[j] = seq_all[j].n;
        for (i = 0; i < seq_all[j].n; i++) {
            s->ev[o] = seq_all[j].e[i];
            if (s->ev[o].kind == EV_NOTE) s->ev[o].d &= (uint8_t)~EV_FRESH;
            o++;
        }
    }
    for (sc = 0; sc < NSCN; sc++)
        for (k = 0; k < NTRACK; k++) {
            for (i = 0; i < 3u; i++) s->mask[sc][k][i] = scn[sc].mask[k][i];
            for (r = 0; r < NREG; r++) if (SCN_HAS(sc, k, r)) s->sv[sc][k][r] = scn[sc].v[k][r];
        }
    s->song_n = seq_song_n;
    memcpy(s->song, seq_song, seq_song_n);
}
static int snap_eq(const snap_t *a, const snap_t *b) { return !memcmp(a, b, sizeof *a); }
static const char *snap_diff(const snap_t *a, const snap_t *b)
{
    static char m[96];
    uint32_t k, r, j, i;
    if (a->bpb != b->bpb || memcmp(a->m, b->m, 6)) return "tempo / master";
    for (k = 0; k < NTRACK; k++) {
        if (a->mach[k] != b->mach[k]) { snprintf(m, sizeof m, "track %u machine", k + 1); return m; }
        for (r = 0; r < NREG; r++) if (a->base[k][r] != b->base[k][r]) { snprintf(m, sizeof m, "track %u reg %u: %u vs %u", k + 1, r, a->base[k][r], b->base[k][r]); return m; }
        if (memcmp(a->lrn_n[k], b->lrn_n[k], 16) || memcmp(a->lrn[k], b->lrn[k], 32)) return "learned pocket";
    }
    if (memcmp(a->hdr, b->hdr, sizeof a->hdr)) return "pattern headers";
    for (j = 0; j < NLIST; j++) if (a->n[j] != b->n[j]) { snprintf(m, sizeof m, "list %u: %u vs %u events", j, a->n[j], b->n[j]); return m; }
    for (i = 0; i < EV_HEAP; i++) if (memcmp(&a->ev[i], &b->ev[i], sizeof(ev_t))) { snprintf(m, sizeof m, "event %u (kind %u)", i, a->ev[i].kind); return m; }
    if (memcmp(a->mask, b->mask, sizeof a->mask) || memcmp(a->sv, b->sv, sizeof a->sv)) return "scenes";
    if (a->song_n != b->song_n || memcmp(a->song, b->song, SONG_N)) return "song";
    return "?";
}

static uint8_t rec[65536];
static uint32_t rnd(uint32_t n) { return (uint32_t)rand() % n; }

static void kit_fresh(void)
{
    uint32_t k;
    static const uint8_t M[NTRACK] = {MA_TAPE, MA_MULTI, MA_WAVE, MA_GRAN};
    seq_play(0);
    seq_init();
    memset(scn, 0, sizeof scn);
    for (k = 0; k < NTRACK; k++) { trk_defaults(&os.trk[k], M[k], k); memset(os.trk[k].lrn_n, 0, 16); }
    os.bpb = 150;
}
/* a sound designed: n registers moved somewhere in their range */
static void tweak(uint32_t k, uint32_t n)
{
    trk_t *t = &os.trk[k];
    while (n--) {
        uint32_t r = rnd(NREG);
        if (st_skip(r, 0) || r == R_ET1 || r == R_ET2 || r == R_LT1 || r == R_LT2) continue;
        t->base[r] = (uint8_t)rnd(reg_max(t->mach, r) + 1u);
    }
}
static void note(uint32_t p, uint32_t k, uint32_t st, uint32_t n, uint32_t v, int32_t off, uint32_t len, uint32_t cond)
{
    seq_put_note(&seq_pat[p][k], st, n, v, off, len, cond);
}
static void lock(uint32_t p, uint32_t k, uint32_t st, uint32_t r, uint32_t v) { seq_put_lock(&seq_pat[p][k], st, r, v); }

static void kit_typical(void)
{
    uint32_t p, s, b;
    kit_fresh();
    tweak(0, 6); tweak(1, 18); tweak(2, 22); tweak(3, 14);
    for (p = 0; p < NPAT; p++) {
        uint32_t bars = 1u + (p & 1u);
        seq_hdr[p].stp[1] = seq_hdr[p].stp[2] = (uint8_t)(16u * bars - 1u);
        for (s = 0; s < 16u * bars; s++) {
            if (s % 4u == 0u) note(p, 1, s, 48, 112, 0, 8, 0);
            if (s % 8u == 4u) note(p, 1, s, 49, 110, 0, 8, 0);
            if (s % 2u == 0u || rnd(10) < 3) { note(p, 1, s, 50, s % 4u == 2u ? 100 : 70, 0, 4, 0); lock(p, 1, s, R_DEC, 20 + rnd(60)); }
            if (s % 2u == 0u) { static const uint8_t N[8] = {36, 36, 39, 41, 43, 36, 46, 43}; note(p, 2, s, N[(s / 2u) % 8u], 100, 0, (s / 2u) % 3u ? 6 : 12, 0); }
        }
        for (b = 0; b < bars; b++) { note(p, 3, 16u * b, 48, 90, 0, 255, 0); note(p, 3, 16u * b, 55, 90, 0, 255, 0); }
    }
    for (s = 0; s < NSCN; s++) for (b = 0; b < 3u + s % 4u; b++) scene_write(s, rnd(4), R_CUT + rnd(16), rnd(128));
    for (s = 0; s < 16u; s++) seq_song[s] = SONG_ROW(s % 8u, 1u + s % 4u);
    seq_song_n = 16;
    pat_enter(0, 0);                            /* (pattern 1's header into the registers, as playing it would) */
}

static void kit_dense(void)
{
    uint32_t p, s;
    static const uint8_t SC[7] = {0, 2, 3, 5, 7, 10, 12};
    kit_fresh();
    tweak(0, 20); tweak(1, 25); tweak(2, 25); tweak(3, 20);
    for (p = 0; p < NPAT; p++) {
        uint32_t k;
        for (k = 0; k < NTRACK; k++) seq_hdr[p].stp[k] = 127;
        seq_hdr[p].bars = 8;
        for (s = 0; s < 64u; s++)                                  /* a live melody, human timing */
            note(p, 0, s * 2u, 60u + SC[rnd(7)], 60u + rnd(60), (int32_t)rnd(1800) - 900, 4u + 2u * rnd(5), 0);
        for (s = 0; s < 128u; s++) {                               /* 16th drums with a decay lock each */
            if (s % 4u == 0u) note(p, 1, s, 48, 112, 0, 8, 0);
            if (s % 8u == 4u) note(p, 1, s, 49, 110, 0, 8, 0);
            note(p, 1, s, 50, 70u + (s % 4u == 2u ? 30u : 0u), 0, 4, s % 16u == 15u ? CD_1_2 : 0);
            lock(p, 1, s, R_DEC, 20 + rnd(60));
        }
        for (s = 0; s < 128u; s += 4u) {                           /* chords with two lock lanes */
            static const uint8_t PR[4][4] = {{48, 52, 55, 59}, {45, 48, 52, 55}, {41, 45, 48, 52}, {43, 47, 50, 53}};
            uint32_t i;
            for (i = 0; i < 4u; i++) note(p, 2, s, PR[(s / 16u) % 4u][i], 80 + rnd(20), 0, 14, 0);
            lock(p, 2, s, R_CUT, 40 + (s * 3u) % 80u);
            lock(p, 2, s, R_TIM, 30 + (s * 7u) % 60u);
        }
        for (s = 0; s < 128u; s += 2u) note(p, 3, s, 36u + SC[rnd(7)], 100, 0, rnd(3) ? 6 : 12, 0);
    }
    for (s = 0; s < NSCN; s++) for (p = 0; p < 12u; p++) scene_write(s, rnd(4), R_CUT + rnd(40), rnd(128));
    for (s = 0; s < SONG_N; s++) seq_song[s] = (uint8_t)rnd(256);
    seq_song_n = SONG_N;
    pat_enter(0, 0);
}

/* odd things: any kind with any fields (LIST edits can make them), residuals at the extremes, a learned pocket */
static void kit_fuzz(void)
{
    uint32_t i, n = rnd(1200), k;
    kit_fresh();
    for (k = 0; k < NTRACK; k++) {
        trk_defaults(&os.trk[k], rnd(MA_N), k);
        tweak(k, rnd(60));
        for (i = 0; i < 16u; i++) if (rnd(3) == 0) { os.trk[k].lrn_n[i] = (uint8_t)(1u + rnd(255)); os.trk[k].lrn[i] = (int16_t)(rnd(65536) - 32768); }
    }
    for (i = 0; i < NPAT; i++) {
        seq_hdr[i].bars = (uint8_t)rnd(9);
        for (k = 0; k < NTRACK; k++) { seq_hdr[i].stp[k] = (uint8_t)rnd(128); seq_hdr[i].spd[k] = (uint8_t)rnd(6); }
    }
    for (i = 0; i < n; i++) {
        ev_t e;
        static const int16_t OFF[] = {0, 0, 0, 1, -1, 2047, -2048, 2048, -2049, 32767, -32768};
        e.step = (uint8_t)rnd(256); e.kind = (uint8_t)rnd(3);
        e.off = rnd(3) ? OFF[rnd(11)] : (int16_t)(rnd(65536) - 32768);
        e.a = (uint8_t)(e.kind == EV_LOCK ? rnd(NREG) : rnd(256)); e.b = (uint8_t)rnd(256); e.c = (uint8_t)rnd(256); e.d = (uint8_t)rnd(256);
        evl_insert(&seq_all[rnd(NLIST)], &e);
    }
    for (i = 0; i < rnd(200); i++) scene_write(rnd(NSCN), rnd(NTRACK), rnd(NREG), rnd(256));
    seq_song_n = (uint8_t)rnd(SONG_N + 1u);
    for (i = 0; i < seq_song_n; i++) seq_song[i] = (uint8_t)rnd(256);
    os.bpb = (uint16_t)(100u + rnd(401)); os.hf = (uint8_t)rnd(256); os.m_glu = (uint8_t)rnd(256);
    pat_enter(0, 0);
}

static uint32_t roundtrip(const char *name, int quiet)
{
    uint32_t n, n2;
    static uint8_t rec2[65536];
    char b[160];
    snap(&A);
    n = st_kit_save(rec, sizeof rec);
    kit_fresh();
    if (st_kit_load(rec, n)) { snprintf(b, sizeof b, "%s: the record did not load", name); check(0, b); return n; }
    snap(&B);
    n2 = st_kit_save(rec2, sizeof rec2);
    if (!quiet || !snap_eq(&A, &B) || n2 != n || memcmp(rec, rec2, n)) {
        snprintf(b, sizeof b, "%s: %u B, back exactly%s%s", name, n, snap_eq(&A, &B) ? "" : " -- NOT: ", snap_eq(&A, &B) ? "" : snap_diff(&A, &B));
        check(snap_eq(&A, &B) && n2 == n && !memcmp(rec, rec2, n), b);
    }
    return n;
}

int main(void)
{
    uint32_t i, k, n, bad = 0, changed = 0, ok_flip = 0;
    char b[200];
    if (os_engine_init()) { fprintf(stderr, "library did not open\n"); return 1; }
    srand(11);

    printf("the frozen templates\n");
    for (i = 0; i < MA_N; i++) {
        static trk_t t;
        trk_defaults(&t, i, NTRACK);
        t.base[R_PAN] = 64;
        snprintf(b, sizeof b, "%s: TPL_V1 is still what the firmware gives a fresh track (else: freeze a TPL_V2)", MACH[i].name);
        check(!memcmp(t.base, TPL_V1[i], NREG), b);
    }

    printf("kits\n");
    kit_fresh();
    n = roundtrip("an empty kit", 0);
    kit_typical();
    {
        uint32_t ev = seq_used, nt = roundtrip("a typical kit (8 patterns of 1-2 bars: drums + locks, bass, pads)", 0);
        printf("        %u events (%u B in RAM); %.1f bits an event with everything\n", ev, ev * 8u, nt * 8.0 / ev);
        printf("        120 KiB holds %u of these\n", 122880u / nt);
    }
    kit_dense();
    {
        uint32_t ev = seq_used, nd, mx = 0;
        for (i = 0; i < NLIST; i++) if (seq_all[i].n > mx) mx = seq_all[i].n;
        nd = roundtrip("a dense kit (8 patterns of 8 bars: a live melody, 16th drums + locks, chords + 2 lanes)", 0);
        printf("        %u events (%u B in RAM), the longest list %u events (the old cap: 256); 120 KiB holds %u\n",
               ev, ev * 8u, mx, 122880u / nd);
        check(mx > 256u, "one track of one pattern holds more than 256 events (the shared heap)");
    }
    for (i = 0; i < 300u; i++) {
        kit_fuzz();
        snprintf(b, sizeof b, "fuzz %u", i);
        roundtrip(b, 1);
    }
    check(1, "300 random kits of odd events (any kind, any field, extreme residuals): all back exactly");

    printf("broken records\n");
    kit_typical();
    n = st_kit_save(rec, sizeof rec);
    kit_dense();
    snap(&A);
    for (i = 0; i < n; i++) if (st_kit_load(rec, i) == 0) bad++;
    snap(&B);
    snprintf(b, sizeof b, "every truncation (0 .. %u B) refused: %u loaded; the kit in RAM untouched", n - 1u, bad);
    check(!bad && snap_eq(&A, &B), b);
    for (i = 0; i < 3000u; i++) {
        uint32_t at = rnd(n * 8u);
        int rr;
        kit_dense();
        snap(&A);
        rec[at >> 3] ^= (uint8_t)(0x80u >> (at & 7u));
        rr = st_kit_load(rec, n);
        rec[at >> 3] ^= (uint8_t)(0x80u >> (at & 7u));
        if (rr == 0) ok_flip++;
        else { snap(&B); if (!snap_eq(&A, &B)) changed++; }
    }
    snprintf(b, sizeof b, "3000 single-bit flips: %u decoded as another kit, %u refused, %u refused ones changed anything",
             ok_flip, 3000u - ok_flip, changed);
    check(!changed, b);
    printf("        (the flash record's CRC catches flips before the decoder: this is its second line)\n");

    printf("sounds\n");
    for (k = 0; k < NTRACK; k++) {
        uint8_t keep[NREG], src[NREG];
        uint32_t r, same = 1, kept = 1, dst = (k + 1u) % NTRACK, sm;
        kit_typical();
        sm = os.trk[k].mach;
        memcpy(src, os.trk[k].base, NREG);
        n = st_sound_save(k, rec, sizeof rec);
        memcpy(keep, os.trk[dst].base, NREG);
        for (r = 0, i = 0; r < n; r++) i += st_sound_load(dst, rec, r) == 0;
        check(!i && !memcmp(keep, os.trk[dst].base, NREG), "every truncation of it refused, the track untouched");
        check(st_sound_load(dst, rec, n) == 0, "loads");
        for (r = 0; r < NREG; r++) {
            if (st_skip(r, 1)) kept &= os.trk[dst].base[r] == keep[r];
            else same &= os.trk[dst].base[r] == src[r];
        }
        snprintf(b, sizeof b, "track %u's %s: %u B; onto track %u: the same registers, its STP SPD FEEL TBL kept", k + 1u, MACH[sm].name, n, dst + 1u);
        check(same && kept && os.trk[dst].mach == sm, b);
    }
    {
        uint32_t m;
        for (m = 0; m < MA_N; m++) {
            trk_defaults(&os.trk[0], m, NTRACK);
            os.trk[0].base[R_PAN] = 64;
            n = st_sound_save(0, rec, sizeof rec);
            snprintf(b, sizeof b, "a fresh %s: %u B", MACH[m].name, n);
            check(n == 1u, b);
        }
    }
    printf("\n%s (%d failed)\n", fails ? "FAILED" : "all passed", fails);
    return fails != 0;
}
