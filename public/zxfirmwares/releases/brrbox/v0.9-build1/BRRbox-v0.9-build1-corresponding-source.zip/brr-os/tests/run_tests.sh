#!/bin/sh
# Every host test of BRR-OS: the unit tests and the scripted session, built with AddressSanitizer and
# UndefinedBehaviorSanitizer; then the session again on two cores (the split must match one core to 1 LSB).
# Run from anywhere: sh tests/run_tests.sh   (python3 tools/make_library_h.py first, once)
set -e
cd "$(dirname "$0")"
CC="${CC:-gcc}"
FLAGS="-O1 -g -std=gnu11 -w -fsanitize=address,undefined -DBOARD_SMK37=1 -I. -I../firmware/src -I../firmware/hal -I../build/gen"
OUT="${TMPDIR:-/tmp}/brros_tests"
mkdir -p "$OUT"
fail=0
for t in flt_unit fx_unit mod_unit voice_unit seq_unit scene_ui_unit store_unit vault_unit shp_unit; do
    $CC $FLAGS -o "$OUT/$t" $t.c -lm
    if (cd "$OUT" && ./$t > $t.log 2>&1); then r="ok"; else r="FAILED"; fail=1; fi
    printf '%-14s %-7s %s\n' "$t" "$r" "$(tail -1 "$OUT/$t.log")"
done
$CC $FLAGS -o "$OUT/host_sim" host_sim.c -lm
(cd "$OUT" && ./host_sim > host_sim.log 2>&1 && cp sim.wav sim1.wav) || { echo "host_sim FAILED"; fail=1; }
grep -E "^presets|^vault|^voices" "$OUT/host_sim.log" || true
$CC -O2 -std=gnu11 -w -DOS_HOST_DUAL -DBOARD_SMK37=1 -I. -I../firmware/src -I../firmware/hal -I../build/gen -o "$OUT/host_sim2" host_sim.c -lm
$CC -O2 -std=gnu11 -w -DBOARD_SMK37=1 -I. -I../firmware/src -I../firmware/hal -I../build/gen -o "$OUT/host_sim1" host_sim.c -lm
(cd "$OUT" && ./host_sim1 > /dev/null && cp sim.wav one.wav && ./host_sim2 > /dev/null && cp sim.wav two.wav)
python3 - "$OUT/one.wav" "$OUT/two.wav" <<'PY' || fail=1
import sys, wave, struct
a, b = (wave.open(p) for p in sys.argv[1:3])
x = a.readframes(a.getnframes()); y = b.readframes(b.getnframes())
d = max(abs(p - q) for p, q in zip(struct.unpack('<%dh' % (len(x) // 2), x), struct.unpack('<%dh' % (len(y) // 2), y)))
print('two cores against one: the largest difference %d LSB' % d)
sys.exit(d > 1)
PY
[ $fail = 0 ] && echo "all passed" || { echo "SOMETHING FAILED (logs in $OUT)"; exit 1; }
