# Licensing

BRR-OS as a whole is **GPL-3.0-only** (`LICENSE`), because it is built on GPL-3.0 code from Felucca.

| Part | Files | Licence, authors |
|---|---|---|
| SMK-37 hardware layer, startup, linker script, update loader | `firmware/hal/`, `firmware/loader/`, `firmware/crt0.S`, `firmware/app.ld` | GPL-3.0-only. Felucca (Leo Kuroshita, Hügelton Instruments); SMK-37 layer by genkigenki (Felucca `smk37` branch). BRR-OS v0.8 adds one field to `smk_input.h`: each pad's last velocity |
| USB MIDI device, update entry, flash access, LCD and pad LEDs, libc | `firmware/src/usb.c` (one change, marked: app USB strings), `ota.c`, `ota_hw.c`, `storage_hw.c`, `lcd.c`, `libc.c` | GPL-3.0-only, Felucca and contributors (see the file headers) |
| Packager, LZ4, installer | `tools/fm1pkg_make.py`, `tools/lz4blk.py`, `tools/fm1_install.py`, `tools/get_toolchain.sh` | GPL-3.0-only, Felucca |
| Build script | `tools/build.py` | GPL-3.0-only, adapted from Felucca's |
| BRR-OS: machines, sequencer, engine, rebuild, effects, decoder, UI, font, encoder | `firmware/src/os_*`, `svbrr_*`, `tools/encoder/`, `tools/encode_library.py`, `tools/analyse_library.py`, `tools/make_library_h.py`, `tools/gen_font.py`, `tests/` | GPL-3.0-only |
| JieLi AC79 SDK files in each package | `uboot.boot`, `cfg_tool.bin`, `cfg/eq_cfg_hw.bin` (read from your SDK checkout, not in this tree) | Apache-2.0 (`LICENSES/Apache-2.0.txt`), JieLi Technology |
| Default library audio | `library/library.svbr` | the owner's own track ("Calculated Overload") and synthesised test sounds |

Not affiliated with or endorsed by M-Vave, JieLi, Hügelton Instruments or the SMK-37 port kit. M-Vave, SMK-37,
FM-1 and Felucca are their owners' names.
