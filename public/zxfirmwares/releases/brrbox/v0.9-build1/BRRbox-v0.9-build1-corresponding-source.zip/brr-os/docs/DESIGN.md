# BRR-OS design (v0.9: one clock, the air, each track's effects, one filter in two halves, the modulators, kits as bits, and a shaper)

The design, in one line: **a register file, one event list and one clock, all locked to the codec's own sample grid.**

This file records what BRR-OS is trying to be, where its ideas come from, and the decisions taken so far. The code follows it. Where the code differs, the code is the newer word and this file gets updated.

## 1. Aspirations

- **An instrument built from a codec.** A custom firmware for the M-VAVE SMK-37 Pro (JieLi AC791N, pi32v2 core, about 578 KB of SRAM, 1 MiB of flash). It runs bare metal on genkigenki's Felucca hardware layer, with no vendor libraries.
- **Samples as oscillators.** About two minutes of audio (350 KB at most) is compiled into flash as SVB4: a 4-bit BRR-style core with variable bit rate (0-4 bits per sample) at 8 kHz, plus side info that rebuilds 4-16 kHz.
  - Every sample is random access: 64 ms keyframes, 2 ms blocks, every unit a power of two of the 0.125 ms sample.
  - Every voice is a small decoder state reading flash directly.
  - The codec's own structure (blocks, keyframes, side info, onsets) is meant to help the DSP natively.
- **Four tracks, an S4-style ambition on a modest CPU.** Each track runs one machine: TAPE, MULTI, GRAN or WAVE. Some machines are polyphonic and some are monophonic.
- **A sequencer in the tradition of the small machines.**
  - Tracker logic underneath: an event list, ticks, commands and tables.
  - XOX, pattern, piano-roll and lane views on top.
  - Elektron-style parameter locks.
  - Yamaha QX-class timing, so live recording keeps a human feel instead of sounding strictly mechanical. A hybrid of machine and human.
- **Sparse, fast and small.** A minimal GUI and as little code as possible. Every view is a projection of the same data, and every control uses the same gesture.

## 2. Inspirations and what we take from each

| Source | Taken |
|---|---|
| SID players (Hubbard, GoatTracker) | The whole synth is a block of registers written by a tiny interpreter. Instruments are pointers to small tables. |
| ProTracker / MOD | The tick; an effect is a letter plus an argument; sample offset; render split at tick boundaries |
| LSDJ | Tables (a tiny program per instrument at tick rate), hop, grooves as data, chains |
| Nanoloop | Fully gestural editing with no menus |
| Elektron (Machinedrum, Monomachine, Octatrack) | Parameter locks, trigless locks, conditional trigs, per-track length and speed, scenes and a crossfader |
| Yamaha QX1 (1984, 384 PPQN) | Real-time recording finer than the grid, quantise as a separate decision, a clock-unit readout |
| Ableton Capture | "I wasn't recording, but that was the take" |

## 3. One clock: the codec's sample is the atom of everything

Since v0.3 the whole engine runs at the codec's own rate. This is the central design decision.

- **The core sample (8 kHz, 0.125 ms) is the tick.** Notes, locks, commands, retrigs and table rows land on any sample. At this resolution the grid is no longer only a groove resolution: it becomes a timbre tool.
- **Every other unit is a power of two of it.**

  | Unit | Core samples | Time | Role |
  |---|---|---|---|
  | sample | 1 | 0.125 ms | the tick: events, retrig, table rows, the LFO step |
  | codec block | 16 | 2 ms | predictor / step decision; also the control block where coefficients are recomputed |
  | side frame | 128 | 16 ms | high-band energies |
  | keyframe | 512 | 64 ms | random access; a wavetable frame |
  | wide | ×4 | 32 kHz | WAVE, whose synth tones need more bandwidth, and every track's rebuilt highs (10) |

  Conversions are shifts. Nothing is rescaled between uses.
- **The tempo is codec blocks per beat.** `BPM = 30000 / bpb`, so 150 BPM is 200 and 120 BPM is 250. A beat is always whole 2 ms blocks, a 16th is always `bpb × 4` samples, and loops start and end on block boundaries.
- **The engine is event-driven.** Each track knows the next sample at which anything is due: the next event in this step's due list, the step boundary, a retrig, a table row, a cut, a voice release or the next block. It renders straight to that sample in a tight loop, then handles what is due. When nothing is happening, the cost is the same as with a 4 ms tick.
- **Synced TAPE is an integer read.** Its position is the clock (rate exactly 1), so it is a plain read with no interpolation, and it cannot drift.
- **Upsamplers at the exact DAC ratio.** The DAC runs at 24 MHz / 544, and exactly 375 output frames equal 68 core samples (and 272 wide samples). Each half renders the 22-24 core samples it needs. The core bus goes up by Hermite plus a 3.9 kHz low-pass; the 32 kHz buses by a 375-phase resampler (10). Everything is read 12 core samples (1.5 ms) late: 5 for the resampler's look-ahead, 7 so the rebuilt highs land on their transients.
- **The pitch wheel is WARP.** It scales both upsamplers' step, so the whole clock domain (tempo, pitch, the grid itself) plays faster or slower together, like tape.
- **Measured on the host, same session:**

  | Version | Grid | CPU per half |
  |---|---|---|
  | v0.2 | 4 ms tick | 30.5 µs |
  | v0.2 | forced to 0.125 ms | 48 µs |
  | v0.3 | 0.125 ms | **19.2 µs** |

  The sound matches v0.2 within 1 dB in every band.

The interface still shows recorded timing in QX-style units of 1/384 of a quarter note.

## 4. The register file

- Each track has **96 one-byte registers** (91 used; 96 is what the scene masks hold). The register numbers are the engine's; which knob shows which register is a table (`PAGES`, os_ui.c), twelve pages of eight:
  - **A MACH:** defined by the machine (see 5).
  - **B FILT:** `CUT RES TYP FEN DRV LOC CMP`. One resonant filter per track (off, LP, BP, HP; see 12), how far ENV2 moves it, drive, low cut, compressor.
  - **C AMP:** `ATK DEC SUS REL RNG VOI LEV PAN`. Every voice's level envelope (see 13), the track's voice limit (see 15), its level and pan.
  - **D ENV1, E ENV2, F LFO1, G LFO2** (v0.7): the modulators (see 13).
  - **H FX** (v0.5): `TIM FBK DEP RAT DIS COL PNG MIX`. The track's multi-effect: phaser, flanger, chorus or delay by where the knobs sit (see 11).
  - **I VERB** (v0.5): `SIZ DCY DMP PRE MOD DIF GAT REV`. The track's reverb (see 11).
  - **J AIR** (v0.4): `WID AIR TLT TON SPR`. The track's rebuilt highs: width, amount, tilt, tonality (see 10); voice spread.
  - **K FEEL:** `FEL WIN VFL GRV TBL TSP STP SPD`. FEEL, WINDOW, VELOCITY FEEL, GROOVE source (see 7), then the table and its speed, track length (1-128 steps) and track speed (1/8× to 4×). STP and SPD show the playing pattern's (each pattern keeps its own, see 15).
  - **L SHAP** (v0.9): `MOD INP A B BIA LPF POS WET`. The track's waveshaper / wavefolder (see 18).
- **One resolver** runs at every block and at once whenever an event writes a register: `eff = modulators( lock( scenes( base )))` (tables write locks). Knobs, faders, locks, tables, the modulators, scenes and MIDI all just write bytes.
- **The page table is the mapping layer.** The engine never sees it. Rearranging the pages, a user's own pages, or pads mapped to registers later are all tables of register numbers; the scripted session finds a register's knob through it (`ui_find`), so it survives any layout.
- **Eight scenes** (v0.8) each hold a mask (96 bits a track) and values for any register of any track; several can be in at once, each at its own amount (see 15).

## 5. Machines: one voice, different position laws

Every machine uses the same SVBRR reader, decode window and interpolator. Only the rule for moving the read position changes.

| Machine | Voices | Page A | Position law |
|---|---|---|---|
| TAPE | 1 | `SMP STR LEN PIT DIR SLC GAT SYN` | With SYN on, the position is the clock phase × loop length (beats), resynced every block. GAT gates it with notes; SLC jumps to an onset slice. With SYN off, a note restarts at the slice chosen by the note. |
| MULTI | 6 | `SMP MAP PIT TUN STR LEN RVS LOP` | Starts at a keyframe offset when a note starts. MAP is chromatic, or KIT (one sample per key). |
| GRAN | 1 cloud, 8 grains | `SMP POS SCN SIZ DEN PIT SPR JIT` | One decode head fills a 256 ms ring of blocks (4 KB per track). Grains are taps into it: decode once, read many times. |
| WAVE | 4 | `SMP FRM CYC SCN DET PIT TUN GLD` | **A keyframe is a wavetable frame.** The track keeps two decoded frames (2 KB) and voices only hold phases; FRM morphs between neighbouring frames. |

Every machine renders at 8 kHz. WAVE renders at 4× (32 kHz) and has no rebuild, because a synth tone has its own content above the core band. Every other track rebuilds its own highs from its own sound after its strip, so they follow its filter (10).

**Spread (SPR).** A voiced machine can also render a side: S = Σ voice × place, so the track is M/S (L = M + S, R = M − S). MULTI places voices by pitch (CHR: low left, high right) or one place per key (KIT); GRAN gives each grain a random place; WAVE alternates voices and splits a detuned pair. The strip filters the side with the same coefficients, and DRV drives L and R. With SPR at 0 there is no side and no cost.

**Anti-aliasing when pitched up.** At 8 kHz, a voice pitched up would fold its top octave back down. Above a rate of 1.02, the voice's source runs through two one-pole filters at 3.2 kHz / rate before the interpolation, at two multiply-adds per source sample.

**Every track owns its voice slots** (8 each), so a track renders on either core; how many may sound is shared (8 in all, see 15) and decided between halves, on core 0.


## 6. Events: 8 bytes, used everywhere

```c
typedef struct { uint8_t step, kind; int16_t off; uint8_t a, b, c, d; } ev_t;
// off: the human residual, Q12 fraction of a step (±0.5 step)
// NOTE  a note   b velocity   c length (1/8 steps, 255 = hold)   d condition (bit 7: just recorded)
// LOCK  a register (0-95)     b value
// CMD   a letter              b argument  c, d extra
```

- **A pattern** is four sorted lists, one per track, and its own header (see 15). There are 8 patterns; a change lands on the playing pattern's end. All 40 lists of a kit share one heap of 10,240 events.
- **Chords** are several NOTE events on the same step.
- **A lane is not stored anywhere.** It is just "LOCK events where a = register".
- **A table is a pattern whose clock is the tick.** It uses the same lists, the same interpreter and the same LIST editor. There are 8 tables of 16 rows: LOCK rows, N (transpose), H (hop), R (retrig) and K (kill).
- **Locks belong to their step.** They apply before any note on that step sounds, even an early one, and last until the next step that has events. A step with only locks is a trigless lock.
- **Commands:** times are `2^(b/16)` samples, so b = 0, 16, 32 … are exactly 1, 2, 4 … samples, and b = 144 is 512 samples (64 ms).
  - `R b d`: retrig every 2^(b/16) samples, with velocity drop d. It is tracker-style: the playing voice jumps back to its start, so a fast retrig is an exact period, a pitch of 8000 / n Hz. On WAVE it is a hard sync.
  - `C b`: cut after 2^(b/16) samples.
  - `T n`: start table n.
  - `H n`: hop to step n.
  - `K`: kill.
  - `N v`: transpose by v - 64. It retunes at once, so a table can change pitch every sample.
  - Planned: `O` offset, `P` slide, `S` speed, `L` stutter, `X` send.
- **Tables:** TSP sets a row every 2^(TSP/16) samples, from 1 sample (8 kHz, table synthesis) to about 30 ms (arpeggios).
- **Conditions:** 50%, 25%, 75%, 1:2, 2:2, 1:4, 2:4, 3:4, 4:4, FILL, !FILL, 1ST.

## 7. Feel: natively quantised live recording

At the moment a key is pressed, its heard position (the clock minus the output latency) is split into **grid step + residual**. Both are stored, so the recording is lossless and already quantised. At playback:

```
time = step + groove[slot] + (|off| <= WIN ? off × FEEL : off)
vel  = 100 + (vel_rec - 100) × VFL
```

- **FEEL** runs from -100% (inverted: a rushed note drags) through 0% (machine) and 100% (as played) to +150% (exaggerated).
- **WIN** snaps only the notes near the grid, so deliberate pushes and flams survive.
- **FEEL and WIN are registers**, so they can be locked per step and morphed by a scene. The mod wheel becomes a machine-to-human crossfader.
- **GRV sources:**
  - off;
  - swing at 54, 58, 62 or 66%;
  - LRN: the track's own pocket, a running average of your residuals per slot;
  - TK1-TK4: the groove of a TAPE track's loop, computed from the encoder's onset map. The sequencer plays in the pocket of the sampled audio.
- **Retro capture:** the last notes you played are always kept. SHIFT+REC writes the last loop's worth into the pattern.
- **Device check:** measure the output latency (`REC_LAT_FRAMES`) and the key-scan period on the unit. The scan runs at 10 kHz over 16 columns, so a full scan is about 1.6 ms.

## 8. Views and controls

Two renderers draw everything. A cell grid draws STEP, ROLL, LANE, PERF and MACH; the pad LEDs are the same cell functions at 2×8. A row list draws LIST. A register strip (the 8 knob values of the current page) is always on screen.

| Control | Everywhere |
|---|---|
| SEQ / CHORD / PARA / FADER BANK / GLOBE / PATCH | STEP / ROLL / LANE / LIST / PERF / MACH view |
| BT | SHIFT |
| KNOB BANK | register page A→B→…→K (SHIFT: back) |
| FX | knobs edit the global FX page, then the MASTER page |
| `<` `>` | step page (LIST: scroll; MACH: sample bank) |
| SEQ PLAY / SEQ REC | play-stop / record arm (SHIFT+REC: retro capture) |
| NOTE REPEAT (hold) | FILL |
| SCALE (hold) + pad | clear step (LIST: delete the row) |
| SHIFT + top pads 1-4 | select track |
| Faders 1-4 | track levels (the LEV registers) |
| Pitch wheel / mod wheel | WARP / the last scene's amount |
| SHIFT + PLAY | save the kit (see 17) |

**One gesture everywhere: whatever you hold is what the knobs edit.**

| Holding | Knobs | Keys |
|---|---|---|
| nothing | base registers (with SHIFT: choose the lane register) | play the selected track; recorded when REC is on |
| step pads | locks on those steps | set that step's chord |
| scene pad (PERF) | that scene's values | — |
| keys, then tap a pad | — | stamp the held chord onto that step |

A tap on an empty step places the last-played note; a tap on a full step clears it.

## 9. Budgets (measured cross-compiled; the device's CPU is still unknown)

- **Code:** the sound engine (decoder, registers, filter, air, effects, modulators, machines, sequencer, render) is about 60 KB of code with the shaper (rv32imfc, -Os; 54.5 KB without it). It was 36.1 KB in v0.4; v0.5 added 5.2 KB net for each track's effects, v0.6 8.6 KB for the matched filter, its air half, the response contract and the anti-aliased drive, v0.7 6 KB for the modulators and the page table, and v0.8 0.8 KB for the shared voices, patterns, the song and eight scenes. The preset codec and the vault add 3.1 KB of code and 0.4 KB of tables (the frozen templates); v0.9's shaper 6 KB. The whole app (engine and UI) measures about 80 KB; about 150 KB of flash is still free.
- **Library:** 345.5 KB, unchanged since v0.4 (the side windows live in a spare directory byte), plus 4.6 KB of onset maps. 4.5 KB of headroom under 350 KB.
- **RAM:** RAM and pool are one SRAM with a movable boundary. v0.5 moves it from 72 / 360 KiB to **40 / 392 KiB**, because each track's effects need 46 KB. The pool holds about 382 KB of its 392 KiB (19 KB spare; the build requires 8), counted for the 32-bit target:
  - each track's effects: 4 × 36 KB of delay lines (two 2 s lines, 8-bit block float, and a 16-bit 64 ms head) and 4 × 10 KB of reverb (16-bit), 189 KB in all
  - the kit's events: one heap of 10,240 (80 KB: the 64 + 16 KB of v0.7's fixed lists, shared)
  - GRAN rings 16 KB, WAVE frames 8 KB
  - the resampler's 188 phases × 32 taps: 24 KB (computed at boot, no libm)
  - buses 14 KB (two cores × core, wide, air and scratch), the four tracks' air 7.9 KB, voices 12.4 KB (4 × 8 slots)
  - the vault's index 7.5 KB and its 1 KB window; the shapers' state 3 KB
  - upsamplers 3 KB, the text strip, the update protocol's buffers

  The master chorus, flanger and reverb (27 KB) are gone: compiled out (`OS_MASTER_FX`). Plain RAM holds about 27 KB of globals of its 40 KiB (the state, the UI, the eight scenes 3.2 KB, the audio buffers).
- **CPU (host):** about 30 µs per 2.9 ms half for the full session, 1 % of one host core. The filter on in all four tracks: 21.5 µs against 15.1 with none. With every effect on in all four tracks (allpass stages, the chorus voice and the reverb) the engine costs 34 µs against 15 µs with none: the effects cost about 1.3 times the rest of the engine. They run inside the tracks, so the second core takes its share, and MIX 0 / REV 0 cost nothing.

## 10. The air, the submix and the master bus (v0.4)

v0.3 rebuilt 4-16 kHz once, on the sum of the four tracks. Distorting a sum makes the tracks intermodulate, one transient envelope cannot be right for a kick and a pad at once, and it could not know that a voice an octave up has moved its highs up an octave. v0.4 gives every track its own highs, its own stereo and its own compressor, and puts a master bus at the end.

**A track's air (`os_hf.c`), on the clock:**

1. **Core domain, every core sample.** A 6th-order high-pass at 2 kHz of the track's sound (after its strip). Its energy through the same filter again is the encoder's own reference (a zero-phase 2-4 kHz Butterworth), so the side info's ratios mean at playback what they meant at encode time. A 90-degree all-pass pair makes the band analytic, `× e^(−j3πn/4)` (an 8-entry table) moves 2-4 kHz to ±1 kHz, and an elliptic low-pass cleans it.
2. **Copy-up with one table.** The baseband times six carriers at 5, 7 … 15 kHz is six copies of the 2-4 kHz band, abutting from 4 to 16 kHz. All six, with their gains, are one complex table of 32 entries: 1 ms, 8 core samples. It is built per block from 8 entries by symmetry (C[m+8] = j(E−O), C[m+16] = −C[m]), so the copy-up costs 2 multiplies a sample and needs no band filters. Each slot has a fixed Schroeder phase (π k²/6), so the six copies of a transient do not peak together.
3. **Noise that tiles flat.** Complex noise points at 2 kHz (one every 4 core samples), linearly interpolated. The interpolation's spectrum is a triangle-squared whose shifted copies sum to exactly flat, so the same carriers make six noise bands with no gaps or bumps. It follows the track's 2-4 kHz power, 1 ms up and 8 ms down. A noisy band's own envelope is itself random, so noise times that envelope fluctuates twice: a hi-hat got 10 dB dips it never had. The slow release keeps a decay smooth; the follower's excess over the true power is measured per block and divided back out, so the level still follows the side info.
4. **Stereo for free.** Im() of the same products is the 90-degree twin of every copy and noise band. L and R take the pair rotated by ±ψ (WID: 0-45°), so their correlation is cos 2ψ at full power each. In mono the highs lose at most 3 dB.
5. **Targets per block, with no lag.** The side frame each voice reads, mapped to the six slots at the voice's playback rate (a voice an octave up moves its bands an octave up). In a kit, every sounding voice reads its own frame and the track's targets are their mix, weighted by each voice's 2-4 kHz energy. A hi-hat's ratios must not ride on a kick's attack. Frames sit on the clock, so the targets are frame-constant and known ahead. Tonality sets copy vs noise; AIR, TLT and TON (page J) scale, tilt and bias it.
6. **Played 7 core samples ahead.** The chain's group delay near 3 kHz is about 7 core samples. The rest of the mix waits 7 core samples instead, so every offset stays a whole clock sample.

**The side-info window (library).** The 16 codes span 45 dB relative to the 2-4 kHz band, from −39 dB. That clipped a hi-hat, whose highs sit 20-30 dB above its 2-4 kHz band, and a dull loop 40 dB below it. Each sample now places its window: a signed offset in 3 dB steps, chosen by the encoder for least clipping. It is stored in the directory byte that was always 0, so older libraries play exactly as before.

**The submix.** machine (M, and S when spread) → strip → low cut (LOC, 12 dB/oct) → compressor (CMP: RMS, 5 / 100 ms, ratio up to 4:1, gain stepped per block) → level / pan. The core part goes to the core bus. Sums are linear, so one upsampler for all four tracks is exactly four. The air goes to the air bus and WAVE to the wide bus, both at 32 kHz.

**Up to the DAC.** The core bus by Hermite plus a 3.9 kHz low-pass. The wide and air buses by one resampler: 32 taps, Kaiser, flat to 14 kHz, images below −53 dB, with 375 phases because 272 wide samples are exactly 375 frames. Only 188 phases are stored, since phase 375 − p is phase p reversed. At WARP ≠ 1 the nearest phase is used: under 42 ns of jitter.

**The master bus,** after the effects:
- AIR: a shelf above 7 kHz on the side, a third of it on the mid.
- WID: the side's level, 0-200 %.
- GLU: a stereo-linked RMS compressor whose ratio, threshold and make-up all rise from exactly off.
- CEL: a 1 ms look-ahead peak limiter (sliding minimum over the window, release 60 ms).

The limiter replaces v0.3's always-on soft clip. Live recording's heard clock accounts for the 1.5 ms and the 1 ms.

**Measured** against the original audio: envelope error per band in 5 ms hops (2 ms for drums), 60 dB floor, level-matched. Lower is better; the recipe is the offline Round 1-2 rebuild.

| Material | v0.3 (on the mix) | v0.4 (per track) | offline recipe |
|---|---|---|---|
| one loop, solo (CO 4) | 5.58 dB | 2.35 dB | 2.06 dB |
| four loops, mixed and panned | 5.14 dB | **2.30 dB** | 2.32 dB (per track) |
| kick / snare | 9.9 / 10.0 dB | 4.9 / 2.9 dB | |
| closed / open hat | 29.1 / 30.2 dB | 2.6 / 8.3 dB (3.1 over its first 280 ms) | |
| crash | 16.2 dB | 2.2 dB | |

The open hat's last 60 ms sit near −74 dB, where the codec spends 0 bits a block, so the core itself ends early; the metric's 50 dB floor still counts it. The 1/8 ms noise envelope moved the closed hat from 4.9 to 2.6 dB and the solo loop from 2.41 to 2.35, and the mix from 2.18 to 2.30: a wash within the metric's noise, and the drums were the weak case.

The highs' crest factor on the mix is 21.7 dB against the original's 22.3. Without the Schroeder phases it was 26.5, with peaks twice the original's. The dual-core split is still bit-identical to one core.

## 11. Each track's effects (v0.5)

Every track has its own multi-effect and its own reverb, inserted after its compressor and before level, pan and the air:

```
machine -> strip -> low cut -> comp -> MULTI-FX -> REVERB -> level / pan -> core bus
                                                          \-> the air, rebuilt from the wet sound
```

**At 8 kHz, before the air.** Both effects run on the clock, one core sample per sample. The air rebuilds 4-16 kHz from whatever it is fed, so echoes, chorus voices and reverb tails get their highs back. The copy-up shifts frequencies rather than scaling them, so a comb's spacing and a phaser's notches in 2-4 kHz are carried up as they are. Delay memory is a quarter of what 32 kHz would need: 2 s of stereo line is 36 KB.

**The multi-effect: one structure, four characters.**

```
x -> (+) -> allpass chain (DIS: 6 swept stages) -> delay line (TIM, modulated by DEP at RAT) -> COL -> wet
      ^_________________________________ FBK (+-) _________________________________________/
```

| TIM | Character |
|---|---|
| 0 (with DIS) | phaser: the allpass chain alone, mixed with the dry; FBK is resonance |
| 0.4-10 ms | flanger (FBK < 0: hollow) |
| 10-40 ms | chorus: a second voice at 0.73 x, its LFO in anti-phase, fades in from 5 ms and out by 60 ms; the channels' LFOs 90 degrees apart |
| synced | delay: n/64 of a bar (exactly n × bpb clock samples), or triplets, up to 2 s; DEP is tape wow, DIS smears the repeats, COL darkens or thins them |

- **Only one profile at a time, but it morphs.** TIM glides (about 100 ms), so turning it moves through the characters, and a synced time pitches like tape when it changes. Every control is a register, so locks, scenes and the LFO move between profiles in real time: one scene a chorus, another a dotted-eighth delay, the mod wheel between them.
- **Tempo sync is native.** A synced delay is a whole number of clock samples at every tempo: the line is read before the sample is written, so the n-th echo lands on exactly n × the time and never drifts off the grid. A synced LFO's phase *is* the song position, so a sweep restarts on PLAY and repeats exactly every pass. WARP bends everything with the clock, like tape. Nothing inside needs MIDI clock.
- **Stereo.** ST: two lines, L into L and R into R. PING: the sum into L, L's echo into R, R's back into L, so L R L R, each echo up to 2 s.
- **Memory: 8-bit block floating point.** The full 2 s line is kept as one scale per 16-sample codec block (a quarter-octave index) and an int8 per sample. The noise sits about 48 dB under each block's peak (measured on a loop: 48.2 dB per pass), and any position can be read directly. The newest 64 ms are also kept 16-bit (71 dB), so chorus, flanger and phaser never touch the 8-bit line. 36 KB a track instead of 64.
- **The loop's guard** is exactly linear to twice full scale, then a soft knee: a hot track passes untouched, and runaway feedback stays bounded.

**The reverb:** pre-delay, four input allpasses (DIF), a 4-line FDN (Householder) with damping (DMP) and two modulated lines (MOD). SIZ scales the lines and DCY is RT60. DCY 127 is FREEZE: the tail is held, the input shut. GAT closes the wet n steps after the track's last note: gated reverb on the clock. At 8 kHz the lines are a third as long as at 24 kHz, so four reverbs cost about what the old master reverb did.

**WAVE renders real highs at 32 kHz.** Its dry sound stays at 32 kHz. Its effects run on a 7-tap triangle decimation to the clock, and the wet gets its own air, with targets measured live from the dry WAVE's own 4-16 kHz.

**The air follows the image.** The air is built from the mid, so each side gets it scaled by the high-passed L/R-to-mid energy of the last 2 ms block. A ping-pong echo, 31 ms or more apart, takes its highs with it.

**Measured:** the same effect run at 48 kHz on the original audio is the reference, against the firmware (the effect at 8 kHz, the highs rebuilt after it). Envelope error per band, 5 ms hops; the same loop with no effect scores 2.35 dB.

| Effect | v0.5 L / R | v0.6 L / R |
|---|---|---|
| flanger (2.9 ms, FBK −0.6, synced sweep) | 2.68 / 2.69 | 2.68 / 2.69 |
| chorus (20 ms, synced) | 2.86 / 2.81 | 2.86 / 2.81 |
| ping-pong delay (3/16, FBK 0.49) | 3.62 / 2.76 | 3.62 / 2.76 |
| dark delay (1/8, COL low-pass in the loop) | 3.09 / 3.09 | **2.57 / 2.57** |
| phaser (6 stages, synced sweep) | 3.43 / 3.73 | **3.00 / 3.25** |

Chorus and flanger come within about 0.4 dB of no effect at all. In v0.5 the rest showed one missing piece: the air did not know the response of what sits between the sound and the output. The dark delay's echoes came out about 1.3 dB too bright, and the phaser's notch pattern was copied into 4-12 kHz. Since v0.6 both declare their response (the contract, 12), which closed most of it. The ping-pong's left side still carries some of the right's echo highs, because the air is built mono and steered by image gains; true stereo air (two rebuilds per stereo track) would fix it, at about twice the air's cost.

## 12. The filter: one prototype, two halves (v0.6)

A track's filter (page B: CUT RES TYP, FEN) is one analog prototype: LP, BP or HP, 12 dB/oct, cutoff 20 Hz-20 kHz, Q 0.5-17. The core runs at 8 kHz, so the core can hold that filter only below 4 kHz. Before v0.6, the rebuilt highs above that came from whatever 2-4 kHz the filter left: a generic lift, not the filter's own response.

**The core half: magnitude-matched (`os_flt.c`).** The plain bilinear map squeezes every response to zero at 4 kHz and cannot place a cutoff above it. Measured: a resonant LP at 6 kHz whistled at 3.4 kHz (+13.7 dB, where the real filter has +3), and an LP at 818 Hz was 12-19 dB too deep near 3-3.4 kHz. Now:
- The poles come by impulse invariance at fp = min(fc, 0.42 fs). Above that, Q eases as Q/r² (r = fc/fp), so a cutoff above Nyquist shows its skirt, not a false peak.
- The numerator is matched to the prototype's magnitude in-band, after M. Vicanek's matched second-order filters. LP: at DC, the pole frequency and Nyquist. BP: its zero at DC kept, matched at half the pole frequency and at Nyquist. HP: its double zero at DC kept, its gain matched at the pole frequency, easing to 0.6 of it above the split.
- The design is continuous as a cutoff sweeps through 4 kHz.
- Any biquad is a TPT state-variable filter plus a mix of its LP, BP and HP outputs, so the filter keeps the SVF's smooth modulation. It is designed every 0.5 ms, and its seven coefficients glide between designs (42 dB rms from designing every sample, on a 10-octave-per-second sweep).
- An LFO on CUT at 100 Hz or more (filter FM) uses the plain bilinear map every sample, the only one fast enough.
- Measured against the prototype over 50 Hz-3.9 kHz: LP within 1.4 dB (amplitude-weighted) except a resonant LP right at 4 kHz; BP and HP within about 2 dB in third octaves.

**The air half.** The rebuilt highs are first un-filtered: divided by what the core filter did to the 2-4 kHz band they are copied from. That gain is analytic at once (the prototype over the band) and corrected slowly (about 8 ms) by measurement: the band before and after the filter, through the copy band's own shape. That shape is the air's 2 kHz Butterworth, then its baseband low-pass mirrored about 3 kHz as an elliptic high-pass. Through a gentler band a resonance just under 2 kHz leaked in; through a sharper or higher one a steep slope was under-read. Either way the highs came out 2-3 dB off. Then the highs run through the same prototype at 32 kHz, designed on the same schedule. Above 4 kHz the filter's slope, resonance and self-oscillation are real.

**Measured:** the analog prototype applied at 48 kHz to the original audio is the reference (the matched design at 48 kHz, within 0.9 dB of analog to 16 kHz). Envelope error per band 4-16 kHz; core deviation in third octaves 0.25-3.8 kHz against the unfiltered core path's own band edge, where the reference is within 40 dB of its loudest band. The same loop with no filter scores 2.35 dB.

| Filter | v0.5 high band | v0.6 high band | v0.6 core |
|---|---|---|---|
| LP 818 Hz, Q 0.7 / 5 | 15.3 / 15.9 | 2.51 / 3.16 | 0.3 / 0.2 |
| LP 2 kHz, Q 0.7 / 5 | 18.2 / 28.0 | 2.66 / 3.47 | 0.2 / 0.2 |
| LP 3.6 kHz, Q 0.7 / 5 | 16.6 / 19.3 | 2.52 / 2.47 | 0.9 / 0.4 |
| LP 6.2 kHz, Q 0.7 / 5 | 9.1 / 11.2 | 2.45 / 2.74 | 0.6 / 1.7 |
| LP 10 kHz, Q 0.7 / 5 | 4.0 / 5.1 | 2.38 / 2.46 | 0.1 / 1.3 |
| HP 1.5 / 6.2 kHz | 2.4 / 6.1 | 2.33 / 2.37 | 0.0 / 2.8 |
| BP 1.5 / 6.2 kHz, Q 3 | 10.2 / 6.6 | 2.80 / 2.52 | 0.4 / 8.0 |
| all 14 | 13.9 | **2.65** | 2.4 |

(v0.5's core column is not comparable: it was scored against a bilinear reference.) The two worst are resonant LPs at low cutoffs, about 1 dB over the no-filter baseline. Tried and rejected: un-tilting the copies (a complex pole-zero on the baseband, so each copy does not carry the filter's slope across its slot). It helped the worst case and hurt the rest: 2.82 overall. The band-pass centred above 4 kHz is accurate in the high band; in the core, only its lower skirt shows, 30-40 dB down, and that is where its 8 dB lives.

**The drive** (DRV, after the filter) is now x/√(1+x²) with first-order antiderivative anti-aliasing: F(x) = √(1+x²) − 1, written x²/(√(1+x²)+1) so a quiet signal loses nothing. Measured on a 1.7 kHz sine, where every harmonic but the fundamental folds back, it folds 7-9 dB less than v0.5's x/(1+|x|). The air rebuilds the highs a drive would have made.

**The response contract.** It is for anything added later. The air is rebuilt from the end of the chain, so every linear stage between a voice and the air's tap must tell the air what it did:
- A stage with resonance or a sharp shape is realised on the air too, as this filter is.
- A smooth stage declares its magnitude only. The air's targets per slot are scaled by |H(slot)|² / |H(2-4 kHz)|² (`flt_slot_gain`).
- The low cut does the latter. So does the multi-effect (`tx_slots`). An echo train of feedback g through COL gives the wet c/(1 − g²c) per frequency (c = |COL|²), mixed by the wet's measured share of the output's highs. The phaser's dry and wet are coherent, so its slot gain is the whole response, dry·d + wet·w·A/(1 − fbk·A·e^−jωT), over both channels' sweeps.
- Not yet declared: the reverb's damping.

**Costs:** with the filter on in all four tracks, the host renders a half in 21.5 µs against 15.1 with none: about 1.6 µs per track, including the 32 kHz half and the band measurement. Code +8.6 KB, RAM +1.9 KB.

## 13. The modulators (v0.7)

One envelope and one LFO, written once (`os_mod.c`) as a coefficient set (from registers, per block) and a state (per voice or per track), and used five times:

| | Where | Page | Registers |
|---|---|---|---|
| AMP | every voice | C | `ATK DEC SUS REL RNG` |
| ENV1 | every voice | D | `AT1 DE1 SU1 RE1 RG1` + target `ET1`, depth `ED1` |
| ENV2 | the track | E | `AT2 DE2 SU2 RE2 RG2` + `ET2 ED2`, and `FLT`: also to the cutoff, by FEN |
| LFO1 | every voice | F | `RT1 MU1 SH1 MD1 PH1` + `LT1 LD1` |
| LFO2 | the track | G | `RT2 MU2 SH2 MD2 PH2` + `LT2 LD2` (the old LFO, grown) |

**Envelopes.** Attack linear; decay and release one-pole toward their targets. RNG LONG: 2 ms-4.1 s a stage (pads, ~12 s in all); SHORT: 0.1 ms-330 ms (hits, under 1 s in all); 128 exponential steps either way. Measured within 1 % of the designed time at both ends of both ranges. A long stage needed one fix: the fast exp's 2e-4 error, amplified in 1 − e^−a, made a 4 s decay 1.8 s (in v0.6 too), so small a uses the series. ENV2 opens with any note, from where it is, and closes when the last held note is released.

**LFOs.** RATE spans two decades (0.1-10 Hz at 1X, 3.7 % a step), MUL shifts it: 1/64 to ×256, so 0.0016 Hz to 2.56 kHz, measured exact to four digits across all eight multipliers. MUL = SYNC turns RATE into a note value: 26 of them, 1/64T to 64 bars, in 1/384 of a bar (bpb / 6 clock samples), so straight, dotted and triplet values are exact at every tempo. The phase step carries a 32-bit fraction (no 64-bit maths), so even a 64-bar cycle is exact. A synced FREE LFO's phase is the song position. Shapes: SIN TRI SQR SAW RMP EXP S&H SMT. Modes: FREE, TRIG (restart at PH), HOLD (the free LFO's value at the note), ONE (a cycle, then hold: with EXP, an extra AD envelope), HALF. Square and saw are not band-limited.

**Routes, not a matrix.** Each source has one target (any register, or none) and a depth: ±128 register units at the ends, squared, so near the centre a step is 0.03 units (3 cents of pitch) and full depth spans any register. How a target is driven depends on what it is:
- **Track sources** (ENV2, LFO2) drive pitch, tune, cutoff, level and the WAVE frame every clock sample, through the track's modulation bus. Every other register is driven at the 2 ms block through the resolver.
- **Voice sources** (ENV1, LFO1) drive each voice's own pitch, tune, level, pan and WAVE frame morph every clock sample. A MULTI voice's sample start and length are driven as it starts, and a GRAN grain's position and size as each grain starts. Every other register belongs to the track, so a voice source there follows the newest voice, at the block.

So every modulator reaches every register, and a knob or pad mapped later is one more source of the same kind.

**What is limited, and why.**
- A voice's WAVE frame morphs only within the frame pair the track has loaded. Per-voice frames would need a frame decode per voice: about 4× WAVE's cost and 8 KB. Deferred.
- The filter and the effects are per track, so they are not voice targets.
- ENV1 starts at 0 with each note, so it cannot move a start point; LFO1 can (TRIG with a start phase, HOLD, S&H).

**Measured:**
- 30 unit checks (`tests/mod_unit.c`) cover stage times, rates, synced periods at every tempo, song lock, the five modes, the eight shapes, ENV2's gate over overlapping notes, and a voice's ENV1 on its own pitch.
- Costs on the host: every modulator live on every track renders a half in about 41 µs against about 33 with the session's own use. A source nothing uses does not run. Code +6 KB, RAM +2.5 KB.

## 14. Two cores: the second one accelerates, one is enough

The AC79 has a second core. The SMK-37 hardware layer runs it as a worker that does one job at a time for core 0, only inside the audio interrupt. Its waiting loop runs from RAM, so it never touches the flash. This comes from X0X, Melodee and Jangada's work on the FM-1, and Felucca ships it as a beta.

- **Every unit must work on one core.** On some units core 1 misreads shared RAM. Each job carries a check word: a wrong one, or a job not done within 4 ms, stops core 1 until power-off, and core 0 renders its part.
- **Built to split:**
  - Each track owns its voices, state and scratch.
  - Control runs first on core 0: pattern changes, audio grooves.
  - Then the tracks render, some on each core, each core into its own buses. A track's render includes its own rebuilt highs, so the second core takes that work too.
  - Then core 0 sums, upsamples and runs the master bus. (Each track's effects run inside its render, on whichever core it is on.)
- **The split is chosen by last half's measured cost per track**, as Felucca does it. It leaves the busier core the least, and none when the handover (about 100 µs) would cost more than it saves.
- **Proof on the host:** the split path, with tracks 3-4 rendered "on core 1" into their own bus, matches one core up to the order of floating-point sums: in v0.7's session, 599 of 4.9 million 16-bit samples differ, by 1 LSB. (v0.4 was bit-identical only because no bus took sound from both tracks 3 and 4; since v0.5, WAVE's wet joins the core bus.)
- **Build:** `tools/build.py --cpu2` makes a separate package (`brros-smk37-cpu2.fwsc`). The default build has nothing of the second core in it. SHIFT + PATCH switches the second core on or off while running, and the header shows `%2` while it renders tracks.

## 15. Kits, patterns, scenes and the song (v0.8)

**A kit is everything that plays:** the four tracks' sounds, 8 patterns, 8 tables, 8 scenes, the song, the tempo and the master bus. It is the unit of saving (16, 17).

**Voices: eight for all four tracks.** The budget is CPU, so it counts what sounds: a poly voice not yet fading out, and a sounding mono track (TAPE, GRAN) as one. Two limits:
- **A track's own (VOI, 1-8).** Checked at the note, on the track's own core: past it, the track's oldest releasing voice (else its oldest) is choked (1 ms) and the note takes a free slot. A steal fades; it is never a restart. VOI is a register, so a lock can make one step mono.
- **All eight.** Checked at the start of every half, on core 0, before the tracks render: notes fire inside a track's render, possibly on the other core, so no track may touch another's voices mid-half. A note that lands on a full budget sounds at once; the half after, the oldest releasing voice anywhere (else the oldest) is choked. The budget can run over for one half (2.9 ms) by the notes that started in it, never longer; 4,000 halves of random notes never found it over after a check (at most 11 within one half). Choking voices count toward neither limit. Mono tracks are never choked.

**Patterns.** Each pattern keeps its own header: each track's length and speed (STP, SPD: the registers show the playing pattern's and are written back at its end) and its length in bars, 1-8 or AUTO (its longest track, rounded up to bars). At its end every track starts at step 1 again, so the polymeter of a short track lives inside its pattern and a song of patterns is deterministic. A cued pattern, or the song's next one, comes in on the exact clock sample the playing one ends. Trig conditions count passes since the pattern came in and keep counting while it repeats; a new pattern starts them from 0 (1ST is its first pass).

**The song.** Up to 64 one-byte rows: a pattern (3 bits) and its repeats (5 bits, 1-32), looped. PLAY with the song on starts at its first row.

**The event heap.** v0.7 gave every list 256 events, so one track of a dense 8-bar pattern (16ths with a lock each) did not fit. The kit's 40 lists are now slices of one heap of 10,240 events, in a fixed order (pattern-major, then the tables): an insert moves the heap above it up one event and the slices after it, a delete moves it down. Same RAM as before; any one list can hold what the others leave. The move is at most the whole heap (80 KB) under the engine lock; editing is a person's pace.

**Scenes: eight, stacked, each at its own amount.** A scene is a mask and values per track. Any number can be in, in the order they came in; the resolver moves each register toward each scene's value by that scene's amount (1-127), oldest first, so a newer scene sits on top of an older one where both set a register. The rounding is to nearest in both directions (v0.7 lost a step on the way down). Locks still win. The pads give the amount (CONTROLS.md): velocity when tapped (latched), velocity pushed toward 127 by pressure while held (momentary), the wheel for the last scene touched.

## 16. Presets as bits (v0.8)

The goal was bytes, not kilobytes, and recall as immediate as a lock. The codec (`os_store.c`) is a bit stream read in one pass, with no tables beyond the templates:

- **A sound is a delta from a frozen template.** Its machine (2 bits), then only the registers that differ from that machine's template (`TPL_V1`, 4 × 88 bytes in flash): a gap to the next one (exp-Golomb), and the value as a small signed step from the template or raw. A fresh sound is **1 byte**; the session's designed sounds are 14-33 bytes. The template is never edited: a firmware whose defaults change adds `TPL_V2` and keeps V1 for the records made under it (the record header carries the version); a unit test fails the day the defaults and V1 part ways.
- **Every other value goes through a field coder with its own context:** `0` the same as the last value of that field, `10` + exp-Golomb a small step from it, `11` + raw. So a column of equal velocities costs a bit a note, a bass line a few bits a note, and a lock lane, predicted from the last value of its own register, a few bits a step. This is the tracker's column view, kept in the order the list is in.
- **A list** is step groups: the gap and the counts of notes, locks and commands (each `0` when as the last group's), then each event's residual (0: 1 bit; a live note's: 14 bits) and its four fields. Every field of every event is kept, so the round trip is exact (a lock edited in LIST to carry a residual keeps it); only the recorder's this-pass flag is dropped.
- **A kit** is the tempo and master bus (6 bytes), four sounds with their learned pockets, 8 pattern headers and their 32 lists, 8 tables, 8 scenes (each value a step from its track's own) and the song.
- **Loading checks first, then writes.** A dry pass decodes everything (bounds, counts, the heap's room) and changes nothing; only a record that passed is written, so a broken record never leaves a half-loaded kit. A sound loads like a lock: bytes into the base registers, the strip re-derived. It keeps the track's STP, SPD, FEEL and table.

Measured (`store_unit.c`): an empty kit is 45 B; the session's kit 270 B; a typical one (8 patterns of 1-2 bars: drums with a lock on every hat, bass, pads; 426 events) 1,386 B, 26 bits an event with everything; a dense one (8 patterns of 8 bars: a live melody with human timing, 16th drums with locks, chords with two lock lanes; 4,992 events) 14.3 KB. 120 KiB holds about 88 typical kits or 8 dense ones. The random parts of those test kits (velocities, lock values, residuals) cost what they cost; real playing repeats more. Every truncation of a record is refused; of 3,000 single-bit flips, the ones refused changed nothing (the flash's CRC catches flips before the decoder anyway).

## 17. The vault: the 120 KiB data area (v0.8)

Presets live in FL_DATA (0x9D000-0xBAFFF) and nowhere else: the user sample area (USRFLASH) stays the samples'. `os_vault.c`:

- **Chunks.** A 28-byte header (magic, type, id, part, LAST, format version, generation, sequence, length, payload CRC-32, header CRC-32), then the payload, padded to 4 bytes. A chunk never crosses a 4 KiB sector, so every sector reads on its own from its first byte. Payload first, header last: a cut leaves no header, so no chunk.
- **Records.** A sound or a kit is its chunks 0 .. LAST of one generation. It counts only once its LAST chunk is written, so a save cut short by the power leaves the previous version whole. Per (type, id) only the newest whole generation counts; a deletion is a one-chunk generation of its own.
- **The ring.** Chunks go at the head, sector after sector. The rule: the sector after the head's never holds anything live. Moving into a new sector first copies the live chunks of the sector after it in (they fit: they filled at most a sector), so that one can be erased next time round. Every sector is erased in turn, so wear is spread by construction (6,000 saves: every sector erased 122-123 times). The area holds live data up to all but two sectors (about 112 KB).
- **A copy cut short** by the power is finished in place at the next boot: the same bytes again, because programming only takes bits to 0 and what is there is already part of them. (Without that, the half-written copy took the room the rest needed, and the ring stopped: the power-cut test found it.)
- **Erasing** stops the audio for tens of ms, so the vault erases only when allowed. A save while playing that would need an erase is refused before a byte is written: a dry run plans the whole write first. Stopped and silent for a second, the vault erases a dead sector ahead (up to three), so saves while playing usually find room.
- **Streaming.** No record is ever whole in RAM: the kit encoder runs once to measure and once for each 1 KB window as it is written, and the decoder reads through a 1 KB cache. A kit can be any size the area takes (tested: 9,800 events, 49.7 KB). On the host a typical kit saves in 1.6 ms and loads in 0.5 ms, the 49.7 KB one in 38 and 1.7 ms; the device will be some tens of times slower.
- **Someone else's data.** An area holding anything that is not ours (Felucca's store, the stock VM) is left alone: nothing is written until the owner asks for it to be erased (SHIFT + PLAY twice). A blank area is claimed at once with a small owner record, so a later save cut short is never mistaken for someone else's bytes.
- **Bounds.** Every flash access goes through `st_read` / `st_erase` / `st_prog` (storage_hw.c), which refuse anything outside the storage areas; the vault asserts it stays inside FL_DATA, and the host's simulated NOR counts any access outside it (none in any test). What is programmed always comes from RAM.

Tested on a simulated NOR (`vault_unit.c`): 6,000 random saves and deletes of 0-24 KB against a model, all checked and remounted every 500; the area filled to 91 % then FULL; saves while playing either done or refused untouched; foreign data left alone until formatted; 4,000 saves with the power cut at random points (including during erases, during the copies, and again during the boot's repair): every record was its old or its new self after each, the vault always came back.

**Not yet measured on the unit:** how long an erase and a page program (256 bytes at a time) keep the interrupts off, and so whether a save while playing is inaudible.

## 18. The shaper (v0.9)

One more effect on every track: a waveshaper / wavefolder (`os_shp.c`, page L). Before or after the filter is one register, not two copies: the one function is called at one of two points in the track (PRE: after the machine; POST: after the filter and DRV), so the switch costs nothing.

**The chain:** LPF (a one-pole tone) → ×INP → up 2× → +BIA → the model, anti-aliased → down 2× → DC blocker → level match → with the dry by WET.

**Aliasing is the problem at 8 kHz.** A shaper makes harmonics far above the core's 4 kHz Nyquist, which fold back as inharmonic tones. The options were measured as the filter's were, against the same chain run alias-free (at 16×, brick-walled to 4 kHz), on loops and on sines from 220 Hz to 3.1 kHz:

| | aliases under the harmonics (high notes) | 2-4 kHz band (what the air copies) | loops, SNR |
|---|---|---|---|
| shaping at 8 kHz | from 10 dB under to 12 dB over (FOLD, CHEB) | as is | 27 dB |
| first-order ADAA at 8 kHz | 7-19 dB under | −4.5 dB: its average dulls the top | 21 dB |
| 2× up, ADAA at 16 kHz, a decimator that undoes the average | **26-39 dB under** | **within 0.2 dB** | **31.5 dB** |

(Aliases: sines at 2.6 and 3.1 kHz through CLIP, FOLD, TAPE and CHEB.)

The third is the one: a 23-tap half-band up (12 multiplies a sample: its odd phase is the centre tap), ADAA at 16 kHz, and a 23-tap decimator designed with 1/cos(πf/16k) in its passband (ADAA's two-tap average, undone) and a half-sample advance. The chain then delays by exactly 11 samples of its rate (1.4 ms on the core, 0.34 ms on WAVE's 32 kHz, which runs the same chain), and the dry is delayed to match, so WET mixes without combing (dry + wet of a linear setting: +5.98 dB, against 6.02 for no combing). In C, on a real loop, the chain's error against the alias-free reference is 26-32 dB per model, 7-10 dB better than shaping at 8 kHz; POLY, which barely aliases, measures 38 dB (42 at 8 kHz: what is left is the filters' own edge).

**The models** are each a function and its anti-derivative, written so that nothing cancels in single precision (u²/(√(1+u²)+1), not √(1+u²)−1); the ADAA falls back to the function at the midpoint only when the input barely moves (relative to its size), where the two agree. FOLD's sine is a degree-9 polynomial on the quarter period (no libm). CHEB is the Chebyshev polynomials T2-T7, gliding between orders, held at ±1 outside. POLY is x + E·x² + O·x³: the formula model, since nothing on the device can type a formula. BITS is not anti-aliased: its crunch is the point.

**Level.** The wet is matched to the input (energies per 2 ms block, ~50 ms, −40 to +12 dB), so INP is character, not loudness; XOVR and RECT do not saturate, so their INP is undone first. Measured at +36 dB on a three-tone signal: every model within 0.4 dB of the input (FOLD +0.4, RECT +0.3, the rest 0.0).

**The air knows where it sits.** PRE, the filter shapes the harmonics and the air does as before. POST, the harmonics never went through the filter: the shaper tells the air the share of the track it made (WET's wet over wet + dry), and the air neither un-filters nor filters that share. The 32 kHz copy of the filter is blended toward through (an SVF's LP + k·BP + HP is its input, so a blend of mix coefficients is a blend of responses), and the un-filter's gain the same way. A WAVE note behind a 300 Hz low-pass, folded POST, comes out bright up to 8 kHz; folded PRE, dark.

**Switching.** WET 0 is off and costs nothing (the session renders bit-identical to v0.8). On: 8 ms unheard while the chain fills and the level match settles, then an 8 ms fade. Off: an 8 ms fade with the parameters frozen. The largest sample step through on/off every half second stays within the dry's and the shaped sound's own.

**Cost (host):** 27-91 ns a sample mono, depending on the model (FOLD most), about 100 ns for an M/S track: a tenth to a quarter of what a track costs. 6 KB of code; 3 KB of state in the pool.

## 19. Next

The order, as decided:

1. ~~The filter stage, with an air that knows the response~~: done in v0.6 (12).
2. ~~ENV and LFO~~: done in v0.7 (13).
3. ~~The sequencer and pattern control, scenes, presets~~: done in v0.8 (15-17). ~~A shaper on every track~~: done in v0.9 (18).
4. **The sequencer pages and the GUI refresh:** layers of control between the engine and a new GUI (piano roll, XOX and more), designed as their own modules. The engine and store already have more than the panel shows: the kit's slot (64), saving and loading single sounds (128 slots), the song's rows, a pattern's length, deleting presets.

Also open: the rest of the command set, MIDI in/out at the edges, user samples in USRFLASH (kept free for them), and the device measurements above. For the air: a sidechain (a free slot on page J), per-grain side info for GRAN, and listening on the unit, since the measurements above are only a proxy for the ear.
