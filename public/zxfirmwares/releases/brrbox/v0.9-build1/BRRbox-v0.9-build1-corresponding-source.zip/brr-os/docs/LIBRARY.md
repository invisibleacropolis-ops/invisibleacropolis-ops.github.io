# The sample library

The library is one SVB4 container (`library/library.svbr`), `library/manifest.json` and `library/onsets.json`. The manifest holds the
names, the default four-track scene and the tempo. The build turns both into `build/gen/os_library.h`, so the
library becomes part of the firmware image and every voice reads it in place.

## Encode your own

```sh
python3 tools/encode_library.py library/spec.example.json
```

`spec.example.json`:

```json
{
 "bpm": 128,
 "q": 18,
 "samples": [
  {"file": "../my-samples/drums.wav", "name": "DRUMS"},
  {"file": "../my-samples/bass.wav",  "name": "BASS", "q": 24},
  {"file": "../my-samples/pad.wav",   "name": "PAD"},
  {"file": "../my-samples/vox.wav",   "name": "VOX"}
 ],
 "scene": [
  {"si": 0, "start": 0, "beats": 16},
  {"si": 1, "start": 0, "beats": 16},
  {"si": 2, "start": 0, "beats": 16},
  {"si": 3, "start": 0, "beats": 8}
 ]
}
```

- **Files:** any WAV, mono or stereo, any rate. Stereo is mixed to mono, everything is resampled to 48 kHz and
  peak-normalised.
- **Names:** up to 8 characters.
- **q:** allowed coding noise under the signal, in dB. The default is 18. 24 is cleaner and about 30 % bigger;
  12 is grittier and about 30 % smaller. It can be set per sample.
- **Scene:** what the four tracks hold at power-on. `start` is in core samples (8000 per second); `beats` is
  1/2/4/8/16/32 at `bpm`. Loops are cut in whole beats, so trim your files to start on a downbeat.
- **Onsets:** `encode_library.py` also writes `onsets.json`, the onset map of every sample (spectral flux on the
  decoded core, one frame every 4 ms, refined to the sample). TAPE uses it for slices (`SLC`), and `GRV TK1-4`
  uses it to take a loop's own groove. Run `tools/analyse_library.py` again if you change the library by hand.
- **Wavetables:** WAVE reads one keyframe (512 core samples, 64 ms) as one frame and loops its first `CYC` samples.
  Author a wavetable as a sample whose every 512 samples at 8 kHz hold one frame. For example, two cycles of 256,
  band-limited to about 40 harmonics so high notes don't alias. Any other sample works too, just buzzier.
- **Budget:** 350,000 B. The encoder warns above it. At q 18 expect about 160 KB per minute of material.

## Format (SVB4), for reference

| Part | Size |
|---|---|
| Header + static rANS tables (shared) | 296 B |
| Directory | 26 B per sample (length, keyframes, offsets, loop, root, side window) |
| Keyframe offsets | 3 B per 64 ms |
| Keyframe seeds | 3 B per 64 ms: the two previous decoded samples (12 bits each) the predictor restarts from |
| Audio | per 16-sample block (2 ms): 0-4 bits/sample, 1 of 8 predictors, 1 of 32 step sizes; rANS-coded, totals 4096 |
| Side info | 34 bits per 16 ms (128 core samples): 8 band energies (4 bits) + tonality (2 bits), fixed rate, directly indexed |

**Side window (v0.4).** A band code c means `−39 + 3 (c + off)` dB relative to the core's 2-4 kHz band. `off` is the
sample's signed window offset (directory byte 25, which was always 0 before). The encoder picks it for least
clipping: a hi-hat's highs sit 20-30 dB above its own 2-4 kHz band (off +10), a kick's or a dull loop's 40-60 dB
below (off −8). Older libraries have 0 and play as before.

**SVB4 is the one-clock layout.** Every unit is a power of two of the 8 kHz sample: 16-sample blocks, 128-sample side frames (4 per keyframe), 512-sample keyframes. Against SVB3's 32-sample blocks and 20 ms frames, the blocks cost 4.5 % and the side frames 6 KB on the default library. In exchange, transients' coding noise stays within 2 ms, the tempo grid is twice as fine, and the high band follows the original 0.2 dB more closely. Older containers have 32-sample blocks, so re-encode them.

**Why seeds.** SVB2 restarted the predictor from silence at every keyframe. In a quiet decaying tail, that could
put a small step into the audio every 64 ms (the default kick showed jumps of up to -27 dBFS). With seeds, keyframe
edges measure the same as ordinary block edges. Random access stays exact, and the seeded prediction saves almost
as much as the seeds cost (+2.9 KB on the default library). The decoder reads SVB2 too.

Decoding a symbol costs one 32×32→32 multiply, shifts and adds. There is no divide and no 64-bit arithmetic,
so it avoids the pi32v2 erratum documented in felucca-bsp `docs/CPU.md`.
