# Controls (v0.9)

**One gesture everywhere: whatever you hold is what the knobs edit.**

## The screen

```
1 TAPE  2 MULTI  3 WAVE  4 GRAN       the tracks (selected one lit, "-" = muted)
P1 150.0 STEP A MACH        REC >     pattern, tempo, view, knob page, recording, playing
┌──────────────────────────────────┐
│  the view                        │  STEP / ROLL / LANE / LIST / PERF / MACH
│                                  │
└──────────────────────────────────┘
STEP 05 C-4 E-4 +12                   what you hold, or where you are
CUT 2K5   RES 40    TYP LP    FEN +20 the 8 knobs of this page, always shown;
ATK 12MS  DEC 640MS SUS 100   REL 1.1S a lock on a held step shows in blue
```

## Buttons

| Button | Does |
|---|---|
| SEQ | STEP view: the pads are 16 steps (`<` `>` page through longer tracks) |
| CHORD | ROLL view: piano roll, 16 steps x 2 octaves (OCT moves it) |
| PARA | LANE view: one register's locks across the steps |
| FADER BANK | LIST view: the event list itself (tracker rows) |
| GLOBE | PERF view: scenes and patterns; GLOBE again: mutes, FILL, capture and patterns |
| PATCH | MACH view: machine and sample for the track, all 56 registers (five pages at a time) |
| KNOB BANK | knob page A MACH → B FILT → C AMP → D ENV1 → E ENV2 → F LFO1 → G LFO2 → H FX → I VERB → J AIR → K FEEL → L SHAP (SHIFT: back) |
| FX | the selected track's FX page (H); again: its VERB page (I); again: MASTER (GLU AIR WID CEL HF GR BPM MST); again: back where you were. SHIFT+FX: every track's effects in / out |
| BT | **SHIFT** |
| SEQ PLAY | play / stop (every track starts at step 0 on the next block; with the song on, at its first row) |
| SHIFT + PLAY | **save the kit** into the vault (the 120 KiB data area). Stopped: always. Playing: when it needs no erase (the vault keeps erased room ready while stopped and silent), never while recording. The kit loads again at power-on |
| SEQ REC | record arm. **SHIFT+REC: retro capture**, which writes what you just played (last loop) into the pattern |
| NOTE REPEAT (hold) | FILL (the `FILL` / `!FIL` conditions) |
| SCALE (hold) + pad | clear that step. In LIST, SCALE deletes the row |
| OCT- / OCT+ | keyboard octave (and the ROLL rows) |
| SHIFT + top pads 1-4 | select track 1-4, in any view |
| SHIFT + PATCH | second core on / off (a `--cpu2` build; the header shows `%2` while it renders) |

## Pads in STEP / ROLL / LANE

| Gesture | Result |
|---|---|
| tap an empty step | places the last key you played (note and velocity) |
| tap a full step | clears it (ROLL: toggles just the note at the last key's row) |
| hold step(s) + turn a knob | **a parameter lock** on those steps for that register. An empty step gets a lock with no note (a trigless lock) |
| hold a step + press keys | those keys become the step's chord |
| hold keys + tap a step | **chord stamp**: the held keys go onto that step |
| SHIFT + turn a knob | that register becomes the LANE |

Locks belong to their step. They apply before any note on the step sounds, even one played early, and they hold until the next step that has events.

## Keys

Keys play the selected track and set the note that a tap places. When REC is on and the transport is playing, each note is recorded as **grid step + your residual** (shown in 1/384 of a beat, the Yamaha QX unit). You hear your timing back exactly. Page K (FEEL) then decides what plays:

| Register | Does |
|---|---|
| FEL (FEEL) | -100 % inverted · 0 % the grid · 100 % as played · 150 % exaggerated |
| WIN | only notes this close to the grid get FEEL; ones further off stay as played |
| VFL | velocity: fixed at 100 (0) to as played (127) |
| GRV | groove: OFF · swing 54/58/62/66 % · LRN (your own pocket, learned while recording) · TK1-4 (the pocket of that TAPE track's loop, from the onset map) |

Every one of them is a register, so it can be locked per step or put in a scene.

## PERF pads (v0.8)

**Page 1 (GLOBE): the top row is the kit's 8 scenes.** A scene is a set of register values on any tracks.

| Gesture | Result |
|---|---|
| tap a scene | it comes in, **latched**, at the tap's velocity (a soft tap: part of the way); tap again: out |
| hold a scene | it is in while held (**momentary**), and pressing harder pushes it toward all the way; let go: out |
| hold a latched scene | pushed while held; let go: back at its latched amount |
| hold a scene + turn knobs | write the scene: the selected track's registers (SHIFT + top pads pick the track). Writing never latches it |
| CLR (SCALE) + a scene | the scene sets nothing any more |
| **mod wheel** | the amount of the last scene you touched: up brings it in (latched), down to 0 takes it out |

Scenes **stack**: each one in moves its registers toward its own values by its amount, oldest first, so a newer scene sits on top of an older one where both set a register. Locks still win over scenes. With FEEL in two scenes, the wheel is a machine-to-human crossfader: latch one, touch the other, ride the wheel.

**Page 2 (GLOBE again):** top pads 1-4 mute the tracks, 7 is FILL (hold), 8 is capture.

**The bottom row picks patterns 1-8** on both pages. Playing, the choice waits for the playing pattern's end, then every track starts at step 1. Stopped, it is the pattern at once.

## MACH pads

The top row picks the machine: TAPE, MULTI, GRAN, WAVE. Page A goes back to that machine's defaults; the other pages are kept. The bottom row picks the sample (`<` `>` change the bank).

## LIST

| K1 | K2 | K3 | K4 | K5 | K6 | K7 | K8 |
|---|---|---|---|---|---|---|---|
| row | step | residual (PPQ) | note / register / letter | velocity / value / argument | length (1/8 steps) / extra | condition | kind (NOTE, LOCK, CMD) |

- **Pads:** a pad inserts a note at its step.
- **SHIFT + `<` `>`:** switch between the pattern and tables 1-8. A table row is a step that the tick clocks.
- **Commands:** times are `2^(b/16)` core samples (1 sample = 0.125 ms).
  - `R b d`: retrig with velocity drop d. The playing voice jumps back to its start, so fast retrigs are pitches.
  - `C b`: cut.
  - `T n`: start table n.
  - `H n`: hop to step n.
  - `K`: kill.
  - `N v`: transpose by v - 64. It retunes at once, so a table can play a new pitch every sample.

| b | samples | time | as a retrig |
|---|---|---|---|
| 0 | 1 | 0.125 ms | 8 kHz |
| 32 | 4 | 0.5 ms | 2 kHz tone |
| 48 | 8 | 1 ms | 1 kHz tone |
| 64 | 16 | 2 ms | 500 Hz tone |
| 80 | 32 | 4 ms | 250 Hz buzz |
| 112 | 128 | 16 ms | a fast roll |
| 138 | 394 | 49 ms | a 32nd at 150 BPM |
| 144 | 512 | 64 ms | |

- **Tables:** TSP (page K) sets the row time the same way: TSP 112 is 16 ms (an arpeggio), TSP 0 is a row every sample (table synthesis).
- **The LFOs (pages F, G):** 0.0016 Hz to 2.56 kHz through the multiplier. Aimed at pitch, cutoff, level or the WAVE frame, they act every sample: FM, filter FM, AM, wavetable scanning at audio rate.

## The knob pages (v0.9)

| Page | Knobs |
|---|---|
| A MACH | the machine's own 8 |
| B FILT | CUT RES TYP FEN DRV LOC CMP |
| C AMP | ATK DEC SUS REL RNG VOI LEV PAN |
| D ENV1 | AT1 DE1 SU1 RE1 RG1 ET1 ED1 |
| E ENV2 | AT2 DE2 SU2 RE2 RG2 ET2 ED2 FLT |
| F LFO1 | RT1 MU1 SH1 MD1 PH1 LT1 LD1 |
| G LFO2 | RT2 MU2 SH2 MD2 PH2 LT2 LD2 |
| H FX | TIM FBK DEP RAT DIS COL PNG MIX |
| I VERB | SIZ DCY DMP PRE MOD DIF GAT REV |
| J AIR | WID AIR TLT TON SPR |
| K FEEL | FEL WIN VFL GRV TBL TSP STP SPD |
| L SHAP | MOD INP A B BIA LPF POS WET (A and B are named by the model) |

Which register each knob edits is one table in the firmware (`PAGES`, os_ui.c), separate from the engine. Pages can be rearranged, and later mapped your own way, without touching the sound.

## Page B: the filter (v0.6)

| Knob | Range (default) | Does |
|---|---|---|
| CUT | 20 Hz-20 kHz (20 kHz) | Cutoff. Since v0.6 the whole range is real: below 4 kHz the core follows the analog filter's own curve; above it the core shows the filter's skirt, and the rebuilt highs go through the same filter at 32 kHz, so a cutoff at 8 kHz, its slope and its resonance are where they should be. |
| RES | 0-127 (0) | Resonance, Q 0.5 to 17. A resonance above 4 kHz rings in the rebuilt highs. |
| TYP | OFF, LP, BP, HP (OFF) | Filter type, 12 dB/oct. |
| FEN | ±63 (0) | How much ENV2 moves the cutoff, up to ±100 register steps (about ±8 octaves), when ENV2's FLT is on. |
| DRV | 0-127 (0) | A soft saturator, x/√(1+x²), with anti-aliasing (ADAA): about 8 dB less folding back than v0.5's. Its level rises with drive (×2.1 small-signal at 127) and its peaks stay bounded. |
| LOC | OFF, 20 Hz-20 kHz | Low cut, 12 dB/oct. |
| CMP | 0-127 | Compressor: threshold down to −30 dB, ratio up to 4:1, auto make-up. 0 is off. |

An LFO2 on CUT below 100 Hz sweeps the matched filter. At 100 Hz and above (filter FM) the filter switches to the plain per-sample map, which is the only one fast enough.

## Page C: the AMP envelope and the voice (v0.7)

| Knob | Range (default) | Does |
|---|---|---|
| ATK DEC REL | per RNG (0, 70, 40) | Attack (linear), decay and release (exponential) of every voice's level. |
| SUS | 0-127 (127) | Sustain level. |
| RNG | LONG, SHRT (LONG) | LONG: each stage 2 ms-4.1 s (pads: A+D+R up to ~12 s). SHRT: 0.1 ms-330 ms (hits: under 1 s in all). 128 steps either way. |
| VOI | 1-8, MONO (MULTI 6, WAVE 4) | The track's voice limit. Past it, the track's oldest releasing voice (else its oldest) fades out in 1 ms for the new note. TAPE and GRAN show MONO. It is a register: lock it per step for a mono line inside a poly part. |
| LEV PAN | | Track level and pan. |

**Eight voices for all four tracks.** A sounding TAPE or GRAN track counts as one. When a note lands on a full budget it still sounds at once; at the next 2.9 ms the oldest releasing voice anywhere (else the oldest voice) fades out in 1 ms. So the budget can run over for one half, never longer.

**SPR** (voice spread) moved to page J.

## Pages D and E: ENV1 (per voice), ENV2 (per track) (v0.7)

The same envelope as AMP, with a target and a depth.

| Knob | Range (default) | Does |
|---|---|---|
| ATn DEn SUn REn RGn | as AMP (ENV1: 0, 60, 0, 40, SHRT; ENV2: 0, 70, 0, 40, LONG) | The envelope. |
| ETn | any register, or --- (---) | Its target. Turn through the list; the label of the register shows. |
| EDn | ±63 (0) | Depth: up to ±128 steps of the target at the ends, squared, so the middle is fine (one step from 0 is 3 cents of pitch). |
| FLT (ENV2) | OFF, ON (ON) | ENV2 also moves the cutoff, by FEN (page B), on top of its own target. |

**ENV1 runs in every voice.** Each note has its own. On pitch, tune, level, pan and the WAVE frame it acts per voice, every sample. On a MULTI sample's start (STR) and length (LEN) it acts as the voice starts, and on a GRAN grain's position (POS) and size (SIZ) as each grain starts. Everything else belongs to the track (the filter, the effects), so ENV1 there follows the newest voice. ENV1 starts from 0 at each note, so to move start points per note use LFO1 (TRIG with a start phase, or HOLD / S&H).

**ENV2 runs once per track.** Any note opens it, from wherever it is (no click), and it closes when the last held note is released. On pitch, tune, cutoff, level and the WAVE frame it acts every sample; on any other register at the 2 ms block.

## Pages F and G: LFO1 (per voice), LFO2 (per track) (v0.7)

| Knob | Range (default) | Does |
|---|---|---|
| RTn | two decades per multiplier (64: ~1 Hz) | Rate: 0.1-10 Hz at 1X, 3.7 % a step. With MU = SYNC: a note value, 1/64T to 64 bars, straight, dotted and triplet. |
| MUn | 1/64 1/16 1/4 1X 4X 16X 64X 256X SYNC (1X) | Multiplier: the whole span is 0.0016 Hz (a 10-minute cycle) to 2.56 kHz (audio-rate FM and AM). |
| SHn | SIN TRI SQR SAW RMP EXP S&H SMT (SIN) | Shape. SAW falls, RMP rises, EXP falls exponentially, S&H steps, SMT glides between random values. |
| MDn | FREE TRIG HOLD ONE HALF (LFO1: TRIG, LFO2: FREE) | FREE runs on its own (per voice it follows the track's free LFO1, so all voices are in step). TRIG restarts at PH with each note. HOLD takes the free LFO's value at the note and holds it. ONE runs one cycle from PH and holds; HALF half a cycle. |
| PHn | 0-127 (0) | Start phase, 0-357° (TRIG, ONE, HALF). |
| LTn LDn | as ET / ED | Target and depth. |

A synced FREE LFO's phase is the song position: it restarts on PLAY and repeats exactly every pass. LFO1 acts per voice exactly like ENV1, and LFO2 per track like ENV2. Square and saw are not band-limited, so at audio rate they alias, as on most hardware LFOs.

## Page L: the track's shaper (v0.9)

A waveshaper / wavefolder on every track, before its filter or after it.

| Knob | Range (default) | Does |
|---|---|---|
| MOD | TAPE TUBE CLIP FOLD CHEB XOVR RECT BITS POLY (TAPE) | The model (below). |
| INP | +0.0 to +36.0 dB (+11.9) | Input drive. The wet is level-matched to the input (slow, ~50 ms), so INP changes the character, not the loudness. |
| A, B | 0-127, per model | Named by the model (below). |
| BIA | ±63 (0) | DC offset into the shaper: even harmonics and asymmetry. The DC is removed after it. |
| LPF | 200 Hz-4 kHz, OFF (OFF) | A one-pole low-pass before the shaper (the tone): fewer, softer harmonics. |
| POS | PRE, POST (PRE) | PRE: before the track's filter, which then shapes the harmonics. POST: after the filter and DRV, so a low-passed sound folded comes out bright. |
| WET | 0-127 (0) | 0 is off (no CPU). 64: dry and wet both full. 127: wet only. Switching on is silent for 8 ms (the shaper fills), then fades in over 8 ms; off fades out over 8 ms. |

| MOD | A | B |
|---|---|---|
| TAPE | KNE: soft (algebraic) to firm (cubic knee) | DRK: darkening after it, 4 kHz down to 800 Hz |
| TUBE | ASY: the negative side harder and lower | SAG: the bias follows the level, as a tube's supply sags |
| CLIP | KNE: hard to a wide soft knee | SPL: the negative ceiling lower |
| FOLD | SHP: triangle folds to sine folds (West Coast) | FLD: folds ×1.0-8.0 |
| CHEB | HRM: the harmonic, 2.0-7.0, gliding between orders (a sine at full level comes out as that harmonic) | FND: how much fundamental stays |
| XOVR | GAP: crossover distortion, the dead zone around zero | SFT: its softness |
| RECT | FUL: half-wave to full-wave (the octave up) | — |
| BITS | BIT: 16.0 to 1.0 bits | RAT: the rate held down, 16 kHz to 250 Hz |
| POLY | EVN: x², even harmonics (bipolar) | ODD: x³, odd harmonics |

POLY is the formula model, x + EVN·x² + ODD·x³ inside ±1; the device has no way to type a formula. Every knob is a register: it can be locked per step, set by the scenes and aimed at by the modulators (an LFO on INP or FLD sweeps the folds).

## Page J: the track's rebuilt highs (v0.4)

| Knob | Range | Does |
|---|---|---|
| WID | 0-127 (64) | Width of the track's rebuilt highs. Their L and R are the same highs rotated ±0-45°, so 127 is fully decorrelated at full power. In mono, the highs lose at most 3 dB. |
| AIR | 0-127 (64) | Amount of rebuilt highs: 0 is the bare 8 kHz core, 64 is as encoded, 127 is +6 dB. |
| TLT | ±63 | Tilt of the highs, ±6 dB at 4 and 16 kHz. |
| TON | ±63 | Tonality bias: + more copied harmonics, − more noise. |
| SPR | 0-127 | Voice spread. MULTI places voices by pitch (CHR) or per key (KIT), GRAN scatters grains, WAVE alternates voices and splits a detuned pair. TAPE ignores it. Defaults: MULTI 40, GRAN 72, WAVE 48. |

Every knob on every page is a register: it can be locked per step, morphed by the scenes and aimed at by any of the four modulators.

## Page H: the track's multi-effect (v0.5)

One effect, four characters. Where TIM sits decides what it is, and turning it morphs one into the next (the time glides over ~100 ms, so a synced delay pitches like tape when you move it).

| Knob | Range (default) | Does |
|---|---|---|
| TIM | 0 / 0.4-40 ms / 1/64-1B / 1/64T-1/1T (40) | **0:** no delay, the allpass chain alone: a **phaser** (needs DIS). **0.4-10 ms: flanger. 10-40 ms: chorus** (a second voice fades in from 5 ms and out by 60 ms). **Synced:** n/64 of a bar, shown as a fraction (3/16 is a dotted eighth, 1B a bar), then triplets: a **delay**, exact to the clock sample at every tempo, up to 2 s. |
| FBK | ±63 (0) | Feedback, ±0.97. Negative: a hollow flanger. Phaser: resonance. Delay: repeats. |
| DEP | 0-127 (40) | Modulation depth: the delay's sweep (up to 20 ms; at delay times, tape wow), or the phaser's sweep (±2.5 octaves). |
| RAT | 0.02-22 Hz, then 1/64-64B (40) | Modulation rate. The synced values (from 104) follow the song position: a sweep restarts on PLAY and repeats exactly every pass. |
| DIS | OFF, 80 Hz-3.6 kHz (OFF) | Dispersion: 6 allpass stages centred here. With TIM 0 it is the phaser; with a delay it smears the repeats more on each pass. |
| COL | ±63 (0) | Colour in the loop: − a low-pass (3.8 kHz down to 200 Hz), + a high-pass (20 Hz up to 2 kHz). Each repeat gets darker or thinner. |
| PNG | ST, PING (ST) | ST: L into L, R into R, the LFOs 90° apart (a stereo chorus). PING: the sum into L, L's echo into R, R's back into L: L R L R. |
| MIX | 0-127 (0) | 0 is off (no CPU). 64: dry and wet both full (a phaser's deepest notches). 127: wet only. |

## Page I: the track's reverb (v0.5)

| Knob | Range (default) | Does |
|---|---|---|
| SIZ | 0-127 (80) | Room size: the four lines from 25 % to 100 %. |
| DCY | 0.2 s-100 s, FRZ (60) | Decay time (RT60). 127 is **FREEZE**: the tail is held and the input shut. |
| DMP | 0-127 (50) | Damping: the tail's top falls from 3.8 kHz to 400 Hz. |
| PRE | 0-127 ms (0) | Pre-delay. |
| MOD | 0-127 (30) | Line modulation: a slowly moving, chorused tail. |
| DIF | 0-127 (90) | Input diffusion: low is grainy and early, high is smooth. |
| GAT | OFF, 1-64 steps (OFF) | Gated reverb on the clock: the wet closes this many steps after the track's last note. |
| REV | 0-127 (0) | Amount, as MIX on page H. 0 is off. |

Every knob on pages H and I is a register: it can be locked per step, morphed by the scenes and aimed at by the modulators.

## The MASTER page (FX, pressed three times)

| Knob | Range (default) | Does |
|---|---|---|
| GLU | 0-100 (20) | Glue compressor on the whole mix: ratio, threshold and make-up all rise from exactly off. |
| AIR | 0-100 (25) | A shelf above 7 kHz on the side (up to +6 dB), a third of it on the mid. |
| WID | 0-200 % (100) | Level of the side. |
| CEL | 0.0 to −12.0 dB (−0.5) | Ceiling of the 1 ms look-ahead limiter. |
| HF | 0-100 (50) | The global amount of every track's rebuilt highs (50 = as encoded). |
| GR | | Read-only: the glue's gain reduction now. |
| BPM | 60-300 | Tempo (in whole codec blocks per beat). |
| MST | 0-127 (100) | Master level. |

## Faders and wheels

- **Faders 1-4:** track levels (the LEV registers), with soft takeover.
- **Pitch wheel:** WARP, ±2 semitones. It bends the whole clock: tempo, pitch and grid move together, like tape.
- **Mod wheel:** the amount of the last scene touched (PERF).

## Patterns, the song and the kit (v0.8)

- **A kit** is four tracks' sounds, 8 patterns, 8 tables, 8 scenes, a song, the tempo and the master bus. SHIFT + PLAY saves it; it comes back at power-on.
- **A pattern** keeps each track's STP and SPD (the registers show the playing pattern's) and a length of 1-8 bars; AUTO (the default) is its longest track, rounded up to bars. At its end every track starts again at step 1, so a short track's polymeter lives inside the pattern. Trig conditions (1:2, 1ST ...) count passes from when the pattern came in, and keep counting while it repeats.
- **The song** is up to 64 rows of a pattern and its repeats (1-32), looped. Each next pattern comes in on the exact clock sample the playing one ends.
- **Events:** one heap of 10,240 for the whole kit (8 patterns × 4 tracks + 8 tables), so one dense 8-bar part can take what the others leave.
- Not on the panel yet (the next UI pass): picking the kit's slot, saving and loading single sounds, editing the song rows and a pattern's length. The engine and the store already have them.
