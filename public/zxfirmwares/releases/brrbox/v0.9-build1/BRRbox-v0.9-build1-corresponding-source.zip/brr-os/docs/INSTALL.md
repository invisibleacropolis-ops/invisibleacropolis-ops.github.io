# Installing BRR-OS on an SMK-37 Pro, safely

BRR-OS uses the same update machinery as the stock firmware and the Felucca-family ports. The
procedure below follows the SMK-37 port kit (genkigenki/fm1-to-smk37, `docs/02-update-and-recovery.md`).
Read it once before you start.

## 0. What BRR-OS writes, and what it never touches

- **The update path** writes the app area (`0x04000-0x9CFFF`, by the update loader) and the update staging area
  (`0xBB000-0xBFFFF`). The allow-list and its asserts live in `firmware/hal/fm1_flash_map.h` and are unchanged.
- **Presets (v0.8)** go to the data area, `0x9D000-0xBAFFF` (FL_DATA, the region Felucca uses for its store), and
  nowhere else. The user sample area (`0xC2000-0xE9FFF`) is not written: it is kept for samples.
- **Never written:** `0x00000-0x03FFF` (boot), `0xC0000-0xC1FFF` (Bluetooth pairing and **your unit's key and pad
  calibration**), `0xF4000-0xFDFFF` (stock resources) and `0xFF000-0xFFFFF` (key_mac).
- **The data area is only taken over when you say so.** It is the stock firmware's settings area (and Felucca's
  store). If it holds anything that is not BRR-OS's, BRR-OS writes nothing there: the first SHIFT + PLAY says
  `OTHER DATA IN STORE: SHIFT+PLAY ERASES`, and only a second SHIFT + PLAY within 4 s (stopped) erases it. Your
  backup (step 1) holds the original; a blank area is claimed at once.
- **Pins:** BRR-OS uses the SMK board layer as it is (one addition in v0.8: each pad's last velocity is kept, for
  the scenes). It never drives PB1 (charger, 8 s reset) or the matrix rows
  (PA9, PH6, PH8, PH9), and it has no TRS MIDI IN.

## 1. Back up the whole flash first (once, before anything else)

You need [jl-uboot-tool](https://github.com/kagaimiq/jl-uboot-tool) (Python 3, root / elevated shell), a USB cable,
and an installer that can run only the check step and then send one SysEx. Felucca's `tools/fm1_install.py` (copied
here) and SLOOP's installer have the pieces.

1. Close every program that uses the keyboard's MIDI port.
2. Run **only the check step** with `build/brros-smk37.fwsc`: identity query, enter upgrade, serve the reads. The stock
   app accepts the package and resets into the update loader (identity `ota-SMK-37 Pro_9xx`). Nothing in the app area
   has been rewritten yet.
3. Send the loader the UBOOT key `F0 22 24 35 7D F7`. The keyboard comes back as a USB disk named `WL82 UBOOT1.00`.
4. Read the flash twice:
   ```
   python3 jluboottool.py --device <device> --chip wl82 "read 0 0x100000 smk37-dump-1.bin"
   python3 jluboottool.py --device <device> --chip wl82 "read 0 0x100000 smk37-dump-2.bin"
   ```
5. Check the dumps:
   - Both are 1,048,576 B.
   - Both have the same SHA-256.
   - Offset `0xC1224` reads `trimdat`.
   - Note the JEDEC id the tool prints (the tested unit: `0xEB6014`).
6. Keep the dump in two places. The ranges `0xC0000-0xC1FFF` and `0xFF000-0xFFFFF` exist only on your unit.
7. Power-cycle. The keyboard returns in update mode. Continue with step 2 below, or install the stock package to
   stay stock.

## 2. Install

```sh
python3 tools/fm1_install.py build/brros-smk37.fwsc          # the package for the model printed on your unit
```

Or use any Felucca/SLOOP-family web installer that accepts SMK packages. Leave the keyboard alone until it
restarts. If the install is interrupted, power-cycle and run the installer again; the loader resumes.

**First boot:** the screen shows `BRR-OS v0.3`, then the STEP view. Press **SEQ PLAY**: track 1 (TAPE) plays its loop at once; the other three wait for steps.

## 3. Back to stock

Use M-Vave's own updater with the factory package for your model. BRR-OS packages carry the model's identity
(`SMK-37 Pro_9xx`, `SMK-37 Elite_9xx`, `MKE-P37_9xx`), so the updater accepts the return.

If you let BRR-OS take over the data area, it holds BRR-OS presets, not the stock settings. How the stock firmware
treats that is not tested: if it misbehaves, restore `0x9D000-0xBAFFF` from your backup (from UBOOT).

## 4. If something goes wrong

- **To update or recover while BRR-OS is running:** hold **OCTAVE- and OCTAVE+ for 5 s** to enter UBOOT. Hosts can
  also send `F0 22 24 35 7D F7`.
- **Crashes at startup:** two boots in a row that die within 30 s go straight to UBOOT (the boot-loop guard).
- **Crash screen:** a red screen shows the fault vector, PC and return address for 4 s, then the keyboard restarts.
  Write the three numbers down.
- **From UBOOT:** reinstall, restore the dump's app area, or install the stock package.

## 5. Bring-up checklist (first time on a unit)

| Check | Expected |
|---|---|
| Boot | splash, then the STEP view of track 1; no crash screen |
| SEQ PLAY | track 1's loop plays; the play LED is on; the CPU figure (header, right) is shown |
| SEQ / CHORD / PARA / FADER BANK / GLOBE / PATCH | the six views; the button for the current view is lit |
| SHIFT (BT) + top pads 1-4 | select a track (its tab lights) |
| Tap pads in STEP | steps light in the track colour; the pad LEDs match the screen |
| Hold a pad + turn a knob | a lock: the strip value turns blue, a dot appears on the step |
| Hold keys + tap a pad | the chord lands on the step (ROLL shows it) |
| REC, play along, REC | your notes land where you played them; LIST shows the residuals in 1/384 of a beat |
| Page D, K5 (FEL) | 0 % snaps to the grid, 100 % as played |
| Faders 1-4 | track levels move once each fader is moved |
| Wheels | pitch: WARP ±2 st (everything, in sync); mod: the amount of the last scene touched (PERF) |
| PERF: tap a scene pad, hold one, hold + turn | tap latches it in at your velocity (tap again: out); hold is momentary and pressure pushes it; hold + turn writes it |
| SHIFT + PLAY (stopped), the first time | `OTHER DATA IN STORE...` if the data area holds the stock settings; a second press within 4 s erases it, then `KIT 1 SAVED, n KB FREE` |
| Power off and on after a save | the kit comes back (patterns, sounds, scenes, tempo) |
| Page L (SHAP): WET up, turn MOD | the track through each model; INP changes the character, not the level. POS: a low-passed note folded PRE is dark, POST bright. Watch the CPU figure with a shaper on all four tracks |
| SHIFT + PLAY while playing | saves, or says `STOP TO SAVE` when it needs an erase. **Listen**: does a save while playing click? Report it (the page programs keep the interrupts off briefly; not measured yet) |
| CPU (header) | Watch it with all four tracks busy. Try a full MULTI chord and a dense GRAN cloud. If it climbs past ~70 %, the floating-point path is slow on this core: report it |
| Update | `tools/fm1_install.py` finds the keyboard (port "BRR-OS SMK37") and can reinstall |

**The second core (optional, after everything above works on one core):**

1. Install `brros-smk37-cpu2.fwsc` (`tools/build.py --cpu2`). Back on one core any time: install the default package.
2. With all four tracks busy, the header shows `%2` when core 1 renders tracks. Press SHIFT + PATCH to switch it off and
   on, and compare the CPU figure.
3. If it never shows `%2`, or the message says "NOT ANSWERING": this unit runs on one core. That is a known variation
   (some units' core 1 misreads RAM, and the driver stops it after the first bad job). Nothing else changes.
4. The deeper test is felucca-bsp's `hwtest-exp` (`k`, then `p`). `cpu1=` should grow by 1,000 each time, and `late`,
   `rejected` and `faults` should stay 0.

**Two measurements for the feel (report them and they become constants):**

1. **Output latency:** `REC_LAT_FRAMES` in `os_audio.c` is 16 frames, a guess for the DAC pipeline. Record a
   metronome-tight part against the kit. If every note lands consistently early or late in LIST, that offset is the
   correction.
2. **Key timing:** the scan runs at 10 kHz over 16 columns, about 1.6 ms per full pass, and key edges are stamped
   in that interrupt, in samples of the clock (0.125 ms). If recorded residuals look grainier than ~2 ms, report it.
